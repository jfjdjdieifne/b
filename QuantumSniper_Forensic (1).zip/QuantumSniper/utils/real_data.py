"""
Tick loaders.

Binance Vision aggTrades schema (no header):
  0 agg_id, 1 price, 2 qty, 3 first_id, 4 last_id,
  5 timestamp (µs or ms), 6 is_buyer_maker, 7 is_best_match

The May 2026 monthly file is ~1.8GB uncompressed. We NEVER load it whole.
"""
import os
import zipfile
import pandas as pd
import numpy as np


TS_MIN_MS = 1_514_764_800_000  # 2018
TS_MAX_MS = 1_893_456_000_000  # 2030


def _normalize_ticks(df):
    df = df.copy()
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df["size"] = pd.to_numeric(df["size"], errors="coerce")
    df["timestamp"] = pd.to_numeric(df["timestamp"], errors="coerce")
    df = df.dropna()
    df["timestamp"] = df["timestamp"].astype(np.int64)
    df["is_buyer_maker"] = df["is_buyer_maker"].astype(str).str.lower().isin(
        ("true", "1", "t", "yes")
    )

    # µs → ms (Binance Vision 2026 files are microseconds)
    micro = df["timestamp"] > 10_000_000_000_000
    if micro.any():
        df.loc[micro, "timestamp"] = df.loc[micro, "timestamp"] // 1000

    valid = (df["timestamp"] > TS_MIN_MS) & (df["timestamp"] < TS_MAX_MS)
    df = df.loc[valid]
    df = df[(df["price"] > 0) & (df["size"] > 0)]
    return df.reset_index(drop=True)


def load_local_binance_data(csv_path):
    print(f"\n[*] Loading: {csv_path}...")
    try:
        raw = pd.read_csv(csv_path, header=None, low_memory=False)
    except Exception as e:
        print(f"[!] Error: {e}")
        return pd.DataFrame()

    if raw.shape[1] < 7:
        print(f"[!] Unexpected column count: {raw.shape[1]}")
        return pd.DataFrame()

    # Drop a header row if someone saved one
    if str(raw.iloc[0, 1]).replace(".", "", 1).isalpha():
        raw = raw.iloc[1:]

    df = raw.iloc[:, [5, 1, 2, 6]].copy()
    df.columns = ["timestamp", "price", "size", "is_buyer_maker"]
    df = _normalize_ticks(df)

    if not df.empty:
        sample_price = df["price"].median()
        sample_ts = pd.to_datetime(df["timestamp"].iloc[0], unit="ms")
        print(
            f"[*] Loaded {len(df):,} ticks | "
            f"Median Price: ${sample_price:,.2f} | "
            f"Start: {sample_ts.date()}"
        )
    return df


def iter_binance_ticks(path, chunksize=700_000):
    """Yield cleaned tick chunks from a CSV or a .zip containing one CSV."""
    print(f"\n[*] Streaming ticks from: {path}")
    src = path
    inner = None
    if str(path).lower().endswith(".zip"):
        z = zipfile.ZipFile(path)
        names = [n for n in z.namelist() if n.lower().endswith(".csv")]
        if not names:
            raise FileNotFoundError(f"no CSV inside {path}")
        inner = z.open(names[0])
        src = inner

    reader = pd.read_csv(
        src,
        header=None,
        usecols=[1, 2, 5, 6],
        names=["price", "size", "timestamp", "is_buyer_maker"],
        chunksize=chunksize,
        low_memory=True,
    )
    try:
        for i, chunk in enumerate(reader):
            cleaned = _normalize_ticks(chunk)
            if len(cleaned):
                yield cleaned
            if (i + 1) % 5 == 0:
                print(f"    … parsed chunk {i + 1}")
    finally:
        if inner is not None:
            inner.close()


def generate_realistic_tick_data(num_ticks=400_000, seed=42, start_price=67000.0):
    """
    Synthetic tape for unit tests / smoke runs.
    Bounded, scale-invariant injections. Does NOT explode to $800k.
    """
    print(f"\n[*] Generating synthetic tape ({num_ticks:,} ticks, start ${start_price:,.0f})...")
    rng = np.random.default_rng(seed)
    n = int(num_ticks)
    dt = rng.exponential(800.0, n).astype(np.int64)
    timestamps = np.int64(1_717_200_000_000) + np.cumsum(dt)

    log_vol = np.log(0.00007) + np.cumsum(rng.normal(0.0, 0.008, n))
    log_vol = np.clip(log_vol, np.log(0.00003), np.log(0.00025))
    sigma = np.exp(log_vol)
    shocks = rng.normal(0.00000015, 1.0, n) * sigma

    # A few ICT-like raids: 3–6% dump then reclaim. Relative to n, never OOB.
    if n >= 20_000:
        centers = [int(n * f) for f in (0.22, 0.48, 0.67, 0.85)]
        width = max(n // 200, 80)
        reclaim = max(n // 120, 120)
        for c in centers:
            a = max(0, c - width)
            b = min(n, c)
            c2 = min(n, c + reclaim)
            shocks[a:b] -= 0.000035
            shocks[b:c2] += 0.000028

    prices = start_price * np.exp(np.cumsum(shocks))
    # Safety rail so a bad seed cannot produce a 10x fantasy tape.
    prices = np.clip(prices, start_price * 0.55, start_price * 1.70)

    sizes = rng.lognormal(mean=-1.1, sigma=0.85, size=n)
    is_buyer_maker = shocks < 0
    # Flip 25% to keep the tape from being perfectly informative.
    flip = rng.random(n) < 0.25
    is_buyer_maker = np.where(flip, ~is_buyer_maker, is_buyer_maker)

    return pd.DataFrame({
        "timestamp": timestamps,
        "price": prices,
        "size": sizes,
        "is_buyer_maker": is_buyer_maker,
    })
