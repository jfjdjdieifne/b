# QuantumSniper — ICT Quant Engine (forensic build)

Long-only crypto spot engine on **dollar-volume bars**.
Cognitive stack: Perception → Reasoning → Decision → Risk → Simulator.

This build is an audit repair of `QuantumSniper (36).zip`.
The original ZIP **crashed** (`KeyError: 'swept_level'`) and leaked future bars.
This build runs. On Binance BTCUSDT May 2026 it **does not have edge**.

```
Net PnL May 2026:  -$125.11  (-1.25%)
Win rate:          36.4%
Profit factor:     0.41
Trades:            66
```

Treat those numbers as a leak-free baseline, not a product.

## Layout

```
QuantumSniper/
├── main.py
├── models/          perception, reasoning, decision, risk, contract
├── engine/          simulator (fees + square-root impact)
├── data/            dollar-bar builder (Numba, streaming)
├── utils/           Binance Vision loader + bounded synthetic tape
├── tests/           causality + contract + smoke
└── AUDIT.md         full forensic report
```

## Run

```bash
pip install -r requirements.txt

# Reproduce May 2026 from cached dollar bars (no 1.8GB tick file needed)
python3 main.py --cache data/cache_dvbars_2026_05.csv

# Or stream a Binance Vision monthly zip
python3 main.py --csv /path/to/BTCUSDT-aggTrades-2026-05.zip --bars 2000

# Synthetic smoke test (not an edge)
python3 main.py --synthetic --bars 600

python3 tests/test_engine.py
```

Tick files belong in `data/` (CSV or ZIP). They are not shipped.

## Constitution (non-negotiable)

1. Dollar-volume bars. Time is not the clock.
2. Cognitive thresholds (percentiles / regime), no `if RSI > 30`.
3. Asymmetric payoff: cut losers, leave winners alone.
4. Decision at close of `t`, fill at open of `t+1`. Resting stops fill when traded.
5. No look-ahead. No overfitting a single month.

## Honest limitations

- No live broker path.
- No walk-forward.
- No short side.
- Meta-labeling / XGBoost is refused until there are enough clean trades
  across several months. 66 rows is not a dataset.
