import os
import glob
import argparse
import pandas as pd
import numpy as np

from data.data_processor import create_quantum_bars, create_quantum_bars_streaming
from models.alpha_v2 import QuantumBrain
from models.risk import RiskManager
from engine.simulator import QuantumSimulator
from utils.real_data import (
    load_local_binance_data,
    generate_realistic_tick_data,
    iter_binance_ticks,
)


def scan_csv(data_dir="data"):
    os.makedirs(data_dir, exist_ok=True)
    files = []
    for pat in ("*.csv", "*.zip"):
        files.extend(glob.glob(os.path.join(data_dir, pat)))
    # ignore cache / results
    files = [f for f in files if "cache_dvbars" not in os.path.basename(f)]
    return sorted(files)


def resolve_tick_source(cli_path=None):
    if cli_path and os.path.exists(cli_path):
        return cli_path
    local = scan_csv()
    if local:
        return local[0]
    env = os.environ.get("QUANTUM_TICK_PATH")
    if env and os.path.exists(env):
        return env
    fallback = "/tmp/binance/BTCUSDT-aggTrades-2026-05.zip"
    if os.path.exists(fallback):
        return fallback
    return None


def build_bars(source, num_bars_target, cache_path=None):
    if cache_path and os.path.exists(cache_path):
        print(f"[*] Loading cached dollar bars: {cache_path}")
        return pd.read_csv(cache_path, parse_dates=["datetime"])

    if source is None:
        ticks = generate_realistic_tick_data(num_ticks=400_000)
        df_bars = create_quantum_bars(ticks, num_bars_target=min(num_bars_target, 600))
        return df_bars

    size_mb = os.path.getsize(source) / (1024 * 1024)
    print(f"[*] Tick source: {source} ({size_mb:.1f} MB)")

    if size_mb > 40 or source.lower().endswith(".zip"):
        # Monthly Vision dump: horizon is the calendar month, known ex-ante.
        horizon = 31.0 * 24.0
        df_bars = create_quantum_bars_streaming(
            iter_binance_ticks(source),
            num_bars_target=num_bars_target,
            horizon_hours=horizon,
        )
    else:
        ticks = load_local_binance_data(source)
        if ticks.empty:
            return pd.DataFrame()
        df_bars = create_quantum_bars(ticks, num_bars_target=num_bars_target)

    if cache_path and len(df_bars):
        os.makedirs(os.path.dirname(cache_path) or ".", exist_ok=True)
        df_bars.to_csv(cache_path, index=False)
        print(f"[*] Cached dollar bars → {cache_path}")
    return df_bars


def run_pipeline(df_bars):
    if df_bars is None or df_bars.empty:
        return None, None, []

    brain = QuantumBrain()
    df_signals = brain.think(df_bars)

    buy_bars = df_signals[df_signals["buy_signal"] == 1]
    print(f"\n[*] Signals found: {len(buy_bars)}")
    if not buy_bars.empty:
        print("\n── Top Narratives ──")
        top = buy_bars.nlargest(min(5, len(buy_bars)), "conviction")
        for _, r in top.iterrows():
            print(f"  {r['narrative']}")

    risk = RiskManager()
    sim = QuantumSimulator(initial_capital=10_000.0)
    results, logs = sim.run_simulation(df_signals, risk)
    return results, sim, logs


def print_stats(results, sim):
    print("\n" + "=" * 55)
    print("  PERFORMANCE REPORT")
    print("=" * 55)

    if results is None or results.empty:
        print("[!] No trades executed.")
        return

    sells = results[results["type"] == "SELL"].copy()
    if sells.empty:
        print("[!] No closed trades.")
        return

    total_pnl = sim.capital - sim.initial_capital
    wr = (sells["pnl_pct"] > 0).mean() * 100
    wins = sells.loc[sells["pnl_pct"] > 0, "pnl_pct"]
    losses = sells.loc[sells["pnl_pct"] < 0, "pnl_pct"]

    if "pnl_usd" in sells.columns:
        gp = sells.loc[sells["pnl_usd"] > 0, "pnl_usd"].sum()
        gl = abs(sells.loc[sells["pnl_usd"] < 0, "pnl_usd"].sum())
    else:
        gp = gl = 0.0
    pf = gp / gl if gl > 0 else float("inf")

    avg_w = wins.mean() * 100 if len(wins) else 0.0
    avg_l = losses.mean() * 100 if len(losses) else 0.0
    exp = (wr / 100.0 * avg_w) + ((1 - wr / 100.0) * avg_l)

    eq = sells["capital"]
    peak = eq.cummax()
    dd = (eq - peak) / peak.replace(0, np.nan)
    mdd = float(dd.min() * 100) if len(dd) else 0.0

    if "scalp" in sells.columns:
        scalp_trades = sells[sells["scalp"] == True]
        swing_trades = sells[sells["scalp"] == False]
        scalp_wr = (scalp_trades["pnl_pct"] > 0).mean() * 100 if len(scalp_trades) else 0.0
        swing_wr = (swing_trades["pnl_pct"] > 0).mean() * 100 if len(swing_trades) else 0.0
    else:
        scalp_trades = swing_trades = pd.DataFrame()
        scalp_wr = swing_wr = 0.0

    print(f"Final Capital : ${sim.capital:,.2f}")
    print(f"Net PnL       : ${total_pnl:,.2f} ({total_pnl / sim.initial_capital * 100:.2f}%)")
    print(f"Total Trades  : {len(sells)}")
    print(f"Win Rate      : {wr:.1f}%")
    print(f"Profit Factor : {pf:.2f}")
    print(f"Expectancy    : {exp:.2f}%/trade")
    print(f"Max Drawdown  : {mdd:.2f}%")
    print(f"Avg Win       : {avg_w:.2f}%")
    print(f"Avg Loss      : {avg_l:.2f}%")
    print(f"Avg Bars Held : {sells['bars_held'].mean():.1f}")
    print("\n── Mode Breakdown ──")
    print(f"Scalp Trades  : {len(scalp_trades)} | WR: {scalp_wr:.1f}%")
    print(f"Swing Trades  : {len(swing_trades)} | WR: {swing_wr:.1f}%")

    with open("trade_log.txt", "w", encoding="utf-8") as f:
        for log in sim.detailed_log:
            f.write(log + "\n")
    results.to_csv("quantum_results.csv", index=False)
    print("\n[*] Full log → trade_log.txt")
    print("[*] Results   → quantum_results.csv")


def main():
    parser = argparse.ArgumentParser(description="QuantumSniper ICT-Quant Engine")
    parser.add_argument("--csv", default=None, help="Path to aggTrades CSV or ZIP")
    parser.add_argument("--bars", type=int, default=2000, help="Target dollar-volume bars")
    parser.add_argument("--synthetic", action="store_true", help="Force synthetic tape")
    parser.add_argument("--cache", default="data/cache_dvbars.csv", help="Bar cache path")
    args = parser.parse_args()

    print("\n" + "=" * 55)
    print("  QUANTUM ICT ENGINE — FORENSIC BUILD")
    print("=" * 55)

    if args.synthetic:
        source = None
        print("[!] SYNTHETIC tape. Results are a smoke test, not an edge.")
    else:
        source = resolve_tick_source(args.csv)
        if source is None:
            print("[!] No tick file found. Falling back to synthetic smoke test.")
            print("    Place a Binance aggTrades CSV/ZIP in data/ or pass --csv.")

    df_bars = build_bars(source, num_bars_target=args.bars, cache_path=args.cache)
    if df_bars is None or df_bars.empty:
        print("[!] No bars. Abort.")
        return

    results, sim, _ = run_pipeline(df_bars)
    if sim:
        print_stats(results, sim)


if __name__ == "__main__":
    main()
