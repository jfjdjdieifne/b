"""Forensic tests: contract, causality, bounded synthetic, end-to-end smoke."""
import os
import sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from utils.real_data import generate_realistic_tick_data
from data.data_processor import create_quantum_bars
from models.perception import MarketPerception
from models.alpha_v2 import QuantumBrain
from models.risk import RiskManager
from models.contract import PERCEPTION_REQUIRED, DECISION_REQUIRED
from engine.simulator import QuantumSimulator


def test_synthetic_is_bounded():
    ticks = generate_realistic_tick_data(num_ticks=30_000, seed=7, start_price=67000)
    assert ticks["price"].min() > 67000 * 0.5
    assert ticks["price"].max() < 67000 * 1.8
    assert len(ticks) == 30_000


def test_synthetic_small_n_does_not_crash():
    ticks = generate_realistic_tick_data(num_ticks=5_000, seed=1)
    assert len(ticks) == 5_000


def test_swing_published_only_after_confirmation():
    ticks = generate_realistic_tick_data(num_ticks=40_000, seed=3)
    bars = create_quantum_bars(ticks, num_bars_target=180)
    perc = MarketPerception()
    bars["atr"] = (bars["high"] - bars["low"]).rolling(14, min_periods=1).mean()
    ssl_s, bsl_s, ssl_q, bsl_q, ssl_raw, bsl_raw = perc.find_liquidity_levels(bars)
    lo = bars["low"].values
    hi = bars["high"].values
    max_sw = 8
    for i, lvl in enumerate(ssl_raw):
        if np.isnan(lvl):
            continue
        window = lo[max(0, i - max_sw): i + 1]
        assert np.any(np.isclose(window, lvl)), f"SSL at {i} not in past window"
    for i, lvl in enumerate(bsl_raw):
        if np.isnan(lvl):
            continue
        window = hi[max(0, i - max_sw): i + 1]
        assert np.any(np.isclose(window, lvl)), f"BSL at {i} not in past window"


def test_htf_ignores_future_closes():
    ticks = generate_realistic_tick_data(num_ticks=40_000, seed=4)
    bars = create_quantum_bars(ticks, num_bars_target=180)
    perc = MarketPerception()
    htf_a = perc._causal_htf_bull(bars["close"], compression=5).values.copy()
    poisoned = bars["close"].copy()
    mid = len(poisoned) // 2
    poisoned.iloc[mid + 1:] = 1e12
    htf_b = perc._causal_htf_bull(poisoned, compression=5).values
    assert np.allclose(htf_a[: mid + 1], htf_b[: mid + 1]), "HTF leaked future closes"


def test_pipeline_contract_and_execution():
    ticks = generate_realistic_tick_data(num_ticks=50_000, seed=5)
    bars = create_quantum_bars(ticks, num_bars_target=200)
    assert len(bars) > 50
    df = QuantumBrain().think(bars)
    for c in DECISION_REQUIRED:
        assert c in df.columns, c
    risk = RiskManager()
    sim = QuantumSimulator(initial_capital=10_000.0)
    results, logs = sim.run_simulation(df, risk)
    # Must not crash; 0 trades is a legal outcome.
    assert sim.position == 0.0  # leftover must be force-closed
    assert isinstance(logs, list)


def test_hard_stop_uses_bar_low_not_close():
    rm = RiskManager()
    # close is above stop, low pierces it
    exit_flag, reason, px = rm.evaluate_position(
        entry_price=100.0,
        structural_stop_price=98.0,
        bars_held=1,
        current_price=101.0,
        current_low=96.0,
        current_atr=1.0,
        highest_price_since_entry=101.0,
        is_scalp=False,
        max_hold_bars=18,
    )
    assert exit_flag and reason == "Hard Stop"
    exit_flag2, reason2, _ = rm.evaluate_position(
        entry_price=100.0,
        structural_stop_price=90.0,
        bars_held=1,
        current_price=101.0,
        current_low=99.5,
        current_atr=1.0,
        highest_price_since_entry=101.0,
    )
    assert not exit_flag2


if __name__ == "__main__":
    tests = [
        test_synthetic_is_bounded,
        test_synthetic_small_n_does_not_crash,
        test_swing_published_only_after_confirmation,
        test_htf_ignores_future_closes,
        test_pipeline_contract_and_execution,
        test_hard_stop_uses_bar_low_not_close,
    ]
    failed = 0
    for fn in tests:
        try:
            fn()
            print(f"PASS  {fn.__name__}")
        except Exception as e:
            failed += 1
            print(f"FAIL  {fn.__name__}: {type(e).__name__}: {e}")
            import traceback
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    sys.exit(1 if failed else 0)
