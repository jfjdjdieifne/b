# Handover — QuantumSniper forensic build (2026-08-12)

This file replaces the previous handover, which described an engine that
did not exist (`alpha.py`, `VPIN < 0.40`, prices of hundreds of millions).

## What you are receiving

A runnable, leak-checked, long-only ICT stack on dollar-volume bars.

```
Perception  → causal swings / sweep / BOS / OB / OFI / VPIN / regime
Reasoning   → one narrative per sweep, conviction in [0, 100]
Decision    → regime-conditional threshold, one-setup-one-shot
Risk        → resting hard stop on bar low, time stop, BE, trail
Simulator   → t+1 open fills, 10 bps taker, square-root impact
```

## What the previous ZIP actually was

It crashed on `KeyError: 'swept_level'`. Perception and Reasoning spoke
different column languages. Swing confirmation and HTF leaked the future.
The synthetic tape exploded to $800k. See `AUDIT.md`.

## May 2026 (Binance Vision BTCUSDT aggTrades)

21,080,265 ticks → 2,512 dollar bars ($13.2M each) → 66 trades.

| | |
|---|---|
| Net | −1.25% |
| WR | 36.4% |
| PF | 0.41 |
| Avg win / avg loss | +0.40% / −0.57% |

The engine is honest. It is not profitable. Do not dress that up.

## Rules for the next agent

1. Do not add XGBoost / meta-labeling on 66 trades. Refuse it.
2. Do not retune trail / threshold / ATR multiples on May 2026 alone.
   If you change a parameter, pre-declare it and test April + June + July.
3. Do not remove fees or slippage.
4. Do not reintroduce time bars.
5. Keep `models/contract.py` as the only column vocabulary. If you rename
   a column, you update the contract and the tests in the same commit.
6. A swing published at the unconfirmed pivot is a look-ahead bug. HTF
   `groupby().transform('last')` is a look-ahead bug. Both already happened.

## How to run

```bash
python3 tests/test_engine.py
python3 main.py --cache data/cache_dvbars_2026_05.csv
```
