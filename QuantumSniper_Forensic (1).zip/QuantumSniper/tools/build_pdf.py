#!/usr/bin/env python3
"""Engineering PDF: audit summary + every source line."""
import os
from datetime import date

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor, white, black
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Preformatted, PageBreak,
    Table, TableStyle, ListFlowable, ListItem, KeepTogether,
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "QuantumSniper_Full_Code.pdf")

pdfmetrics.registerFont(TTFont("DejaVu", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("DejaVuBold", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DejaVuMono", "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"))

NAVY = HexColor("#0B1F33")
RED = HexColor("#8B1E1E")
GREEN = HexColor("#1E4D2B")
AMBER = HexColor("#7A5B12")
INK = HexColor("#1A1A1A")
RULE = HexColor("#C5C9CE")
CODE_BG = HexColor("#F4F1EA")

SOURCE_FILES = [
    "main.py",
    "models/contract.py",
    "models/perception.py",
    "models/reasoning.py",
    "models/decision.py",
    "models/risk.py",
    "models/alpha_v2.py",
    "engine/simulator.py",
    "data/data_processor.py",
    "utils/real_data.py",
    "tests/test_engine.py",
]


def styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle(
        "CoverTitle", fontName="DejaVuBold", fontSize=22, leading=28,
        textColor=white, alignment=0, spaceAfter=6,
    ))
    ss.add(ParagraphStyle(
        "CoverSub", fontName="DejaVu", fontSize=11, leading=15,
        textColor=HexColor("#D7DEE7"), spaceAfter=4,
    ))
    ss.add(ParagraphStyle(
        "H1c", fontName="DejaVuBold", fontSize=14, leading=18,
        textColor=NAVY, spaceBefore=14, spaceAfter=8,
    ))
    ss.add(ParagraphStyle(
        "H2c", fontName="DejaVuBold", fontSize=11.5, leading=15,
        textColor=NAVY, spaceBefore=10, spaceAfter=5,
    ))
    ss.add(ParagraphStyle(
        "Bodyc", fontName="DejaVu", fontSize=9.2, leading=13.2,
        textColor=INK, spaceAfter=6,
    ))
    ss.add(ParagraphStyle(
        "Bulletc", fontName="DejaVu", fontSize=9.2, leading=13.0,
        textColor=INK, leftIndent=12, spaceAfter=2,
    ))
    ss.add(ParagraphStyle(
        "Warn", fontName="DejaVuBold", fontSize=9.5, leading=13,
        textColor=RED, spaceBefore=4, spaceAfter=8,
    ))
    ss.add(ParagraphStyle(
        "CodeHead", fontName="DejaVuBold", fontSize=10, leading=13,
        textColor=NAVY, spaceBefore=12, spaceAfter=4,
    ))
    ss.add(ParagraphStyle(
        "CodeBody", fontName="DejaVuMono", fontSize=6.4, leading=8.2,
        textColor=HexColor("#222"), backColor=CODE_BG,
        leftIndent=2, rightIndent=2, spaceAfter=8,
    ))
    ss.add(ParagraphStyle(
        "Cell", fontName="DejaVu", fontSize=8, leading=11, textColor=INK,
    ))
    ss.add(ParagraphStyle(
        "CellB", fontName="DejaVuBold", fontSize=8, leading=11, textColor=INK,
    ))
    ss.add(ParagraphStyle(
        "CellH", fontName="DejaVuBold", fontSize=8, leading=11, textColor=white,
    ))
    ss.add(ParagraphStyle(
        "Footer", fontName="DejaVu", fontSize=7.5, textColor=HexColor("#666"),
    ))
    return ss


def header_footer(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0, A4[1] - 12 * mm, A4[0], 12 * mm, fill=1, stroke=0)
    canvas.setFillColor(white)
    canvas.setFont("DejaVu", 8)
    canvas.drawString(16 * mm, A4[1] - 8 * mm, "QuantumSniper  ·  Forensic Engineering Binder")
    canvas.drawRightString(A4[0] - 16 * mm, A4[1] - 8 * mm, "CONFIDENTIAL")
    canvas.setFillColor(RULE)
    canvas.rect(0, 0, A4[0], 10 * mm, fill=1, stroke=0)
    canvas.setFillColor(HexColor("#333"))
    canvas.setFont("DejaVu", 8)
    canvas.drawString(16 * mm, 4 * mm, "Decision at t  ·  Fill at t+1  ·  Zero look-ahead")
    canvas.drawRightString(A4[0] - 16 * mm, 4 * mm, f"{doc.page}")
    canvas.restoreState()


def cover_footer(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(NAVY)
    canvas.rect(0, 0, A4[0], A4[1], fill=1, stroke=0)
    canvas.setFillColor(HexColor("#C9A227"))
    canvas.rect(0, A4[1] - 28 * mm, A4[0], 6, fill=1, stroke=0)
    canvas.setFillColor(white)
    canvas.setFont("DejaVuBold", 11)
    canvas.drawString(22 * mm, A4[1] - 24 * mm, "QUANT ENGINE  ·  CLOSED ROOM")
    canvas.restoreState()


def kv_table(rows, s):
    data = [[Paragraph(a, s["CellB"]), Paragraph(b, s["Cell"])] for a, b in rows]
    t = Table(data, colWidths=[55 * mm, 120 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), HexColor("#EEF2F6")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("GRID", (0, 0), (-1, -1), 0.3, RULE),
    ]))
    return t


def metric_table(header, rows, s, col_w):
    head = [Paragraph(h, s["CellB"]) for h in header]
    body = [[Paragraph(str(c), s["Cell"]) for c in row] for row in rows]
    t = Table([head] + body, colWidths=col_w)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), white),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("GRID", (0, 0), (-1, -1), 0.3, RULE),
        ("FONTNAME", (0, 0), (-1, 0), "DejaVuBold"),
    ]
    for i in range(1, len(body) + 1):
        if i % 2 == 0:
            style.append(("BACKGROUND", (0, i), (-1, i), HexColor("#F7F5F0")))
    t.setStyle(TableStyle(style))
    # header paragraphs need white text - use a dedicated style
    return t


def build():
    s = styles()
    doc = SimpleDocTemplate(
        OUT, pagesize=A4,
        leftMargin=16 * mm, rightMargin=16 * mm,
        topMargin=18 * mm, bottomMargin=16 * mm,
        title="QuantumSniper Forensic Binder",
        author="Lead Quant / Auditor",
    )
    story = []

    # ----- COVER (drawn by cover_footer; we overlay text with a spacer trick)
    # We'll put cover content as flowables on a navy page via onFirstPage.
    story.append(Spacer(1, 55 * mm))
    story.append(Paragraph("QUANTUMSNIPER", s["CoverTitle"]))
    story.append(Paragraph("Forensic Engineering Binder  ·  Full Source", s["CoverTitle"]))
    story.append(Spacer(1, 6 * mm))
    story.append(Paragraph(
        "The ZIP you sent did not run. This binder is the repaired engine, "
        "the leak audit, and every line of source as it exists on disk after "
        "the 2026-08-12 forensic pass.",
        s["CoverSub"],
    ))
    story.append(Spacer(1, 8 * mm))
    story.append(Paragraph(f"Date  {date.today().isoformat()}", s["CoverSub"]))
    story.append(Paragraph("Market  BTCUSDT spot  ·  Binance Vision May 2026", s["CoverSub"]))
    story.append(Paragraph("Status  RUNNABLE  ·  NO EDGE  ·  ML REFUSED", s["CoverSub"]))
    story.append(PageBreak())

    # ----- VERDICT
    story.append(Paragraph("0.  Auditor's verdict", s["H1c"]))
    story.append(Paragraph(
        "Original artifact <b>QuantumSniper (36).zip</b> crashed on "
        "<font face='DejaVuMono'>KeyError: 'swept_level'</font>. "
        "Perception wrote one vocabulary. Reasoning and Decision read another. "
        "Swing confirmation and the HTF construction leaked future bars. "
        "The synthetic tape exploded from ~$1.7k to ~$808k. "
        "Stale CSVs in the ZIP quoted prices of four hundred million dollars.",
        s["Bodyc"],
    ))
    story.append(Paragraph(
        "After the repair the engine runs, is contract-checked, and is leak-tested. "
        "On 21,080,265 real May 2026 ticks it produced 66 trades, 36.4% win rate, "
        "profit factor <b>0.41</b>, net <b>−1.25%</b>. "
        "That is a leak-free baseline, not a product. I will not dress it up.",
        s["Bodyc"],
    ))
    story.append(Paragraph(
        "XGBoost / meta-labeling is REFUSED on 66 observations. "
        "That is not a smarter Reasoning layer. That is a May-2026 memorizer.",
        s["Warn"],
    ))

    story.append(Paragraph("1.  What was broken in the ZIP", s["H1c"]))
    story.append(Paragraph("1.1  Column-contract breach (fatal)", s["H2c"]))
    story.append(Paragraph(
        "The previous agent patched a comment in reasoning.py claiming the "
        "correct column was <font face='DejaVuMono'>regime_list</font>, "
        "then never created that column in Perception. Two generations of the "
        "schema were glued together.",
        s["Bodyc"],
    ))
    story.append(metric_table(
        ["Reasoning / Decision expected", "Perception actually wrote"],
        [
            ["swept_level", "swept_ssl"],
            ["trend", "trend_score"],
            ["regime_list", "MISSING"],
            ["htf_bull", "htf_trend"],
            ["in_ob", "in_ob_zone"],
            ["pb_quiet", "pullback_vol_low"],
        ],
        s, [85 * mm, 90 * mm],
    ))
    story.append(Spacer(1, 3 * mm))

    story.append(Paragraph("1.2  Look-ahead (constitution rule 4)", s["H2c"]))
    story.append(Paragraph(
        "• Fractal swings used <font face='DejaVuMono'>lo[i+1 : i+sw+1]</font> "
        "and published the level at index i, then ffilled. Bars i .. i+sw−1 "
        "knew an unconfirmed pivot.",
        s["Bulletc"],
    ))
    story.append(Paragraph(
        "• HTF used <font face='DejaVuMono'>groupby(i//5).transform('last')</font> "
        "plus <font face='DejaVuMono'>np.repeat</font>. Every member of a group "
        "received the group's last close. Textbook leakage.",
        s["Bulletc"],
    ))
    story.append(Paragraph(
        "• Dollar-bar size was <font face='DejaVuMono'>sum(price*size)/600</font> "
        "over the full sample, so early bar boundaries depended on future volume.",
        s["Bulletc"],
    ))

    story.append(Paragraph("1.3  Dead SCALP path", s["H2c"]))
    story.append(Paragraph(
        "trend ∈ {0.0, 0.4, 1.0}. Regime 'down' is exactly trend = 0.0. "
        "Decision killed every bar with trend &lt; 0.12. Scalp mode was unreachable. "
        "Theatre, not architecture.",
        s["Bodyc"],
    ))

    story.append(Paragraph("1.4  Other defects", s["H2c"]))
    for line in [
        "Synthetic generator crashed for n < 520,000 and, at n = 1e6, produced a 480× fantasy tape.",
        "Hard stop evaluated on close only — a wick through the stop was forgiven.",
        "Open position at end of sample was orphaned.",
        "Profit factor assumed every trade risked 10% of initial capital.",
        "Handover referenced alpha.py, VPIN < 0.40, detailed_trade_logs.txt — none exist.",
        "EQH printed, never implemented. Session clock computed, never consumed, and it violates timelessness.",
        "No tests. No __init__.py. No tick data in the ZIP that claimed a May 2026 backtest.",
    ]:
        story.append(Paragraph("• " + line, s["Bulletc"]))

    story.append(Paragraph("2.  What was repaired (engineering, not May-fitting)", s["H1c"]))
    for line in [
        "Single column contract in models/contract.py. Each layer asserts on exit.",
        "Swings published at confirm = pivot + window only.",
        "Causal HTF: a group is visible only after it closes.",
        "Bar size from a warmup rate × a known horizon (calendar month for Vision files).",
        "regime_list is actually produced. Down-regime pays a higher threshold instead of a ban.",
        "One setup, one bullet (setup_sweep_idx). Re-firing the same sweep is not alpha.",
        "No chase: displacement ≥ 0.08 and pullback ≥ 0.30 or there is no trade.",
        "Resting hard stop fills when the bar low trades through the level.",
        "Other exits: decide on close t, fill next open. Residual position force-closed.",
        "Bounded synthetic tape. Streaming Vision reader for a 1.8 GB monthly file on a 2 GB box.",
        "Causality + contract + smoke tests.",
    ]:
        story.append(Paragraph("• " + line, s["Bulletc"]))
    story.append(Paragraph(
        "Trail / ATR multiples were NOT retuned after seeing May. "
        "That would have been overfitting a single month.",
        s["Warn"],
    ))

    story.append(Paragraph("3.  May 2026 — real tape", s["H1c"]))
    story.append(Paragraph(
        "Source: Binance Vision BTCUSDT-aggTrades-2026-05. "
        "21,080,265 ticks. Price $72,600 – $82,800. "
        "2,512 dollar-volume bars at $13,230,474 each. "
        "Median bar range 0.23% ($184).",
        s["Bodyc"],
    ))
    story.append(kv_table([
        ["Final capital", "$9,874.89"],
        ["Net PnL", "−$125.11  (−1.25%)"],
        ["Trades", "66"],
        ["Win rate", "36.4%  (constitution target was ~40%)"],
        ["Profit factor", "0.41"],
        ["Expectancy", "−0.22% / trade"],
        ["Max drawdown", "−1.20%"],
        ["Avg win / avg loss", "+0.40%  /  −0.57%   ← payoff inverted"],
        ["Avg bars held", "8.8   (winners 13.6 · losers 6.0)"],
    ], s))
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Exit autopsy", s["H2c"]))
    story.append(metric_table(
        ["Reason", "N", "WR", "Avg", "USD"],
        [
            ["Hard Stop", "33", "0%", "−0.62%", "−180"],
            ["Swing: Trail", "25", "96%", "+0.39%", "+85"],
            ["Swing: BE", "4", "0%", "−0.30%", "−11"],
            ["Time Stop: Faded", "3", "0%", "−0.41%", "−10"],
            ["Time Stop: No Move", "1", "0%", "−0.94%", "−9"],
        ],
        s, [50 * mm, 22 * mm, 25 * mm, 35 * mm, 30 * mm],
    ))
    story.append(Spacer(1, 3 * mm))
    story.append(Paragraph(
        "Shape of asymmetry is correct (losers die faster). Magnitude is inverted. "
        "Median ATR is 0.23%. Trail arms at 2.5×ATR ≈ 0.58% and gives back 1.2×ATR. "
        "After 20 bps round-trip the win is crumbs. The hard stop sits ~1×ATR under "
        "structure (0.5–1.1%). Constitution says let winners run with no ceiling. "
        "This implementation slaughters them at the first wiggle. "
        "I did not widen the trail after seeing this table.",
        s["Bodyc"],
    ))

    story.append(Paragraph("4.  What this engine is not", s["H1c"]))
    for line in [
        "Not a hedge fund. PF 0.41 after real fees is a lab notebook, not a product.",
        "Not live-ready. No broker, no session state, no reconnect, no inventory clock.",
        "Not ready for meta-labeling. 24 winning rows is not a training set.",
        "Not evidence of robustness. One month, one symbol, one resolution.",
    ]:
        story.append(Paragraph("• " + line, s["Bulletc"]))

    story.append(Paragraph("5.  Next steps I will accept", s["H1c"]))
    story.append(Paragraph(
        "1. Freeze every parameter. Stream April, June, July 2026 from the same Vision source. "
        "Report PF / WR / payoff ratio on each month separately. No peeking, no retune.",
        s["Bodyc"],
    ))
    story.append(Paragraph(
        "2. Only after that: a pre-declared trail experiment (e.g. arm at 4×ATR, "
        "giveback 2×ATR) run on the held-out months, never on May first.",
        s["Bodyc"],
    ))
    story.append(Paragraph(
        "3. A real stand-aside: if causal HTF is bearish, emit 0 trades. "
        "The constitution prefers silence to buying knives in an 82k→73k tape.",
        s["Bodyc"],
    ))
    story.append(Paragraph(
        "4. Live path only after the above is green on more than one month. Not before.",
        s["Bodyc"],
    ))

    story.append(Paragraph("6.  Constitution (still binding)", s["H1c"]))
    for line in [
        "Timelessness — dollar-volume bars. Wall-clock is not a feature.",
        "Cognitive over hardcoded — percentiles and regime, not RSI > 30.",
        "Asymmetric payoff — 40% WR is acceptable; losers die; winners are not capped.",
        "Zero look-ahead — decide on close of t, fill open of t+1. Resting stops fill when traded.",
        "No overfitting — 0 trades is a legal, honourable result.",
    ]:
        story.append(Paragraph("• " + line, s["Bulletc"]))

    story.append(PageBreak())
    story.append(Paragraph("7.  Full source listing", s["H1c"]))
    story.append(Paragraph(
        "Every production file as written after the forensic pass. "
        "This is the engineering record, not a marketing brochure.",
        s["Bodyc"],
    ))

    for rel in SOURCE_FILES:
        path = os.path.join(ROOT, rel)
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()
        # Preformatted does not wrap; long lines get clipped. Break very long lines.
        lines = []
        for line in src.splitlines():
            if len(line) > 118:
                while len(line) > 118:
                    lines.append(line[:118])
                    line = "        " + line[118:]
                lines.append(line)
            else:
                lines.append(line)
        block = "\n".join(lines)
        story.append(Paragraph(rel, s["CodeHead"]))
        story.append(Preformatted(block, s["CodeBody"]))

    def first_page(canvas, doc_):
        cover_footer(canvas, doc_)

    def later(canvas, doc_):
        header_footer(canvas, doc_)

    doc.build(story, onFirstPage=first_page, onLaterPages=later)
    print(f"wrote {OUT}  ({os.path.getsize(OUT):,} bytes)")


if __name__ == "__main__":
    build()
