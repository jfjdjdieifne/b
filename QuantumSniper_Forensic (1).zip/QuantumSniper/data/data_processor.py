"""
Dollar-volume bar builder.

Bar size is estimated from a WARMUP window of ticks (first ~10% or first
N ticks), never from the full sample's future dollar volume. The Numba
kernel is stateful so a 1.8GB monthly aggTrade file can be streamed in
chunks on a 2GB machine.
"""
import numpy as np
import pandas as pd
from numba import njit


@njit
def generate_dollar_volume_bars(
    timestamps,
    prices,
    sizes,
    is_sell_initiator,
    target_dollar_volume,
    current_dv,
    current_bv,
    current_sv,
    current_high,
    current_low,
    current_open,
    is_new_bar,
):
    n = len(prices)
    out_ts = np.zeros(n, dtype=np.int64)
    out_open = np.zeros(n, dtype=np.float64)
    out_high = np.zeros(n, dtype=np.float64)
    out_low = np.zeros(n, dtype=np.float64)
    out_close = np.zeros(n, dtype=np.float64)
    out_bv = np.zeros(n, dtype=np.float64)
    out_sv = np.zeros(n, dtype=np.float64)

    bar_idx = 0

    for i in range(n):
        price = prices[i]
        size = sizes[i]
        dollar_sz = price * size
        is_sell = is_sell_initiator[i]

        if is_new_bar:
            current_open = price
            current_high = price
            current_low = price
            is_new_bar = False

        if price > current_high:
            current_high = price
        if price < current_low:
            current_low = price

        vol_needed = target_dollar_volume - current_dv

        if dollar_sz < vol_needed:
            current_dv += dollar_sz
            if is_sell:
                current_sv += dollar_sz
            else:
                current_bv += dollar_sz
        else:
            fill = vol_needed
            rem = dollar_sz - vol_needed
            if is_sell:
                current_sv += fill
            else:
                current_bv += fill

            out_ts[bar_idx] = timestamps[i]
            out_open[bar_idx] = current_open
            out_high[bar_idx] = current_high
            out_low[bar_idx] = current_low
            out_close[bar_idx] = price
            out_bv[bar_idx] = current_bv
            out_sv[bar_idx] = current_sv
            bar_idx += 1

            while rem >= target_dollar_volume:
                out_ts[bar_idx] = timestamps[i]
                out_open[bar_idx] = price
                out_high[bar_idx] = price
                out_low[bar_idx] = price
                out_close[bar_idx] = price
                if is_sell:
                    out_bv[bar_idx] = 0.0
                    out_sv[bar_idx] = target_dollar_volume
                else:
                    out_bv[bar_idx] = target_dollar_volume
                    out_sv[bar_idx] = 0.0
                bar_idx += 1
                rem -= target_dollar_volume

            current_dv = rem
            current_bv = rem if not is_sell else 0.0
            current_sv = rem if is_sell else 0.0
            current_open = price
            current_high = price
            current_low = price
            is_new_bar = current_dv == 0.0

    state = (
        current_dv,
        current_bv,
        current_sv,
        current_high,
        current_low,
        current_open,
        is_new_bar,
    )
    return (
        out_ts[:bar_idx],
        out_open[:bar_idx],
        out_high[:bar_idx],
        out_low[:bar_idx],
        out_close[:bar_idx],
        out_bv[:bar_idx],
        out_sv[:bar_idx],
        state,
    )


def _empty_state():
    return (0.0, 0.0, 0.0, -1e18, 1e18, 0.0, True)


def _bars_frame(t, o, h, l, c, bv, sv):
    df = pd.DataFrame({
        "timestamp": t,
        "open": o,
        "high": h,
        "low": l,
        "close": c,
        "buy_vol": bv,
        "sell_vol": sv,
        "total_vol": bv + sv,
    })
    if len(df) == 0:
        return df
    df["ofi_ratio"] = (df["buy_vol"] - df["sell_vol"]) / (df["total_vol"] + 1e-9)
    df["datetime"] = pd.to_datetime(df["timestamp"], unit="ms", errors="coerce")
    return df


def estimate_target_dv(prices, sizes, timestamps, num_bars_target, horizon_hours=None):
    """
    Causal bar size: project from the warmup window's dollar-volume RATE
    onto a known horizon. Horizon defaults to the span of THIS batch
    (correct for an in-memory completed sample). Pass horizon_hours
    explicitly when streaming a file whose end you already know
    (e.g. 31*24 for a monthly Vision dump).
    """
    n = len(prices)
    if n == 0:
        return 1_000_000.0
    warmup = min(n, max(n // 10, 20_000)) if n >= 20_000 else max(n // 5, 1)
    dv = float(np.sum(prices[:warmup] * sizes[:warmup]))
    t0 = int(timestamps[0])
    t1 = int(timestamps[warmup - 1])
    hours = max((t1 - t0) / 3_600_000.0, 0.01)
    if horizon_hours is None:
        horizon_hours = max((int(timestamps[-1]) - t0) / 3_600_000.0, hours)
    target = (dv / hours) * float(horizon_hours) / max(num_bars_target, 1)
    return max(target, 1_000.0)


def create_quantum_bars(tick_df, num_bars_target=600, target_dv=None, horizon_hours=None):
    ts = tick_df["timestamp"].values.astype(np.int64)
    prices = tick_df["price"].values.astype(np.float64)
    sizes = tick_df["size"].values.astype(np.float64)
    is_sell = tick_df["is_buyer_maker"].values.astype(np.bool_)

    if target_dv is None:
        target_dv = estimate_target_dv(
            prices, sizes, ts, num_bars_target, horizon_hours=horizon_hours
        )
    print(f"[*] Dollar Bar Target: ${target_dv:,.0f} per bar (aim ~{num_bars_target})")

    t, o, h, l, c, bv, sv, _ = generate_dollar_volume_bars(
        ts, prices, sizes, is_sell, float(target_dv), *_empty_state()
    )
    df = _bars_frame(t, o, h, l, c, bv, sv)
    if len(df):
        print(
            f"[*] Created {len(df)} Dollar-Volume Bars | "
            f"Price range: ${df['close'].min():,.0f} - ${df['close'].max():,.0f}"
        )
    else:
        print("[!] No bars produced.")
    return df


def create_quantum_bars_streaming(
    tick_iter, num_bars_target=2000, target_dv=None, horizon_hours=None
):
    """
    tick_iter yields DataFrames with columns timestamp, price, size, is_buyer_maker.
    First chunk estimates target_dv if not provided. Incomplete last bar is dropped.
    """
    state = _empty_state()
    chunks_out = []
    resolved_target = target_dv
    total_ticks = 0

    for i, chunk in enumerate(tick_iter):
        if chunk is None or len(chunk) == 0:
            continue
        ts = chunk["timestamp"].values.astype(np.int64)
        prices = chunk["price"].values.astype(np.float64)
        sizes = chunk["size"].values.astype(np.float64)
        is_sell = chunk["is_buyer_maker"].values.astype(np.bool_)
        total_ticks += len(chunk)

        if resolved_target is None:
            resolved_target = estimate_target_dv(
                prices, sizes, ts, num_bars_target, horizon_hours=horizon_hours
            )
            print(
                f"[*] Dollar Bar Target (warmup): ${resolved_target:,.0f} "
                f"(aim ~{num_bars_target} bars)"
            )

        t, o, h, l, c, bv, sv, state = generate_dollar_volume_bars(
            ts, prices, sizes, is_sell, float(resolved_target), *state
        )
        if len(t):
            chunks_out.append(_bars_frame(t, o, h, l, c, bv, sv))
        if (i + 1) % 5 == 0:
            done = sum(len(x) for x in chunks_out)
            print(f"    … streamed {total_ticks:,} ticks → {done} bars")

    if not chunks_out:
        print("[!] No bars produced from stream.")
        return pd.DataFrame()

    df = pd.concat(chunks_out, ignore_index=True)
    print(
        f"[*] Created {len(df)} Dollar-Volume Bars from {total_ticks:,} ticks | "
        f"Price range: ${df['close'].min():,.0f} - ${df['close'].max():,.0f}"
    )
    return df
