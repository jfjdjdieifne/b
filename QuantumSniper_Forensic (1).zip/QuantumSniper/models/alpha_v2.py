from models.perception import MarketPerception
from models.reasoning import MarketReasoning
from models.decision import DecisionEngine
from models.contract import (
    PERCEPTION_REQUIRED,
    REASONING_REQUIRED,
    DECISION_REQUIRED,
    assert_columns,
)


class QuantumBrain:
    def __init__(self):
        self.perception = MarketPerception()
        self.reasoning = MarketReasoning()
        self.decision = DecisionEngine()

    def think(self, df_bars):
        print("\n[Brain] Phase 1/3 → Perception")
        df_p = self.perception.perceive(df_bars)
        assert_columns(df_p, PERCEPTION_REQUIRED, "Perception")

        print("\n[Brain] Phase 2/3 → Reasoning")
        df_r = self.reasoning.reason(df_p)
        assert_columns(df_r, REASONING_REQUIRED, "Reasoning")

        print("\n[Brain] Phase 3/3 → Decision")
        df_s = self.decision.generate_signals(df_r)
        assert_columns(df_s, DECISION_REQUIRED, "Decision")
        return df_s
