"""
Reasoning layer — builds an ICT narrative and a conviction score.

Reads ONLY the Perception contract. Does not invent columns.
Weights are regime-conditional (cognitive), not a single hardcoded RSI gate.
"""
import numpy as np
import pandas as pd


class MarketReasoning:

    def get_best_sweep(self, sweep_arr, i, lookback=12):
        # Include bar i: the sweep is known at its own close; fill is t+1.
        start = max(0, i - lookback)
        window = sweep_arr[start:i + 1]
        if len(window) == 0:
            return 0.0, -1
        best_val = float(window.max())
        if best_val < 0.08:
            return 0.0, -1
        return best_val, start + int(np.argmax(window))

    def get_displacement(self, bos_arr, ofi_arr, cl_arr, atr_arr, sweep_idx, current_i):
        if sweep_idx < 0:
            return 0.0, -1

        search_end = min(current_i + 1, sweep_idx + 8)
        if search_end <= sweep_idx:
            return 0.0, -1

        w_bos = bos_arr[sweep_idx:search_end]
        w_ofi = ofi_arr[sweep_idx:search_end]
        best_bos = float(w_bos.max()) if len(w_bos) else 0.0
        best_ofi = float(w_ofi.max()) if len(w_ofi) else 0.5

        if best_bos >= 0.15:
            idx = sweep_idx + int(np.argmax(w_bos))
            recency = float(np.exp(-(idx - sweep_idx) * 0.20))
            return float(np.clip(best_bos * 0.70 + recency * 0.30, 0, 1)), idx

        if best_bos > 0.04 and best_ofi > 0.60:
            return float(np.clip(best_bos * 0.45 + (best_ofi - 0.50) * 0.45, 0, 0.50)), -1

        if best_ofi > 0.70:
            return float(np.clip((best_ofi - 0.50) * 0.55, 0, 0.35)), -1

        if search_end > sweep_idx + 1:
            price_move = cl_arr[search_end - 1] - cl_arr[sweep_idx]
            atr_approx = atr_arr[sweep_idx] if atr_arr[sweep_idx] > 0 else cl_arr[sweep_idx] * 0.003
            if atr_approx > 0 and price_move > atr_approx:
                return float(min(price_move / (atr_approx * 3.0), 0.35)), -1

        return 0.0, -1

    def score_pullback(self, df, i, bos_idx, sweep_idx):
        cl = float(df["close"].iloc[i])
        atr_i = max(float(df["atr"].iloc[i]), 1.0)

        ref_idx = bos_idx if (bos_idx > 0 and bos_idx < i) else sweep_idx
        if ref_idx < 0 or ref_idx >= i:
            ref_idx = max(0, i - 3)
        in_pullback = float(cl <= float(df["close"].iloc[ref_idx]))

        vpin_s = float(df["vpin_safety"].iloc[i])
        if np.isnan(vpin_s):
            vpin_s = 0.5

        ob_mid = df["ob_mid"].iloc[i]
        if not np.isnan(ob_mid) and float(ob_mid) > 0:
            ob_prox = float(np.exp(-abs(cl - float(ob_mid)) / atr_i * 0.5))
        else:
            ob_prox = 0.35

        in_ob = float(df["in_ob"].iloc[i])
        pb_q = float(df["pb_quiet"].iloc[i])
        ofi_p = float(df["ofi_pct"].iloc[i])
        if np.isnan(ofi_p):
            ofi_p = 0.5

        score = (
            in_pullback * 0.20
            + vpin_s * 0.25
            + ob_prox * 0.20
            + in_ob * 0.15
            + pb_q * 0.10
            + ofi_p * 0.10
        )
        return float(np.clip(score, 0, 1))

    def get_regime_config(self, regime_mode):
        configs = {
            "up": {
                "w_fund": 0.60, "w_conf": 0.40,
                "scalp": False, "max_bars": 18,
                "sizing": 0.10, "label": "SWING",
            },
            "range": {
                "w_fund": 0.52, "w_conf": 0.48,
                "scalp": False, "max_bars": 10,
                "sizing": 0.08, "label": "RANGE",
            },
            "down": {
                "w_fund": 0.55, "w_conf": 0.45,
                "scalp": True, "max_bars": 5,
                "sizing": 0.06, "label": "SCALP",
            },
        }
        return configs.get(str(regime_mode), configs["range"])

    def build_narrative(self, df, i, sweep_arr, bos_arr, ofi_arr, swept_arr, cl_arr, atr_arr):
        empty = {
            "conviction": 0.0, "sweep_s": 0.0, "disp_s": 0.0,
            "pb_s": 0.0, "trend_s": 0.0,
            "stop_price": 0.0, "scalp": False,
            "max_bars": 18, "sizing": 0.10, "label": "", "narrative": "",
            "sweep_idx": -1,
        }

        sweep_s, sweep_idx = self.get_best_sweep(sweep_arr, i)
        if sweep_s < 0.08:
            return empty

        disp_s, bos_idx = self.get_displacement(
            bos_arr, ofi_arr, cl_arr, atr_arr, sweep_idx, i
        )
        if disp_s < 0.08:
            return {**empty, "sweep_s": sweep_s, "sweep_idx": sweep_idx}

        pb_s = self.score_pullback(df, i, bos_idx, sweep_idx)
        # No mitigation = no trade. Chasing the displacement is not ICT.
        if pb_s < 0.30:
            return {**empty, "sweep_s": sweep_s, "disp_s": disp_s, "pb_s": pb_s, "sweep_idx": sweep_idx}

        trend_s = float(df["trend"].iloc[i])
        if np.isnan(trend_s):
            trend_s = 0.5

        regime_mode = df["regime_list"].iloc[i]
        htf = float(df["htf_bull"].iloc[i])
        if np.isnan(htf):
            htf = 0.5
        cfg = self.get_regime_config(regime_mode)

        fundamentals = sweep_s * 0.50 + disp_s * 0.50
        confirmations = pb_s
        trend_mult = 0.80 + trend_s * 0.40
        htf_mult = 0.90 + htf * 0.20

        conviction = (
            fundamentals * cfg["w_fund"] + confirmations * cfg["w_conf"]
        ) * trend_mult * htf_mult * 100.0
        conviction = float(np.clip(conviction, 0, 100))

        stop = 0.0
        if 0 <= sweep_idx < len(swept_arr):
            swept = float(swept_arr[sweep_idx])
            if swept > 0:
                atr_i = max(float(df["atr"].iloc[i]), 1.0)
                stop = swept - 0.20 * atr_i

        text = (
            f"[{cfg['label']}] "
            f"Sw:{sweep_s:.2f} "
            f"D:{disp_s:.2f} "
            f"PB:{pb_s:.2f} "
            f"Tr:{trend_s:.2f} "
            f"→{conviction:.0f}"
        )

        return {
            "conviction": conviction,
            "sweep_s": sweep_s,
            "disp_s": disp_s,
            "pb_s": pb_s,
            "trend_s": trend_s,
            "stop_price": stop,
            "scalp": cfg["scalp"],
            "max_bars": cfg["max_bars"],
            "sizing": cfg["sizing"],
            "label": cfg["label"],
            "narrative": text,
            "sweep_idx": sweep_idx,
        }

    def reason(self, df_perceived):
        df = df_perceived.copy()
        n = len(df)

        sweep_arr = df["sweep_score"].fillna(0).values
        bos_arr = df["bos_score"].fillna(0).values
        ofi_arr = df["ofi_pct"].fillna(0.5).values
        swept_arr = df["swept_level"].fillna(0).values
        cl_arr = df["close"].values
        atr_arr = df["atr"].fillna(1.0).values

        conv = np.zeros(n)
        stops = np.zeros(n)
        scalps = np.zeros(n, dtype=bool)
        max_b = np.full(n, 18, dtype=int)
        sizing = np.full(n, 0.10)
        labels = [""] * n
        nars = [""] * n
        sweep_ids = np.full(n, -1, dtype=int)

        for i in range(12, n):
            r = self.build_narrative(
                df, i, sweep_arr, bos_arr, ofi_arr, swept_arr, cl_arr, atr_arr
            )
            conv[i] = r["conviction"]
            stops[i] = r["stop_price"]
            scalps[i] = r["scalp"]
            max_b[i] = r["max_bars"]
            sizing[i] = r["sizing"]
            labels[i] = r["label"]
            nars[i] = r["narrative"]
            sweep_ids[i] = int(r["sweep_idx"])

        df["conviction"] = conv
        df["stop_raw"] = stops
        df["is_scalp"] = scalps
        df["max_bars"] = max_b
        df["trade_size"] = sizing
        df["reg_label"] = labels
        df["narrative"] = nars
        df["setup_sweep_idx"] = sweep_ids

        buckets = [20, 30, 40, 50, 60]
        dist = {f">{b}": int((conv > b).sum()) for b in buckets}
        print(f"  ✓ Conviction dist: {dist}")
        return df
