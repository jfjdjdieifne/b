"""
Single source of truth for the inter-layer column contract.

Previous ZIP crashed because Perception wrote `swept_ssl` / `trend_score`
while Reasoning/Decision read `swept_level` / `trend` / `regime_list`.
If a column is not in this list, it does not exist as far as the brain
is concerned.
"""

PERCEPTION_REQUIRED = (
    "open", "high", "low", "close", "buy_vol", "sell_vol", "total_vol", "atr",
    "ssl", "bsl", "ssl_q",
    "sweep_score", "swept_level", "bos_score",
    "ob_hi", "ob_lo", "ob_mid", "ob_q", "in_ob",
    "ofi_pct", "ofi_acc", "vpin_safety", "pb_quiet", "buy_pressure",
    "trend", "vol_pct", "htf_bull", "regime_list",
)

REASONING_REQUIRED = PERCEPTION_REQUIRED + (
    "conviction", "stop_raw", "is_scalp", "max_bars", "trade_size",
    "reg_label", "narrative", "setup_sweep_idx",
)

DECISION_REQUIRED = REASONING_REQUIRED + (
    "buy_signal", "structural_stop_level", "dynamic_threshold",
)


def assert_columns(df, required, layer):
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise KeyError(
            f"[{layer}] column-contract breach. Missing: {missing}"
        )
    return df
