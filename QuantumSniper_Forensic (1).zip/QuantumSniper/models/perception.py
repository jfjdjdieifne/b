"""
Perception layer — causal ICT microstructure features on dollar-volume bars.

Constitution:
  - Every feature published at bar i uses only information known at the
    close of bar i. Swing pivots are published at the confirmation bar
    (pivot + window), never at the unconfirmed pivot.
  - HTF is built from completed higher-timeframe groups only.
  - Rolling percentiles compare the current value to the PAST window,
    excluding the current observation from the rank baseline.
"""
import numpy as np
import pandas as pd


def _causal_percentile(series, window, min_periods):
    """P(past < current) on a trailing window. Current bar is ranked, not in baseline."""

    def ep(arr):
        if len(arr) < 4:
            return 0.5
        return float(np.searchsorted(np.sort(arr[:-1]), arr[-1])) / max(len(arr) - 1, 1)

    return series.rolling(window, min_periods=min_periods).apply(ep, raw=True)


class MarketPerception:

    def find_liquidity_levels(self, df):
        """
        Multi-scale fractal swings. A pivot at index p with window sw is
        only known at confirm = p + sw. We write the level at `confirm`.
        """
        n = len(df)
        lo = df["low"].values
        hi = df["high"].values
        atr = df["atr"].values

        ssl_price = np.full(n, np.nan)
        bsl_price = np.full(n, np.nan)
        ssl_score = np.zeros(n)
        bsl_score = np.zeros(n)

        swing_low_count = 0
        swing_high_count = 0

        for sw in (3, 5, 8):
            w = sw / 16.0
            for p in range(sw, n - sw):
                confirm = p + sw  # first bar at which the right side is fully known
                atr_p = float(atr[p]) if atr[p] > 0 else 1.0

                left_lo = lo[p - sw:p]
                right_lo = lo[p + 1:p + sw + 1]
                left_hi = hi[p - sw:p]
                right_hi = hi[p + 1:p + sw + 1]

                is_swing_low = bool(
                    (lo[p] <= left_lo).all()
                    and (lo[p] <= right_lo).all()
                    and lo[p] < left_lo.mean()
                )
                if is_swing_low:
                    depth = (left_lo.mean() - lo[p]) / atr_p
                    sc = float(np.tanh(depth * 1.5)) * w
                    if np.isnan(ssl_price[confirm]):
                        ssl_price[confirm] = lo[p]
                        ssl_score[confirm] = sc
                        swing_low_count += 1
                    else:
                        ssl_score[confirm] = min(ssl_score[confirm] + sc, 1.0)

                is_swing_high = bool(
                    (hi[p] >= left_hi).all()
                    and (hi[p] >= right_hi).all()
                    and hi[p] > left_hi.mean()
                )
                if is_swing_high:
                    depth = (hi[p] - left_hi.mean()) / atr_p
                    sc = float(np.tanh(depth * 1.5)) * w
                    if np.isnan(bsl_price[confirm]):
                        bsl_price[confirm] = hi[p]
                        bsl_score[confirm] = sc
                        swing_high_count += 1
                    else:
                        bsl_score[confirm] = min(bsl_score[confirm] + sc, 1.0)

        print(f"  [DEBUG] Confirmed swing lows: {swing_low_count} | highs: {swing_high_count}")

        ssl_s = pd.Series(ssl_price, index=df.index).ffill()
        bsl_s = pd.Series(bsl_price, index=df.index).ffill()

        ssl_q = pd.Series(ssl_score, index=df.index).replace(0.0, np.nan).ffill().fillna(0.0)
        bsl_q = pd.Series(bsl_score, index=df.index).replace(0.0, np.nan).ffill().fillna(0.0)

        decay_ssl = np.zeros(n)
        decay_bsl = np.zeros(n)
        last_ssl = None
        last_bsl = None
        for i in range(n):
            if not np.isnan(ssl_price[i]):
                last_ssl = i
            decay_ssl[i] = 0.0 if last_ssl is None else float(np.exp(-(i - last_ssl) * 0.02))
            if not np.isnan(bsl_price[i]):
                last_bsl = i
            decay_bsl[i] = 0.0 if last_bsl is None else float(np.exp(-(i - last_bsl) * 0.02))

        ssl_q = (ssl_q * pd.Series(decay_ssl, index=df.index)).clip(0, 1)
        bsl_q = (bsl_q * pd.Series(decay_bsl, index=df.index)).clip(0, 1)

        # SSL is sell-side: it must sit below the current close. Causal (same-bar close).
        ssl_s = ssl_s.where(ssl_s < df["close"], np.nan).ffill()

        return ssl_s, bsl_s, ssl_q, bsl_q, ssl_price, bsl_price

    def find_equal_levels(self, values, tol_pct=0.0015, window=25):
        n = len(values)
        out = np.zeros(n)
        for i in range(window, n):
            tol = values[i] * tol_pct
            matches = int(np.sum(np.abs(values[i - window:i] - values[i]) < tol))
            if matches >= 1:
                out[i] = min(matches / 4.0, 1.0)
        return out

    def measure_sweep(self, df, ssl_s, ssl_q):
        n = len(df)
        sweep_sc = np.zeros(n)
        swept_lvl = np.zeros(n)

        lo = df["low"].values
        hi = df["high"].values
        op = df["open"].values
        cl = df["close"].values
        atr = df["atr"].values
        tvol = df["total_vol"].values
        ssl = ssl_s.fillna(0.0).values
        ssq = ssl_q.fillna(0.0).values

        vol_med = pd.Series(tvol).rolling(20, min_periods=3).median().values

        sweep_count = 0
        for i in range(1, n):
            level = ssl[i]
            if level <= 0:
                continue
            if lo[i] > level * 1.001:
                continue

            atr_i = atr[i] if atr[i] > 0 else 1.0
            vm = vol_med[i] if (not np.isnan(vol_med[i]) and vol_med[i] > 0) else max(tvol[i], 1.0)

            penetration = max(level - lo[i], 0.0) / atr_i
            closed_above = float(cl[i] > level)

            # Took liquidity and never reclaimed — not a sweep, a breakdown.
            if penetration > 2.5 and cl[i] < level:
                sweep_sc[i] = 0.04
                swept_lvl[i] = level
                continue

            rng = max(hi[i] - lo[i], atr_i * 0.10)
            wick_below = (min(op[i], cl[i]) - lo[i]) / rng
            rejection = (cl[i] - lo[i]) / rng
            vol_score = float(np.tanh((tvol[i] / vm) - 0.8))
            strength = float(ssq[i])

            if closed_above and penetration > 0:
                score = (
                    0.35 * closed_above
                    + 0.20 * wick_below
                    + 0.20 * max(vol_score, 0.0)
                    + 0.15 * (1.0 - min(penetration / 2.0, 1.0))
                    + 0.10 * strength
                )
            elif wick_below > 0.40 or rejection > 0.50:
                score = (
                    0.30 * wick_below
                    + 0.25 * rejection
                    + 0.20 * max(vol_score, 0.0)
                    + 0.15 * strength
                    + 0.10 * (1.0 - min(penetration / 3.0, 1.0))
                ) * 0.75
            else:
                score = (0.10 + 0.05 * strength) * max(vol_score + 0.5, 0.1)

            if penetration > 1.8:
                score *= 0.55

            final = float(np.clip(score, 0.0, 1.0))
            sweep_sc[i] = final
            swept_lvl[i] = level
            if final > 0.08:
                sweep_count += 1

        print(f"  [DEBUG] Sweeps (>0.08): {sweep_count}")
        return pd.Series(sweep_sc, index=df.index), pd.Series(swept_lvl, index=df.index)

    def detect_bos(self, df, bsl_s):
        n = len(df)
        bos_sc = np.zeros(n)
        bsl = bsl_s.fillna(0.0).values
        cl = df["close"].values
        hi = df["high"].values
        atr = df["atr"].values
        tvol = df["total_vol"].values
        vol_med = pd.Series(tvol).rolling(15, min_periods=3).median().values

        bos_count = 0
        for i in range(2, n):
            level = bsl[i]
            if level <= 0:
                continue
            atr_i = atr[i] if atr[i] > 0 else 1.0
            vm = vol_med[i] if (not np.isnan(vol_med[i]) and vol_med[i] > 0) else max(tvol[i], 1.0)

            if cl[i] > level and cl[i - 1] <= level:
                body = float(np.tanh((cl[i] - level) / atr_i))
                vol = float(np.tanh(tvol[i] / vm - 0.5))
                bos_sc[i] = float(np.clip(body * 0.65 + max(vol, 0.0) * 0.35, 0.0, 1.0))
                bos_count += 1
            elif hi[i] > level and cl[i] <= level:
                body = float(np.tanh((hi[i] - level) / atr_i))
                bos_sc[i] = float(np.clip(body * 0.40, 0.0, 0.40))

        print(f"  [DEBUG] Close-through BOS: {bos_count}")
        return pd.Series(bos_sc, index=df.index)

    def find_order_blocks(self, df, bos_sc):
        n = len(df)
        ob_hi = np.full(n, np.nan)
        ob_lo = np.full(n, np.nan)
        ob_mid = np.full(n, np.nan)
        ob_q = np.zeros(n)

        op = df["open"].values
        cl = df["close"].values
        hi = df["high"].values
        lo = df["low"].values
        tvol = df["total_vol"].values
        bos = bos_sc.values
        vol_med = pd.Series(tvol).rolling(15, min_periods=3).median().values

        for i in range(5, n):
            if bos[i] < 0.06:
                continue
            best_sc = 0.0
            best_idx = -1
            for j in range(max(0, i - 8), i):
                rng_j = max(hi[j] - lo[j], 1.0)
                bearish = max((op[j] - cl[j]) / rng_j, 0.0)
                vm = vol_med[j] if (not np.isnan(vol_med[j]) and vol_med[j] > 0) else max(tvol[j], 1.0)
                vs = float(np.tanh(tvol[j] / vm - 0.3))
                rec = float(np.exp(-(i - j) * 0.35))
                sc = (bearish + 0.25) * 0.40 + max(vs, 0.0) * 0.35 + rec * 0.25
                if sc > best_sc:
                    best_sc = sc
                    best_idx = j
            if best_idx >= 0 and best_sc > 0.06:
                ob_hi[i] = hi[best_idx]
                ob_lo[i] = lo[best_idx]
                ob_mid[i] = 0.5 * (hi[best_idx] + lo[best_idx])
                ob_q[i] = float(np.clip(best_sc * bos[i], 0.0, 1.0))

        idx = df.index
        ob_hi_s = pd.Series(ob_hi, index=idx).ffill()
        ob_lo_s = pd.Series(ob_lo, index=idx).ffill()
        ob_mid_s = pd.Series(ob_mid, index=idx).ffill()
        ob_q_s = pd.Series(ob_q, index=idx).replace(0.0, np.nan).ffill().fillna(0.0)

        in_ob = (
            (df["low"] <= ob_hi_s * 1.003) & (df["high"] >= ob_lo_s * 0.997)
        ).astype(float)

        return ob_hi_s, ob_lo_s, ob_mid_s, ob_q_s, in_ob

    def read_order_flow(self, df):
        bv = df["buy_vol"]
        sv = df["sell_vol"]
        tvol = df["total_vol"]

        ofi_raw = (bv - sv) / (tvol + 1e-9)
        ofi_pct = _causal_percentile(ofi_raw, 60, 6).fillna(0.5)
        ofi_acc = ofi_pct.diff(2).fillna(0.0)

        abs_imb = (bv - sv).abs()
        vpin = abs_imb.rolling(30, min_periods=4).sum() / (
            tvol.rolling(30, min_periods=4).sum() + 1e-9
        )
        vpin_safety = (1.0 - _causal_percentile(vpin, 60, 6)).fillna(0.5)

        vol_ratio = tvol / (tvol.rolling(6, min_periods=2).mean() + 1e-9)
        pb_quiet = (vol_ratio < 0.95).astype(float)

        buy_pres = bv.rolling(4, min_periods=2).mean() / (
            tvol.rolling(4, min_periods=2).mean() + 1e-9
        )

        return {
            "ofi_raw": ofi_raw,
            "ofi_pct": ofi_pct,
            "ofi_acc": ofi_acc,
            "vpin": vpin.fillna(0.5),
            "vpin_safety": vpin_safety,
            "pb_quiet": pb_quiet,
            "buy_pressure": buy_pres.fillna(0.5),
        }

    def classify_regime(self, df):
        cl = df["close"]
        atr = df["atr"]

        ema21 = cl.ewm(span=21, min_periods=1).mean()
        ema55 = cl.ewm(span=55, min_periods=1).mean()
        ema200 = cl.ewm(span=200, min_periods=1).mean()

        trend = (ema21 > ema55).astype(float) * 0.40 + (ema55 > ema200).astype(float) * 0.60

        rv = atr / (cl + 1e-9)
        vol_pct = _causal_percentile(rv, 80, 8).fillna(0.5)

        htf_bull = self._causal_htf_bull(cl, compression=5)

        regime_list = []
        for t in trend.values:
            if t > 0.60:
                regime_list.append("up")
            elif t < 0.40:
                regime_list.append("down")
            else:
                regime_list.append("range")

        return {
            "trend": trend,
            "vol_pct": vol_pct,
            "htf_bull": htf_bull,
            "regime_list": pd.Series(regime_list, index=df.index),
        }

    def _causal_htf_bull(self, close, compression=5):
        """
        Higher-timeframe close is the last COMPLETED group only.
        Bars 0..4 see close[0]. At bar 5 the group [0..4] completes and
        its close (close[4]) becomes the HTF print. No intra-group leak.
        """
        n = len(close)
        cl = close.values.astype(np.float64)
        htf_c = np.empty(n, dtype=np.float64)
        last = cl[0]
        for i in range(n):
            if i > 0 and (i % compression == 0):
                last = cl[i - 1]
            htf_c[i] = last
        s = pd.Series(htf_c, index=close.index)
        fast = s.ewm(span=6, min_periods=1).mean()
        slow = s.ewm(span=18, min_periods=1).mean()
        return (fast > slow).astype(float)

    def perceive(self, df_bars):
        df = df_bars.copy()
        df["atr"] = (df["high"] - df["low"]).rolling(14, min_periods=1).mean()

        print("  → Liquidity levels (causal confirmation)...")
        ssl_s, bsl_s, ssl_q, bsl_q, _, _ = self.find_liquidity_levels(df)

        print("  → Equal highs / lows...")
        eql = pd.Series(self.find_equal_levels(df["low"].values), index=df.index)
        eqh = pd.Series(self.find_equal_levels(df["high"].values), index=df.index)
        combined_ssl_q = (ssl_q * 0.70 + eql * 0.30).clip(0, 1)
        combined_bsl_q = (bsl_q * 0.70 + eqh * 0.30).clip(0, 1)

        print("  → Sweep detection...")
        sweep_sc, swept_lvl = self.measure_sweep(df, ssl_s, combined_ssl_q)

        print("  → Break of Structure...")
        bos_sc = self.detect_bos(df, bsl_s)

        print("  → Order Blocks...")
        ob_hi, ob_lo, ob_mid, ob_q, in_ob = self.find_order_blocks(df, bos_sc)

        print("  → Order Flow...")
        of = self.read_order_flow(df)

        print("  → Regime (causal HTF)...")
        reg = self.classify_regime(df)

        df["ssl"] = ssl_s
        df["bsl"] = bsl_s
        df["ssl_q"] = combined_ssl_q
        df["bsl_q"] = combined_bsl_q
        df["eql"] = eql
        df["eqh"] = eqh
        df["sweep_score"] = sweep_sc
        df["swept_level"] = swept_lvl
        df["bos_score"] = bos_sc
        df["ob_hi"] = ob_hi
        df["ob_lo"] = ob_lo
        df["ob_mid"] = ob_mid
        df["ob_q"] = ob_q
        df["in_ob"] = in_ob
        df["ofi_pct"] = of["ofi_pct"]
        df["ofi_acc"] = of["ofi_acc"]
        df["vpin_safety"] = of["vpin_safety"]
        df["pb_quiet"] = of["pb_quiet"]
        df["buy_pressure"] = of["buy_pressure"]
        df["trend"] = reg["trend"]
        df["vol_pct"] = reg["vol_pct"]
        df["htf_bull"] = reg["htf_bull"]
        df["regime_list"] = reg["regime_list"]

        print(
            f"  ✓ Usable sweeps: {int((sweep_sc > 0.08).sum())} | "
            f"Usable BOS: {int((bos_sc > 0.06).sum())}"
        )
        return df
