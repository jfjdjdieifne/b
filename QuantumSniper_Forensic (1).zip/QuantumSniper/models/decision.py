"""
Decision layer — dynamic threshold, long-only.

The previous build hard-killed every bar with trend < 0.12. Because trend
only takes values {0.0, 0.4, 1.0}, that gate made SCALP / down-regime
completely unreachable. Down-regime now pays a higher threshold instead
of being banned — that is the actual ICT reversal path (SSL sweep + BOS
against a bearish tape).
"""
import numpy as np


class DecisionEngine:

    def dynamic_threshold(self, trend_s, vol_pct, regime_mode):
        bases = {"up": 38.0, "range": 42.0, "down": 48.0}
        base = bases.get(str(regime_mode), 42.0)
        vol_adj = float(vol_pct) * 8.0
        trend_adj = (0.5 - float(trend_s)) * 6.0
        return float(np.clip(base + vol_adj + trend_adj, 30.0, 65.0))

    def generate_signals(self, df_reasoned):
        df = df_reasoned.copy()
        n = len(df)

        signals = np.zeros(n)
        stops = np.zeros(n)
        thresholds = np.zeros(n)
        spent_sweeps = set()

        for i in range(12, n):
            trend_s = float(df["trend"].iloc[i])
            vol_pct = float(df["vol_pct"].iloc[i])
            if np.isnan(trend_s):
                trend_s = 0.5
            if np.isnan(vol_pct):
                vol_pct = 0.5
            regime_mode = df["regime_list"].iloc[i]

            thresh = self.dynamic_threshold(trend_s, vol_pct, regime_mode)
            thresholds[i] = thresh

            conviction = float(df["conviction"].iloc[i])
            if conviction < thresh:
                continue
            if i >= 1 and signals[i - 1] == 1:
                continue

            # One narrative, one bullet. Re-firing the same sweep is not alpha.
            sweep_id = int(df["setup_sweep_idx"].iloc[i])
            if sweep_id < 0 or sweep_id in spent_sweeps:
                continue
            spent_sweeps.add(sweep_id)

            signals[i] = 1
            sp = float(df["stop_raw"].iloc[i])
            atr_i = max(float(df["atr"].iloc[i]), 1.0)
            if sp <= 0:
                sp = float(df["close"].iloc[i]) - atr_i
            stops[i] = sp

        df["buy_signal"] = signals
        df["structural_stop_level"] = stops
        df["dynamic_threshold"] = thresholds
        print(f"  ✓ Final buy signals: {int(signals.sum())}")
        return df
