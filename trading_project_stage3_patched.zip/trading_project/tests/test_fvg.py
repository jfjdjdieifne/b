import math,numpy as np,pandas as pd,pytest
from trading_system.zones.fvg import CausalFVGEngine,FVGDataError,_FVGAuditEngine
from trading_system.audit.causal_state import *
def df(rows):return pd.DataFrame(rows,columns=['open','high','low','close'],dtype=float)
def test_geometries_timing_equality():
 d=df([(9,10,8,9),(10,11,9,10),(12,13,11,12)]);b,e=CausalFVGEngine().analyze(d);assert b.loc[2,'fvg_candidate_created'];assert b.loc[2,'created_fvg_zone_low']==10;assert b.loc[2,'created_fvg_zone_high']==11;assert not b.loc[:1,'fvg_candidate_created'].any();assert len(e)==1
 d2=df([(10,11,9,10),(9,10,8,9),(7,8,6,7)]);b,_=CausalFVGEngine().analyze(d2);assert b.loc[2,'created_fvg_direction']=='BEARISH_FVG_CANDIDATE'
 eq=df([(9,10,8,9),(9,10,8,9),(10,11,10,10)]);assert not CausalFVGEngine().analyze(eq)[0].fvg_candidate_created.any()
def test_stacking_identity_width_body():
 d=df([(9,10,8,9),(11,12,10,11),(13,14,13,13.5),(15,16,15,15.5)]);b,e=CausalFVGEngine().analyze(d);assert b.created_fvg_id.dropna().tolist()==[0,1];assert b.loc[2,'created_fvg_gap_width']==3;assert math.isnan(b.loc[2,'created_fvg_gap_width_percentile']);assert b.loc[3,'created_fvg_gap_width_history_count']==1
def test_lifecycle_multifact_reclaim():
 d=df([(9,10,8,9),(11,12,10,11),(13,14,11,13),(10,12,7,8),(9,11,8,10)]);b,e=CausalFVGEngine().analyze(d);types=e[e.fvg_id==0].event_type.tolist();assert all(x in types for x in ['FIRST_TOUCH','FIRST_FULL_RANGE_COVERAGE','FIRST_FAR_SIDE_WICK_BREACH','FIRST_FAR_SIDE_CLOSE_BREACH','FIRST_CLOSE_RECLAIM_OF_FAR_SIDE']);assert types.count('FIRST_TOUCH')==1
def test_creation_bar_old_interaction_and_multiple():
 d=df([(9,10,8,9),(11,12,10,11),(13,14,11,13),(15,16,13,15),(10,17,7,12)]);b,e=CausalFVGEngine().analyze(d);assert b.known_bullish_fvg_candidate_count.iloc[-1]>=2;assert e[e.event_position==4].fvg_id.nunique()>=2
def audit(d):
 fb,fe=CausalFVGEngine().analyze(d)
 for k in range(1,len(d)):
  tb,te=CausalFVGEngine().analyze(d.iloc[:k]);pd.testing.assert_frame_equal(fb.iloc[:k],tb,check_exact=True);pd.testing.assert_frame_equal(fe[fe.event_position<k].reset_index(drop=True),te,check_exact=True)
def test_audits_state_future_scale():
 d=df([(9,10,8,9),(11,12,10,11),(13,14,11,13),(10,12,7,8),(9,11,8,10)]);r=verify_truncation_invariance(_FVGAuditEngine,d,split_fractions=(),additional_split_points=[1,2,3,4]);assert all(x.passed for x in r);assert verify_state_isolation(_FVGAuditEngine,d,d*2,policy=ReentrancyPolicy.IDEMPOTENT_REENTRANT).passed;audit(d);b,e=CausalFVGEngine().analyze(d);bs,es=CausalFVGEngine().analyze(d*8);pd.testing.assert_series_equal(b.created_fvg_gap_width_fraction,bs.created_fvg_gap_width_fraction,check_exact=True)
def test_close_reclaim_gap_over_requires_no_touch():
 d=df([(9,10,8,9),(11,12,10,11),(13,14,11,13),(9,12,7,8),(12.5,13,12,12.5)])
 b,e=CausalFVGEngine().analyze(d);r=e[(e.fvg_id==0)&(e.event_type=='FIRST_CLOSE_RECLAIM_OF_FAR_SIDE')];assert r.event_position.tolist()==[4];assert b.loc[4,'bullish_fvg_first_close_reclaim_count']==1;assert not ((e.event_position==4)&(e.event_type=='FIRST_TOUCH')).any()

def test_partial_coverage_exact_far_touch_and_no_repeats():
 d=df([(9,10,8,9),(11,12,10,11),(13,14,12,13),(11.5,12,11,11),(10,12,10,11),(9,13,8,9)])
 b,e=CausalFVGEngine().analyze(d);touch=e[(e.fvg_id==0)&(e.event_type=='FIRST_TOUCH')];assert touch.zone_range_coverage_fraction.iloc[0]==0.5;assert not b.loc[4,'bullish_fvg_first_far_side_wick_breach_count'];assert e[(e.fvg_id==0)&(e.event_type=='FIRST_TOUCH')].shape[0]==1;assert e[(e.fvg_id==0)&(e.event_type=='FIRST_FULL_RANGE_COVERAGE')].shape[0]==1;assert e[(e.fvg_id==0)&(e.event_type=='FIRST_FAR_SIDE_WICK_BREACH')].shape[0]==1

def test_event_table_schema_positions_ids_and_path_ambiguity():
 d=df([(9,10,8,9),(11,12,10,11),(13,14,11,13),(10,15,7,8)])
 b,e=CausalFVGEngine().analyze(d);assert list(e.columns)==list(__import__('trading_system.zones.fvg',fromlist=['_E'])._E);assert (e[e.event_type!='FVG_CREATED'].event_position>e[e.event_type!='FVG_CREATED'].creation_position).all();assert (e[e.event_type=='FVG_CREATED'].event_position==e[e.event_type=='FVG_CREATED'].creation_position).all();assert set(e.fvg_id)<=set(e[e.event_type=='FVG_CREATED'].fvg_id)
 b2,e2=CausalFVGEngine().analyze(d.copy());pd.testing.assert_frame_equal(b,b2,check_exact=True);pd.testing.assert_frame_equal(e,e2,check_exact=True)

def test_numerical_overflow_rejected():
 m=np.finfo(float).max;d=df([(-m,-m,-m,-m),(0,1,-1,0),(m,m,m,m)])
 with pytest.raises(FVGDataError,match='width overflow'):CausalFVGEngine().analyze(d)

def test_explicit_input_contract_cases():
 valid=df([(9,10,8,9)])
 cases=[valid.assign(high=np.inf),valid.assign(open=20),valid.assign(close=20),df([(9,8,10,9)])]
 for x in cases:
  with pytest.raises(FVGDataError):CausalFVGEngine().analyze(x)
 x=valid.copy();x['open']=True
 with pytest.raises(FVGDataError):CausalFVGEngine().analyze(x)
 x=valid.copy();x.index=[1];x['created_fvg_id']=0
 with pytest.raises(FVGDataError):CausalFVGEngine().analyze(x)
 dup=df([(9,10,8,9),(9,10,8,9)]);dup.index=[1,1]
 with pytest.raises(FVGDataError):CausalFVGEngine().analyze(dup)
 un=df([(9,10,8,9),(9,10,8,9)]);un.index=[2,1]
 with pytest.raises(FVGDataError):CausalFVGEngine().analyze(un)
 bad=valid.copy();bad['open']='x'
 with pytest.raises(FVGDataError):CausalFVGEngine().analyze(bad)

def test_validation_empty_immutable():
 empty=df([]);b,e=CausalFVGEngine().analyze(empty);assert b.empty and e.empty;assert list(e.columns)==list(__import__('trading_system.zones.fvg',fromlist=['_E'])._E)
 d=df([(9,10,8,9)]);before=d.copy();CausalFVGEngine().analyze(d);pd.testing.assert_frame_equal(d,before)
 for x in [d.assign(high=np.nan),df([(9,8,10,9)]),df([(20,10,8,9)])]:
  with pytest.raises(FVGDataError):CausalFVGEngine().analyze(x)
