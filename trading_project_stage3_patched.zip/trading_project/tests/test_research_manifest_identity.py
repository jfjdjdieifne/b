import numpy as np
import pandas as pd
import pytest

from trading_system.decision.evidence_vector import (
    CausalEvidenceVectorEngine,
    EvidenceVectorConfig,
    OrderFlowEvidenceMode,
)
from trading_system.decision.narrative import CausalMarketNarrativeEngine
from trading_system.research.manifest_identity import (
    ManifestIdentityError,
    validate_feature_manifest_identity,
    validate_narrative_manifest_identity,
)


def certified_feature_manifest():
    return CausalEvidenceVectorEngine(
        config=EvidenceVectorConfig(
            environment=False,
            temporal_context=False,
            structure=True,
            liquidity=False,
            order_blocks=False,
            fvg=False,
            dealing_range=False,
            multiscale=False,
            order_flow_mode=OrderFlowEvidenceMode.NONE,
        )
    ).manifest()


@pytest.mark.parametrize(
    "payload",
    [
        ["2.1C"],
        ("2.1C",),
        {"source": "2.1C"},
        {"2.1C"},
        np.array(["2.1C"]),
        pd.Series(["2.1C"]),
        pd.Index(["2.1C"]),
    ],
)
def test_feature_manifest_rejects_nonscalar_metadata_cleanly(payload):
    manifest = certified_feature_manifest()
    manifest.at[0, "source_module"] = payload
    with pytest.raises(ManifestIdentityError, match="scalar|malformed"):
        validate_feature_manifest_identity(manifest)


@pytest.mark.parametrize("missing", [None, pd.NA, np.nan])
def test_feature_manifest_canonicalizes_supported_missing_sentinels(missing):
    manifest = certified_feature_manifest()
    manifest.at[0, "freshness_column"] = missing
    validate_feature_manifest_identity(manifest)


def test_feature_manifest_accepts_equivalent_numpy_scalars():
    manifest = certified_feature_manifest()
    event_row = manifest["feature_name"] == "structural_break_event"
    manifest.loc[event_row, "event_local"] = np.bool_(True)
    manifest.loc[event_row, "source_module"] = np.str_("2.1C")
    validate_feature_manifest_identity(manifest)


def _first_missing_coordinate(frame):
    for row_position in range(len(frame)):
        for column in frame.columns:
            if pd.isna(frame.iloc[row_position][column]):
                return row_position, column
    raise AssertionError("certified narrative manifest has no missing cell")


@pytest.mark.parametrize("missing", [None, pd.NA, np.nan])
def test_narrative_manifest_canonicalizes_missing_sentinels(missing):
    manifest = CausalMarketNarrativeEngine.narrative_manifest()
    row_position, column = _first_missing_coordinate(manifest)
    manifest.at[row_position, column] = missing
    validate_narrative_manifest_identity(manifest)


def test_narrative_manifest_rejects_nonscalar_payload_cleanly():
    manifest = CausalMarketNarrativeEngine.narrative_manifest()
    manifest.at[0, "foundation_clause"] = ["FORGED"]
    with pytest.raises(ManifestIdentityError, match="scalar|malformed"):
        validate_narrative_manifest_identity(manifest)


def test_narrative_manifest_rejects_dtype_change_even_with_same_values():
    manifest = CausalMarketNarrativeEngine.narrative_manifest()
    manifest["serialization_order"] = pd.array(
        manifest["serialization_order"], dtype="Int64"
    )
    with pytest.raises(ManifestIdentityError, match="dtype"):
        validate_narrative_manifest_identity(manifest)


def test_all_malformed_manifest_exceptions_are_normalized():
    feature = certified_feature_manifest()
    feature.at[0, "feature_name"] = np.array(["structure_state_after"])
    narrative = CausalMarketNarrativeEngine.narrative_manifest()
    narrative.at[0, "name"] = {"bad": "value"}
    for validator, manifest in (
        (validate_feature_manifest_identity, feature),
        (validate_narrative_manifest_identity, narrative),
    ):
        with pytest.raises(ManifestIdentityError):
            validator(manifest)
