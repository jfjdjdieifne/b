import math

import numpy as np
import pandas as pd
import pytest

from trading_system.audit.causal_state import (
    ReentrancyPolicy,
    verify_state_isolation,
    verify_truncation_invariance,
)
from trading_system.core.causal_percentile import (
    CausalPercentileConfigError,
    CausalPercentileDataError,
    CausalPercentileTracker,
    _PercentileAuditEngine,
    causal_percentile_series,
)


def test_module_01_certifies_expanding_and_bounded_modes():
    rng = np.random.default_rng(2026)
    df = pd.DataFrame({"feature": rng.normal(size=301)})

    for max_history in (None, 17):
        results = verify_truncation_invariance(
            lambda: _PercentileAuditEngine(
                source_column="feature", max_history=max_history
            ),
            df,
            additional_split_points=[1, 2, 16, 17, 18, 127, 300],
        )
        assert all(result.passed for result in results)


def test_module_01_certifies_adapter_state_isolation():
    rng = np.random.default_rng(9)
    df_a = pd.DataFrame({"feature": rng.normal(size=101)})
    df_b = pd.DataFrame({"feature": rng.normal(size=103)})

    result = verify_state_isolation(
        lambda: _PercentileAuditEngine(source_column="feature"),
        df_a,
        df_b,
        policy=ReentrancyPolicy.IDEMPOTENT_REENTRANT,
    )
    assert result.passed


def test_nan_skip_does_not_enter_history_and_reset_is_complete():
    tracker = CausalPercentileTracker(max_history=3, nan_policy="skip")
    tracker.observe(1.0)
    missing = tracker.observe(np.nan)
    tracker.observe(2.0)

    assert not missing.accepted
    assert tracker.history_snapshot() == (1.0, 2.0)
    assert tracker.total_pushed == 2
    assert tracker.total_skipped == 1

    tracker.reset()
    assert tracker.is_empty
    assert tracker.total_pushed == 0
    assert tracker.total_skipped == 0


def test_series_preserves_index_and_prior_only_counts():
    index = pd.Index(["a", "b", "c", "d"])
    values = pd.Series([10.0, np.nan, 20.0, 15.0], index=index)
    result = causal_percentile_series(values)

    assert result.index.equals(index)
    assert result["sample_count"].tolist() == [0, 1, 1, 2]
    assert result["accepted"].tolist() == [True, False, True, True]
    assert math.isnan(result.loc["a", "percentile"])
    assert result.loc["c", "percentile"] == 1.0
    assert result.loc["d", "percentile"] == 0.5


@pytest.mark.parametrize("invalid", [0, -1, 1.5, True])
def test_invalid_max_history_rejected(invalid):
    with pytest.raises(CausalPercentileConfigError):
        CausalPercentileTracker(max_history=invalid)


@pytest.mark.parametrize("invalid", [True, np.bool_(False), np.inf, -np.inf, "x"])
def test_invalid_observations_rejected(invalid):
    with pytest.raises(CausalPercentileDataError):
        CausalPercentileTracker().observe(invalid)
