import numpy as np
import pandas as pd
import pytest

from trading_system.research.hashing import (
    ResearchHashError,
    canonical_sha256,
)
from trading_system.research.information_time import (
    InformationPhase,
    TimeIndexedTimelineAdapter,
)


def test_canonical_hash_is_deterministic_and_mapping_order_independent():
    left = canonical_sha256(domain="TEST", payload={"b": 2, "a": 1})
    right = canonical_sha256(domain="TEST", payload={"a": 1, "b": 2})
    assert left == right
    assert left == canonical_sha256(domain="TEST", payload={"a": 1, "b": 2})


def test_hash_domain_separation():
    payload = {"value": 1}
    assert canonical_sha256(domain="A", payload=payload) != canonical_sha256(
        domain="B", payload=payload
    )


def test_exact_integers_above_float_precision_remain_distinct():
    first = canonical_sha256(domain="INT", payload=2**53 + 1)
    second = canonical_sha256(domain="INT", payload=2**53 + 2)
    assert first != second


def test_bool_integer_and_float_identities_are_distinct():
    assert canonical_sha256(domain="TYPE", payload=False) != canonical_sha256(
        domain="TYPE", payload=0
    )
    assert canonical_sha256(domain="TYPE", payload=1) != canonical_sha256(
        domain="TYPE", payload=1.0
    )


def test_missing_sentinels_have_explicit_common_identity():
    hashes = {
        canonical_sha256(domain="MISSING", payload=value)
        for value in (None, pd.NA, np.nan, pd.NaT)
    }
    assert len(hashes) == 1


def test_dataframe_hash_is_dtype_row_column_and_index_aware():
    frame = pd.DataFrame(
        {"a": pd.array([1, 2], dtype="Int64"), "b": [1.5, 2.5]},
        index=pd.Index([10, 20], name="rows"),
    )
    original = canonical_sha256(domain="FRAME", payload=frame)
    assert original != canonical_sha256(
        domain="FRAME", payload=frame.astype({"a": "float64"})
    )
    assert original != canonical_sha256(
        domain="FRAME", payload=frame.iloc[::-1]
    )
    assert original != canonical_sha256(
        domain="FRAME", payload=frame[["b", "a"]]
    )
    relabeled = frame.copy(deep=True)
    relabeled.index = pd.Index([11, 21], name="rows")
    assert original != canonical_sha256(domain="FRAME", payload=relabeled)


def test_explicit_empty_dataframe_hash_is_stable_and_schema_aware():
    empty = pd.DataFrame(
        {
            "high": pd.Series([], dtype="float64"),
            "low": pd.Series([], dtype="float64"),
        }
    )
    first = canonical_sha256(domain="EMPTY", payload=empty)
    second = canonical_sha256(domain="EMPTY", payload=empty.copy(deep=True))
    assert first == second
    assert first != canonical_sha256(
        domain="EMPTY", payload=empty.astype({"high": "Float64"})
    )


def test_timestamp_and_information_key_normalize_to_utc():
    utc = pd.DatetimeIndex([pd.Timestamp("2025-01-01T00:00:00Z")])
    local = utc.tz_convert("Europe/Vilnius")
    adapter = TimeIndexedTimelineAdapter("timeline")
    utc_key = adapter.key_for_position(
        utc, 0, InformationPhase.COMPLETED_ROW_AVAILABLE, 1
    )
    local_key = adapter.key_for_position(
        local, 0, InformationPhase.COMPLETED_ROW_AVAILABLE, 1
    )
    assert canonical_sha256(domain="KEY", payload=utc_key) == canonical_sha256(
        domain="KEY", payload=local_key
    )
    assert canonical_sha256(domain="TIME", payload=utc[0]) == canonical_sha256(
        domain="TIME", payload=local[0]
    )


def test_positive_and_negative_zero_have_distinct_representation_hashes():
    assert canonical_sha256(domain="ZERO", payload=0.0) != canonical_sha256(
        domain="ZERO", payload=-0.0
    )


def test_positive_infinity_rejected():
    with pytest.raises(ResearchHashError, match="nonfinite"):
        canonical_sha256(domain="BAD", payload=np.inf)


def test_negative_infinity_rejected():
    with pytest.raises(ResearchHashError, match="nonfinite"):
        canonical_sha256(domain="BAD", payload=-np.inf)


def test_naive_timestamp_rejected():
    with pytest.raises(ResearchHashError, match="naive"):
        canonical_sha256(domain="BAD", payload=pd.Timestamp("2025-01-01"))


def test_unsupported_object_scalar_rejected():
    with pytest.raises(ResearchHashError, match="unsupported"):
        canonical_sha256(domain="BAD", payload=object())


def test_input_dataframe_immutable():
    frame = pd.DataFrame({"x": pd.array([1, pd.NA], dtype="Int64")})
    before = frame.copy(deep=True)
    canonical_sha256(domain="IMMUTABLE", payload=frame)
    pd.testing.assert_frame_equal(frame, before, check_exact=True)
