# RESEARCH-DEBT-006 — Participation-Conditioned Absorption

**Owner:** Module 3.2  
**Status:** OPEN

The same delta ratio can occur under very different total classified volume.
V1 absorption evidence uses imbalance extremeness but does not condition on
absolute participation.

Future work may evaluate causal participation context only with consistent feed
units and walk-forward/out-of-sample tests.

Forbidden premature fixes:

- fixed volume moving average;
- fixed high-volume threshold;
- arbitrary unit mixing;
- hidden participation multiplier.
