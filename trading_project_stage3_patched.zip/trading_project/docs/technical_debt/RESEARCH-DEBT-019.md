# RESEARCH-DEBT-019 — Evidence Reliability vs Sample Support

History/support counts are exposed as metadata and excluded from the evidence
availability denominator. V1 applies no arbitrary confidence transform.
Reliability versus support requires later causal empirical evaluation.
