# RESEARCH-DEBT-009 — Order Block Origin Heuristic

**Status:** OPEN

V1 selects the most recent opposite-body candle inside a causal structural leg.
This is an explicit operational ICT heuristic, not proof of optimal or
institutional origin.

Future walk-forward/OOS research may compare full-candle/body geometries and
other causal displacement-context alternatives. Origin selection must never use
future mitigation outcomes or in-sample hindsight optimization.
