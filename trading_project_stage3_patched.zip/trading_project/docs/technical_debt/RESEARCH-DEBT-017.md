# RESEARCH-DEBT-017 — Multi-Scale Event Confluence

Persistent state may be carried as-of; event-local structural breaks cannot be blindly forward-filled. Event-arrival confluence needs a separate temporal contract.
