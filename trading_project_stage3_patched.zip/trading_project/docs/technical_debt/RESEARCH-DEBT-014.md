# RESEARCH-DEBT-014 — HTF Clock / Event-Bar Unification

Time, dollar, volume, and event bars require different causal aggregation and
closure contracts. V1 supports fixed-duration UTC clock buckets only and does
not force event bars into timeframe semantics.
