# RESEARCH-DEBT-023 — Outcome Censoring and Competing-Risk Estimand

Module 6.2A-1 records factual terminal lifecycle states and
`RIGHT_CENSORED_AS_OF_BOUNDARY` snapshots but does not choose a statistical
estimand or censor-aware estimator. Future work must define how contradiction,
supersession, establishment, and as-of censoring participate in an explicit
research question before selecting any competing-risk, survival, or other
statistical method. Censored records must not be silently recoded or dropped.
