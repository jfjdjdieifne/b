# RESEARCH-DEBT-008 — Breaker Block Structural Definition

**Status:** OPEN

A far-side OB-candidate close breach is not automatically a breaker block.
Legitimate breaker semantics require a prior candidate, causal far-side
violation, subsequent structural context, and a precisely defined role
reversal/retest without future backfill.

V1 emits factual far-side wick/close/reclaim events only. Automatic inversion
or breaker labels are forbidden until a separate causal contract is designed.
