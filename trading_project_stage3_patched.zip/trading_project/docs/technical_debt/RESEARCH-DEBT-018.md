# RESEARCH-DEBT-018 — Evidence Redundancy / Collinearity

Transparent primitives may be mathematically related. Module 6.1A performs no
full-sample correlation selection. Future selection/regularization must be fit
on training data only and evaluated walk-forward.
