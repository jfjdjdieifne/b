# RESEARCH-DEBT-024 — Overlapping Hypothesis Dependence / Non-IID Research Samples

Module 6.2A-2 exposes each selected sample's label-information interval and
deduplicates repeated as-of observations of the same mature factual outcome.
It does not solve statistical dependence between different hypotheses whose
label intervals overlap, belong to supersession chains, or share future market
paths.

Future work must define dependence-aware validation and uncertainty contracts,
which may include temporal blocks, clusters, supersession-chain grouping, or
other justified methods. Temporal eligibility does not imply samples are IID,
and this debt must not be converted into arbitrary sample deletion, embargo,
or weighting without a separate audited design.
