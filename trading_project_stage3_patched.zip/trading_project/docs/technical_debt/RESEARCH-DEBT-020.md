# RESEARCH-DEBT-020 — Hypothesis Lifecycle Termination Semantics

Continuation hypotheses have no defensible positive-success resolution in V1.
They remain monitoring until a causal contradiction or supersession. No fixed
TTL, decay, or bar-count expiry may be introduced without an explicit causal
contract and walk-forward evaluation.
