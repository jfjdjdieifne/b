# RESEARCH-DEBT-021 — Evidence-Bearing Calibration

V1 uses only logically descriptive bearings: alignment, directional opposition,
contradiction, context, qualification, neutrality, unknown, and not-applicable.
Predictive SUPPORTS semantics require later train-only, walk-forward empirical
calibration and are not present in Module 6.1B.
