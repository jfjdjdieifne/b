# RESEARCH-DEBT-011 — FVG Lifecycle Density / Dependence

**Status:** OPEN

Stacked gaps and one large bar can create many correlated lifecycle facts.
Future statistical aggregation needs explicit causal weighting/episode
semantics. V1 preserves independent identities and raw normalized events; it
does not treat all interactions as independent empirical samples.
