# RESEARCH-DEBT-012 — Dealing Range Selection Semantics

V1 pairs sequential confirmed opposite-side swings with same-side replacement.
This is a causal operational candidate model, not proof of the uniquely correct
ICT dealing range. Future BOS/liquidity/HTF alternatives require walk-forward
comparison without hindsight selection.
