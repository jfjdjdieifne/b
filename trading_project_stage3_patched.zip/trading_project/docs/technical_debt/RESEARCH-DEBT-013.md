# RESEARCH-DEBT-013 — Dealing Range Hierarchy / Nested Ranges

V1 exposes only the latest sequential range context while retaining historical
range creation rows. External/internal and multi-scale nested range hierarchy is
deferred; no premature hierarchy heuristic is implemented.
