# RESEARCH-DEBT-016 — Multi-Scale Authority / Weight Learning

V1 treats scales equally and emits factual agreement only. Scale authority and predictive weights require causal Layer 8 learning, not assumptions.
