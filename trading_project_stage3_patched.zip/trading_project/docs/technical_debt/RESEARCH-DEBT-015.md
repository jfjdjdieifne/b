# RESEARCH-DEBT-015 — HTF Partial-Bar Information

V1 exposes completed HTF bars only. Partial HTF information can be causal but
requires a separate explicit evolving-state contract to prevent mixing partial
and confirmed features.
