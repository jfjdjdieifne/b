# RESEARCH-DEBT-010 — IFVG Role-Reversal Definition

**Status:** OPEN

Far-side close breach does not automatically create an inverted FVG. A causal
IFVG contract requires the original candidate, violation, subsequent
interaction/reclaim/retest, structural context, and no future backfill. V1
preserves factual lifecycle events only and performs no automatic direction
flip.
