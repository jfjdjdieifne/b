# RESEARCH-DEBT-025 — Reference-Price and Market-Time Alignment

Module 6.2A-1 V1 uses creation-row completed close only as a non-executable
research reference mark under the current completed-row contract. Future work
must address venue timestamp semantics, corrected bars, intrabar hypothesis
versions, market lineage, contract rolls/corporate actions, and cross-timeline
alignment before extending or changing this reference contract. No entry or
fill interpretation is certified.
