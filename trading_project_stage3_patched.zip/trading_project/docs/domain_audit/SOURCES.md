# D1 Sources Consulted

## Primary/official sources successfully identified

1. **The Inner Circle Trader — official YouTube channel**  
   https://www.youtube.com/@InnerCircleTrader  
   Channel description identifies Michael J. Huddleston/ICT as the author of the material and hosts publicly released mentorship lectures.

2. **2022 ICT Mentorship Episode 3 — Internal Range Liquidity & Market Structure Shifts**  
   https://www.youtube.com/watch?v=nQfHZ2DEJ8c  
   Uploaded 2022-01-26. Official-channel search metadata confirms the title/topic. A reliable complete transcript and exact timestamps were not available through the research interface.

3. **ICT official website**  
   https://theinnercircletrader.com/  
   Identifies Huddleston/The Inner Circle Trader and links official material. Publicly indexed pages did not provide a complete concept glossary.

4. **ICT OTE Pattern Recognition Series playlist**  
   https://www.youtube.com/playlist?list=PLVgHx4Z63paaRnabpBl38GoMkxF1FiXCF  
   Public playlist associated with ICT material. Search metadata identifies a 20-video OTE recognition series; exact primary-video transcript verification was incomplete.

## Official technical sources

5. **pandas merge_asof official documentation**  
   https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.merge_asof.html

6. **pandas time-series/timezone official guide**  
   https://pandas.pydata.org/pandas-docs/stable/user_guide/timeseries.html

## Secondary terminology cross-checks — not treated as primary proof

7. ICT vs SMC terminology comparison  
   https://phidiaspropfirm.com/education/ict-vs-smc

8. CHoCH secondary explainer  
   https://tradingfinder.com/education/forex/ict-choch-in-trading/

9. ICT abbreviations secondary glossary  
   https://innercircletrader.net/tutorials/ict-abbreviations/

## Research limitation

YouTube search exposed official titles/descriptions but not consistently reliable full transcripts, upload metadata, or exact chapter timestamps. No quotation or timestamp was manufactured. Entries without directly verified primary text are explicitly MEDIUM/LOW confidence and require manual review of the official mentorship videos before predictive interpretation in Layer 6.
