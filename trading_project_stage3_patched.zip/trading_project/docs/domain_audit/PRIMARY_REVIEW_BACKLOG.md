# Primary-Source Review Backlog

**Status:** OPEN

Manual review of official Michael J. Huddleston / Inner Circle Trader material is still required for:

- Order Block exact qualifiers and variations by teaching era
- Breaker Block prerequisites and role-reversal sequence
- Mitigation Block
- Inverse/Inversion FVG
- Consequent Encroachment
- OTE exact Fibonacci levels and source-era variations
- PD Array taxonomy
- Kill Zone schedules by instrument, era, timezone, and DST
- Judas Swing
- Balanced Price Range (BPR)
- Liquidity Void
- Liquidity sweep/raid wording and prerequisites
- Market Structure Shift rule variations across mentorship eras

For every review item, record the official URL, title, publication/upload date, exact timestamp/chapter, faithful paraphrase or short verified quotation, and any conflicting formulation across eras.

## Layer 6 block

Concepts without an audited implementation are blocked from receiving Layer 6 weights, even when terminology is source-verified. Concepts currently blocked include Mitigation Block, Breaker interpretation, IFVG, OTE, unified PD Arrays, Judas Swing, BPR, and Liquidity Void.

Existing factual project modules may enter empirical Layer 6 testing only under documented project semantics; no source-fidelity or predictive-edge claim is implied.
