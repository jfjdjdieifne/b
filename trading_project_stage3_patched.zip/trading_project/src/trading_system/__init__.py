"""Certified causal trading-intelligence foundation and environment modules."""

__version__ = "0.1.0"

__all__ = ["__version__"]
