# -*- coding: utf-8 -*-
"""
scan_last_month_michael_style_v7.py
════════════════════════════════════════════════════════════════════
النسخة النهائية (بطلب صريح: "دور شو أكتر شغلتين إذا موجودين بيكون في
صفقة نحتملها ومنصير نعتبرها نقطة حسب مايكل - شو أول شي لازم نشوفه
بغض النظر عن الجلسات").

⚠️ الجواب المُستخرَج من كل البحث الموثّق اليوم (ictkillzone.com +
innercircletrader.net ICT Daily Bias Guide): أول شرطين حصرياً، بلا
أي قيد جلسة زمنية (لأن الكريبتو 24/7 - القيد بجلسة معينة كان خطأنا
بكل المحاولات v1-v6):
  1. Daily Bias واضح (BULLISH/BEARISH محسوب حتمياً - "Daily bias
     comes first - without it, the rest of the model is guesswork").
  2. سحب سيولة حقيقي (GENUINE_REVERSAL_SWEEP) لمستوى **مهم فعلاً**
     (MAJOR أو MODERATE - لا أي سوينغ محلي عشوائي minor) بعكس اتجاه
     الانحياز - "Look for a liquidity sweep of the previous range
     high or low" - بغض النظر عن أي وقت باليوم (لا قيد جلسة).

الفرق عن v6: v6 كانت تفحص فقط "آخر سوينغ مهم" (نقطة واحدة في كل
لحظة) - لو انسحب سوينغ مهم آخر (ليس الأحدث) لاحقاً، لم تُسجَّل. v7
تفحص **كل** السوينغات المهمة المتاحة في كل لحظة (لا فقط الأحدث)،
فتُسجّل أي سحب حقيقي جديد لأي منها - يطابق فعلياً كيف يعمل تاجر
حقيقي (يراقب كل مستويات السيولة المهمة القائمة، لا نقطة واحدة فقط).
"""
import json
import logging
import sys
import datetime
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine

brain = BrainCore()
ae = AuthenticityEngine()

SYMBOL = "ETH/USDT"
EXEC_TF = "15m"

full_data = brain.data_manager.get_ohlcv(SYMBOL, EXEC_TF, 3000, output_format="dict")
n = len(full_data["closes"])
print(f"إجمالي الشموع ({EXEC_TF}): {n}")
start_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][0]/1000, tz=datetime.timezone.utc)
end_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][-1]/1000, tz=datetime.timezone.utc)
print(f"النطاق: {start_dt} -> {end_dt}\n")

candidates = []
already_reported = set()  # (level_price rounded) لتفادي تكرار نفس المستوى المسحوب

MIN_LOOKBACK = 150

for i in range(MIN_LOOKBACK, n):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }

    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=250)
    except Exception:
        continue
    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"):
        continue

    try:
        sig = ae.detect_significant_swings(window_data, swing_window=2, lookback_candles=150)
    except Exception:
        continue

    n_window = len(window_data["closes"])

    if daily_bias == "BULLISH":
        important_levels = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
        for candidate in important_levels:
            level_price = candidate["price"]
            key = round(level_price, 2)
            if key in already_reported:
                continue
            res = classify_sweep_or_run(window_data, level_price, level_is_high=False, check_from_idx=i)
            if (res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP"
                    and res.get("candle_index_from_end") == (i - n_window)):
                already_reported.add(key)
                ts = full_data["timestamps"][i]
                dt = datetime.datetime.fromtimestamp(ts/1000, tz=datetime.timezone.utc)
                candidates.append({
                    "index": i, "timestamp": ts, "datetime_utc": dt.isoformat(),
                    "mechanical_bias": daily_bias, "bias_strength": anchor.get("strength"),
                    "sweep_type": "SSL_SWEPT_LOW", "swept_level_price": level_price,
                    "swept_level_tier": candidate["tier"],
                })
    else:
        important_levels = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
        for candidate in important_levels:
            level_price = candidate["price"]
            key = round(level_price, 2)
            if key in already_reported:
                continue
            res = classify_sweep_or_run(window_data, level_price, level_is_high=True, check_from_idx=i)
            if (res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP"
                    and res.get("candle_index_from_end") == (i - n_window)):
                already_reported.add(key)
                ts = full_data["timestamps"][i]
                dt = datetime.datetime.fromtimestamp(ts/1000, tz=datetime.timezone.utc)
                candidates.append({
                    "index": i, "timestamp": ts, "datetime_utc": dt.isoformat(),
                    "mechanical_bias": daily_bias, "bias_strength": anchor.get("strength"),
                    "sweep_type": "BSL_SWEPT_HIGH", "swept_level_price": level_price,
                    "swept_level_tier": candidate["tier"],
                })

candidates.sort(key=lambda c: c["index"])
print(f"=== إجمالي النقاط المرشحة (bias + سحب حقيقي لأي سوينغ MAJOR/MODERATE، بلا قيد جلسة - 24/7): {len(candidates)} ===\n")
for c in candidates:
    print(f"  [{c['index']}] {c['datetime_utc']}  bias={c['mechanical_bias']}({c['bias_strength']})  sweep={c['sweep_type']} level={c['swept_level_price']:.2f}({c['swept_level_tier']})")

with open("/tmp/last_month_michael_candidates_v7.json", "w") as f:
    json.dump(candidates, f, indent=2, default=str)
