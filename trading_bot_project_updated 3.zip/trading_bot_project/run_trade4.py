import sys, json, time, logging
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from human_trades_backtest import run_human_trades_backtest

brain = BrainCore()

t0 = time.time()
result = run_human_trades_backtest(
    brain, trade_ids=[4], capital_usd=100.0, extract_lessons=True,
)
elapsed = time.time() - t0

with open("/tmp/trade4_result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False, default=str)

print(f"DONE in {elapsed:.1f}s")
print(json.dumps({k: v for k, v in result.items() if k != "results"}, indent=2, ensure_ascii=False))
for r in result.get("results", []):
    print(json.dumps(r, indent=2, ensure_ascii=False, default=str))
