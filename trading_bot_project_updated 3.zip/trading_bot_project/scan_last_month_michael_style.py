# -*- coding: utf-8 -*-
"""
scan_last_month_michael_style.py
════════════════════════════════════════════════════════════════════
إعادة تصميم ثالثة وأخيرة (بطلب صريح من المستخدم: "بدي مايكل شلون
بيشتغل بالزبط - كيف بيدور عَ صفقة وكيف بيختارها وكيف بيعرف انو هون
في صفقة"). هذه النسخة مبنية حصراً من بحث ويب خارجي مستقل (لا اجتهاد
شخصي - راجع سجل الجلسة) يوثّق **جدول مايكل الزمني الحرفي اليومي**:

  1. Daily Bias يُحسب **مرة واحدة باليوم** (من فريم Daily نفسه، لا من
     15m ولا كل ساعة) - "The daily bias must come from the daily
     chart... reading bias off the 1-hour or 15-minute is the most
     common error."
  2. يُعلَّم نطاق سعري واحد بس: من منتصف ليل نيويورك (00:00 NY) حتى
     افتتاح لندن (03:00 NY تقريباً؛ نستخدم نافذتنا الموثّقة أصلاً
     LONDON_KILLZONE بداية 02:00 NY) - overnight range، بالضبط أداة
     compute_overnight_range() الموجودة أصلاً بالمشروع.
  3. **فقط عند لحظتين محددتين باليوم** (لا كل ساعة/شمعة): افتتاح
     London Kill Zone (02:00 NY) وافتتاح NY AM Kill Zone (08:30 NY)
     - "Once the bias is set, I wait for the London session to
     open... Look for a liquidity sweep of the previous range high
     or low."
  4. عند كل لحظة كهذه: نفحص هل صار سحب سيولة حقيقي (GENUINE_REVERSAL_
     SWEEP) لنفس نطاق الليل تحديداً (لا أي سوينغ عشوائي) - إن نعم،
     هذه بالضبط "لحظة تستاهل نقعد نحللها" (نقطة مرشحة حقيقية).

⚠️ صدق منهجي: لا فحص مطلقاً "هل تحرك السعر فعلاً بعدها" بهذه المرحلة
- المعيار الوحيد هنا هو معيار مايكل الميكانيكي البحت (bias + وقت
جلسة محدد + سحب سيولة لنطاق محدد) - نفس الفحوصات المستخدمة أصلاً
بالبوت الحي (compute_mechanical_bias_anchor + compute_overnight_range
+ classify_sweep_or_run)، لا أداة جديدة مخترعة.
"""
import json
import logging
import sys
import datetime
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from ict_sessions import compute_overnight_range, ts_to_ny

brain = BrainCore()

SYMBOL = "ETH/USDT"
EXEC_TF = "15m"

full_data = brain.data_manager.get_ohlcv(SYMBOL, EXEC_TF, 3000, output_format="dict")
n = len(full_data["closes"])
print(f"إجمالي الشموع ({EXEC_TF}): {n}")
start_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][0]/1000, tz=datetime.timezone.utc)
end_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][-1]/1000, tz=datetime.timezone.utc)
print(f"النطاق: {start_dt} -> {end_dt}\n")

# نبني قائمة الأيام الفريدة (بتوقيت NY) ضمن نطاق بياناتنا
ny_dates = sorted(set(ts_to_ny(ts).date() for ts in full_data["timestamps"]))
print(f"عدد الأيام الفريدة (NY calendar): {len(ny_dates)}\n")

candidates = []

# لكل يوم NY، نفحص فقط لحظتين: افتتاح London KZ (02:00 NY) وافتتاح NY AM KZ (08:30 NY)
for day in ny_dates:
    for session_label, session_hour, session_minute in [
        ("LONDON_KZ_OPEN", 2, 0),
        ("NY_AM_KZ_OPEN", 8, 30),
    ]:
        # نبني الـtimestamp المستهدف لهذه اللحظة بتوقيت NY لنفس اليوم
        target_dt_ny = datetime.datetime.combine(day, datetime.time(session_hour, session_minute), tzinfo=ts_to_ny(full_data["timestamps"][0]).tzinfo)
        target_ts = int(target_dt_ny.timestamp() * 1000)

        # نجد أقرب شمعة فعلية متاحة عند/بعد هذه اللحظة مباشرة (بيانات حقيقية، لا اختراع)
        idx = None
        for i, ts in enumerate(full_data["timestamps"]):
            if ts >= target_ts:
                idx = i
                break
        if idx is None or idx < 150:
            continue  # لا بيانات كافية سابقة لهذه اللحظة (بداية/نهاية النافذة)

        # ⚠️ فقط البيانات حتى هذه اللحظة بالضبط (idx inclusive) - محاكاة
        # "ماذا لو كنا نحلل الآن فقط، بلا أي معرفة بالمستقبل"
        window_data = {
            "opens": full_data["opens"][:idx+1], "highs": full_data["highs"][:idx+1],
            "lows": full_data["lows"][:idx+1], "closes": full_data["closes"][:idx+1],
            "timestamps": full_data["timestamps"][:idx+1],
        }
        cur_ts = full_data["timestamps"][idx]

        # ── الخطوة 1: Daily Bias (حتمي ميكانيكياً، يُحسب "كأنه من فريم
        # Daily" - نستخدم نافذة أطول (خلال آخر 150+ شمعة 15m ~ 37 ساعة)
        # لتقريب استقرار قراءة الفريم اليومي، لا فريم 15m اللحظي الضيق) ──
        try:
            anchor = compute_mechanical_bias_anchor(window_data, lookback=250)
        except Exception:
            continue
        daily_bias = anchor.get("anchor_direction")
        if daily_bias not in ("BULLISH", "BEARISH"):
            continue

        # ── الخطوة 2: النطاق الليلي (Overnight Range) لنفس اليوم ──
        try:
            overnight = compute_overnight_range(window_data, cur_ts)
        except Exception:
            continue
        if not overnight.get("found"):
            continue

        # ── الخطوة 3: هل صار سحب سيولة حقيقي لهذا النطاق تحديداً، بعكس
        # اتجاه الانحياز (Judas Swing المتوقع) أو بنفس اتجاهه (استمرار)؟
        # نفحص كلا الطرفين - القاع والقمة - لأن مايكل نفسه يفحص "أياً من
        # الطرفين" حسب الاتجاه الفعلي للحركة (لا افتراض مسبق لأي طرف) ──
        range_high, range_low = overnight["range_high"], overnight["range_low"]
        sweep_low = classify_sweep_or_run(window_data, range_low, level_is_high=False,
                                            check_from_idx=None)
        sweep_high = classify_sweep_or_run(window_data, range_high, level_is_high=True,
                                             check_from_idx=None)

        genuine_sweep_found = None
        if sweep_low.get("found") and sweep_low.get("classification") == "GENUINE_REVERSAL_SWEEP":
            # سحب القاع = يتوقع صعود بعده (يطابق انحياز BULLISH)
            if daily_bias == "BULLISH":
                genuine_sweep_found = ("SSL_SWEPT_LOW", sweep_low)
        if sweep_high.get("found") and sweep_high.get("classification") == "GENUINE_REVERSAL_SWEEP":
            if daily_bias == "BEARISH":
                genuine_sweep_found = ("BSL_SWEPT_HIGH", sweep_high)

        if genuine_sweep_found:
            sweep_type, sweep_info = genuine_sweep_found
            dt = datetime.datetime.fromtimestamp(cur_ts/1000, tz=datetime.timezone.utc)
            candidates.append({
                "index": idx, "timestamp": cur_ts, "datetime_utc": dt.isoformat(),
                "ny_session_trigger": session_label,
                "mechanical_bias": daily_bias, "bias_strength": anchor.get("strength"),
                "overnight_range_high": range_high, "overnight_range_low": range_low,
                "sweep_type": sweep_type,
                "sweep_candle_index_from_end": sweep_info.get("candle_index_from_end"),
            })

print(f"=== إجمالي النقاط المرشحة (بمنهجية مايكل الحرفية - نطاق ليلي + وقت جلسة محدد + سحب مؤكد): {len(candidates)} ===\n")
for c in candidates:
    print(f"  [{c['index']}] {c['datetime_utc']} ({c['ny_session_trigger']})  bias={c['mechanical_bias']}({c['bias_strength']})  sweep={c['sweep_type']}")

with open("/tmp/last_month_michael_candidates.json", "w") as f:
    json.dump(candidates, f, indent=2, default=str)
