# -*- coding: utf-8 -*-
"""
scan_last_month_michael_style_v2.py
════════════════════════════════════════════════════════════════════
تصحيح جذري (بعد بحث خارجي مستقل إضافي بطلب صريح من المستخدم: "نحنا
كريبتو مو فوركس - كيف بيأثر افتتاح لندن ونيويورك عالتحليل بما إنه
كريبتو؟"):

⚠️ الاكتشاف الحاسم (مصدر متخصص بالضبط: ictkillzone.com "ICT Concepts
for Crypto (BTC/ETH)"): "London open... is meaningless for BTC
because there is no institutional desk in crypto that closes for
the night and reopens at 2 AM." - نافذة London الفوركسية الحرفية
**لا تنطبق على الكريبتو إطلاقاً** (لم يكن يجدر استخدامها بالنسخة
السابقة من هذه الأداة - كانت 7 من 8 نقاط بنيت عليها خطأً).

البديل الصحيح المؤكَّد بنفس المصدر (وهو أصلاً EXECUTABLE_SESSIONS
الموثّق بمشروعنا): "traders use equity-hours overlap windows
(8:30-11 AM ET and 1:30-4 PM ET) as BTC's highest-probability
trading windows... because large institutional participants (hedge
funds, ETF operators) become fully active at the NYSE open" - أي
النافذتان NY_AM_KILLZONE وNY_PM_KILLZONE (الموجودتان أصلاً بـ
ict_sessions.py)، لا نافذة London.

نفس المصدر يؤكد أيضاً: "The more useful BTC range is the overnight
low/high (midnight-8:30 AM ET) measured fresh each day" - يطابق
حرفياً compute_overnight_range() الموجودة أصلاً بمشروعنا (لا تغيير
هنا - كانت صحيحة من البداية).

⚠️ صدق منهجي: لا فحص "هل تحرك السعر فعلاً بعدها" بهذه المرحلة - فقط
معيار مايكل الميكانيكي المُصحَّح (bias + نافذة تنفيذ كريبتو-صحيحة +
سحب سيولة حقيقي لنطاق الليل).
"""
import json
import logging
import sys
import datetime
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from ict_sessions import compute_overnight_range, ts_to_ny

brain = BrainCore()

SYMBOL = "ETH/USDT"
EXEC_TF = "15m"

full_data = brain.data_manager.get_ohlcv(SYMBOL, EXEC_TF, 3000, output_format="dict")
n = len(full_data["closes"])
print(f"إجمالي الشموع ({EXEC_TF}): {n}")
start_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][0]/1000, tz=datetime.timezone.utc)
end_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][-1]/1000, tz=datetime.timezone.utc)
print(f"النطاق: {start_dt} -> {end_dt}\n")

ny_dates = sorted(set(ts_to_ny(ts).date() for ts in full_data["timestamps"]))
print(f"عدد الأيام الفريدة (NY calendar): {len(ny_dates)}\n")

candidates = []

# ⚠️ التصحيح: فقط النافذتان الموثّقتان فعلياً للكريبتو (لا London)
# NY_AM_KILLZONE = 08:30-11:00 NY (الأقوى - تداخل NQ/ES)
# NY_PM_KILLZONE = 13:30-16:00 NY (ثانوية)
for day in ny_dates:
    for session_label, session_hour, session_minute in [
        ("NY_AM_KZ_OPEN", 8, 30),
        ("NY_PM_KZ_OPEN", 13, 30),
    ]:
        target_dt_ny = datetime.datetime.combine(
            day, datetime.time(session_hour, session_minute),
            tzinfo=ts_to_ny(full_data["timestamps"][0]).tzinfo
        )
        target_ts = int(target_dt_ny.timestamp() * 1000)

        idx = None
        for i, ts in enumerate(full_data["timestamps"]):
            if ts >= target_ts:
                idx = i
                break
        if idx is None or idx < 150:
            continue

        window_data = {
            "opens": full_data["opens"][:idx+1], "highs": full_data["highs"][:idx+1],
            "lows": full_data["lows"][:idx+1], "closes": full_data["closes"][:idx+1],
            "timestamps": full_data["timestamps"][:idx+1],
        }
        cur_ts = full_data["timestamps"][idx]

        try:
            anchor = compute_mechanical_bias_anchor(window_data, lookback=250)
        except Exception:
            continue
        daily_bias = anchor.get("anchor_direction")
        if daily_bias not in ("BULLISH", "BEARISH"):
            continue

        try:
            overnight = compute_overnight_range(window_data, cur_ts)
        except Exception:
            continue
        if not overnight.get("found"):
            continue

        range_high, range_low = overnight["range_high"], overnight["range_low"]
        sweep_low = classify_sweep_or_run(window_data, range_low, level_is_high=False, check_from_idx=None)
        sweep_high = classify_sweep_or_run(window_data, range_high, level_is_high=True, check_from_idx=None)

        genuine_sweep_found = None
        if sweep_low.get("found") and sweep_low.get("classification") == "GENUINE_REVERSAL_SWEEP":
            if daily_bias == "BULLISH":
                genuine_sweep_found = ("SSL_SWEPT_LOW", sweep_low)
        if sweep_high.get("found") and sweep_high.get("classification") == "GENUINE_REVERSAL_SWEEP":
            if daily_bias == "BEARISH":
                genuine_sweep_found = ("BSL_SWEPT_HIGH", sweep_high)

        if genuine_sweep_found:
            sweep_type, sweep_info = genuine_sweep_found
            dt = datetime.datetime.fromtimestamp(cur_ts/1000, tz=datetime.timezone.utc)
            candidates.append({
                "index": idx, "timestamp": cur_ts, "datetime_utc": dt.isoformat(),
                "ny_session_trigger": session_label,
                "mechanical_bias": daily_bias, "bias_strength": anchor.get("strength"),
                "overnight_range_high": range_high, "overnight_range_low": range_low,
                "sweep_type": sweep_type,
                "sweep_candle_index_from_end": sweep_info.get("candle_index_from_end"),
            })

print(f"=== إجمالي النقاط المرشحة (NY AM + NY PM فقط - الصحيح للكريبتو): {len(candidates)} ===\n")
for c in candidates:
    print(f"  [{c['index']}] {c['datetime_utc']} ({c['ny_session_trigger']})  bias={c['mechanical_bias']}({c['bias_strength']})  sweep={c['sweep_type']}")

with open("/tmp/last_month_michael_candidates_v2.json", "w") as f:
    json.dump(candidates, f, indent=2, default=str)
