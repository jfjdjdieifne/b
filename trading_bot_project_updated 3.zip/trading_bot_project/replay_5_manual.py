# -*- coding: utf-8 -*-
"""
replay_5_manual.py
════════════════════════════════════════════════════════════════════
يعيد تحليل نفس الخمسة نقاط الأصلية بالضبط (بتواريخها الثابتة، بمعزل
عن انزياح نافذة "آخر شهر" الحية) بمحرك multi_pass_analysis الكامل،
بعد كل التعديلات الثلاثة هذه الجلسة (محرك الإبطال + Breaker Block +
إصلاح فجوة الرفض المزدوجة) - لمقارنة قبل/بعد مباشرة بطلب المستخدم.

نفس آلية analyze_discovered_setups.py بالضبط، فقط تُقرأ القائمة من
/tmp/manual_5_replay.json بدل /tmp/last_month_final_unique.json.
"""
import sys, json, time, logging
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from multi_pass_analysis import MultiPassAnalysis
from human_trades_backtest import compute_trade_outcome

SYMBOL = "ETH/USDT"
TIMEFRAME = "5m"

with open("/tmp/manual_5_replay.json") as f:
    all_candidates = json.load(f)

brain = BrainCore()
mpa = MultiPassAnalysis(brain)

results = []
for i, cand in enumerate(all_candidates):
    end_ts = cand["timestamp"]
    print(f"\n{'='*80}\n[{i+1}/{len(all_candidates)}] تحليل النقطة: {cand['datetime_utc']}\n{'='*80}")

    try:
        entry_data = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, TIMEFRAME, end_ts, limit=300)
        entry_ind = {}
        try:
            entry_ind = brain.ta.compute_all(entry_data) if hasattr(brain, "ta") else {}
        except Exception:
            entry_ind = {}

        mtf_data = {"entry": entry_data}
        mtf_indicators = {"entry": entry_ind}

        t0 = time.time()
        analysis = mpa.run(SYMBOL, TIMEFRAME, mtf_data, mtf_indicators, is_backtest=True, end_ts=end_ts)
        elapsed = time.time() - t0

        signal = analysis.get("signal")
        entry = analysis.get("entry")
        sl = analysis.get("stop_loss")
        tp = analysis.get("tp")
        narrative = (analysis.get("narrative") or "")[:300]

        print(f"النتيجة: signal={signal} entry={entry} sl={sl} tp={tp} (استغرق {elapsed:.1f}s)")
        print(f"السرد: {narrative}")

        outcome = None
        if signal in ("BUY", "SELL", "BUY_LIMIT", "SELL_LIMIT") and all(
            isinstance(v, (int, float)) for v in (entry, sl, tp)
        ):
            is_short = signal in ("SELL", "SELL_LIMIT")
            outcome = compute_trade_outcome(brain, SYMBOL, end_ts, entry, sl, tp, is_short)
            print(f"النتيجة الفعلية (بعد التحليل فقط): {outcome.get('outcome')} pnl={outcome.get('pnl_pct')}")

        results.append({
            "candidate": cand, "signal": signal, "entry": entry, "sl": sl, "tp": tp,
            "narrative": narrative, "elapsed_sec": elapsed, "outcome": outcome,
            "full_analysis": {k: v for k, v in analysis.items() if k != "multi_pass_stage_log"},
            "stage_log": analysis.get("multi_pass_stage_log", {}),
        })
    except Exception as e:
        print(f"خطأ: {e}")
        results.append({"candidate": cand, "error": str(e)})

    with open("/tmp/manual_5_replay_results.json", "w") as f:
        json.dump(results, f, indent=2, default=str)

print(f"\n\n=== انتهى - {len(results)} نقطة محلَّلة ===")
