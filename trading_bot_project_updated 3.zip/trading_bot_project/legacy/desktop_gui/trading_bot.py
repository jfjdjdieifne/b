# -*- coding: utf-8 -*-
# TradingBot: البوت الرئيسي الذكي
"""
⚠️ إصلاح خطأ حقيقي (تنظيف كود): هذا الملف كان "كوداً ميتاً" بالكامل -
لا يستدعيه أي ملف آخر بالمشروع، ويستخدم واجهات لم تعد موجودة إطلاقاً
بعد إعادة هيكلة المشروع:
  - self.chat.receive_message() / send_message() -> ChatInterface
    الحالي عنده فقط chat(user_message)
  - self.brain.analyze_market() -> BrainCore الحالي عنده full_analysis()
  - self.brain.signal_generator -> غير موجود؛ القرار يصدر مباشرة من
    الـ AI ضمن full_analysis() نفسها (لا محرك إشارة منفصل بعد الآن)

تم إعادة كتابته ليتوافق مع BrainCore/ChatInterface الحاليين فعلياً،
كواجهة بسيطة اختيارية (main.py يبقى الواجهة الرئيسية الموصى بها).
"""
import logging
from brain_core import BrainCore
from chat_interface import ChatInterface


class TradingBot:
    """
    واجهة مبسّطة تجمع BrainCore (التحليل) وChatInterface (المحادثة).
    """
    def __init__(self):
        self.logger = logging.getLogger("TradingBot")
        self.brain = BrainCore()
        self.chat = ChatInterface()
        self.logger.info("TradingBot initialized.")

    def run(self, symbol=None, timeframe=None):
        """
        تشغيل تحليل كامل واحد + رد محادثة يلخّصه.

        Args:
            symbol: الزوج (افتراضي من Config.DEFAULT_SYMBOL)
            timeframe: الفريم (افتراضي من Config.DEFAULT_TIMEFRAME)
        """
        self.logger.info("TradingBot running...")
        analysis = self.brain.full_analysis(symbol=symbol, timeframe=timeframe)

        ai = analysis.get("ai_analysis", {})
        if "error" in analysis:
            summary = f"تعذّر التحليل: {analysis['error']}"
        else:
            summary = (
                f"تحليل {analysis.get('symbol')} ({analysis.get('timeframe')}):\n"
                f"الإشارة: {ai.get('signal', 'N/A')} | الثقة: {ai.get('confidence', 'N/A')}%\n"
                f"السرد: {ai.get('narrative', '')[:300]}"
            )

        reply = self.chat.chat(summary)
        return {"analysis": analysis, "chat_reply": reply}