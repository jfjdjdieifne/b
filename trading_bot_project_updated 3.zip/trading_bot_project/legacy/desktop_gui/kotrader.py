# -*- coding: utf-8 -*-
"""Kotrader v7 — ICT/SMC Trading Bot — Desktop App"""
import os,sys,json,time,threading,re,traceback
from datetime import datetime
os.environ.pop("HTTP_PROXY",None);os.environ.pop("HTTPS_PROXY",None)
os.environ.pop("http_proxy",None);os.environ.pop("https_proxy",None)
BASE_DIR=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,BASE_DIR)
import tkinter as tk
from tkinter import ttk,messagebox,filedialog,Menu
import requests
from config import Config
C={'bg':'#0e1219','surface':'#161c26','card':'#1c2433','border':'#2d3648','accent':'#00e6b8','accent2':'#8b7cf7','danger':'#ff4d5a','warning':'#ffa84d','info':'#4da6ff','text':'#e8eef5','text2':'#9aa5b8','text3':'#5c6a82','gold':'#f0c040'}
LOG_DIR=os.path.join(BASE_DIR,'logs');os.makedirs(LOG_DIR,exist_ok=True)
def _log(msg,tag='GEN'):
    ts=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    with open(os.path.join(LOG_DIR,f'kotrader_{datetime.now().strftime("%Y%m%d")}.log'),'a',encoding='utf-8')as f:f.write(f'[{ts}][{tag}]{msg}\n')
F={'mono':('Consolas',11),'monos':('Consolas',10),'ui':('Segoe UI',10),'uib':('Segoe UI',10,'bold'),'uism':('Segoe UI',9),'title':('Segoe UI',18,'bold'),'h2':('Segoe UI',12,'bold'),'stat':('Segoe UI',22,'bold')}

class Card(tk.Frame):
    def __init__(self,p,title=None,**kw):
        super().__init__(p,bg=C['card'],highlightbackground=C['border'],highlightthickness=1,padx=18,pady=14,**kw)
        if title:tk.Label(self,text=title,font=F['h2'],bg=C['card'],fg=C['text']).pack(anchor='w',pady=(0,10))

class StatBox(tk.Frame):
    def __init__(self,p,title,value='...',color=C['accent'],**kw):
        super().__init__(p,bg=C['surface'],padx=16,pady=12,**kw)
        self.val=tk.Label(self,text=str(value),font=F['stat'],bg=C['surface'],fg=color);self.val.pack()
        tk.Label(self,text=title,font=F['uism'],bg=C['surface'],fg=C['text2']).pack(pady=(2,0))
    def set(self,v):self.val.configure(text=str(v))

class Btn(tk.Frame):
    def __init__(self,p,text,cmd=None,color=C['accent'],**kw):
        super().__init__(p,bg=color,cursor='hand2',**kw);self._c=color;self._cmd=cmd
        t='#000'if color in[C['accent'],C['warning'],C['gold']]else'#fff'
        self._l=tk.Label(self,text=text,font=('Segoe UI',9,'bold'),bg=color,fg=t,padx=14,pady=7);self._l.pack()
        for w in[self,self._l]:
            w.bind('<Button-1>',lambda e:cmd and cmd())
            w.bind('<Enter>',lambda e,s=self:s._h(True));w.bind('<Leave>',lambda e,s=self:s._h(False))
    def _h(self,e):
        c='#00c9a0'if self._c==C['accent']else('#7567e8'if self._c==C['accent2']else self._c)
        self.configure(bg=c if e else self._c);self._l.configure(bg=c if e else self._c)
    def set(self,text):self._l.configure(text=text)

class Console(tk.Frame):
    def __init__(self,p,height=10,**kw):
        super().__init__(p,bg=C['surface'],**kw)
        self.t=tk.Text(self,bg=C['surface'],fg=C['text'],font=F['monos'],insertbackground=C['accent'],relief='flat',border=0,padx=12,pady=10,wrap='word',height=height)
        sb=ttk.Scrollbar(self,orient='vertical',command=self.t.yview);self.t.configure(yscrollcommand=sb.set)
        self.t.pack(side='left',fill='both',expand=True);sb.pack(side='right',fill='y')
        self.t.bind('<Control-c>',lambda e:self._cp())
        m=Menu(self.t,tearoff=0,bg=C['surface'],fg=C['text'],font=F['uism'])
        m.add_command(label="Copy",command=self._cp);m.add_command(label="Select All",command=lambda:self.t.tag_add('sel','1.0','end'))
        self.t.bind('<Button-3>',lambda e:m.tk_popup(e.x_root,e.y_root))
    def _cp(self):
        try:s=self.t.get('sel.first','sel.last');self.t.clipboard_clear();self.t.clipboard_append(s)
        except:pass
    def w(self,txt):
        self.t.configure(state='normal');self.t.insert('end',txt);self.t.see('end');self.t.configure(state='disabled')
    def clear(self):self.t.configure(state='normal');self.t.delete('1.0','end');self.t.configure(state='disabled')
    def set(self,txt):self.clear();self.w(txt+'\n')

class KotraderApp:
    def __init__(self,root):
        self.root=root;root.title("Kotrader - ICT/SMC Trading Bot");root.geometry("1320x850");root.minsize(1080,700);root.configure(bg=C['bg'])
        self.analyzing=False;self.testing=False;self.stop_test=False;self.chatting=False
        self.key_results={};self.selected_keys=set()
        self._build()

    def _build(self):
        self.sb=tk.Frame(self.root,bg=C['surface'],width=200);self.sb.pack(side='left',fill='y');self.sb.pack_propagate(False)
        lf=tk.Frame(self.sb,bg=C['surface'],height=85);lf.pack(fill='x',pady=(16,8));lf.pack_propagate(False)
        tk.Label(lf,text="KOTRADER",font=('Segoe UI',12,'bold'),bg=C['surface'],fg=C['accent']).pack()
        tk.Label(lf,text="ICT/SMC Trading Bot",font=('Segoe UI',7),bg=C['surface'],fg=C['text3']).pack()
        tk.Frame(self.sb,bg=C['border'],height=1).pack(fill='x',padx=14,pady=6)
        self._nb={}
        for k,lbl in[('dashboard','Dashboard'),('keys','My Keys'),('analysis','Analysis'),('backtest','Backtest'),('finder','Find Setups'),('training','Training'),('chat','Chat'),('settings','Settings')]:
            b=tk.Frame(self.sb,bg=C['surface'],cursor='hand2',height=36);b.pack(fill='x',padx=8,pady=1);b.pack_propagate(False)
            inner=tk.Frame(b,bg=C['surface']);inner.place(relx=0.5,rely=0.5,anchor='center',width=180,height=30)
            ll=tk.Label(inner,text=f"    {lbl}",font=F['uism'],bg=C['surface'],fg=C['text2'],anchor='w');ll.pack(fill='both',expand=True,padx=10)
            self._nb[k]=(b,inner,ll)
            for w in[b,inner,ll]:w.bind('<Button-1>',lambda e,key=k:self._nav(key))
        tk.Frame(self.sb,bg=C['border'],height=1).pack(fill='x',padx=14,pady=4)
        self.status_lbl=tk.Label(self.sb,text="Ready",font=('Segoe UI',8),bg=C['surface'],fg=C['accent']);self.status_lbl.pack(side='bottom',pady=14)
        self.main=tk.Frame(self.root,bg=C['bg']);self.main.pack(side='left',fill='both',expand=True)
        self.hdr=tk.Frame(self.main,bg=C['bg'],height=50);self.hdr.pack(fill='x',padx=24,pady=(14,0));self.hdr.pack_propagate(False)
        self.htitle=tk.Label(self.hdr,text="Dashboard",font=F['title'],bg=C['bg'],fg=C['text']);self.htitle.pack(side='left')
        self.hsub=tk.Label(self.hdr,text="",font=F['uism'],bg=C['bg'],fg=C['text2']);self.hsub.pack(side='left',padx=(10,0),pady=(7,0))
        self.run_badge=tk.Label(self.hdr,text="",font=('Segoe UI',9,'bold'),bg=C['bg'],fg=C['gold']);self.run_badge.pack(side='right',pady=(6,0))
        self.content=tk.Frame(self.main,bg=C['bg']);self.content.pack(fill='both',expand=True,padx=24,pady=14)
        self.tabs={}
        self._t_dash();self._t_keys();self._t_analysis();self._t_backtest();self._t_finder();self._t_training();self._t_chat();self._t_settings()
        self._nav('dashboard')

    def _nav(self,key):
        self.active=key
        ts={'dashboard':'Overview','keys':'Cloudflare Management','analysis':'ICT Top-Down Analysis','backtest':'Historical Backtest','finder':'Discover Setups','training':'Custom Trades','chat':'AI Chat (Gemma-4)','settings':'Configuration'}
        self.htitle.configure(text=key.title());self.hsub.configure(text=ts.get(key,''))
        self._ub()
        for k,(b,i,ll)in self._nb.items():
            if k==key:i.configure(bg=C['accent']);ll.configure(bg=C['accent'],fg='#000')
            else:i.configure(bg=C['surface']);ll.configure(bg=C['surface'],fg=C['text2'])
        for k,f in self.tabs.items():f.pack_forget()
        if key in self.tabs:self.tabs[key].pack(fill='both',expand=True)
        if key=='dashboard':self._rd()
        elif key=='keys':self._rkt()

    def _ub(self):
        if self.analyzing:self.run_badge.configure(text="  ANALYSING...  ",fg=C['gold'])
        elif self.chatting:self.run_badge.configure(text="  CHAT ACTIVE  ",fg=C['info'])
        elif self.testing:self.run_badge.configure(text="  TESTING KEYS  ",fg=C['warning'])
        else:self.run_badge.configure(text="")

    # ═══ DASHBOARD ═══
    def _t_dash(self):
        f=tk.Frame(self.content,bg=C['bg']);sr=tk.Frame(f,bg=C['bg']);sr.pack(fill='x',pady=(0,12))
        self.dk=StatBox(sr,'Cloudflare Keys');self.dk.pack(side='left',padx=(0,8),fill='x',expand=True)
        self.da=StatBox(sr,'Accounts');self.da.pack(side='left',padx=8,fill='x',expand=True)
        self.dm=StatBox(sr,'Model',color=C['accent2']);self.dm.pack(side='left',padx=8,fill='x',expand=True)
        self.db=StatBox(sr,'Knowledge',color=C['info']);self.db.pack(side='left',padx=(8,0),fill='x',expand=True)
        c=Card(f,"Quick Actions");c.pack(fill='x',pady=(0,10));ar=tk.Frame(c,bg=C['card']);ar.pack(fill='x')
        Btn(ar,'BTC/USDT',lambda:self._qa('BTC/USDT','1h')).pack(side='left',padx=(0,6))
        Btn(ar,'ETH/USDT',lambda:self._qa('ETH/USDT','1h')).pack(side='left',padx=6)
        Btn(ar,'Test Keys',lambda:self._nav('keys'),C['accent2']).pack(side='left',padx=6)
        Btn(ar,'Quick Scan',self._qs,C['info']).pack(side='left',padx=6)
        c2=Card(f,"Session Log");c2.pack(fill='both',expand=True);self._do=Console(c2,14);self._do.pack(fill='both',expand=True);self._do.w("Kotrader v7 ready.\n")
        self.tabs['dashboard']=f
    def _rd(self):
        try:
            cf=Config.CLOUDFLARE_ACCOUNTS;u=len({a['account_id']for a in cf})
            self.dk.set(len(cf));self.da.set(u);self.dm.set((Config.CLOUDFLARE_MODEL or'').split('/')[-1][:14])
            kb=Config.KNOWLEDGE_FILE;self.db.set(f"{os.path.getsize(kb)/1024:.0f}KB"if os.path.exists(kb)else'N/A')
        except:pass

    # ═══ KEYS ═══
    def _t_keys(self):
        f=tk.Frame(self.content,bg=C['bg'])
        c=Card(f,"Cloudflare Keys - Zero-Quota Testing");c.pack(fill='x',pady=(0,10))
        br=tk.Frame(c,bg=C['card']);br.pack(fill='x')
        self.btn_ta=Btk(Btn,br,'Test All Keys',self._st_a,C['accent']);self.btn_ta.pack(side='left',padx=(0,6))
        Btn(br,'Test Selected',self._tse,C['accent2']).pack(side='left',padx=6)
        Btn(br,'Add Keys',self._akd,C['accent2']).pack(side='left',padx=6)
        Btn(br,'Refresh',self._rkt,C['info']).pack(side='left',padx=6)
        self.ksl=tk.Label(br,text="",font=F['uism'],bg=C['card'],fg=C['text2']);self.ksl.pack(side='right',padx=10)
        self.kpf=tk.Frame(f,bg=C['bg']);self.kpb=ttk.Progressbar(self.kpf,mode='determinate');self.kpb.pack(fill='x')
        self.kpl=tk.Label(self.kpf,text="",font=('Segoe UI',8),bg=C['bg'],fg=C['text2']);self.kpl.pack(anchor='w')
        c2=Card(f,"Live Output");c2.pack(fill='x',pady=(8,8));self._ko=Console(c2,5);self._ko.pack(fill='x')
        c3=Card(f,"Key Inventory - Click Sel column to select");c3.pack(fill='both',expand=True)
        tf=tk.Frame(c3,bg=C['card']);tf.pack(fill='both',expand=True)
        cols=('#','Account ID','Token','Status','Speed','Quota','Sel')
        self._kt=ttk.Treeview(tf,columns=cols,show='headings',height=10)
        for cn in cols:self._kt.heading(cn,text=cn,anchor='w')
        self._kt.column('#',width=30,anchor='center');self._kt.column('Account ID',width=170);self._kt.column('Token',width=170)
        self._kt.column('Status',width=110,anchor='center');self._kt.column('Speed',width=65,anchor='center')
        self._kt.column('Quota',width=85,anchor='center');self._kt.column('Sel',width=40,anchor='center')
        vs=ttk.Scrollbar(tf,orient='vertical',command=self._kt.yview);self._kt.configure(yscrollcommand=vs.set)
        self._kt.pack(side='left',fill='both',expand=True);vs.pack(side='right',fill='y')
        self._kt.tag_configure('ok',foreground=C['accent']);self._kt.tag_configure('fail',foreground=C['danger']);self._kt.tag_configure('testing',foreground=C['warning'])
        self._kt.bind('<Button-1>',self._okc);self._rkt()
        self.tabs['keys']=f
    def _rkt(self):
        self._kt.delete(*self._kt.get_children());accs=Config.CLOUDFLARE_ACCOUNTS
        for i,a in enumerate(accs):
            aid=a['account_id'];si=aid[:10]+'...';to=a['token'][:8]+'...'+a['token'][-4:]
            st=self.key_results.get(aid,'Not tested');sp=self.key_results.get(aid+'_speed','');q=self.key_results.get(aid+'_quota','?')
            tag='ok'if'OK'in str(st)else('fail'if'FAIL'in str(st)else('testing'if'...'in str(st)else''))
            sel='V'if aid in self.selected_keys else'-'
            self._kt.insert('','end',values=(i+1,si,to,st,sp,q,sel),tags=(tag,))
        ok=sum(1 for v in self.key_results.values()if'OK'in str(v));self.ksl.configure(text=f"OK: {ok}/{len(accs)}")
    def _okc(self,ev):
        col=self._kt.identify_column(ev.x)
        if col!='#7':return
        item=self._kt.identify_row(ev.y);vals=self._kt.item(item,'values')
        if vals:
            idx=int(vals[0])-1;accs=Config.CLOUDFLARE_ACCOUNTS
            if idx<len(accs):aid=accs[idx]['account_id']
            if aid in self.selected_keys:self.selected_keys.discard(aid)
            else:self.selected_keys.add(aid);self._rkt()
    def _st_a(self):
        if self.testing:return
        self.testing=True;self.stop_test=False;self.key_results.clear();self.selected_keys.clear()
        self.btn_ta.set('Testing...');self._ub();self.status_lbl.configure(text='Testing keys...',fg=C['warning'])
        threading.Thread(target=lambda:self._run_test(Config.CLOUDFLARE_ACCOUNTS),daemon=True).start()
    def _tse(self):
        if not self.selected_keys:messagebox.showinfo("Select","Click Sel column first.");return
        if self.testing:return
        self.testing=True;self.stop_test=False
        ids=list(self.selected_keys);accs=[a for a in Config.CLOUDFLARE_ACCOUNTS if a['account_id']in ids]
        self.btn_ta.set('Testing...');self._ub();self.status_lbl.configure(text='Testing keys...',fg=C['warning'])
        threading.Thread(target=lambda:self._run_test(accs),daemon=True).start()
    def _run_test(self,accs):
        total=len(accs)
        def u(fn):self.root.after(0,fn)
        u(lambda:[self.kpf.pack(fill='x',pady=(4,0)),self.kpb.configure(maximum=total,value=0),self._ko.clear(),self._ko.w(f"Testing {total} keys...\n")])
        for i,acc in enumerate(accs):
            if self.stop_test:break
            aid=acc['account_id'];token=acc['token'];n=i+1
            u(lambda a=aid:self.key_results.update({a:'Testing...',a+'_speed':'',a+'_quota':'?'}))
            u(self._rkt)
            u(lambda a=aid,n=n,t=total:self.kpl.configure(text=f"Testing {n}/{t}: {a[:12]}..."))
            u(lambda n=n,t=total,a=aid:self._ko.w(f"[{n:2d}/{t}] {a[:12]}... -> "))
            try:
                t0=time.time()
                r=requests.get(f"https://api.cloudflare.com/client/v4/accounts/{aid}",headers={"Authorization":f"Bearer {token}"},timeout=10)
                ms=int((time.time()-t0)*1000)
                if r.status_code==200:
                    quota='?'
                    try:
                        t2=time.time()
                        r2=requests.post(f"https://api.cloudflare.com/client/v4/accounts/{aid}/ai/run/@cf/google/gemma-4-26b-a4b-it",headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"},json={"prompt":"Say OK","max_tokens":3},timeout=12)
                        quota='OK'if r2.status_code==200 else('QUOTA'if r2.status_code==429 else str(r2.status_code))
                    except:quota='?'
                    u(lambda a=aid,m=ms,q=quota:[self.key_results.update({a:'OK',a+'_speed':f'{m}ms',a+'_quota':q}),self._ko.w(f'OK ({ms}ms) Quota:{q}\n')])
                else:
                    u(lambda a=aid,c=r.status_code,m=ms:[self.key_results.update({a:f'FAIL {c}',a+'_speed':f'{m}ms',a+'_quota':'-'}),self._ko.w(f'FAIL HTTP {c}\n')])
            except requests.Timeout:u(lambda a=aid:[self.key_results.update({a:'FAIL TIMEOUT',a+'_speed':'10s+',a+'_quota':'-'}),self._ko.w('TIMEOUT\n')])
            except Exception as e:u(lambda a=aid,em=str(e)[:40]:[self.key_results.update({a:'FAIL ERR',a+'_speed':'',a+'_quota':'-'}),self._ko.w(f'ERR {em}\n')])
            u(lambda v=i+1:self.kpb.configure(value=v));u(self._rkt);time.sleep(0.15)
        okc=sum(1 for v in self.key_results.values()if'OK'in str(v))
        # Load key tracker for extra info
        tracker_info=''
        try:
            from ai_client import AIClient;ai=AIClient();good=ai.get_known_good_keys()
            if good:tracker_info=f'\n{len(good)} keys have successfully served AI responses (tracked in data/cf_ai_ok.json)\n'
        except:pass
        u(lambda o=okc,t=total,ti=tracker_info:[self._ko.w(f'\n{"="*50}\nResult: {o}/{t} Active | {t-o} Failed\nNote: Quota="OK"=has neurons, "QUOTA"=daily limit hit\n{ti}\n'),self.kpf.pack_forget(),self.btn_ta.set('Test All Keys')])
        self.testing=False;u(lambda:[self._ub(),self.status_lbl.configure(text='Ready',fg=C['accent'])])
    def _akd(self):
        d=tk.Toplevel(self.root,bg=C['card']);d.title("Add Keys");d.geometry("530x340");d.transient(self.root);d.grab_set()
        tk.Label(d,text="Account ID:Token (one per line):",font=F['ui'],bg=C['card'],fg=C['text']).pack(padx=20,pady=(16,8),anchor='w')
        tx=tk.Text(d,bg=C['surface'],fg=C['text'],font=F['monos'],insertbackground=C['accent'],relief='flat',height=9,padx=10,pady=10);tx.pack(fill='both',expand=True,padx=20,pady=4)
        def add():
            raw=tx.get('1.0','end-1c').strip()
            if not raw:messagebox.showwarning("Empty","Paste keys.",parent=d);return
            pairs=[]
            for ln in raw.split('\n'):
                ln=ln.strip()
                if':'in ln:a,tok=ln.split(':',1);a,tok=a.strip(),tok.strip()
                if a and tok:pairs.append(f"{a}:{tok}")
            if not pairs:messagebox.showwarning("Error","No valid pairs.",parent=d);return
            ep=os.path.join(BASE_DIR,'.env')
            with open(ep,'r',encoding='utf-8')as fh:env=fh.read()
            ns=','.join(pairs)
            if'CLOUDFLARE_ACCOUNTS='in env:env=env.replace('CLOUDFLARE_ACCOUNTS=',f'CLOUDFLARE_ACCOUNTS={ns},')
            else:env+=f'\nCLOUDFLARE_ACCOUNTS={ns}\n'
            with open(ep,'w',encoding='utf-8')as fh:fh.write(env)
            messagebox.showinfo("Done",f"Added {len(pairs)}. Restart Kotrader.",parent=d);d.destroy()
        Btn(d,'Add to Project',add).pack(pady=12)

    # ═══ ANALYSIS ═══
    def _t_analysis(self):
        f=tk.Frame(self.content,bg=C['bg'])
        c=Card(f,"ICT Top-Down Analysis - Weekly>Daily>4H>1H>Entry TF");c.pack(fill='x',pady=(0,10))
        cr=tk.Frame(c,bg=C['card']);cr.pack(fill='x')
        tk.Label(cr,text="Symbol:",font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(0,4))
        self.asym=ttk.Combobox(cr,values=['BTC/USDT','ETH/USDT','SOL/USDT','BNB/USDT','XRP/USDT','DOGE/USDT','ADA/USDT','AVAX/USDT','LINK/USDT','DOT/USDT','OTHER...'],width=12,state='readonly');self.asym.set('BTC/USDT');self.asym.pack(side='left',padx=(0,4))
        self.aother=tk.Entry(cr,bg=C['surface'],fg=C['text'],font=F['uism'],insertbackground=C['accent'],relief='flat',width=10);self.aother.insert(0,'custom');self.aother.bind('<FocusIn>',lambda e:self.aother.delete(0,'end')if'custom'in self.aother.get()else None)
        tk.Label(cr,text="TF:",font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(10,4))
        self.atf=ttk.Combobox(cr,values=['5m','15m','30m','1h','4h'],width=5,state='readonly');self.atf.set('15m');self.atf.pack(side='left',padx=(0,10))
        tk.Label(cr,text="Key:",font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(0,4))
        self.akey=ttk.Combobox(cr,values=['All (Random)'],width=16,state='readonly');self.akey.set('All (Random)');self.akey.pack(side='left',padx=(0,10))
        self._pk();self.btn_a=Btk(Btn,cr,'Analyze',self._ra);self.btn_a.pack(side='left',padx=(6,6))
        Btn(cr,'Quick Scan',self._qs,C['info']).pack(side='left')
        self.apf=tk.Frame(f,bg=C['bg'])
        c2=Card(f,"Analysis Report");c2.pack(fill='both',expand=True);self._ao=Console(c2,18);self._ao.pack(fill='both',expand=True)
        self.tabs['analysis']=f
    def _pk(self):
        accs=Config.CLOUDFLARE_ACCOUNTS;vals=['All (Random)']
        try:
            from ai_client import AIClient
            ai=AIClient();good=ai.get_known_good_keys()
        except:good=[]
        for i,a in enumerate(accs):
            aid=a['account_id'];st=self.key_results.get(aid,'?')
            ai_ok='AI' if aid in good else('?')
            ok='(OK)'if'OK'in str(st)else('(?)'if'?'in str(st)else'(X)')
            vals.append(f'{ok} {ai_ok} Key #{i+1}: {aid[:8]}...')
        self.akey['values']=vals
    def _gs(self):s=self.asym.get();return self.aother.get().strip()if s=='OTHER...'else s
    def _ra(self):
        if self.analyzing:return
        sym=self._gs();tf=self.atf.get()
        self.analyzing=True;self.btn_a.set('Running...');self._ub();self.status_lbl.configure(text='Analysing...',fg=C['gold'])
        self._ao.clear();self._ao.w(f'KOTRADER ANALYSIS\nSymbol: {sym}  Timeframe: {tf}\nStarted: {datetime.now().strftime("%H:%M:%S")}\n{"="*60}\n\n')
        self.apf.pack(fill='x',pady=(4,4))
        self.apb=ttk.Progressbar(self.apf,mode='indeterminate');self.apb.pack(fill='x');self.apb.start(10)
        self.apl=tk.Label(self.apf,text="",font=('Segoe UI',9,'bold'),bg=C['bg'],fg=C['gold']);self.apl.pack(anchor='w',pady=(4,2))
        threading.Thread(target=self._ra_thread,args=(sym,tf),daemon=True).start()
    def _ra_thread(self,sym,tf):
        u=lambda fn:self.root.after(0,fn);start=time.time()
        try:
            from brain_core import BrainCore
            u(lambda:self.apl.configure(text='[1/6] Fetching OHLCV data from OKX...'))
            u(lambda:self._ao.w('  [1/6] Fetching OHLCV data from OKX exchange...\n'));time.sleep(0.3)
            u(lambda:self.apl.configure(text='[2/6] Computing technical indicators...'))
            u(lambda:self._ao.w('  [2/6] Computing: EMA, RSI, MACD, ATR, swing points, S/R levels...\n'));time.sleep(0.3)
            u(lambda:self.apl.configure(text='[3/6] Loading ICT knowledge base...'))
            u(lambda:self._ao.w('  [3/6] Loading ICT knowledge base (22 sections, 730KB)...\n'));time.sleep(0.2)
            u(lambda:self.apl.configure(text='[4/6] Multi-Pass: Weekly > Daily > 4H > 1H > Entry...'))
            u(lambda:self._ao.w('  [4/6] Running Multi-Pass Top-Down Analysis:\n        STEP 1: WEEKLY - Building macro narrative...\n'))
            u(lambda:self._ao.w('        STEP 2: DAILY - Determining bias direction...\n'))
            u(lambda:self._ao.w('        STEP 3: 4H - Refining zones & structure...\n'))
            u(lambda:self._ao.w('        STEP 4: 1H - Tactical entry check...\n'))
            time.sleep(0.2)
            u(lambda:self.apl.configure(text='[5/6] Running AI analysis (Gemma-4-26b)...'))
            u(lambda:self._ao.w('\n  [5/6] AI Analysis running via Cloudflare Gemma-4-26b...\n        This may take 30-90 seconds. Please wait...\n'))
            b=BrainCore();r=b.full_analysis(sym,tf)
            elapsed=time.time()-start
            u(lambda:self.apl.configure(text=f'[6/6] Complete! ({elapsed:.0f}s / {elapsed/60:.1f} min)'))
            u(lambda:self._ao.w(f'\n  [6/6] Analysis complete in {elapsed:.0f}s ({elapsed/60:.1f} min)\n\n'))
            txt=self._fmt(r,sym,tf,elapsed);u(lambda:self._ao.w(txt))
            u(lambda:self._do.w(f'\n[{datetime.now().strftime("%H:%M")}] {sym} {tf} - Done in {elapsed:.0f}s\n'))
            _log(f'Analysis: {sym} {tf} - {elapsed:.0f}s','ANALYSIS')
        except Exception as e:
            elapsed=time.time()-start
            u(lambda:self._ao.w(f'\n  ERROR after {elapsed:.0f}s:\n  {e}\n{traceback.format_exc()}\n'))
            _log(f'Analysis error: {e}','ERROR')
        finally:
            u(lambda:[self.apb.stop(),self.apf.pack_forget(),self.btn_a.set('Analyze'),self.status_lbl.configure(text='Ready',fg=C['accent'])])
            self.analyzing=False;u(self._ub)
    def _fmt(self,r,sym,tf,elapsed):
        L=['='*60,f'  REPORT: {sym} ({tf})  |  Time: {elapsed:.0f}s ({elapsed/60:.1f} min)','='*60]
        if not isinstance(r,dict):L.append(str(r));return'\n'.join(L)
        ai=r.get('ai_analysis',{})
        if not isinstance(ai,dict):L.append(json.dumps(r,ensure_ascii=False,indent=2));return'\n'.join(L)
        sig=ai.get('signal','?');em_map={'BUY':'>>> BUY <<<','SELL':'>>> SELL <<<','HOLD':'--- HOLD ---'}
        L.append(f'\n  SIGNAL:    {em_map.get(sig,sig)}');L.append(f'  {"-"*50}')
        L.append(f'  Bias:          {ai.get("bias","?")}');L.append(f'  Confidence:    {ai.get("confidence","?")}%')
        L.append(f'  Market Regime: {ai.get("market_regime","?")}');L.append(f'  Macro Bias:    {ai.get("macro_bias","?")}')
        for label,key in[('NARRATIVE','narrative'),('ARCHETYPE','archetype'),('STRUCTURE','structure_analysis'),('REASONING','reasoning')]:
            v=ai.get(key,'')
            if v:L.append(f'\n  {"-"*50}\n  {label}:\n  {v}')
        if sig in('BUY','SELL'):
            L.append(f'\n  {"-"*50}');L.append(f'  Entry:         ${ai.get("entry","?")}')
            L.append(f'  Stop Loss:     ${ai.get("stop_loss","?")}');L.append(f'  Take Profit:   ${ai.get("tp","?")}')
        bos=ai.get('bos_reconciliation','')
        if bos:L.append(f'\n  {"-"*50}\n  BOS CHECK:\n  {bos}')
        vs=r.get('verification_score')
        if vs is not None:L.append(f'\n  {"-"*50}\n  Verification Score: {vs}%')
        L.append(f'\n{"="*60}');return'\n'.join(L)
    def _qa(self,sym,tf):self._nav('analysis');self.asym.set(sym);self.atf.set(tf);self.root.after(200,self._ra)
    def _qs(self):
        self.status_lbl.configure(text='Scanning...',fg=C['info']);self._ub();self._ao.set('Quick Technical Scan (No AI):\n')
        def w():
            try:
                from data_manager import DataManager;from technical_analyzer import TechnicalAnalyzer
                dm=DataManager();ta=TechnicalAnalyzer();L=['QUICK SCAN (Indicators Only):\n']
                for s in Config.SCAN_SYMBOLS[:7]:
                    try:
                        d=dm.get_ohlcv(s,'1h',100)
                        if not d:L.append(f'  ! {s}: No data');continue
                        cls=d['closes'];cur=cls[-1];chg=((cur-cls[-20])/cls[-20])*100 if len(cls)>=20 else 0
                        dr='UP'if chg>0 else'DN';L.append(f'  [{dr}] {s:<12} ${cur:>10.2f}  {chg:+.2f}%')
                    except Exception as e:L.append(f'  X {s}: {e}')
                self.root.after(0,lambda:self._ao.set('\n'.join(L)))
            except Exception as e:self.root.after(0,lambda:self._ao.set(f'Error: {e}'))
            finally:self.root.after(0,lambda:[self.status_lbl.configure(text='Ready',fg=C['accent']),self._ub()])
        threading.Thread(target=w,daemon=True).start()

    # ═══ BACKTEST ═══
    def _t_backtest(self):
        f=tk.Frame(self.content,bg=C['bg'])
        c=Card(f,"Historical Backtest - KnownSetupsFinder");c.pack(fill='x',pady=(0,10))
        cr=tk.Frame(c,bg=C['card']);cr.pack(fill='x')
        tk.Label(cr,text="Symbol:",font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(0,4))
        self.bs=ttk.Combobox(cr,values=['BTC/USDT','ETH/USDT'],width=10,state='readonly');self.bs.set('BTC/USDT');self.bs.pack(side='left',padx=(0,10))
        tk.Label(cr,text="Entry TF:",font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(8,4))
        self.btf=ttk.Combobox(cr,values=['5m','15m','1h','4h'],width=5,state='readonly');self.btf.set('4h');self.btf.pack(side='left',padx=(0,10))
        for lbl,attr,default in[('Min%:','bmn','2.5'),('Max:','bmx','5'),('Lookback:','blb','600')]:
            tk.Label(cr,text=lbl,font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(8,4))
            e=tk.Entry(cr,bg=C['surface'],fg=C['text'],font=F['uism'],insertbackground=C['accent'],relief='flat',width=5);e.insert(0,default);e.pack(side='left',padx=(0,10));setattr(self,attr,e)
        self.btn_b=Btk(Btn,cr,'Run Backtest',self._rb);self.btn_b.pack(side='left',padx=(8,0))
        c2=Card(f,"Report");c2.pack(fill='both',expand=True);self._bo=Console(c2,16);self._bo.pack(fill='both',expand=True)
        self.tabs['backtest']=f
    def _rb(self):
        sym=self.bs.get();tf=self.btf.get()
        try:mv=float(self.bmn.get())
        except:mv=2.5
        try:mx=int(self.bmx.get())
        except:mx=5
        try:lb=int(self.blb.get())
        except:lb=600
        self.btn_b.set('Running...');self.status_lbl.configure(text='Backtesting...',fg=C['gold']);self._ub()
        self._bo.set(f'Backtest: {sym} Entry TF={tf}\n{"="*50}\nFetching data...\n')
        def w():
            t0=time.time()
            try:
                from known_setups_finder import KnownSetupsFinder;fdr=KnownSetupsFinder();ss=fdr.find_setups(sym,tf,lb,mx,mv)
                elapsed=time.time()-t0
                L=[f'BACKTEST: {sym} | Entry TF: {tf}','='*55,f'{sym} {tf} Min:{mv}% Max:{mx} Lookback:{lb}',f'Completed in {elapsed:.0f}s ({elapsed/60:.1f} min)','='*55,'']
                if not ss:L.append('No setups found.')
                else:
                    bulls=[s for s in ss if s.get('direction')=='BULLISH'];bears=[s for s in ss if s.get('direction')=='BEARISH']
                    avg=sum(abs(s.get('actual_move_pct',0))for s in ss)/len(ss);mxv=max(abs(s.get('actual_move_pct',0))for s in ss)
                    L.append(f'Setups: {len(ss)} | BULL: {len(bulls)} | BEAR: {len(bears)}')
                    L.append(f'Avg Move: {avg:+.2f}% | Max: {mxv:.2f}%')
                    L.append(f'\n{"-"*55}\n#   Dir      Date        Move%     Start -> End\n{"-"*55}')
                    for i,s in enumerate(ss):
                        d=s.get('direction','?');em='BULL'if d=='BULLISH'else'BEAR';pct=s.get('actual_move_pct',0)
                        L.append(f'{i+1:<4}{em:<9}{str(s.get("date","?")):<12}{pct:+.2f}%   ${s.get("start_price",0):>10.2f} -> ${s.get("end_price",0):>10.2f}')
                    L.append('-'*55);L.append(f'\nSCORE: {len(ss)} setups | Avg: {avg:.2f}% | Time: {elapsed:.0f}s')
                self.root.after(0,lambda:self._bo.set('\n'.join(L)))
                _log(f'Backtest: {sym} {tf} - {len(ss)if ss else 0} setups in {elapsed:.0f}s','BACKTEST')
            except Exception as e:
                elapsed=time.time()-t0;self.root.after(0,lambda:self._bo.set(f'Error after {elapsed:.0f}s: {e}'))
            finally:self.root.after(0,lambda:[self.btn_b.set('Run Backtest'),self.status_lbl.configure(text='Ready',fg=C['accent']),self._ub()])
        threading.Thread(target=w,daemon=True).start()

    # ═══ FINDER ═══
    def _t_finder(self):
        f=tk.Frame(self.content,bg=C['bg'])
        c=Card(f,"Known Setups Finder");c.pack(fill='x',pady=(0,10))
        cr=tk.Frame(c,bg=C['card']);cr.pack(fill='x')
        tk.Label(cr,text="Symbol:",font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(0,4))
        self.fs=ttk.Combobox(cr,values=['BTC/USDT','ETH/USDT'],width=10,state='readonly');self.fs.set('BTC/USDT');self.fs.pack(side='left',padx=(0,8))
        tk.Label(cr,text="TF:",font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(8,4))
        self.ftf=ttk.Combobox(cr,values=['4h','1h','2h'],width=5,state='readonly');self.ftf.set('4h');self.ftf.pack(side='left',padx=(0,8))
        tk.Label(cr,text="Lookback:",font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(8,4))
        self.flb=tk.Entry(cr,bg=C['surface'],fg=C['text'],font=F['uism'],insertbackground=C['accent'],relief='flat',width=5);self.flb.insert(0,'500');self.flb.pack(side='left',padx=(0,8))
        tk.Label(cr,text="Max:",font=F['uism'],bg=C['card'],fg=C['text2']).pack(side='left',padx=(8,4))
        self.fmx=tk.Entry(cr,bg=C['surface'],fg=C['text'],font=F['uism'],insertbackground=C['accent'],relief='flat',width=5);self.fmx.insert(0,'10');self.fmx.pack(side='left',padx=(0,8))
        self.btn_f=Btk(Btn,cr,'Find Setups',self._rf);self.btn_f.pack(side='left',padx=(8,0))
        c2=Card(f,"Results");c2.pack(fill='both',expand=True);self._fo=Console(c2,14);self._fo.pack(fill='both',expand=True)
        self.tabs['finder']=f
    def _rf(self):
        sym=self.fs.get();tf=self.ftf.get()
        try:lb=int(self.flb.get())
        except:lb=500
        try:mx=int(self.fmx.get())
        except:mx=10
        self.btn_f.set('Searching...');self._fo.set(f'Searching {sym} {tf}...\n')
        def w():
            t0=time.time()
            try:
                from known_setups_finder import KnownSetupsFinder;fdr=KnownSetupsFinder();ss=fdr.find_setups(sym,tf,lb,mx,1.0)
                elapsed=time.time()-t0
                L=[f'FINDER: {sym} {tf} | Lookback:{lb} | Max:{mx}','='*50,f'Completed in {elapsed:.0f}s','']
                if not ss:L.append('No setups.')
                else:
                    L.append(f'{len(ss)} setups:')
                    for i,s in enumerate(ss):
                        d=s.get('direction','?');em='BULL'if d=='BULLISH'else'BEAR'
                        L.append(f'  [{i+1:2d}] {em}  {s.get("date","?")}  |  {s.get("actual_move_pct",0):+.2f}%  |  ${s.get("start_price",0):.2f} -> ${s.get("end_price",0):.2f}')
                self.root.after(0,lambda:self._fo.set('\n'.join(L)))
            except Exception as e:self.root.after(0,lambda:self._fo.set(f'Error: {e}'))
            finally:self.root.after(0,lambda:self.btn_f.set('Find Setups'))
        threading.Thread(target=w,daemon=True).start()

    # ═══ TRAINING ═══
    def _t_training(self):
        f=tk.Frame(self.content,bg=C['bg'])
        c=Card(f,"Training - Custom Trade Import & Testing");c.pack(fill='x',pady=(0,10))
        tk.Label(c,text="Paste any format (JSON, CSV OHLC, plain text).",font=F['uism'],bg=C['card'],fg=C['text2']).pack(anchor='w',pady=(0,8))
        self.ti=tk.Text(c,bg=C['surface'],fg=C['text'],font=F['monos'],insertbackground=C['accent'],relief='flat',height=6,padx=10,pady=10);self.ti.pack(fill='x')
        br=tk.Frame(c,bg=C['card']);br.pack(fill='x',pady=(8,0))
        Btn(br,'Parse',self._pt).pack(side='left',padx=(0,6));Btn(br,'Test',self._tt,C['accent2']).pack(side='left',padx=6)
        Btn(br,'Format',self._sfmt,C['info']).pack(side='left',padx=6);Btn(br,'Load File',self._ltf,C['info']).pack(side='left',padx=6)
        c2=Card(f,"Result");c2.pack(fill='both',expand=True);self._to=Console(c2,14);self._to.pack(fill='both',expand=True);self._to.w('Accepted: JSON, OHLC CSV, plain description.\n')
        self.tabs['training']=f
    def _sfmt(self):self._to.set('FORMATS:\n1) JSON: {"candles":[...],"expected_signal":"BUY"}\n2) CSV: ts,open,high,low,close,vol\n3) Plain: "BTC/USDT 4h sweep below 42000..."')
    def _pt(self):
        raw=self.ti.get('1.0','end-1c').strip()
        if not raw:self._to.set('No data.');return
        self._to.set('Parsing...\n')
        def w():
            try:
                try:d=json.loads(raw);self.root.after(0,lambda:self._to.w(f'JSON valid: {list(d.keys())[:5]}'));return
                except:pass
                lines=[l.strip()for l in raw.split('\n')if l.strip()];cnt=0
                for ln in lines:
                    parts=ln.replace(',',' ').split();nums=[float(p)for p in parts if p.replace('.','',1).replace('-','',1).isdigit()]
                    if len(nums)>=5:cnt+=1
                if cnt>0:self.root.after(0,lambda:self._to.w(f'{cnt} OHLC rows detected.'))
                else:self.root.after(0,lambda:self._to.w(f'Free-text ({len(lines)} lines).'))
            except Exception as e:self.root.after(0,lambda:self._to.w(f'Error: {e}'))
        threading.Thread(target=w,daemon=True).start()
    def _tt(self):
        raw=self.ti.get('1.0','end-1c').strip()
        if not raw:return
        self._to.set('Testing...\n')
        def w():
            try:
                from brain_core import BrainCore;b=BrainCore();sym='BTC/USDT';tf='4h'
                for s in['BTC','ETH','SOL']:
                    if s in raw.upper():sym=s+'/USDT'if s!='BTC'else'BTC/USDT';break
                for t in['4h','1h','1d']:
                    if t in raw:tf=t;break
                r=b.full_analysis(sym,tf);txt=self._fmt(r,sym,tf,0);self.root.after(0,lambda:self._to.w(txt))
            except Exception as e:self.root.after(0,lambda:self._to.w(f'Error: {e}'))
        threading.Thread(target=w,daemon=True).start()
    def _ltf(self):
        fp=filedialog.askopenfilename(title="Load",filetypes=[('All','*.*')])
        if not fp:return
        try:
            with open(fp,'r',encoding='utf-8',errors='replace')as fh:c=fh.read()
            self.ti.delete('1.0','end');self.ti.insert('1.0',c);self._to.set(f'Loaded: {os.path.basename(fp)} ({len(c)} chars)')
        except Exception as e:self._to.set(f'Error: {e}')

    # ═══ CHAT ═══
    def _t_chat(self):
        f=tk.Frame(self.content,bg=C['bg'])
        c=Card(f,"Chat with Kotrader AI - Gemma-4 Real AI");c.pack(fill='both',expand=True)
        self._co=tk.Text(c,bg=C['surface'],fg=C['text'],font=('Segoe UI',11),insertbackground=C['accent'],relief='flat',border=0,padx=14,pady=12,wrap='word',height=20);self._co.pack(fill='both',expand=True)
        self._co.bind('<Control-c>',lambda e:self._cpw(self._co))
        m=Menu(self._co,tearoff=0,bg=C['surface'],fg=C['text'],font=F['uism']);m.add_command(label="Copy",command=lambda:self._cpw(self._co));m.add_command(label="Select All",command=lambda:self._co.tag_add('sel','1.0','end'))
        self._co.bind('<Button-3>',lambda e:m.tk_popup(e.x_root,e.y_root))
        qp=tk.Frame(c,bg=C['card']);qp.pack(fill='x',pady=(8,4))
        for p in['Analyze BTC','What is BOS?','Explain FVG','How many keys?','Settings']:
            b=tk.Label(qp,text=p,font=('Segoe UI',8),bg=C['surface'],fg=C['text2'],padx=8,pady=3,cursor='hand2');b.pack(side='left',padx=2)
            b.bind('<Button-1>',lambda e,c=p:self._sc(c));b.bind('<Enter>',lambda e,b=b:b.configure(fg=C['accent']));b.bind('<Leave>',lambda e,b=b:b.configure(fg=C['text2']))
        inf=tk.Frame(c,bg=C['card']);inf.pack(fill='x')
        self._ci=tk.Entry(inf,bg=C['surface'],fg=C['text'],font=('Segoe UI',12),insertbackground=C['accent'],relief='flat')
        self._ci.pack(side='left',fill='x',expand=True,ipady=6,padx=(0,6));self._ci.bind('<Return>',lambda e:self._sc())
        Btn(inf,'Send',self._sc).pack(side='right')
        self._ac('Kotrader',"Hi! I'm your AI trading assistant.\n\nAsk me anything about ICT concepts, the bot, or trading.\nTry: \"What is a Break of Structure?\" or \"Analyze BTC/USDT\"")
        self.tabs['chat']=f
    def _cpw(self,w):
        try:s=w.get('sel.first','sel.last');w.clipboard_clear();w.clipboard_append(s)
        except:pass
    def _ac(self,who,txt):
        self._co.configure(state='normal');cl=C['accent']if who!='You'else C['accent2']
        self._co.insert('end',f'\n  {who}: ',('name',));self._co.insert('end',txt+'\n')
        self._co.tag_configure('name',foreground=cl,font=('Segoe UI',11,'bold'));self._co.see('end');self._co.configure(state='disabled')
    def _sc(self,txt_ov=None):
        msg=txt_ov or self._ci.get().strip()
        if not msg:return
        if not txt_ov:self._ci.delete(0,'end')
        self._ac('You',msg);self.chatting=True;self._ub()
        threading.Thread(target=self._call_chat,args=(msg,),daemon=True).start()
    def _call_chat(self,msg):
        try:
            from ai_client import AIClient
            kb_path=Config.KNOWLEDGE_FILE;kb_text=""
            if os.path.exists(kb_path):
                with open(kb_path,'r',encoding='utf-8',errors='replace')as f:kb_text=f.read()[:20000]
            system="You are Kotrader, an ICT/SMC trading assistant. Speak English/Arabic. Be concise (<400 words). Below is part of the ICT knowledge base:\n\n"+kb_text[:15000]
            ai=AIClient();response=ai.query(msg,system_prompt=system,max_tokens=600,use_cache=False)
            if response:
                response=response.strip()
                if response.startswith('{'):
                    try:
                        parsed=json.loads(response)
                        if isinstance(parsed,dict):response=parsed.get('response',parsed.get('text',str(parsed)))
                    except:pass
                if len(response)>2500:response=response[:2500]+'...'
                self.root.after(0,lambda:self._ac('Kotrader',response))
            else:self.root.after(0,lambda:self._ac('Kotrader',"No response. Check keys."))
        except Exception as e:self.root.after(0,lambda:self._ac('Kotrader',f"Error: {str(e)[:200]}"))
        finally:self.chatting=False;self.root.after(0,self._ub)

    # ═══ SETTINGS ═══
    def _t_settings(self):
        f=tk.Frame(self.content,bg=C['bg'])
        c=Card(f,"Configuration - Edit .env");c.pack(fill='x',pady=(0,12))
        fields=[('AI_PROVIDER_ORDER',','.join(Config.AI_PROVIDER_ORDER),'Provider order'),
                ('CLOUDFLARE_MODEL',Config.CLOUDFLARE_MODEL,'Model name'),
                ('MAX_ACCEPTABLE_PROVIDER_SECONDS',str(int(Config.MAX_ACCEPTABLE_PROVIDER_SECONDS)),'Slow cutoff (s)'),
                ('TEMPERATURE',str(Config.TEMPERATURE),'AI randomness'),
                ('BORDERLINE_CONFIDENCE_LOW',str(Config.BORDERLINE_CONFIDENCE_LOW),'Consensus min%'),
                ('BORDERLINE_CONFIDENCE_HIGH',str(Config.BORDERLINE_CONFIDENCE_HIGH),'Consensus max%'),
                ('DEFAULT_SYMBOL',Config.DEFAULT_SYMBOL,'Default pair'),
                ('MAX_TOKENS',str(Config.MAX_TOKENS),'Max output tokens')]
        self.se={}
        for label,val,desc in fields:
            row=tk.Frame(c,bg=C['card']);row.pack(fill='x',pady=6)
            lf=tk.Frame(row,bg=C['card']);lf.pack(side='left',anchor='w',padx=(0,12))
            tk.Label(lf,text=label,font=('Consolas',10),bg=C['card'],fg=C['accent']).pack(anchor='w')
            tk.Label(lf,text=desc,font=('Segoe UI',7),bg=C['card'],fg=C['text3']).pack(anchor='w')
            e=tk.Entry(row,bg=C['surface'],fg=C['text'],font=('Consolas',10),insertbackground=C['accent'],relief='flat',width=52);e.insert(0,val);e.pack(side='right',fill='x',expand=True,ipady=4);self.se[label]=e
        br=tk.Frame(f,bg=C['bg']);br.pack(fill='x',pady=(8,0))
        Btn(br,'Save',self._sv).pack(side='left',padx=(0,8));Btn(br,'Export ZIP',self._ez,C['accent2']).pack(side='left',padx=8);Btn(br,'View .env',self._ve,C['info']).pack(side='left',padx=8)
        self.tabs['settings']=f
    def _sv(self):
        ep=os.path.join(BASE_DIR,'.env')
        try:
            with open(ep,'r',encoding='utf-8')as fh:env=fh.read()
            for label,e in self.se.items():
                key=label.split(' ',1)[1]if' 'in label else label;v=e.get().strip()
                p=re.compile(rf'^{key}\s*=.*$',re.MULTILINE)
                if p.search(env):env=p.sub(f'{key}={v}',env)
                else:env+=f'\n{key}={v}\n'
            with open(ep,'w',encoding='utf-8')as fh:fh.write(env);messagebox.showinfo("Saved","Restart Kotrader.")
            _log('Settings saved','CONFIG')
        except Exception as e:messagebox.showerror("Error",str(e))
    def _ez(self):
        import zipfile
        fp=filedialog.asksaveasfilename(defaultextension='.zip',filetypes=[('ZIP','*.zip')],title='Export')
        if not fp:return
        try:
            base=BASE_DIR;parent=os.path.dirname(base)
            with zipfile.ZipFile(fp,'w',zipfile.ZIP_DEFLATED)as zf:
                for root,dirs,files in os.walk(base):
                    dirs[:]=[d for d in dirs if not d.startswith('__')]
                    for fn in files:
                        if'محادثاتي'in fn:continue
                        fpp=os.path.join(root,fn);zf.write(fpp,os.path.relpath(fpp,parent))
            messagebox.showinfo("Done",f"Exported: {fp}")
        except Exception as e:messagebox.showerror("Error",str(e))
    def _ve(self):
        ep=os.path.join(BASE_DIR,'.env')
        try:
            with open(ep,'r',encoding='utf-8')as fh:lines=fh.readlines()
            masked=[]
            for ln in lines:
                if'='in ln and any(k in ln for k in['KEY','TOKEN','ACCOUNTS']):
                    kk,vv=ln.split('=',1)
                    if len(vv.strip())>25:masked.append(f'{kk}=...{vv.strip()[-20:]}')
                    else:masked.append(ln.rstrip())
                else:masked.append(ln.rstrip())
            d=tk.Toplevel(self.root,bg=C['card']);d.title(".env (Masked)");d.geometry("620x420");d.transient(self.root)
            tx=tk.Text(d,bg=C['surface'],fg=C['text'],font=('Consolas',10),relief='flat',padx=12,pady=12)
            tx.pack(fill='both',expand=True,padx=12,pady=12);tx.insert('1.0','\n'.join(masked));tx.configure(state='disabled')
        except Exception as e:messagebox.showerror("Error",str(e))

def Btk(cls,p,text,cmd=None,color=C['accent']):
    return cls(p,text,cmd,color)

if __name__=='__main__':
    root=tk.Tk();app=KotraderApp(root);root.mainloop()
