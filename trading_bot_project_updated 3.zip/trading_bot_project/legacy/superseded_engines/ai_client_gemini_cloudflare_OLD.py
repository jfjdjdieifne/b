# -*- coding: utf-8 -*-
"""
AI Client - Gemini (أساسي) + Cloudflare Workers AI (احتياطي طوارئ)
════════════════════════════════════════════════════════════
⚠️ قرار نهائي (يوليو 2026): Gemini هو المزود الأساسي واليومي -
Groq, OpenRouter, Mistral, SambaNova, SiliconFlow أُزيلوا نهائياً
(مقارنة موضوعية أثبتت عدم وجود فرق دقة حقيقي، بينما Gemini أسرع).

Cloudflare Workers AI أُضيف لاحقاً (نفس الشهر) كـ**احتياطي طوارئ
حصراً** - ليس بديلاً يومياً - بعد أن أثبتت جلسات الاستخدام الفعلية
أن حصة Gemini اليومية (7 مفاتيح × 20 طلب/يوم) قد تُستهلك بالكامل.
موديل Cloudflare المُختار (gemma-4-26b-a4b-it) اختير بعد مقارنة فعلية
مباشرة بين 7 مرشحين على نفس الصفقة الحقيقية عبر reading_comprehension_test.py
- طابق دقة Gemini 2.5 Flash بنسبة 77% مقابل 76% (فرق ضمن هامش الخطأ
الطبيعي)، لكنه أبطأ بشكل كبير (~100-135 ثانية مقابل ~11 ثانية للطلب
الواحد) - مقبول صراحة لأنه يُستخدم فقط "كطوق نجاة" عند توقف Gemini
الكامل، لا كاستخدام يومي معتاد.

- 7 مفاتيح Gemini + N توكن Cloudflare (تبديل تلقائي بينهما عند
  rate-limit/quota يومي - Gemini يُجرَّب أولاً دائماً)
- Cache + إحصائيات
- واجهة عامة (query, query_json, status...) متوافقة مع باقي الكود

- ⚠️ حماية تلقائية دائمة من البطء (Auto Slow-Provider Cutoff): بعد
  كل طلب ناجح يُقاس زمن الاستجابة الفعلي. إذا تجاوز
  Config.MAX_ACCEPTABLE_PROVIDER_SECONDS (افتراضياً 45 ثانية) يُعلَّم
  المزود تلقائياً كـ"بطيء جداً" ويُستبعد من باقي محاولات الجلسة
  الحالية - حتى لو كانت نتيجته دقيقة. أُبقيت هذه الآلية عامة (تعمل
  لأي مزود) رغم أن Gemini وحده مفعّل حالياً، تحسباً لأي إضافة مستقبلية.
"""
import os
import re
import requests
import json
import time
import hashlib
import logging
import concurrent.futures
from config import Config


class _Provider:
    """تمثيل داخلي لمزود AI واحد مع مفاتيحه وحالته"""

    def __init__(self, name, keys, model):
        self.name = name
        self.keys = keys
        self.model = model
        self.current_index = 0
        self.key_stats = {
            k[-8:]: {"requests": 0, "errors": 0, "exhausted": False}
            for k in keys
        }
        # ── حماية تلقائية من البطء (Auto Slow-Provider Cutoff) ──
        # مرة يثبت هذا المزود إنه أبطأ من الحد المسموح، يُستبعد فوراً
        # من باقي الجلسة الحالية بغض النظر عن دقته - القرار: السرعة
        # شرط أساسي، مش رفاهية.
        self.too_slow = False
        self.last_response_seconds = None

    @property
    def has_keys(self):
        return len(self.keys) > 0

    @property
    def all_exhausted(self):
        if not self.keys:
            return True
        if self.too_slow:
            return True
        return all(self.key_stats[k[-8:]]["exhausted"] for k in self.keys)

    def current_key(self):
        return self.keys[self.current_index]

    def next_key(self):
        for _ in range(len(self.keys)):
            self.current_index = (self.current_index + 1) % len(self.keys)
            k = self.keys[self.current_index]
            if not self.key_stats[k[-8:]]["exhausted"]:
                return k
        return None

    def mark_exhausted(self, key):
        self.key_stats[key[-8:]]["exhausted"] = True

    def reset(self):
        for stat in self.key_stats.values():
            stat["exhausted"] = False
        # إعادة تفعيل مزود بطيء (مثلاً بداية جلسة/يوم جديد، أو لو تحسّن
        # أداؤه لاحقاً) - إعادة التفعيل يدوية عمداً، ما بتصير تلقائياً
        # بمنتصف نفس الجلسة لتفادي التذبذب (بطيء/سريع/بطيء).
        self.too_slow = False
        self.last_response_seconds = None


class AIClient:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self.logger = logging.getLogger("AIClient")

        # ═══ Cloudflare Workers AI فقط - Gemini مُعطَّل بالكامل ═══
        # ⚠️ قرار صريح من المستخدم (يوليو 2026): "عطّلي موديل Gemini
        # كله ما بدي ياه، خلينا على موديل Cloudflare فقط". السبب:
        # اختبار فعلي حقيقي أظهر أن الجمع بين Gemini+Cloudflare بنفس
        # التحليل (حوض مفاتيح موحَّد) كان "يحرق" مفاتيح Gemini السريعة
        # بأول مرحلتين، فيترك المراحل المتبقية تعتمد بالكامل على
        # Cloudflare البطيء تحت ضغط - نتيجة أسوأ من استخدام Cloudflare
        # فقط من البداية بتوقعات زمنية واضحة وثابتة.
        # Gemini لا يُنشأ كمزود إطلاقاً الآن (لا مجرد استبعاد من الترتيب)
        # - حتى منطق "أي مزود عنده مفاتيح ينضاف تلقائياً بالآخر" أدناه
        # لن يُعيده، لأنه ببساطة غير موجود بـ self.providers.
        self.providers = {}
        if "gemini" in Config.AI_PROVIDER_ORDER and Config.GEMINI_API_KEYS:
            self.providers["gemini"] = _Provider(
                "gemini", Config.GEMINI_API_KEYS, Config.GEMINI_MODEL
            )
        # ⚠️ إصلاح خطأ حقيقي مُكتشف (يوليو 2026): حصة الـ10,000 نيورون
        # اليومية المجانية مرتبطة بـ**الحساب** (account_id)، لا بالتوكن -
        # عدة توكنات لنفس الحساب تتشارك نفس الحصة فعلياً (فشلا معاً
        # بمجرد نفادها، رسالة Cloudflare الصريحة: "used up your daily
        # free allocation of 10,000 neurons"). الحل: كل "مفتاح" بقائمة
        # cloudflare.keys هو الآن سلسلة مركّبة "account_id|token" - كل
        # زوج (حساب مختلف فعلياً) له حصته المستقلة تماماً، تماماً كمبدأ
        # تعدد مفاتيح Gemini. _call_cloudflare() يفصلها وقت الاستدعاء.
        cf_composite_keys = [
            f"{acc['account_id']}|{acc['token']}" for acc in Config.CLOUDFLARE_ACCOUNTS
        ]
        if cf_composite_keys:
            self.providers["cloudflare"] = _Provider(
                "cloudflare", cf_composite_keys, Config.CLOUDFLARE_MODEL
            )

        self.provider_order = [
            p for p in Config.AI_PROVIDER_ORDER if p in self.providers
        ]
        # أي مزود عنده مفاتيح بس نسي يتحط بالترتيب، يضاف بالآخر تحوطاً
        for p in self.providers:
            if p not in self.provider_order:
                self.provider_order.append(p)

        if Config.OPENROUTER_API_KEYS:
            self.providers["openrouter"] = _Provider(
                "openrouter", Config.OPENROUTER_API_KEYS, Config.OPENROUTER_MODEL
            )
            if "openrouter" not in self.provider_order:
                self.provider_order.append("openrouter")

        if not self.provider_order:
            self.logger.error(
                "❌ لا يوجد أي مزود AI مُفعّل! أضف مفتاح API واحد على الأقل بملف .env"
            )

        # Cache & Stats عامة
        self.cache = {}
        self.last_request_time = 0
        self.request_count = 0
        self.total_cost = 0.0
        self.session = requests.Session()

        # ═══ KEY AI TRACKER ═══
        # Tracks which Cloudflare keys have successfully served AI responses.
        # Used by Kotrader to prefer known-good keys. Stored in data/cf_ai_ok.json
        self._key_tracker_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 'data', 'cf_ai_ok.json'
        )
        self._known_good_keys = self._load_key_tracker()

    def _load_key_tracker(self):
        try:
            if os.path.exists(self._key_tracker_path):
                with open(self._key_tracker_path, 'r') as f:
                    return json.load(f)
        except: pass
        return {}

    def _save_key_ai_ok(self, account_id, token):
        """Mark a Cloudflare key as AI-capable (successful AI response)."""
        self._known_good_keys[account_id] = {
            'token_preview': token[-8:],
            'last_ok': time.strftime('%Y-%m-%d %H:%M'),
            'count': self._known_good_keys.get(account_id, {}).get('count', 0) + 1
        }
        try:
            os.makedirs(os.path.dirname(self._key_tracker_path), exist_ok=True)
            with open(self._key_tracker_path, 'w') as f:
                json.dump(self._known_good_keys, f, indent=2)
        except: pass

    def _save_key_ai_fail(self, account_id, reason):
        """Mark a Cloudflare key as having failed an AI attempt."""
        self._known_good_keys[account_id] = {
            'token_preview': self._known_good_keys.get(account_id, {}).get('token_preview', '?'),
            'last_fail': time.strftime('%Y-%m-%d %H:%M'),
            'fail_reason': reason[:100],
            'count': self._known_good_keys.get(account_id, {}).get('count', 0)
        }
        try:
            os.makedirs(os.path.dirname(self._key_tracker_path), exist_ok=True)
            with open(self._key_tracker_path, 'w') as f:
                json.dump(self._known_good_keys, f, indent=2)
        except: pass

    def get_known_good_keys(self):
        """Return list of account_ids that have successfully served AI responses."""
        return [k for k, v in self._known_good_keys.items() 
                if v.get('last_ok') and (not v.get('last_fail') or v.get('last_ok', '') > v.get('last_fail', ''))]

    def get_key_tracker_data(self):
        """Return the full key tracker dict for Kotrader display."""
        return dict(self._known_good_keys)


        active_names = ", ".join(self.provider_order) or "NONE"
        self.logger.info(f"✅ AIClient جاهز | ترتيب المزودين: {active_names}")

    # ══════════════════════════════════════════════════════════
    #  تنظيف الرد (حذف <think>...</think> من نماذج reasoning)
    # ══════════════════════════════════════════════════════════

    def _clean_response(self, text):
        if not text:
            return text

        if "<think>" in text and "</think>" in text:
            result = text.split("</think>")[-1].strip()
            if result:
                return result

        if "<think>" in text and "</think>" not in text:
            self.logger.warning("⚠️ الموديل استهلك كل التوكنز بالتفكير!")

            json_start = text.rfind('{"')
            if json_start != -1:
                candidate = text[json_start:]
                if not candidate.endswith("}"):
                    candidate += "}"
                return candidate

            thinking = text.replace("<think>", "").strip()
            lines = thinking.split("\n")
            key_info = []
            for line in lines:
                line = line.strip()
                if any(w in line.lower() for w in [
                    "bias", "bullish", "bearish", "signal",
                    "buy", "sell", "hold", "entry", "stop",
                    "target", "confidence", "therefore",
                    "conclusion", "recommend"
                ]):
                    key_info.append(line)

            if key_info:
                return json.dumps({
                    "signal": "HOLD",
                    "confidence": 50,
                    "reasoning": " | ".join(key_info[-5:]),
                    "note": "Model ran out of tokens while thinking.",
                })

            return json.dumps({
                "signal": "HOLD",
                "confidence": 0,
                "reasoning": "Model used all tokens on thinking.",
                "note": "Try again or reduce data size.",
            })

        return text

    # ══════════════════════════════════════════════════════════
    #  طلبات كل مزود على حدة
    # ══════════════════════════════════════════════════════════

    def _call_gemini(self, provider, key, prompt, system_prompt, max_tokens,
                      temperature, force_json, timeout, response_schema=None):
        url = (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{provider.model}:generateContent?key={key}"
        )
        # ═══ إدارة ميزانية "التفكير الداخلي" (thinking) ═══
        # في نماذج Gemini 2.5، الـ thinking tokens تُخصم من نفس حد
        # maxOutputTokens. بدون سقف، الموديل ممكن يستهلك كل الحد
        # بالتفكير ويقطع الـ JSON النهائي. نحجز جزء ثابت للتفكير
        # ونضمن مساحة كافية للرد الفعلي.
        thinking_budget = min(2048, max(0, max_tokens - 300))

        generation_config = {
            "temperature": temperature,
            "maxOutputTokens": max_tokens,
            "thinkingConfig": {"thinkingBudget": thinking_budget},
        }
        if force_json:
            generation_config["responseMimeType"] = "application/json"
            # ═══ Schema صارم = بنية JSON ثابتة 100% ═══
            # بدون schema، النموذج حر يختار شكل الإخراج (نص مقابل عدد
            # مقابل dict متداخل)، وهذا سبب "عدم الاستقرار" بالبنية.
            # مع responseSchema، جوجل تفرض فرضاً أن الحقل يطابق النوع
            # المحدد - confidence سيكون INTEGER دائماً، لا يوجد شكل آخر.
            if response_schema:
                generation_config["responseSchema"] = response_schema

        body = {
            "system_instruction": {"parts": [{"text": system_prompt}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": generation_config,
        }
        resp = self.session.post(url, json=body, timeout=timeout)

        if resp.status_code == 200:
            data = resp.json()
            candidates = data.get("candidates", [])
            if not candidates:
                # ممكن يكون البرومبت اتحجب (Safety filters)
                reason = data.get("promptFeedback", {}).get("blockReason", "unknown")
                raise _SoftFail(f"Gemini: no candidates (block_reason={reason})")
            parts = candidates[0].get("content", {}).get("parts", [])
            text = "".join(p.get("text", "") for p in parts)
            usage = data.get("usageMetadata", {})
            in_tok = usage.get("promptTokenCount", 0)
            out_tok = usage.get("candidatesTokenCount", 0)

            # ═══ كشف انقطاع الرد بسبب حد التوكن (MAX_TOKENS) ═══
            # ⚠️ إصلاح خطأ حقيقي مُكتشف بالباك تيست الفعلي: كان الكود
            # يتجاهل حقل finishReason كلياً، فلو Gemini قطع الـJSON
            # بمنتصفه (لأن الرد الفعلي + التفكير الداخلي تجاوزا
            # maxOutputTokens)، كانت النتيجة تصل ناقصة لـquery_json()،
            # يفشل الـparsing، ونحصل على "UNKNOWN" بصمت - يُحسب كـ"فشل
            # تحليل" رغم أن المزود نجح فعلياً، والمشكلة فقط حجم الحد.
            # الحل: نتحقق صراحة من finishReason، ولو كان MAX_TOKENS
            # (بغض النظر هل النص صالح JSON أو لا)، نرفع استثناء خاص
            # يُعاد على أساسه المحاولة تلقائياً بحد توكن أعلى - بدل
            # افتراض "لا يوجد حل" وإرجاع UNKNOWN.
            finish_reason = candidates[0].get("finishReason", "")
            if finish_reason == "MAX_TOKENS":
                raise _MaxTokensExceeded(
                    f"Gemini finishReason=MAX_TOKENS (out_tok={out_tok}) - "
                    "الرد انقطع قبل اكتماله، يحتاج حد توكن أعلى"
                )

            return text, in_tok, out_tok
        elif resp.status_code == 429:
            # ═══ تمييز حاسم بين نوعين مختلفين تماماً من 429 ═══
            # 1) Rate limit مؤقت بالدقيقة (RPM) -> يستاهل إعادة محاولة
            #    بعد ثوانٍ قليلة، الحصة سترجع تلقائياً بسرعة
            # 2) نفاد الحصة اليومية بالكامل (RPD - مثلاً حد 20 طلب/يوم
            #    على gemini-2.5-flash بالمستوى المجاني) -> إعادة المحاولة
            #    عليه لا فائدة منها إطلاقاً قبل اليوم التالي - يجب تبديل
            #    المفتاح فوراً بدون إهدار وقت على retries لن تنجح أبداً
            error_text = resp.text
            if "PerDay" in error_text or "generate_content_free_tier_requests" in error_text:
                raise _QuotaExhausted(f"Gemini daily quota exhausted: {error_text[:200]}")
            raise _RateLimited("Gemini rate limited")
        elif resp.status_code in (400, 401, 403):
            raise _KeyInvalid(f"Gemini key invalid/blocked: {resp.text[:200]}")
        else:
            raise _SoftFail(f"Gemini HTTP {resp.status_code}: {resp.text[:200]}")

    # ملاحظة: _call_openai_compatible() (كانت تُستخدم لـ Groq/OpenRouter/
    # SambaNova/SiliconFlow) أُزيلت بالكامل - Gemini فقط مفعّل بالمشروع
    # الآن وله مساره الخاص _call_gemini() فقط.

    @staticmethod
    def _convert_gemini_schema_to_json_schema(schema):
        """
        ⚠️ ضرورية لدعم Cloudflare كمزود احتياطي: كل schemas المشروع
        (signal_schema.py, multi_pass_analysis.py, reading_comprehension_test.py)
        مكتوبة بصيغة Gemini الخاصة (type بحروف كبيرة: "OBJECT", "STRING",
        "NUMBER", "INTEGER", "BOOLEAN", "ARRAY"). لكن Cloudflare Workers AI
        (وأي مزود متوافق مع OpenAI عبر response_format:json_schema) يتوقع
        JSON Schema القياسي (type بحروف صغيرة: "object", "string"...).
        بدون هذا التحويل، الـschema بأكمله يُرفض أو يُتجاهل صامتاً.
        يعمل تكرارياً (recursive) على أي عمق تداخل (properties/items).
        """
        if not isinstance(schema, dict):
            return schema

        _TYPE_MAP = {
            "OBJECT": "object", "STRING": "string", "NUMBER": "number",
            "INTEGER": "integer", "BOOLEAN": "boolean", "ARRAY": "array",
        }

        converted = {}
        for k, v in schema.items():
            if k == "type" and isinstance(v, str):
                converted[k] = _TYPE_MAP.get(v, v.lower())
            elif k == "properties" and isinstance(v, dict):
                converted[k] = {
                    pk: AIClient._convert_gemini_schema_to_json_schema(pv)
                    for pk, pv in v.items()
                }
            elif k == "items" and isinstance(v, dict):
                converted[k] = AIClient._convert_gemini_schema_to_json_schema(v)
            elif k == "enum" and isinstance(v, list):
                converted[k] = v
            else:
                converted[k] = v
        return converted

    # ⚠️ موديلات "استدلال" (Reasoning) على Cloudflare (مثل
    # deepseek-r1-distill-qwen-32b) تكتب سلسلة تفكير داخلية طويلة
    # (<think>...</think>) قبل أي جواب فعلي - حتى مع max_tokens صغير
    # جداً (اختبار فعلي: max_tokens=50 استُهلك بالكامل وهو لسا داخل
    # <think>). هذا يستهلك جزءاً كبيراً من نافذة السياق الإجمالية
    # (دخل+خرج معاً لهذا الموديل تحديداً: 80,000 توكن) بلا داعٍ لمهمة
    # استخراج حقول JSON بسيطة. الحل المُختبر فعلياً (curl مباشر):
    # إلحاق "/no_think" بنهاية البرومبت يقلّل احتمال التفكير الطويل
    # بشكل ملحوظ (لم يُثبَّت أنه يعطّله 100% دائماً - أحياناً لا يزال
    # يحدث، فالتعامل معه يبقى ضرورياً كخط دفاع ثانٍ).
    _REASONING_MODELS_NO_THINK_SUFFIX = ("deepseek-r1", "qwq", "gpt-oss")

    def _call_cloudflare(self, provider, key, prompt, system_prompt, max_tokens,
                          temperature, force_json, timeout, response_schema=None):
        """
        Cloudflare Workers AI - واجهة متوافقة مع OpenAI (chat.completions).
        ⚠️ تحقق فعلي (curl مباشر، يوليو 2026): مجاني بلا بطاقة ائتمان لهذا
        المستوى، ويدعم response_format:json_schema بدقة (اختبار حقيقي:
        {"signal":"BUY"} رجع مطابقاً 100% للـschema المطلوب).

        ⚠️ "key" هنا سلسلة مركّبة "account_id|token" (لا توكن فقط) -
        كل حساب Cloudflare له حصته اليومية المستقلة (10,000 نيورون)،
        فلا يجوز افتراض حساب واحد ثابت لكل التوكنات (خطأ حقيقي مُصلَح:
        كان يُستخدم Config.CLOUDFLARE_ACCOUNT_ID ثابتاً للجميع، فتوكنات
        متعددة لنفس الحساب كانت تتشارك نفس الحصة فعلياً بلا فائدة من
        "تعدد المفاتيح").
        """
        if "|" in key:
            account_id, token = key.split("|", 1)
        else:
            # توافق خلفي: مفتاح قديم بلا حساب مقترن صراحة
            account_id, token = Config.CLOUDFLARE_ACCOUNT_ID, key

        url = (
            f"https://api.cloudflare.com/client/v4/accounts/"
            f"{account_id}/ai/run/{provider.model}"
        )
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

        # ⚠️ إصلاح خطأ حقيقي مُكتشف (يوليو 2026، طلب صريح من المستخدم
        # بإصرار على استخدام deepseek-r1-distill-qwen-32b تحديداً):
        # موديلات الاستدلال تحتاج معاملة خاصة - نُلحق "/no_think"
        # بالبرومبت لتقليل احتمال التفكير الطويل (مُختبر فعلياً)، ونحجز
        # مساحة احتياطية إضافية بحد التوكن (thinking_headroom) لأن نافذة
        # هذه الموديلات (80K لـdeepseek) تُحسب دخل+خرج معاً - فشل فعلي
        # موثّق: طلب 80,689 توكن (40,853 دخل + 39,836 خرج) رفض بسبب
        # تجاوز حد 80,000 بالضبط. نخفّض max_tokens تلقائياً هنا (وليس
        # نتركه كما طُلب) بحيث الدخل+الحد الجديد لا يتجاوزان 95% من
        # نافذة الموديل - نكتشف حجم الدخل التقريبي من طول البرومقت نفسه
        # (~4 حروف/توكن، تقدير معياري متحفظ).
        is_reasoning_model = any(
            tag in provider.model for tag in self._REASONING_MODELS_NO_THINK_SUFFIX
        )
        effective_prompt = prompt
        effective_max_tokens = max_tokens
        if is_reasoning_model:
            effective_prompt = f"{prompt}\n\n/no_think"
            if "deepseek-r1" in provider.model:
                model_context_window = 80000
                estimated_input_tokens = len(system_prompt or "") // 4 + len(effective_prompt) // 4
                safety_margin = int(model_context_window * 0.95)
                available_for_output = safety_margin - estimated_input_tokens
                if available_for_output < 500:
                    # الدخل نفسه كبير جداً لهذا الموديل - لا مجال آمن
                    # لأي إخراج، هذا فشل متوقع يجب رفعه صراحة بدل محاولة
                    # عمياء ستفشل حتماً بنفس الخطأ الموثّق.
                    raise _SoftFail(
                        f"Cloudflare deepseek-r1: البرومبت كبير جداً "
                        f"(~{estimated_input_tokens} توكن مُقدَّر) لنافذة "
                        f"80K الإجمالية لهذا الموديل - لا مساحة آمنة للإخراج"
                    )
                effective_max_tokens = min(max_tokens, available_for_output)

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": effective_prompt})

        body = {
            "messages": messages,
            "max_tokens": effective_max_tokens,
            "temperature": temperature,
        }

        # ⚠️ إصلاح خطأ بطء حقيقي مُكتشف (يوليو 2026، طلب صريح من
        # المستخدم بتسريع gemma-4-26b-a4b-it تحديداً): هذا الموديل أيضاً
        # "موديل استدلال" (خاصية reasoning=true معلنة رسمياً بكتالوج
        # Cloudflare) - يكتب حقل "reasoning" داخلي طويل قبل كل رد، وهذا
        # سبب التذبذب الشديد الموثّق (91-652 ثانية على نفس نوع الطلب
        # بالضبط). فحص فعلي (curl مباشر) وجد بارامتر رسمي مخصص لهذا:
        # reasoning_effort (القيم المقبولة فقط: none/low/medium/high -
        # لا يوجد إلغاء تام، لكن "none" يقلّص التفكير بشكل ملحوظ). تحقق
        # فعلي مباشر: نفس مرحلة Weekly كاملة (26K توكن دخل) أخذت 32.8
        # ثانية بـreasoning_effort=none مقابل 100-135 ثانية بدونه -
        # تحسّن حقيقي بمعدل 3-4× دون تغيير المحتوى المطلوب أو الدقة.
        if "gemma-4" in provider.model:
            body["reasoning_effort"] = "none"

        if force_json and response_schema:
            body["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": "trading_signal",
                    "schema": self._convert_gemini_schema_to_json_schema(response_schema),
                },
            }
        elif force_json:
            # لا schema محدد - نطلب JSON عام بدون بنية صارمة
            body["response_format"] = {"type": "json_object"}

        resp = self.session.post(url, headers=headers, json=body, timeout=timeout)

        if resp.status_code == 200:
            data = resp.json()
            if not data.get("success", True):
                raise _SoftFail(f"Cloudflare: {data.get('errors')}")
            result = data.get("result", {})
            usage = result.get("usage", {})
            in_tok = usage.get("prompt_tokens", 0)
            out_tok = usage.get("completion_tokens", 0)

            # ═══ استخراج النص/الـJSON من الرد ═══
            # مع json_schema، Cloudflare أحياناً يرجع الحقل "response"
            # كـ dict جاهز مباشرة (لا حاجة لإعادة تحليله كنص)، وأحياناً
            # النص الخام بـchoices[0].message.content - نتحقق من الحالتين.
            def _check_schema_echo(candidate):
                """
                ⚠️ إصلاح خطأ حقيقي مُكتشف (deepseek-r1-distill-qwen-32b):
                أحياناً الرد لا يحوي <think> إطلاقاً لكنه أيضاً ليس الجواب
                الفعلي - هو نسخة طبق الأصل من بنية الـjson_schema المطلوبة
                نفسها (حقول "schema"+"name") بدل تعبئتها بقيم حقيقية. فشل
                واضح يجب اكتشافه صراحة بدل قبوله كجواب صحيح خاطئ.
                """
                if (response_schema is not None and isinstance(candidate, dict)
                        and "schema" in candidate and "name" in candidate):
                    raise _SoftFail(
                        "Cloudflare (deepseek-r1): الموديل كرّر بنية "
                        "الـjson_schema المطلوبة نفسها بدل تعبئتها بقيم "
                        "فعلية - فشل معروف لهذا الموديل، يستاهل إعادة محاولة"
                    )

            def _check_reasoning_content_consistency(reasoning_text, content_candidate):
                """
                ⚠️ إصلاح خطأ حقيقي وخطير مُكتشف (يوليو 2026، gemma-4-26b):
                حالات موثّقة فعلياً حيث حقل "reasoning" الداخلي يستنتج
                اتجاهاً صحيحاً بوضوح تام (مثال حقيقي: "Close < Open...
                the candle is BEARISH") بينما حقل "content" النهائي
                (الجواب الفعلي المُستخدَم) يرجع **عكسه تماماً**
                ("BULLISH"). هذا عدم اتساق داخلي خطير - إن مرّ بصمت، قد
                يُبنى قرار BUY/SELL كامل على نتيجة معكوسة عن تحليل
                الموديل الحقيقي الصحيح.

                الفحص: لو الاستنتاج الأخير الصريح بنص reasoning يحتوي
                كلمة اتجاهية واضحة (bullish/bearish) لا تطابق القيمة
                النهائية بنفس الحقل بالـcontent، نرفض الرد صراحة (يستاهل
                إعادة محاولة على مفتاح آخر - نفس آلية _SoftFail الموجودة).

                ⚠️ هذا الفحص متحفظ عمداً (لا يفحص كل تشابه لفظي عابر
                بمنتصف نص التفكير، فقط الجملة الأخيرة الحاسمة التي تحوي
                كلمة استنتاجية صريحة مثل "is/therefore/so/answer/result")
                لتفادي رفض ردود صحيحة بسبب ذكر الاتجاهين أثناء المقارنة
                (كما يحصل طبيعياً بأي تحليل: "if X then bullish, if Y
                then bearish... calculation shows bearish").
                """
                if not reasoning_text or not isinstance(content_candidate, dict):
                    return
                # ⚠️ إصلاح خطأ بمنطق الفحص - نُسخة ثانية (يوليو 2026):
                # المحاولة الأولى اعتمدت على عبارات استنتاج ثابتة سلفاً
                # ("therefore"...) - فشلت لأن حالة حقيقية استخدمت كلمة
                # "Calculation:" غير المدرجة. المحاولة الثانية (آخر ذكر
                # لأي كلمة اتجاهية بكامل النص) فشلت أيضاً - اختبار فعلي
                # حقيقي كشف أن جملة **تعريفية عامة** ("if Close<Open then
                # Bearish, if Close>Open then Bullish") تحتوي كلا
                # الكلمتين وتأتي أحياناً بعد جملة الحساب الفعلي، فتُخفي
                # الاستنتاج الحقيقي الأسبق. الحل الثالث والأدق: نستبعد
                # صراحة أي جملة **شرطية/تعريفية عامة** (تحتوي "if"، "or"،
                # "common"، "either"، "whether" - علامات نمطية على "شرح
                # قاعدة عامة" لا "استنتاج فعلي لهذه الحالة تحديداً")، ثم
                # نأخذ آخر جملة **تقريرية** متبقية (لا شرطية) تذكر إحدى
                # الكلمتين كتمثيل حقيقي لاستنتاج النموذج الفعلي. تحقق
                # فعلي: هذا المنطق حدّد بدقة "Calculation: 150<200 =>
                # Bearish" كالاستنتاج الحقيقي (مستبعداً الجملة الشرطية
                # العامة السابقة لها) - يطابق تماماً الخطأ الموثّق.
                directional_pairs = [("bullish", "bearish")]
                clauses = [c.strip().lower() for c in re.split(r"[\n.]", reasoning_text) if c.strip()]
                conditional_markers = ("if ", " or ", "common", "either", "whether", "typically")
                declarative_clauses = [c for c in clauses if not any(m in c for m in conditional_markers)]

                for field, value in content_candidate.items():
                    if not isinstance(value, str):
                        continue
                    value_lower = value.lower()
                    for word_a, word_b in directional_pairs:
                        if value_lower not in (word_a, word_b):
                            continue
                        opposite = word_b if value_lower == word_a else word_a
                        relevant_clauses = [c for c in declarative_clauses if value_lower in c or opposite in c]
                        if not relevant_clauses:
                            continue
                        last_relevant = relevant_clauses[-1]
                        # التناقض الحقيقي: آخر جملة تقريرية (غير شرطية)
                        # تذكر إحدى الكلمتين تحوي الكلمة **المعاكسة**
                        # للقيمة الموضوعة فعلياً بالحقل النهائي.
                        if opposite in last_relevant and value_lower not in last_relevant:
                            raise _SoftFail(
                                f"Cloudflare (gemma-4): تناقض داخلي مكتشف - حقل "
                                f"'{field}' النهائي='{value}' لكن آخر استنتاج "
                                f"تقريري صريح بالتفكير الداخلي قال '{opposite}' "
                                f"({last_relevant!r}) - فشل اتساق حقيقي موثّق "
                                f"بهذا الموديل، يستاهل إعادة محاولة"
                            )

            if isinstance(result.get("response"), dict):
                _check_schema_echo(result["response"])
                self._save_key_ai_ok(account_id, token)
                return json.dumps(result["response"], ensure_ascii=False), in_tok, out_tok

            if result.get("choices"):
                self._save_key_ai_ok(account_id, token)
                message = result["choices"][0].get("message", {})
                text = message.get("content") or ""
                reasoning_text = message.get("reasoning") or ""
                # If model used all tokens on reasoning, we need higher max_tokens
                if not text and result["choices"][0].get("finish_reason") == "length":
                    raise _MaxTokensExceeded(
                        f"Cloudflare: reasoning consumed all {max_tokens} tokens "
                        "(content is empty). Need higher limit.")
                try:
                    parsed_candidate = json.loads(self._clean_response(text))
                    _check_schema_echo(parsed_candidate)
                    if "gemma-4" in provider.model:
                        _check_reasoning_content_consistency(reasoning_text, parsed_candidate)
                except (json.JSONDecodeError, TypeError):
                    pass
                return text, in_tok, out_tok

            if isinstance(result.get("response"), str):
                self._save_key_ai_ok(account_id, token)
                text = result["response"]
                try:
                    _check_schema_echo(json.loads(self._clean_response(text)))
                except (json.JSONDecodeError, TypeError):
                    pass
                return text, in_tok, out_tok

            self._save_key_ai_fail(account_id, "no valid response")
            raise _SoftFail("Cloudflare: لا يوجد رد نصي/JSON بالنتيجة")

        elif resp.status_code == 429:
            self._save_key_ai_fail(account_id, "rate limited")
            raise _RateLimited("Cloudflare rate limited")
        elif resp.status_code in (400, 401, 403):
            raise _KeyInvalid(f"Cloudflare key invalid/blocked: {resp.text[:200]}")
        elif resp.status_code == 402:
            # حساب يحتاج رصيد فعلي - يعني هذا التوكن/الحساب أصبح مدفوعاً
            # (خارج الحصة المجانية) - لا فائدة من إعادة المحاولة عليه
            raise _QuotaExhausted(f"Cloudflare: يتطلب رصيد مدفوع: {resp.text[:200]}")
        else:
            raise _SoftFail(f"Cloudflare HTTP {resp.status_code}: {resp.text[:200]}")

    def _dispatch(self, provider, key, prompt, system_prompt, max_tokens,
                  temperature, force_json, timeout, response_schema=None):
        if provider.name == "gemini":
            return self._call_gemini(
                provider, key, prompt, system_prompt, max_tokens,
                temperature, force_json, timeout, response_schema
            )
        if provider.name == "cloudflare":
            return self._call_cloudflare(
                provider, key, prompt, system_prompt, max_tokens,
                temperature, force_json, timeout, response_schema
            )
        if provider.name == "openrouter":
            return self._call_openai_compatible(
                provider, key, "https://openrouter.ai/api/v1/chat/completions",
                prompt, system_prompt, max_tokens, temperature, force_json, timeout,
                extra_headers={
                    "HTTP-Referer": "https://localhost",
                    "X-Title": "Kotrader Trading Bot",
                },
            )
        raise _SoftFail(f"Unknown provider {provider.name}")

    # ══════════════════════════════════════════════════════════
    #  الدالة الرئيسية - تجرب كل المزودين بالترتيب
    # ══════════════════════════════════════════════════════════

    def query(self, prompt, system_prompt=None, max_tokens=None, use_cache=True,
              force_json=False, response_schema=None, temperature=None):
        """
        إرسال طلب للـ AI - يجرب كل المزودين بالترتيب المحدد حتى ينجح واحد.
        عند فشل/استنفاد مزود بالكامل ينتقل تلقائياً للتالي.

        Args:
            response_schema: (اختياري) Gemini responseSchema صارم - يفرض
                بنية JSON ثابتة 100% (نوع كل حقل محدد مسبقاً) بدل ترك
                النموذج يختار الشكل بحرية، وهذا يحل مشكلة عدم استقرار
                الشكل (مثلاً confidence كرقم مرة وكـ dict مرة أخرى).
            temperature: (اختياري) يتجاوز Config.TEMPERATURE - مفيد
                لتقليل العشوائية أكثر بمهام تتطلب دقة عالية.
        """
        system_prompt = system_prompt or Config.SYSTEM_PROMPT
        max_tokens = max_tokens or Config.MAX_TOKENS
        temperature = temperature if temperature is not None else Config.TEMPERATURE
        # ⚠️ تسريع إضافي (طلب المستخدم الصريح: "بدي نخلي الدقة بنفس
        # الوقت أسرع شي"، بعد ملاحظة صفقات تاخذ 9-10 دقائق): كانت المهلة
        # 180 ثانية لكل محاولة واحدة - إذا "عَلِق" مفتاح ما (السيرفر لا
        # يرفضه بسرعة، بل يُبقي الاتصال مفتوحاً بلا رد - حالة موثّقة
        # فعلياً بـlogs سابقة: "Read timed out. (read timeout=180)")،
        # كان يُهدر حتى 180 ثانية كاملة على محاولة واحدة معلّقة قبل
        # الانتقال. تحقق فعلي مباشر: أطول رد **ناجح فعلياً** موثّق بهذه
        # الجلسة كان 123.9 ثانية (مرحلة 1H، صفقة ETH/USDT). خفضنا المهلة
        # لـ150 ثانية (هامش أمان 26 ثانية فوق أطول رد ناجح حقيقي موثّق -
        # لا خطر فقدان أي رد شرعي، فقط تقليص الانتظار الأقصى الممكن على
        # طلب معلّق فعلياً لا يريد الرد). هذا يوفر 30 ثانية على كل محاولة
        # معلّقة (لا كل محاولة - فقط الحالات النادرة المعلّقة فعلياً؛
        # الحالات الطبيعية "rate limited" ترفض خلال أجزاء من الثانية
        # أصلاً ولا تتأثر بهذا التعديل إطلاقاً).
        timeout_seconds = 60  # was 150s - too slow

        if not self.provider_order:
            return json.dumps({
                "error": "لا يوجد أي مزود AI مفعّل. أضف مفتاح API بملف .env"
            })

        # ── Cache ──
        cache_key = None
        if use_cache:
            cache_key = hashlib.md5(
                (prompt + str(force_json) + str(response_schema)).encode()
            ).hexdigest()
            if cache_key in self.cache:
                ts, val = self.cache[cache_key]
                if time.time() - ts < Config.CACHE_TTL:
                    self.logger.info("📦 Cache hit")
                    return val

        # ── Rate limiting بسيط بين الطلبات ──
        wait = 1.2 - (time.time() - self.last_request_time)
        if wait > 0:
            time.sleep(wait)

        last_error = None

        for provider_name in self.provider_order:
            provider = self.providers[provider_name]
            if provider.too_slow:
                self.logger.info(
                    f"⏭️ تخطي {provider.name} (مُصنَّف بطيء جداً هذه الجلسة "
                    f"- آخر رد استغرق {provider.last_response_seconds:.1f}s)"
                )
                continue
            if not provider.has_keys or provider.all_exhausted:
                continue

            key_attempts = 0
            max_key_attempts = len(provider.keys)
            # ⚠️ إصلاح فعلي (يوليو 2026، طلب المستخدم الصريح بعد ملاحظة
            # الوقت المهدور بالـlogs الفعلية): كانت القيمة 3 (أي 4 محاولات
            # إجمالية: أصلية + 3 إعادة، بانتظار تصاعدي 5+10+15=30 ثانية
            # لكل مفتاح واحد فقط قبل التبديل) - دليل فعلي موثّق بجلسة
            # سابقة: نفس المفتاح تكرر 4 مرات كاملة قبل التبديل، مع وجود
            # 18 مفتاح احتياطي جاهز فوراً - انتظار طويل بلا داعٍ عندما
            # يوجد بديل متاح فوراً. طلب المستخدم الحرفي: "إذا استخدمت
            # مفتاح ومامشي حاله مسموحلك تعاود مرة وحدة فقط أو تنتقل يلي
            # بعده - مو تعاود أربع خمس مرات". تعديل إضافي لاحق (طلب
            # المستخدم الحرفي): "لما تشتغل بتجرب مرة وحدة بدل مرتين،
            # فقط مرة وحدة وبعدها بتنتقل عالتاني إذا ما اشتغل - بدي نكون
            # أسرع شي". الحل النهائي: صفر إعادة محاولة على نفس المفتاح
            # (محاولة واحدة فقط) - أي فشل (rate limit/soft fail) ينتقل
            # فوراً للمفتاح التالي بلا أي انتظار على هذا المفتاح. مع 18
            # مفتاح احتياطي متاح، التبديل الفوري أرخص زمنياً دائماً من
            # انتظار حتى 5 ثوانٍ على مفتاح قد يبقى محظوراً أصلاً.
            max_retries_per_key = 0
            # ⚠️ حد التوكن الفعلي المُستخدم بهذه المحاولة - قابل للزيادة
            # ديناميكياً عند اكتشاف MAX_TOKENS (الرد انقطع بمنتصفه).
            # منفصل عن `max_tokens` الأصلي لأنه قد يتغير بين محاولة
            # وأخرى بنفس الطلب، بدون التأثير على طلبات مستقبلية أخرى.
            current_max_tokens = max_tokens
            max_tokens_retries = 2  # يسمح بمحاولتين إضافيتين بحد أعلى تدريجياً

            while key_attempts < max_key_attempts:
                key = provider.current_key()
                key_short = key[-8:]
                retry_count = 0
                switched = False
                skip_provider_entirely = False

                while retry_count <= max_retries_per_key:
                    try:
                        self.last_request_time = time.time()
                        self.logger.info(
                            f"🔄 {provider.name} ({provider.model}) | "
                            f"Key: ...{key_short}"
                            + (f" | محاولة {retry_count+1}/{max_retries_per_key+1}" if retry_count > 0 else "")
                        )
                        _dispatch_started = time.time()
                        raw_text, in_tok, out_tok = self._dispatch(
                            provider, key, prompt, system_prompt, current_max_tokens,
                            temperature, force_json, timeout_seconds, response_schema
                        )
                        elapsed = time.time() - _dispatch_started
                        provider.last_response_seconds = elapsed
                        result = self._clean_response(raw_text)

                        # تحديث الإحصائيات (Gemini مجاني بالكامل - لا تكلفة)
                        provider.key_stats[key_short]["requests"] += 1
                        self.request_count += 1

                        if use_cache and cache_key:
                            self.cache[cache_key] = (time.time(), result)

                        self.logger.info(
                            f"✅ OK via {provider.name} | in:{in_tok} out:{out_tok} | "
                            f"{elapsed:.1f}s | #{self.request_count}"
                        )

                        # ── حماية تلقائية من البطء ──
                        # لو هالطلب أخذ أطول من الحد المسموح، نعلّم هذا
                        # المزود "بطيء جداً" حتى لو نجحت النتيجة، ونمنع
                        # استخدامه بباقي الجلسة - القرار: السرعة شرط
                        # أساسي مش رفاهية. النتيجة الحالية بترجع طبيعي
                        # (ما منرميها، هي دقيقة وناجحة)، بس المزود بينشال
                        # تلقائياً من الاستخدام القادم.
                        #
                        # ⚠️ إصلاح خطأ حقيقي مُكتشف بالاختبار الفعلي:
                        # بعد حزف كل المزودين ما عدا Gemini، لو Gemini
                        # نفسه أخذ وقتاً أطول من الحد (أمر متوقع أحياناً
                        # مع دستور ضخم 150K+ توكن، وليس عطلاً حقيقياً)،
                        # كان يُستبعد فوراً فيفشل *كل* تحليل لاحق بالجلسة
                        # بالكامل (لا يوجد أي مزود بديل يُنتقل إليه).
                        # الحل: لا نُعطّل مزوداً لو كان "آخر مزود مفعّل
                        # فعلياً" في provider_order بأكمله - عندها البطء
                        # مقبول (أفضل من توقف كامل)، ويبقى التحذير باللوق
                        # فقط للعلم دون تعطيل عملي.
                        active_providers_count = sum(
                            1 for p in self.provider_order
                            if self.providers[p].has_keys and not self.providers[p].too_slow
                        )
                        if elapsed > Config.MAX_ACCEPTABLE_PROVIDER_SECONDS:
                            if active_providers_count > 1:
                                provider.too_slow = True
                                self.logger.warning(
                                    f"🐢 {provider.name} أخذ {elapsed:.1f}s (أبطأ من الحد "
                                    f"المسموح {Config.MAX_ACCEPTABLE_PROVIDER_SECONDS:.0f}s) "
                                    "- استُبعد تلقائياً من باقي هذه الجلسة (يوجد مزود بديل)"
                                )
                            else:
                                self.logger.warning(
                                    f"🐢 {provider.name} أخذ {elapsed:.1f}s (أبطأ من الحد "
                                    f"المسموح {Config.MAX_ACCEPTABLE_PROVIDER_SECONDS:.0f}s) "
                                    "- لكنه آخر مزود مفعّل، فلن يُستبعد (التوقف الكامل أسوأ "
                                    "من البطء)"
                                )

                        return result


                    except _RateLimited:
                        provider.key_stats[key_short]["errors"] += 1
                        retry_count += 1
                        if retry_count <= max_retries_per_key:
                            wait_time = 5 * retry_count  # backoff تصاعدي: 5, 10, 15s
                            self.logger.warning(
                                f"⏳ {provider.name} rate limited على ...{key_short} - "
                                f"إعادة محاولة خلال {wait_time}s..."
                            )
                            time.sleep(wait_time)
                            continue
                        else:
                            self.logger.warning(
                                f"⏳ {provider.name} rate limited على ...{key_short} "
                                f"(محاولة واحدة فقط) - تبديل فوري للمفتاح التالي"
                            )
                            switched = True
                            break

                    except _MaxTokensExceeded as e:
                        # ═══ إصلاح خطأ حقيقي مُكتشف بالباك تيست الفعلي ═══
                        # اكتُشف أن ردوداً طويلة (14K+ توكن مخرجات، قريبة
                        # من حد MAX_TOKENS الافتراضي 16384) كانت تنقطع
                        # بمنتصف الـJSON، فيفشل query_json() بصمت ويرجع
                        # {"raw_response": ...} أو "UNKNOWN" - يُحسب خطأً
                        # كفشل تحليل رغم أن المزود نجح فعلياً والمشكلة
                        # فقط حجم الحد. الحل: نرفع current_max_tokens
                        # ونعيد المحاولة فوراً على نفس المفتاح (ليست
                        # مشكلة صلاحية مفتاح ولا حصة، فقط حجم الرد).
                        provider.key_stats[key_short]["errors"] += 1
                        max_tokens_retries -= 1
                        if max_tokens_retries >= 0:
                            old_tokens = current_max_tokens
                            current_max_tokens = min(int(current_max_tokens * 1.5), 32768)
                            self.logger.warning(
                                f"✂️ {provider.name}: {e} - رفع حد التوكن من "
                                f"{old_tokens} إلى {current_max_tokens} وإعادة المحاولة فوراً"
                            )
                            continue
                        else:
                            self.logger.warning(
                                f"✂️ {provider.name}: استنفدت محاولات رفع حد التوكن - "
                                "تبديل المفتاح"
                            )
                            switched = True
                            break

                    except _QuotaExhausted as e:
                        # نفاد يومي كامل - لا فائدة من إعادة أي محاولة
                        # على هذا المفتاح اليوم. تعليمه exhausted فوراً
                        # وتبديل بدون إهدار أي وقت على retries عبثية.
                        provider.key_stats[key_short]["errors"] += 1
                        provider.mark_exhausted(key)
                        self.logger.warning(
                            f"📅 {provider.name} ...{key_short}: نفدت الحصة اليومية "
                            f"بالكامل - تبديل فوري للمفتاح التالي (بدون إعادة محاولة) "
                            f"| {e}"
                        )
                        switched = True
                        break

                    except _RequestTooLarge as e:
                        # الطلب أكبر من حد التوكن/دقيقة لهذا المزود -
                        # إعادة المحاولة عبثية (الحجم لن يتغير)، وتجربة
                        # مفتاح آخر لنفس المزود عديمة الفائدة أيضاً (نفس
                        # حد TPM ينطبق عادة على كل مفاتيح نفس المزود) -
                        # ننتقل فوراً للمزود التالي بالكامل دون تعليم
                        # المفتاح exhausted (فهو صالح تماماً لطلبات أصغر
                        # بدوال أخرى بالمشروع لاحقاً).
                        provider.key_stats[key_short]["errors"] += 1
                        last_error = str(e)
                        self.logger.warning(
                            f"📏 {provider.name}: الطلب أكبر من حد TPM المسموح "
                            f"({e}) - تخطي هذا المزود بالكامل والانتقال للتالي"
                        )
                        skip_provider_entirely = True
                        break

                    except _KeyInvalid as e:
                        provider.key_stats[key_short]["errors"] += 1
                        provider.mark_exhausted(key)
                        self.logger.error(f"❌ {provider.name} key ...{key_short}: {e}")
                        switched = True
                        break

                    except (_SoftFail, requests.exceptions.RequestException) as e:
                        provider.key_stats[key_short]["errors"] += 1
                        last_error = str(e)
                        retry_count += 1
                        if retry_count <= max_retries_per_key:
                            # 503 (high demand) عادة مؤقت جداً - إعادة محاولة سريعة كافية
                            wait_time = 4 * retry_count
                            self.logger.warning(
                                f"⚠️ {provider.name}: {e} - إعادة محاولة خلال {wait_time}s..."
                            )
                            time.sleep(wait_time)
                            continue
                        else:
                            self.logger.warning(
                                f"⚠️ {provider.name} فشل (محاولة واحدة فقط) - "
                                "تبديل فوري للمفتاح/المزود التالي"
                            )
                            switched = True
                            break

                if skip_provider_entirely:
                    # الطلب أكبر من حد TPM لهذا المزود بالكامل - لا فائدة
                    # من تجربة أي مفتاح آخر لنفس المزود بنفس الطلب
                    break
                elif switched:
                    next_key = provider.next_key()
                    key_attempts += 1
                    if next_key is None:
                        break
                    continue
                else:
                    # استنفدنا إعادة المحاولات بدون تبديل صريح (حالة نادرة)
                    key_attempts += 1
                    if key_attempts >= max_key_attempts:
                        break

            self.logger.warning(
                f"🔀 كل مفاتيح {provider.name} فشلت/انتهت، الانتقال للمزود التالي..."
            )


        # كل المزودين فشلوا
        error_msg = f"فشل كل المزودين المتاحين ({', '.join(self.provider_order)})"
        if last_error:
            error_msg += f" | آخر خطأ: {last_error}"
        self.logger.error(f"💥 {error_msg}")
        return json.dumps({"error": error_msg})

    def query_json(self, prompt, **kwargs):
        """طلب مع طلب صريح لإخراج JSON + parsing قوي متعدد المراحل"""
        kwargs.setdefault("force_json", True)
        raw = self.query(prompt, **kwargs)

        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            pass

        try:
            if "```json" in raw:
                raw2 = raw.split("```json")[1].split("```")[0]
                return json.loads(raw2)
            elif "```" in raw:
                raw2 = raw.split("```")[1].split("```")[0]
                return json.loads(raw2)
        except (json.JSONDecodeError, IndexError):
            pass

        try:
            s = raw.find("{")
            e = raw.rfind("}") + 1
            if s != -1 and e > s:
                return json.loads(raw[s:e])
        except json.JSONDecodeError:
            pass

        try:
            s = raw.find("{")
            if s != -1:
                candidate = raw[s:]
                opens = candidate.count("{")
                closes = candidate.count("}")
                if opens > closes:
                    candidate += "}" * (opens - closes)
                return json.loads(candidate)
        except json.JSONDecodeError:
            pass

        return {"raw_response": raw[:500]}

    # ══════════════════════════════════════════════════════════
    #  تقسيم عمل حقيقي داخل المرحلة الواحدة (Field-Split Parallel)
    # ══════════════════════════════════════════════════════════
    # ⚠️ طلب المستخدم الدقيق (يوليو 2026): "نفس المرحلة (مثلاً Weekly)
    # أكيد عم تدور ع أكتر من شغلة سوا بنفس الفريم - فينا نخلي كل مفتاح
    # يشتغل شغلة وبالآخر يتقاطعوا، مو أسرع؟". هذا مختلف تماماً عن
    # "تصويت الأغلبية" (نفس السؤال مكرر بمفتاحين، نختار الأغلبية) الذي
    # عُطِّل بطلب صريح سابق - هنا: **نفس المرحلة تُقسَّم لأسئلة فرعية
    # حقيقية مختلفة** (كل استدعاء يجاوب على حقول مختلفة تماماً من نفس
    # الـschema، لا نفس الحقول مكررة)، فتُطلَق بالتوازي بنفس اللحظة على
    # مفاتيح مختلفة، ثم تُدمَج النتائج بدمج بسيط (لا تصويت - كل استدعاء
    # "جاب" جزءه المختلف). كل استدعاء فرعي يستلم **نفس البيانات الخام
    # الكاملة** (نفس الشموع، نفس قسم الدستور) - لا فقدان معلومة، فقط
    # السؤال المطلوب أضيق فأسرع بالتفكير والكتابة.

    def _parse_json_text(self, raw):
        """نفس منطق parsing متعدد المراحل بـquery_json - مُستخرَج كدالة
        مستقلة لإعادة استخدامها بالاستدعاءات الفرعية المتوازية بلا
        تكرار كود. (أُعيدت بعد حذف عرضي أثناء تنظيف كود سابق)."""
        if not raw:
            return {"raw_response": ""}
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            pass
        try:
            if "```json" in raw:
                return json.loads(raw.split("```json")[1].split("```")[0])
            elif "```" in raw:
                return json.loads(raw.split("```")[1].split("```")[0])
        except (json.JSONDecodeError, IndexError):
            pass
        try:
            s, e = raw.find("{"), raw.rfind("}") + 1
            if s != -1 and e > s:
                return json.loads(raw[s:e])
        except json.JSONDecodeError:
            pass
        return {"raw_response": raw[:500]}

    # ══════════════════════════════════════════════════════════
    #  السباق بين مفتاحين (Race) - نفس السؤال بالضبط، أول جواب ناجح يفوز
    # ══════════════════════════════════════════════════════════
    # ⚠️ طلب المستخدم الدقيق (يوليو 2026): تسريع gemma-4-26b-a4b-it
    # (موديل استدلال بطيء وغير مستقر زمنياً - تذبذب موثّق فعلياً بين
    # 32.8s و652s على نفس نوع الطلب بالضبط) **بدون فقدان أي دقة**.
    # ⚠️ الفرق الجوهري عن "التصويت" (الذي عُطِّل بطلب صريح سابق): هنا
    # لا يوجد دمج نتائج ولا تصويت أغلبية - **فقط أول رد ناجح يُستخدم
    # حرفياً كما هو، والرد الثاني (إن وصل لاحقاً) يُهمَل بالكامل ولا
    # يؤثر على أي شيء**. هذا يحل مشكلة "التذبذب الزمني" تحديداً: بما
    # أن نفس الطلب بالضبط قد يأخذ 30 ثانية أو 90 ثانية بشكل عشوائي
    # (طبيعة الموديل الاحتمالية)، إطلاق محاولتين متوازيتين لنفس السؤال
    # يعني أننا نتلقى دائماً بسرعة "أفضل حالة" المتاحة في تلك اللحظة
    # بدل الاعتماد على محاولة واحدة قد تكون هي الأبطأ صدفة. لا مخاطرة
    # حقيقية على الدقة: كلا الاستدعاءين يطرحان نفس السؤال بالضبط على
    # نفس البيانات - الفرق فقط أي واحد وصل أولاً، لا اختلاف بالمحتوى.

    def query_json_race(self, prompt, response_schema, race_count=4, **kwargs):
        """
        يطلق race_count "مساراً" متوازياً بنفس اللحظة، كل مسار يحاول
        مفتاحاً مختلفاً - وإذا فشل مساره (rate limit/خطأ مؤقت)، ينتقل
        فوراً لمفتاح آخر لم يُستخدَم بعد بأي مسار آخر (لا انتظار طويل،
        عندنا عدد كافٍ من المفاتيح لتفادي الحاجة لذلك). يُرجع أول نتيجة
        JSON صالحة تصل من أي مسار - لا دمج ولا تصويت، فقط الأسرع يفوز.

        ⚠️ إصلاح فعلي مُكتشف بالاختبار: النسخة الأولى (race_count=2)
        كانت تفشل بالكامل إذا صادف كلا المفتاحين المُختارين "منهكين"
        بنفس اللحظة (rate limited) - رفعنا race_count الافتراضي و
        أضفنا "احتياطي داخل كل مسار" (كل مسار يجرب حتى 3 مفاتيح مختلفة
        بالتتابع السريع قبل الاستسلام)، بدل الاعتماد على مسارين فقط
        بمحاولة واحدة لكل منهما.
        """
        provider = self.providers.get("cloudflare")
        if not provider or not provider.has_keys:
            return self.query_json(prompt, response_schema=response_schema, **kwargs)

        available_keys = [
            k for k in provider.keys if not provider.key_stats[k[-8:]]["exhausted"]
        ]
        if len(available_keys) <= 1:
            return self.query_json(prompt, response_schema=response_schema, **kwargs)

        system_prompt = kwargs.get("system_prompt") or Config.SYSTEM_PROMPT
        max_tokens = kwargs.get("max_tokens") or Config.MAX_TOKENS
        temperature = kwargs.get("temperature")
        temperature = temperature if temperature is not None else Config.TEMPERATURE
        # نفس تخفيض المهلة الآمن الموضَّح أعلاه بـquery_json (180s → 150s)
        # - يطبَّق هنا أيضاً لأن query_json_race هي المسار الفعلي
        # المستخدم بكل مراحل multi_pass_analysis.py.
        timeout_seconds = 60  # was 150s - too slow

        n = max(2, min(race_count, len(available_keys)))
        # ⚠️ توزيع المفاتيح على المسارات: كل مسار يحصل على شريحة مختلفة
        # من قائمة المفاتيح المتاحة كـ"احتياطي داخلي" خاص فيه - يمنع
        # مسارين مختلفين من "التصادم" على نفس المفتاح البديل عند الفشل.
        lanes = [available_keys[i::n] for i in range(n)]

        def _attempt_lane(lane_keys):
            """يجرب مفاتيح هذا المسار بالتتابع السريع (بلا انتظار طويل
            بين المحاولات - فقط انتقال فوري لمفتاح آخر) حتى ينجح أو
            تنفد مفاتيح هذا المسار تحديداً."""
            last_error = None
            for key in lane_keys:
                t0 = time.time()
                try:
                    raw_text, in_tok, out_tok = self._dispatch(
                        provider, key, prompt, system_prompt, max_tokens,
                        temperature, True, timeout_seconds, response_schema,
                    )
                    parsed = self._parse_json_text(self._clean_response(raw_text))
                    provider.key_stats[key[-8:]]["requests"] += 1
                    elapsed = round(time.time() - t0, 1)
                    return {"success": True, "result": parsed, "elapsed": elapsed, "key": key[-8:]}
                except _QuotaExhausted:
                    provider.mark_exhausted(key)
                    last_error = "quota_exhausted"
                    continue  # فوراً للمفتاح التالي بهذا المسار - بلا انتظار
                except Exception as e:
                    last_error = str(e)
                    continue  # فوراً للمفتاح التالي بهذا المسار - بلا انتظار
            return {"success": False, "error": last_error, "key": None}

        # ⚠️ إصلاح خطأ أداء حقيقي وخطير مُكتشف بالاختبار الفعلي: استخدام
        # `with ThreadPoolExecutor(...) as executor:` كان يجعل السباق
        # بأكمله ينتظر انتهاء **كل** المسارات (حتى الخاسرة/الأبطأ) عند
        # الخروج من الـwith block - لأن `__exit__` يستدعي تلقائياً
        # `shutdown(wait=True)`. دليل الفرق الفعلي المُقاس: مسار فاز
        # فعلياً خلال 24.9 ثانية، لكن الدالة كاملة استغرقت 220.1 ثانية -
        # 195 ثانية ضائعة بانتظار مسارات لم تعد مطلوبة بعد الفوز. الحل:
        # عدم استخدام `with` - استدعاء shutdown(wait=False) صراحةً بعد
        # الحصول على أول نتيجة، للسماح بإرجاع النتيجة فوراً دون انتظار.
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=n)
        futures = {executor.submit(_attempt_lane, lane): idx for idx, lane in enumerate(lanes)}
        first_valid = None
        errors = []
        for future in concurrent.futures.as_completed(futures):
            outcome = future.result()
            if outcome["success"] and isinstance(outcome["result"], dict) and "raw_response" not in outcome["result"]:
                first_valid = outcome
                break
            errors.append(outcome)
        # لا ننتظر المسارات المتبقية - نغلق بلا انتظار (wait=False)،
        # الخيوط الجارية ستكمل بالخلفية وتُهمَل نتيجتها، لكن لن تُعطّل
        # إرجاع النتيجة الفائزة فوراً.
        executor.shutdown(wait=False, cancel_futures=True)

        if first_valid:
            self.logger.info(
                f"🏁 Race: فاز المفتاح ...{first_valid['key']} خلال {first_valid['elapsed']}s "
                f"(من أصل {n} مسارات متوازية)"
            )
            return first_valid["result"]

        # لا رد ناجح من أي مسار - نرجع لاستدعاء عادي احتياطي (يجرب كل
        # المفاتيح المتبقية بمنطق retry الكامل الموجود أصلاً بـquery())
        self.logger.warning(f"⚠️ Race: فشلت كل المسارات المتوازية ({errors}) - محاولة عادية احتياطية شاملة")
        return self.query_json(prompt, response_schema=response_schema, **kwargs)

    def query_json_split_parallel(self, base_prompt, field_groups, timeout_seconds=180):
        """
        ينفّذ عدة استدعاءات فرعية بالتوازي لنفس المرحلة، كل استدعاء
        يطلب مجموعة حقول مختلفة (field_groups) من نفس الـschema الكلي،
        على نفس البيانات الخام الكاملة (base_prompt). يدمج كل النتائج
        بدمج بسيط (union) - كل حقل من مصدره الوحيد المسؤول عنه.

        Args:
            base_prompt: النص الكامل (بيانات + دستور المرحلة) - نفسه
                لكل الاستدعاءات الفرعية، فقط تعليمة "ركّز على هذه الحقول
                فقط" تُضاف لكل واحد.
            field_groups: قائمة dicts، كل واحد {"schema": {...جزء من
                الـschema الكلي...}, "focus_note": نص توضيحي اختياري}

        Returns:
            (merged_dict, meta) - merged_dict فيه كل الحقول من كل
            المجموعات مدموجة، meta فيها تفاصيل كل استدعاء فرعي (الوقت،
            المفتاح المستخدم، النجاح/الفشل) للشفافية الكاملة.
        """
        pool = []
        for provider_name in ("cloudflare", "gemini"):
            provider = self.providers.get(provider_name)
            if not provider:
                continue
            for key in provider.keys:
                if not provider.key_stats[key[-8:]]["exhausted"]:
                    pool.append({"provider": provider_name, "key": key})

        if not pool:
            return {}, {"error": "لا يوجد أي مفتاح حيّ بأي مزود"}

        def _run_sub_call(idx, group):
            worker = pool[idx % len(pool)]
            provider = self.providers[worker["provider"]]
            key = worker["key"]
            focus_note = group.get("focus_note", "")
            sub_prompt = (
                f"{base_prompt}\n\n⚠️ FOCUSED SUB-TASK: For this specific call, "
                f"answer ONLY the fields defined in the JSON schema provided "
                f"(a subset of the full analysis). {focus_note}"
            )
            t0 = time.time()
            try:
                raw_text, in_tok, out_tok = self._dispatch(
                    provider, key, sub_prompt, Config.SYSTEM_PROMPT,
                    Config.MAX_TOKENS, Config.TEMPERATURE, True, timeout_seconds,
                    group["schema"],
                )
                elapsed = round(time.time() - t0, 1)
                parsed = self._parse_json_text(self._clean_response(raw_text))
                provider.key_stats[key[-8:]]["requests"] += 1
                return {"success": True, "result": parsed, "elapsed": elapsed,
                        "provider": worker["provider"], "key": key[-8:]}
            except Exception as e:
                elapsed = round(time.time() - t0, 1)
                return {"success": False, "result": None, "error": str(e),
                        "elapsed": elapsed, "provider": worker["provider"], "key": key[-8:]}

        sub_results = [None] * len(field_groups)
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(field_groups)) as executor:
            future_map = {
                executor.submit(_run_sub_call, i, g): i for i, g in enumerate(field_groups)
            }
            for future in concurrent.futures.as_completed(future_map):
                i = future_map[future]
                sub_results[i] = future.result()

        merged = {}
        for r in sub_results:
            if r and r.get("success") and isinstance(r.get("result"), dict):
                for k, v in r["result"].items():
                    if k not in merged:  # كل حقل من مصدره المسؤول عنه فقط - لا كتابة فوق حقل مُستلَم مسبقاً
                        merged[k] = v

        return merged, {"sub_calls": sub_results}

    # ══════════════════════════════════════════════════════════
    #  فصل التفكير عن الهيكلة (Two-Step: Think then Structure)
    # ══════════════════════════════════════════════════════════
    # ⚠️ طلب المستخدم الدقيق (يوليو 2026) بعد اكتشاف حقيقي خطير مع
    # gpt-oss-120b: تناقض داخلي فعلي بنفس الرد (confidence=85% مع
    # direction="UNCLEAR" بينما daily_bias_summary="Bullish" بوضوح -
    # الموديل حلّل صح لكن فشل يهيكل نتيجته بثبات منطقي). التشخيص:
    # مطالبة الموديل بـ"فكّر بحرية + التزم بschema صارم" بنفس النداء
    # هي مهمتان متعارضتان جزئياً - يهتز الالتزام الصارم أحياناً مع
    # موديلات معينة (لوحظ فقط مع gpt-oss-120b وdeepseek-r1 عبر
    # Cloudflare - Gemini لم يُظهر هذا التناقض بأي اختبار بهذه الجلسة).
    #
    # الحل: خطوتان منفصلتان بدل نداء واحد مُثقَل بمهمتين:
    #   1) TEXT ANALYSIS: نداء أول بلا أي response_format - الموديل
    #      يكتب تحليله الحر الكامل (نفس جودة تحليله الفعلية، بلا قيد
    #      هيكلي يربكه أثناء "التفكير")
    #   2) STRUCTURED EXTRACTION: نداء ثانٍ قصير جداً - يستلم نص
    #      التحليل الحر من الخطوة 1 + الـschema المطلوب، ومهمته فقط
    #      "استخرج ما سبق بهذه البنية بالضبط - لا تُحلّل من جديد،
    #      فقط لخّص ما توصلت إليه أعلاه". مهمة أبسط بكثير (استخراج لا
    #      تحليل)، متوقع أعلى التزاماً بالـschema لأنها لا تتنافس مع
    #      عبء "التفكير" بنفس اللحظة.
    #
    # ⚠️ صدق تقني: هذا يُضاعف عدد الاستدعاءات لكل مرحلة (وقت/حصة أكثر)
    # - ثمن مقبول فقط لحل مشكلة توثقت فعلياً (تناقض داخلي خطير)، وليس
    # تحسيناً عاماً يجب تطبيقه افتراضياً على كل الاستدعاءات.

    def query_json_two_step(self, analysis_prompt, response_schema, max_tokens=None,
                             temperature=None, use_cache=False):
        """
        ينفّذ التحليل بخطوتين منفصلتين: تفكير حر (بلا schema) ثم
        استخراج مُهيكَل (schema صارم، بلا تحليل جديد). يُرجع dict فيه
        النتيجة المُهيكَلة + النص الحر الأصلي (للشفافية والتدقيق).
        """
        # ── الخطوة 1: تفكير حر بلا أي قيد هيكلي ──
        # ⚠️ إصلاح خطأ حقيقي مُكتشف بالاختبار الفعلي: تمرير
        # Config.SYSTEM_PROMPT الافتراضي (يطلب ضمنياً مخرجات منظّمة)
        # بهذه الخطوة كان يجعل الموديل يرجع JSON تلقائياً حتى بلا
        # force_json - يُلغي فائدة "التفكير الحر" بالكامل (دليل فعلي:
        # gpt-oss-120b رجع {"daily_bias":"bullish"...} رغم عدم طلب أي
        # بنية). نستخدم هنا system prompt صريح وواضح يطلب نصاً حراً
        # فقط، لا إشارة لأي تنسيق JSON إطلاقاً.
        free_thinking_system_prompt = (
            "You are an expert trading analyst. Think through this analysis "
            "out loud in plain, flowing prose - like explaining your reasoning "
            "to a colleague. Do NOT format your answer as JSON, a list, or any "
            "structured format. Just write your analysis as natural paragraphs, "
            "reaching clear conclusions by the end."
        )
        free_text = self.query(
            analysis_prompt, system_prompt=free_thinking_system_prompt,
            use_cache=use_cache, force_json=False,
            max_tokens=max_tokens, temperature=temperature,
        )
        if not free_text or (isinstance(free_text, str) and free_text.startswith('{"error"')):
            return {"error": "فشلت خطوة التفكير الحر", "free_text": free_text}

        # ── الخطوة 2: استخراج مُهيكَل من نفس التحليل الحر - لا تحليل جديد ──
        extraction_prompt = f"""
Below is a completed analysis. Your ONLY job now is to extract the
conclusions already reached above into the exact JSON structure required
by the schema. Do NOT re-analyze, do NOT introduce new information, do
NOT contradict what was concluded above - just structure it faithfully.
If the analysis above was ambiguous on a specific field, reflect that
ambiguity honestly (e.g. UNCLEAR) rather than guessing, but do NOT mark
a field as unclear if the analysis above was actually clear about it.

═══ COMPLETED ANALYSIS (extract from this, do not redo it) ═══
{free_text}
═══ END OF ANALYSIS ═══

Extract the above into the required JSON structure now.
"""
        structured = self.query_json(
            extraction_prompt, response_schema=response_schema, use_cache=False,
            max_tokens=max_tokens, temperature=0.0,  # صفر عشوائية - مهمة استخراج بحتة لا إبداع
        )

        if isinstance(structured, dict):
            structured["_free_text_analysis"] = free_text
        return structured

    # ══════════════════════════════════════════════════════════
    #  إدارة عامة
    # ══════════════════════════════════════════════════════════

    def clear_cache(self):
        self.cache.clear()

    def reset_exhausted_keys(self):
        """إعادة تفعيل كل مفاتيح كل المزودين (مثلاً بداية يوم جديد)"""
        for provider in self.providers.values():
            provider.reset()
        self.logger.info("🔄 تمت إعادة تفعيل كل المفاتيح لكل المزودين")

    def status(self):
        """حالة تفصيلية عبر كل المزودين"""
        providers_status = {}
        for name, provider in self.providers.items():
            active_keys = sum(
                1 for k in provider.keys
                if not provider.key_stats[k[-8:]]["exhausted"]
            )
            providers_status[name] = {
                "model": provider.model,
                "total_keys": len(provider.keys),
                "active_keys": active_keys,
                "all_exhausted": provider.all_exhausted,
                "too_slow": provider.too_slow,
                "last_response_seconds": provider.last_response_seconds,
                "per_key": {
                    f"...{k[-8:]}": v for k, v in provider.key_stats.items()
                },
            }

        return {
            "provider_order": self.provider_order,
            "total_requests": self.request_count,
            "total_cost": "$0.00 (Gemini مجاني بالكامل)",
            "cached": len(self.cache),
            "providers": providers_status,
        }


class _RateLimited(Exception):
    """تحديد مؤقت بالدقيقة (RPM) - يستاهل إعادة محاولة بعد ثوانٍ قليلة"""
    pass


class _QuotaExhausted(Exception):
    """نفاد الحصة اليومية بالكامل (RPD) - لا فائدة من إعادة المحاولة
    قبل اليوم التالي، يجب تبديل المفتاح فوراً بدون إهدار وقت"""
    pass


class _RequestTooLarge(Exception):
    """الطلب أكبر من حد التوكن/دقيقة (TPM) لهذا المزود/الموديل تحديداً -
    إعادة المحاولة بنفس البيانات مضمونة الفشل (الحجم ثابت)، لذا يجب
    الانتقال فوراً للمزود التالي بدون إهدار وقت على retries"""
    pass


class _KeyInvalid(Exception):
    pass


class _SoftFail(Exception):
    pass


class _MaxTokensExceeded(Exception):
    """الرد انقطع بمنتصفه لأن maxOutputTokens نفد (finishReason=
    MAX_TOKENS) - غالباً بسبب "تفكير داخلي" طويل + رد JSON مفصّل
    معاً يتجاوزان الحد. يستاهل إعادة محاولة فورية بحد توكن أعلى
    (وليس تبديل مفتاح/مزود - المشكلة هي الحجم، لا صلاحية المفتاح)"""
    pass