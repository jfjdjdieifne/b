# -*- coding: utf-8 -*-
"""NLPProcessor: معالج اللغة الطبيعية الذكي - يستخدم AIClient الموحّد"""
import logging
from ai_client import AIClient


class NLPProcessor:
    def __init__(self):
        self.logger = logging.getLogger("NLPProcessor")
        self.ai = AIClient()
        self.logger.info("NLPProcessor initialized (via unified AIClient).")

    def extract_concepts(self, text):
        prompt = f"استخرج المفاهيم والاستراتيجيات التداولية من النص التالي: {text}"
        return self.ai.query(prompt, max_tokens=1024)