# -*- coding: utf-8 -*-
import logging
import json
import numpy as np
from ai_client import AIClient


class PatternDetector:
    def __init__(self):
        self.logger = logging.getLogger("PatternDetector")
        self.ai = AIClient()

    # ── كشف أنماط الشموع محلياً ──
    def _local_candle_patterns(self, data):
        o = np.array(data["opens"], dtype=float)
        h = np.array(data["highs"], dtype=float)
        l = np.array(data["lows"], dtype=float)
        c = np.array(data["closes"], dtype=float)
        patterns = []
        n = len(c)
        if n < 3:
            return patterns

        body = abs(c[-1] - o[-1])
        rng  = h[-1] - l[-1]

        # Doji
        if rng > 0 and body / rng < 0.1:
            patterns.append("Doji (تردد)")

        # Hammer
        low_shadow = min(o[-1], c[-1]) - l[-1]
        up_shadow  = h[-1] - max(o[-1], c[-1])
        if body > 0 and low_shadow > body * 2 and up_shadow < body * 0.5:
            patterns.append("Hammer (مطرقة صعودية)")

        # Bullish Engulfing
        if c[-2] < o[-2] and c[-1] > o[-1] and o[-1] < c[-2] and c[-1] > o[-2]:
            patterns.append("Bullish Engulfing (ابتلاع صعودي)")

        # Bearish Engulfing
        if c[-2] > o[-2] and c[-1] < o[-1] and o[-1] > c[-2] and c[-1] < o[-2]:
            patterns.append("Bearish Engulfing (ابتلاع هبوطي)")

        # Three White Soldiers
        if n >= 3 and all(c[-i] > o[-i] for i in range(1, 4)):
            if c[-1] > c[-2] > c[-3]:
                patterns.append("Three White Soldiers (صعود قوي)")

        # Three Black Crows
        if n >= 3 and all(c[-i] < o[-i] for i in range(1, 4)):
            if c[-1] < c[-2] < c[-3]:
                patterns.append("Three Black Crows (هبوط قوي)")

        return patterns

    # ── الكشف الكامل ──
    def detect(self, data):
        if not data:
            return {"local": [], "ai": {}}

        local = self._local_candle_patterns(data)

        # إرسال آخر 30 شمعة للـ AI لكشف أنماط معقدة
        last = {k: data[k][-30:] for k in
                ("opens", "highs", "lows", "closes", "volumes")}

        prompt = f"""اكشف الأنماط الفنية المتقدمة في آخر 30 شمعة:
{json.dumps(last)}

الأنماط المكتشفة محلياً: {local}

ابحث عن:
- Chart Patterns (H&S, Double Top/Bottom, Triangles, Wedges, Flags)
- Smart Money (Order Blocks, FVG, Liquidity Sweeps, BOS, CHoCH)
- Wyckoff (Accumulation, Distribution, Spring, UTAD)

أجب JSON فقط."""

        ai_pat = self.ai.query_json(prompt)
        return {"local_patterns": local, "ai_patterns": ai_pat}