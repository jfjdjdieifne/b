# -*- coding: utf-8 -*-
import logging
from config import Config


class ConfluenceEngine:
    """
    محرك التوافق (Confluence):
    يجمع كل العوامل ويعطي score من 100.

    التقسيم:
    - Trend Alignment:  25 نقطة
    - SMC Factors:      25 نقطة
    - Indicators:       25 نقطة
    - MTF Confirmation: 25 نقطة
    ─────────────────────────────
    المجموع:           100 نقطة
    """

    def __init__(self):
        self.logger = logging.getLogger("ConfluenceEngine")

    def calculate_confluence(self, entry_ind, context_ind=None, macro_ind=None):
        """
        حساب درجة التوافق الكلية.
        Returns: dict with score, breakdown, verdict, direction
        """
        if not entry_ind:
            return {
                "score": 0,
                "verdict": "NO_DATA",
                "action": "HOLD",
                "direction": "NEUTRAL",
            }

        trend_score, trend_factors = self._score_trend(entry_ind)
        smc_score, smc_factors = self._score_smc(entry_ind)
        ind_score, ind_factors = self._score_indicators(entry_ind)
        mtf_score, mtf_factors = self._score_mtf(entry_ind, context_ind, macro_ind)

        total = trend_score + smc_score + ind_score + mtf_score
        all_factors = trend_factors + smc_factors + ind_factors + mtf_factors

        # Direction
        bullish_factors = sum(1 for f in all_factors if f.get("bias") == "BULLISH")
        bearish_factors = sum(1 for f in all_factors if f.get("bias") == "BEARISH")

        if bullish_factors > bearish_factors + 2:
            direction = "BULLISH"
        elif bearish_factors > bullish_factors + 2:
            direction = "BEARISH"
        else:
            direction = "NEUTRAL"

        # Verdict
        if total >= Config.CONFLUENCE_STRONG_SCORE:
            verdict = "STRONG_SETUP"
            action = "BUY" if direction == "BULLISH" else ("SELL" if direction == "BEARISH" else "HOLD")
        elif total >= Config.CONFLUENCE_MIN_SCORE:
            verdict = "MODERATE_SETUP"
            action = "BUY" if direction == "BULLISH" else ("SELL" if direction == "BEARISH" else "HOLD")
        else:
            verdict = "WEAK_SETUP"
            action = "HOLD"

        return {
            "score": round(total, 1),
            "max_score": 100,
            "breakdown": {
                "trend": round(trend_score, 1),
                "smc": round(smc_score, 1),
                "indicators": round(ind_score, 1),
                "mtf": round(mtf_score, 1),
            },
            "verdict": verdict,
            "action": action,
            "direction": direction,
            "bullish_factors": bullish_factors,
            "bearish_factors": bearish_factors,
            "factors": [f["name"] for f in all_factors],
        }

    # ══════════════════════════════════════════════
    #  TREND SCORING (25 نقطة)
    # ══════════════════════════════════════════════

    def _score_trend(self, ind):
        score = 0.0
        factors = []

        # EMA Alignment (0-8)
        ema_align = ind.get("ema_align", "MIXED")
        if ema_align == "BULLISH":
            score += 8
            factors.append({"name": "EMA aligned BULLISH", "bias": "BULLISH", "pts": 8})
        elif ema_align == "BEARISH":
            score += 8
            factors.append({"name": "EMA aligned BEARISH", "bias": "BEARISH", "pts": 8})
        else:
            score += 2
            factors.append({"name": "EMA mixed", "bias": "NEUTRAL", "pts": 2})

        # Market Structure (0-10)
        struct = ind.get("struct", "RANGING")
        if "BULLISH" in struct:
            score += 10
            factors.append({"name": f"Structure {struct}", "bias": "BULLISH", "pts": 10})
        elif "BEARISH" in struct:
            score += 10
            factors.append({"name": f"Structure {struct}", "bias": "BEARISH", "pts": 10})
        else:
            score += 3
            factors.append({"name": "Structure RANGING", "bias": "NEUTRAL", "pts": 3})

        # BOS/CHoCH (0-7)
        bos = ind.get("smc", {}).get("bos_choch", {})
        bos_bias = bos.get("current_bias", "NEUTRAL")
        events = bos.get("events", [])
        if bos_bias != "NEUTRAL" and events:
            last_event = events[-1].get("type", "")
            if "BOS" in last_event:
                score += 7
                factors.append({"name": f"BOS {bos_bias}", "bias": bos_bias, "pts": 7})
            elif "CHoCH" in last_event:
                score += 5
                bias = "BULLISH" if "BULLISH" in last_event else "BEARISH"
                factors.append({"name": f"CHoCH {bias}", "bias": bias, "pts": 5})

        return min(score, 25), factors

    # ══════════════════════════════════════════════
    #  SMC SCORING (25 نقطة)
    # ══════════════════════════════════════════════

    def _score_smc(self, ind):
        score = 0.0
        factors = []
        price = ind.get("price", 0)
        atr = ind.get("atr", 0)
        threshold = atr * 0.8 if atr > 0 else price * 0.005

        smc = ind.get("smc", {})

        # Order Blocks (0-8)
        obs = smc.get("order_blocks", {})
        for ob in obs.get("bullish", []):
            if abs(price - ob["top"]) < threshold or (ob["bottom"] <= price <= ob["top"]):
                score += 8
                factors.append({"name": f"Price at Bullish OB {ob['bottom']}-{ob['top']}", "bias": "BULLISH", "pts": 8})
                break
        for ob in obs.get("bearish", []):
            if abs(price - ob["bottom"]) < threshold or (ob["bottom"] <= price <= ob["top"]):
                score += 8
                factors.append({"name": f"Price at Bearish OB {ob['bottom']}-{ob['top']}", "bias": "BEARISH", "pts": 8})
                break

        # FVG (0-6)
        fvg = smc.get("fvg", {})
        for f in fvg.get("bullish", []):
            if abs(price - f["bottom"]) < threshold:
                score += 6
                factors.append({"name": f"Near Bullish FVG {f['bottom']}-{f['top']}", "bias": "BULLISH", "pts": 6})
                break
        for f in fvg.get("bearish", []):
            if abs(price - f["top"]) < threshold:
                score += 6
                factors.append({"name": f"Near Bearish FVG {f['bottom']}-{f['top']}", "bias": "BEARISH", "pts": 6})
                break

        # Liquidity (0-5)
        liq = smc.get("liquidity", {})
        for l in liq.get("sell_side", []):
            if abs(price - l["level"]) < threshold:
                score += 5
                factors.append({"name": f"Near Sell-side Liq {l['level']}", "bias": "BULLISH", "pts": 5})
                break
        for l in liq.get("buy_side", []):
            if abs(price - l["level"]) < threshold:
                score += 5
                factors.append({"name": f"Near Buy-side Liq {l['level']}", "bias": "BEARISH", "pts": 5})
                break

        # Premium/Discount (0-6)
        pd = ind.get("pd_zone", {})
        zone = pd.get("zone", "EQUILIBRIUM")
        if zone == "DISCOUNT":
            score += 6
            factors.append({"name": "Price in DISCOUNT zone", "bias": "BULLISH", "pts": 6})
        elif zone == "PREMIUM":
            score += 6
            factors.append({"name": "Price in PREMIUM zone", "bias": "BEARISH", "pts": 6})

        return min(score, 25), factors

    # ══════════════════════════════════════════════
    #  INDICATORS SCORING (25 نقطة)
    # ══════════════════════════════════════════════

    def _score_indicators(self, ind):
        score = 0.0
        factors = []

        # RSI (0-7)
        rsi = ind.get("rsi", 50)
        if 30 <= rsi <= 40:
            score += 7
            factors.append({"name": f"RSI oversold zone ({rsi})", "bias": "BULLISH", "pts": 7})
        elif 60 <= rsi <= 70:
            score += 7
            factors.append({"name": f"RSI overbought zone ({rsi})", "bias": "BEARISH", "pts": 7})
        elif rsi < 30:
            score += 5
            factors.append({"name": f"RSI extreme oversold ({rsi})", "bias": "BULLISH", "pts": 5})
        elif rsi > 70:
            score += 5
            factors.append({"name": f"RSI extreme overbought ({rsi})", "bias": "BEARISH", "pts": 5})
        else:
            score += 2
            factors.append({"name": f"RSI neutral ({rsi})", "bias": "NEUTRAL", "pts": 2})

        # MACD Cross (0-6)
        mcross = ind.get("macd_cross", "NONE")
        if mcross == "BULLISH_CROSS":
            score += 6
            factors.append({"name": "MACD bullish cross", "bias": "BULLISH", "pts": 6})
        elif mcross == "BEARISH_CROSS":
            score += 6
            factors.append({"name": "MACD bearish cross", "bias": "BEARISH", "pts": 6})

        # Volume (0-5)
        vol = ind.get("vol_analysis", {})
        vol_trend = vol.get("trend", "NORMAL")
        if "STRONG_BUYING" in vol_trend:
            score += 5
            factors.append({"name": "Strong buying volume", "bias": "BULLISH", "pts": 5})
        elif "STRONG_SELLING" in vol_trend:
            score += 5
            factors.append({"name": "Strong selling volume", "bias": "BEARISH", "pts": 5})
        elif "MODERATE" in vol_trend:
            score += 3
            bias = "BULLISH" if "BUYING" in vol_trend else "BEARISH"
            factors.append({"name": f"Moderate volume ({vol_trend})", "bias": bias, "pts": 3})

        # Divergence (0-4)
        div = ind.get("divergence", {})
        div_type = div.get("type", "NONE")
        if div_type == "REGULAR_BULLISH":
            score += 4
            factors.append({"name": "Bullish RSI divergence", "bias": "BULLISH", "pts": 4})
        elif div_type == "REGULAR_BEARISH":
            score += 4
            factors.append({"name": "Bearish RSI divergence", "bias": "BEARISH", "pts": 4})
        elif div_type == "HIDDEN_BULLISH":
            score += 3
            factors.append({"name": "Hidden bullish divergence", "bias": "BULLISH", "pts": 3})
        elif div_type == "HIDDEN_BEARISH":
            score += 3
            factors.append({"name": "Hidden bearish divergence", "bias": "BEARISH", "pts": 3})

        # Candle Patterns (0-3)
        cp = ind.get("candle_patterns", [])
        for p in cp[:1]:
            if p.get("bias") == "BULLISH":
                score += 3
                factors.append({"name": f"Candle: {p['pattern']}", "bias": "BULLISH", "pts": 3})
            elif p.get("bias") == "BEARISH":
                score += 3
                factors.append({"name": f"Candle: {p['pattern']}", "bias": "BEARISH", "pts": 3})

        return min(score, 25), factors

    # ══════════════════════════════════════════════
    #  MTF SCORING (25 نقطة)
    # ══════════════════════════════════════════════

    def _score_mtf(self, entry_ind, context_ind=None, macro_ind=None):
        score = 0.0
        factors = []

        def get_bias(ind):
            if not ind:
                return "NEUTRAL"
            signals = []
            struct = ind.get("struct", "")
            if "BULLISH" in struct:
                signals.append("BULLISH")
            elif "BEARISH" in struct:
                signals.append("BEARISH")

            ema = ind.get("ema_align", "MIXED")
            if ema == "BULLISH":
                signals.append("BULLISH")
            elif ema == "BEARISH":
                signals.append("BEARISH")

            regime = ind.get("regime", {}).get("regime", "")
            if "UP" in regime:
                signals.append("BULLISH")
            elif "DOWN" in regime:
                signals.append("BEARISH")

            bull = signals.count("BULLISH")
            bear = signals.count("BEARISH")
            if bull > bear:
                return "BULLISH"
            elif bear > bull:
                return "BEARISH"
            return "NEUTRAL"

        entry_bias = get_bias(entry_ind)
        context_bias = get_bias(context_ind)
        macro_bias = get_bias(macro_ind)

        # Context TF alignment (0-12)
        if context_ind:
            if context_bias == entry_bias and context_bias != "NEUTRAL":
                score += 12
                factors.append({
                    "name": f"Context TF ({context_ind.get('tf', '?')}) aligned {context_bias}",
                    "bias": context_bias, "pts": 12
                })
            elif context_bias == "NEUTRAL":
                score += 4
                factors.append({
                    "name": "Context TF neutral",
                    "bias": "NEUTRAL", "pts": 4
                })
            else:
                # عكس الاتجاه = خصم
                score += 0
                factors.append({
                    "name": f"⚠️ Context TF OPPOSING ({context_bias} vs {entry_bias})",
                    "bias": context_bias, "pts": 0
                })

        # Macro TF alignment (0-13)
        if macro_ind:
            if macro_bias == entry_bias and macro_bias != "NEUTRAL":
                score += 13
                factors.append({
                    "name": f"Macro TF ({macro_ind.get('tf', '?')}) aligned {macro_bias}",
                    "bias": macro_bias, "pts": 13
                })
            elif macro_bias == "NEUTRAL":
                score += 5
                factors.append({
                    "name": "Macro TF neutral",
                    "bias": "NEUTRAL", "pts": 5
                })
            else:
                score += 0
                factors.append({
                    "name": f"⚠️ Macro TF OPPOSING ({macro_bias} vs {entry_bias})",
                    "bias": macro_bias, "pts": 0
                })

        # If no context/macro → give partial credit
        if not context_ind and not macro_ind:
            score += 8
            factors.append({"name": "Single TF only", "bias": "NEUTRAL", "pts": 8})

        return min(score, 25), factors