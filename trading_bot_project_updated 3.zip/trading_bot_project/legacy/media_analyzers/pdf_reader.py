# -*- coding: utf-8 -*-
"""PDFReader: قارئ PDF الذكي - يستخرج النص محلياً (PyPDF2) ثم يحلله بالـ AIClient الموحّد"""
import logging

try:
    import PyPDF2
except ImportError:
    PyPDF2 = None

from ai_client import AIClient


class PDFReader:
    """قراءة PDF واستخراج النصوص والمفاهيم."""

    def __init__(self):
        self.logger = logging.getLogger("PDFReader")
        self.ai = AIClient()
        self.logger.info("PDFReader initialized (via unified AIClient).")

    def read(self, pdf_path):
        """قراءة ملف PDF محلياً واستخراج النص الخام."""
        if not PyPDF2:
            self.logger.warning("PyPDF2 غير مثبت")
            return ""
        try:
            text_parts = []
            with open(pdf_path, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    text_parts.append(page.extract_text() or "")
            return "\n".join(text_parts)
        except Exception as e:
            self.logger.error(f"PDF read error: {e}")
            return ""

    def extract_text(self, pdf_path):
        """اختصار للتوافق الخلفي مع أي كود قديم كان يستدعي extract_text"""
        return self.read(pdf_path)

    def analyze(self, pdf_path):
        """قراءة الملف ثم تحليل محتواه التداولي بالـ AI"""
        text = self.read(pdf_path)
        if not text:
            return {"error": "تعذرت قراءة الملف أو أنه فارغ"}
        prompt = (
            "استخرج وحلل أهم المفاهيم والاستراتيجيات التداولية من النص التالي "
            f"(مقتطف من PDF):\n\n{text[:8000]}\n\nأجب بصيغة JSON."
        )
        return self.ai.query_json(prompt, max_tokens=2000)