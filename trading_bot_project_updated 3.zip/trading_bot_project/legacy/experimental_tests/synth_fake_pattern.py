# -*- coding: utf-8 -*-
"""
مولّد نمط "شبه انعكاس" لكنه مزيّف - اختبار التمييز الحقيقي
════════════════════════════════════════════════════════════════════
يبني بيانات اصطناعية تشبه ظاهرياً نمط "سحب سيولة + انعكاس" (نفس شكل
synth_data.py تقريباً: فتيل يخترق قاعاً سابقاً) لكن **بدون** الشرط
الحاسم (displacement قوي بعده يؤكد الانعكاس فعلاً) - بدلاً من ذلك،
السعر يستمر بالهبوط بعد الفتيل مباشرة (استمرار حقيقي، لا فخ).

هذا الاختبار الأهم لسؤال "فهم القاعدة مقابل الحفظ": لو البوت "حفظ"
نمط "فتيل تحت قاع = صعود قادم" بشكل سطحي، سيخطئ هنا ويعطي BUY.
لو "فهم" الشرط الحقيقي (الفتيل وحده لا يكفي - لازم displacement
تأكيدي بعده)، يجب أن يتعرف على هذا كاستمرار هابط (LIKELY_CONTINUATION
_RUN) وليس فخاً حقيقياً - نفس الرمز الوهمي ونفس شكل الفتيل تقريباً،
لكن الشرط الحاسم (ما بعد الفتيل) مختلف تماماً.
"""
import numpy as np


def generate_fake_continuation_setup(base_price=47.3183, n_candles=250, seed=99):
    """
    نفس بنية synth_data.py تماماً حتى شمعة الفتيل (سحب واضح تحت قاع
    سابق)، لكن بعدها: استمرار هابط حقيقي (لا اندفاع صاعد، لا تأكيد) -
    هذا "Run" حقيقي وليس "Sweep" حقيقي، رغم تشابه الفتيل ظاهرياً.
    """
    rng = np.random.RandomState(seed)
    n_trend = n_candles - 15

    trend = np.linspace(0, -0.30, n_trend)
    noise = rng.normal(0, 0.012, n_trend).cumsum() * 0.15
    waves = 0.04 * np.sin(np.linspace(0, 7 * np.pi, n_trend))
    closes_trend = base_price * (1 + trend + noise + waves)
    closes_trend = np.maximum(closes_trend, base_price * 0.55)

    opens, highs, lows, closes, volumes = [], [], [], [], []
    prev_close = base_price
    for i in range(n_trend):
        o = prev_close
        c = closes_trend[i]
        body_range = abs(c - o)
        wick = max(body_range * rng.uniform(0.15, 0.55), base_price * 0.0015)
        h = max(o, c) + wick * rng.uniform(0.3, 1.0)
        l = min(o, c) - wick * rng.uniform(0.3, 1.0)
        v = rng.uniform(800, 1500)
        opens.append(o); highs.append(h); lows.append(l); closes.append(c); volumes.append(v)
        prev_close = c

    search_start = int(n_trend * 0.7)
    prior_swing_low_idx = search_start + int(np.argmin(lows[search_start:]))
    prior_swing_low = lows[prior_swing_low_idx]
    last_close = closes[-1]

    # تجميع قصير قبل الفتيل (3 شموع) - نفس البنية
    for i in range(3):
        o = last_close
        c = o * (1 + rng.uniform(-0.004, 0.004))
        h = max(o, c) * 1.003
        l = min(o, c) * 0.997
        v = rng.uniform(700, 1100)
        opens.append(o); highs.append(h); lows.append(l); closes.append(c); volumes.append(v)
        last_close = c

    # ═══ شمعة تشبه "سحب سيولة" ظاهرياً - فتيل يخترق القاع السابق ═══
    # لكن هنا: الإغلاق ضعيف جداً (بالكاد فوق القاع، لا "رفض قوي") -
    # هذا الفرق الدقيق المهم: sweep حقيقي يحتاج إغلاق واضح فوق المستوى
    # (رفض قوي)، لا مجرد "لمسة عابرة بالكاد فوقه".
    sweep_open = last_close
    sweep_low = prior_swing_low * 0.985
    sweep_close = prior_swing_low * 1.001  # إغلاق ضعيف جداً - بالكاد فوق المستوى
    sweep_high = max(sweep_open, sweep_close) * 1.001
    opens.append(sweep_open); highs.append(sweep_high); lows.append(sweep_low)
    closes.append(sweep_close); volumes.append(rng.uniform(900, 1300))  # حجم عادي، لا زخم فخ
    last_close = sweep_close

    # ═══ الفرق الجوهري عن synth_data.py: لا اندفاع صاعد يتبع - بدلاً
    # من ذلك، استمرار هابط حقيقي (السعر يكسر تحت الفتيل خلال شموع
    # قليلة - "Run" حقيقي عبر مستوى كان يُفترض أنه "مصيدة") ═══
    for i in range(11):
        o = last_close
        drift = rng.uniform(-0.018, -0.002)  # استمرار هابط واضح، لا ارتداد
        c = o * (1 + drift)
        h = max(o, c) * (1 + rng.uniform(0.001, 0.004))
        l = min(o, c) * (1 - rng.uniform(0.002, 0.010))
        v = rng.uniform(900, 1600)
        opens.append(o); highs.append(h); lows.append(l); closes.append(c); volumes.append(v)
        last_close = c

    n_total = len(closes)
    end_ts = 1800000000000
    timestamps = [end_ts - (n_total - 1 - i) * 4 * 3600 * 1000 for i in range(n_total)]

    data = {
        "timestamps": timestamps,
        "opens": [round(float(x), 4) for x in opens],
        "highs": [round(float(x), 4) for x in highs],
        "lows": [round(float(x), 4) for x in lows],
        "closes": [round(float(x), 4) for x in closes],
        "volumes": [round(float(x), 2) for x in volumes],
        "symbol": "FAKESYNTH/USDT",
        "timeframe": "4h",
        "count": n_total,
        "source": "synthetic_fake_pattern_test",
    }

    ground_truth_pattern = {
        "pattern_type": "FAKE_CONTINUATION (looks like sweep, but is NOT a genuine reversal)",
        "prior_swing_low_price": round(float(prior_swing_low), 4),
        "wick_below_level": round(float(sweep_low), 4),
        "weak_close_back_above": round(float(sweep_close), 4),
        "expected_bot_conclusion": (
            "the wick alone is NOT sufficient evidence of a genuine reversal - "
            "no confirming bullish displacement followed; price continued "
            "lower afterward. This should be classified as "
            "LIKELY_CONTINUATION_RUN / fake sweep, NOT a genuine bullish "
            "reversal signal. A bot that just pattern-matches 'wick below "
            "swing low = buy signal' without checking what happens AFTER "
            "would incorrectly call this bullish."
        ),
    }
    return data, ground_truth_pattern


if __name__ == "__main__":
    import json
    data, gt = generate_fake_continuation_setup()
    print("عدد الشموع:", data["count"])
    print(json.dumps(gt, indent=2, ensure_ascii=False))
    print()
    for i in range(-15, 0):
        print(f"idx={i}: O={data['opens'][i]:.4f} H={data['highs'][i]:.4f} "
              f"L={data['lows'][i]:.4f} C={data['closes'][i]:.4f}")