# -*- coding: utf-8 -*-
"""
اختبار شامل لكل مزودي الـ AI المُعرَّفين بملف .env
يشغّل طلب اختبار بسيط + طلب تداولي حقيقي على كل مزود متاح،
ويعرض تقرير نهائي بحالة كل مزود.
"""
import os
os.environ.pop("HTTP_PROXY", None)
os.environ.pop("HTTPS_PROXY", None)
os.environ.pop("http_proxy", None)
os.environ.pop("https_proxy", None)

from config import Config
from ai_client import AIClient

print("=" * 70)
print("🔍 اختبار مزود الـ AI المُفعّل (Gemini فقط)")
print("=" * 70)

if not Config.has_any_ai_key():
    print("\n❌ لا يوجد أي مفتاح API مُعرَّف!")
    print("   انسخ ملف .env.example إلى .env واملأ مفتاح واحد على الأقل.")
    print("   الأسهل والمجاني: GEMINI_API_KEY من https://aistudio.google.com/apikey")
    raise SystemExit(1)

ai = AIClient()

print(f"\n📋 ترتيب المزودين المُفعّلين: {', '.join(ai.provider_order)}")
for name in ai.provider_order:
    p = ai.providers[name]
    print(f"   • {name}: {len(p.keys)} مفتاح | موديل: {p.model}")

# ═══ اختبار بسيط ═══
print("\n" + "-" * 70)
print("🧪 اختبار 1: سؤال بسيط (2+2)")
print("-" * 70)
result = ai.query("كم يساوي 2+2؟ أجب بكلمة واحدة فقط.", max_tokens=20, use_cache=False)
print(f"الرد: {result}")

# ═══ اختبار تداولي حقيقي مع JSON ═══
print("\n" + "-" * 70)
print("🔥 اختبار 2: تحليل تداولي حقيقي (يجب أن يرجع JSON)")
print("-" * 70)

prompt = """Analyze this BTC/USDT 1H data (last 10 candles):
Open: 107500, 107800, 107200, 107600, 108000, 108300, 107900, 108500, 108800, 109000
High: 107900, 108100, 107700, 108100, 108500, 108600, 108400, 108900, 109200, 109300
Low:  107200, 107500, 106900, 107300, 107800, 108000, 107600, 108200, 108500, 108700
Close:107800, 107300, 107600, 108000, 108300, 108000, 108400, 108800, 109000, 109100
Vol:  1200, 1500, 1800, 1400, 2200, 1100, 1600, 2500, 2100, 1900

Give me JSON only: {"signal": "BUY/SELL/HOLD", "entry": price, "stop_loss": price,
"take_profit": price, "confidence": 0-100}"""

result_json = ai.query_json(prompt, max_tokens=1000, use_cache=False)
print("النتيجة (JSON):")
import json as _json
print(_json.dumps(result_json, ensure_ascii=False, indent=2))

# ═══ التقرير النهائي ═══
print("\n" + "=" * 70)
print("📊 التقرير النهائي - حالة كل مزود")
print("=" * 70)
status = ai.status()
print(f"\nإجمالي الطلبات: {status['total_requests']}")
print(f"التكلفة: {status['total_cost']}")
print()
for name, info in status["providers"].items():
    icon = "✅" if info["active_keys"] > 0 else "❌"
    print(f"{icon} {name} ({info['model']}): "
          f"{info['active_keys']}/{info['total_keys']} مفتاح نشط")

print("\n" + "=" * 70)
if "error" in result_json:
    print("⚠️ فشل الاختبار التداولي - راجع الأخطاء أعلاه وتأكد من صحة المفاتيح بملف .env")
else:
    print("🎉 البوت شغّال تمام! جاهز للاستخدام.")
print("=" * 70)