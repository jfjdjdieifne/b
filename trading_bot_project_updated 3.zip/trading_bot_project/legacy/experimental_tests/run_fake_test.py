# -*- coding: utf-8 -*-
import sys, json, time
sys.path.insert(0, '.')
sys.path.insert(0, 'tests_generalization')
import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s %(message)s')

from synth_fake_pattern import generate_fake_continuation_setup
from brain_core import BrainCore
from reading_comprehension_test import ReadingComprehensionTest

data, ground_truth = generate_fake_continuation_setup()
print("=== بيانات الفخ المزيف ===")
print(f"رمز: {data['symbol']} | نطاق: {min(data['lows']):.2f}-{max(data['highs']):.2f}")
print(json.dumps(ground_truth, indent=2, ensure_ascii=False))

brain = BrainCore()
rc = ReadingComprehensionTest(brain)
t0 = time.time()
result = rc.run(data["symbol"], data["timeframe"], data)
print(f"\nالوقت: {round(time.time()-t0,1)}s")

with open("tests_generalization/fake_pattern_result.json", "w", encoding="utf-8") as f:
    json.dump({"ground_truth": ground_truth, "result": result}, f, indent=2, ensure_ascii=False, default=str)

if "error" in result:
    print("خطأ:", result["error"])
else:
    print("\n=== bot_response ===")
    print(json.dumps(result["bot_response"], indent=2, ensure_ascii=False))

print("\n=== DONE ===")