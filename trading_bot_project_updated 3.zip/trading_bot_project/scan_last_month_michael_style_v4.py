# -*- coding: utf-8 -*-
"""
scan_last_month_michael_style_v4.py
════════════════════════════════════════════════════════════════════
تصحيح رابع (بطلب صريح: "مو قلت كامل جلسة نيويورك نهار وليل؟" - بما أن
الكريبتو 24/7 فعلياً، لا نُقيّد البحث عن سحب السيولة بنافذة ضيقة
(2.5 ساعة killzone) فقط - نفحص **اليوم بأكمله** (24 ساعة) بعد تكوّن
نطاق الليل (overnight range، ينتهي 08:30 NY) بحثاً عن أول سحب سيولة
حقيقي يحصل في أي وقت خلال بقية اليوم - هذا يطابق واقع الكريبتو (لا
"إغلاق" حرفي يوقف الفرص عند 11:00 أو 16:00 كما بالفوركس).

المنهجية النهائية:
  1. لكل يوم NY، نحسب نطاق الليل (00:00-08:30 NY) - نفس الأداة
     الموجودة أصلاً بالمشروع (compute_overnight_range).
  2. من نهاية نطاق الليل (08:30 NY) وحتى نهاية اليوم (23:59 NY)، نفحص
     كل شمعة 15m بحثاً عن **أول لحظة** سحب سيولة حقيقي مؤكد لنفس هذا
     النطاق، بعكس اتجاه الانحياز اليومي (Daily Bias) الحتمي.
  3. لا قيد على وقت الجلسة داخل هذا المدى - الكريبتو 24/7، فالسحب قد
     يحصل NY AM أو PM أو حتى ساعات أخرى - هذا هو التكييف الصحيح لواقع
     الكريبتو بدل تقييد اصطناعي بنوافذ فوركسية الأصل.
"""
import json
import logging
import sys
import datetime
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from ict_sessions import compute_overnight_range, ts_to_ny

brain = BrainCore()

SYMBOL = "ETH/USDT"
EXEC_TF = "15m"

full_data = brain.data_manager.get_ohlcv(SYMBOL, EXEC_TF, 3000, output_format="dict")
n = len(full_data["closes"])
print(f"إجمالي الشموع ({EXEC_TF}): {n}")
start_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][0]/1000, tz=datetime.timezone.utc)
end_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][-1]/1000, tz=datetime.timezone.utc)
print(f"النطاق: {start_dt} -> {end_dt}\n")

ny_dates = sorted(set(ts_to_ny(ts).date() for ts in full_data["timestamps"]))
print(f"عدد الأيام الفريدة (NY calendar): {len(ny_dates)}\n")

candidates = []

for day in ny_dates:
    tz = ts_to_ny(full_data["timestamps"][0]).tzinfo
    # نطاق الليل ينتهي 08:30 NY - بداية فحصنا لليوم بأكمله من هنا
    day_scan_start_ny = datetime.datetime.combine(day, datetime.time(8, 30), tzinfo=tz)
    day_scan_end_ny = datetime.datetime.combine(day, datetime.time(23, 59), tzinfo=tz)
    scan_start_ts = int(day_scan_start_ny.timestamp() * 1000)
    scan_end_ts = int(day_scan_end_ny.timestamp() * 1000)

    day_indices = [i for i, ts in enumerate(full_data["timestamps"])
                   if scan_start_ts <= ts < scan_end_ts]
    if not day_indices:
        continue

    found_for_this_day = False

    for idx in day_indices:
        if found_for_this_day or idx < 150:
            continue

        window_data = {
            "opens": full_data["opens"][:idx+1], "highs": full_data["highs"][:idx+1],
            "lows": full_data["lows"][:idx+1], "closes": full_data["closes"][:idx+1],
            "timestamps": full_data["timestamps"][:idx+1],
        }
        cur_ts = full_data["timestamps"][idx]

        try:
            anchor = compute_mechanical_bias_anchor(window_data, lookback=250)
        except Exception:
            continue
        daily_bias = anchor.get("anchor_direction")
        if daily_bias not in ("BULLISH", "BEARISH"):
            continue

        try:
            overnight = compute_overnight_range(window_data, cur_ts)
        except Exception:
            continue
        if not overnight.get("found"):
            continue

        range_high, range_low = overnight["range_high"], overnight["range_low"]
        n_window = len(window_data["closes"])
        sweep_low = classify_sweep_or_run(window_data, range_low, level_is_high=False, check_from_idx=idx)
        sweep_high = classify_sweep_or_run(window_data, range_high, level_is_high=True, check_from_idx=idx)

        genuine_sweep_found = None
        if (sweep_low.get("found") and sweep_low.get("classification") == "GENUINE_REVERSAL_SWEEP"
                and sweep_low.get("candle_index_from_end") == (idx - n_window)):
            if daily_bias == "BULLISH":
                genuine_sweep_found = ("SSL_SWEPT_LOW", sweep_low)
        if (sweep_high.get("found") and sweep_high.get("classification") == "GENUINE_REVERSAL_SWEEP"
                and sweep_high.get("candle_index_from_end") == (idx - n_window)):
            if daily_bias == "BEARISH":
                genuine_sweep_found = ("BSL_SWEPT_HIGH", sweep_high)

        if genuine_sweep_found:
            sweep_type, sweep_info = genuine_sweep_found
            dt = datetime.datetime.fromtimestamp(cur_ts/1000, tz=datetime.timezone.utc)
            dt_ny = ts_to_ny(cur_ts)
            candidates.append({
                "index": idx, "timestamp": cur_ts, "datetime_utc": dt.isoformat(),
                "datetime_ny": dt_ny.strftime("%Y-%m-%d %H:%M NY"),
                "mechanical_bias": daily_bias, "bias_strength": anchor.get("strength"),
                "overnight_range_high": range_high, "overnight_range_low": range_low,
                "sweep_type": sweep_type,
            })
            found_for_this_day = True

print(f"=== إجمالي النقاط المرشحة (اليوم بأكمله بعد نطاق الليل - 24/7 كريبتو): {len(candidates)} ===\n")
for c in candidates:
    print(f"  [{c['index']}] {c['datetime_ny']} ({c['datetime_utc']} UTC)  bias={c['mechanical_bias']}({c['bias_strength']})  sweep={c['sweep_type']}")

with open("/tmp/last_month_michael_candidates_v4.json", "w") as f:
    json.dump(candidates, f, indent=2, default=str)
