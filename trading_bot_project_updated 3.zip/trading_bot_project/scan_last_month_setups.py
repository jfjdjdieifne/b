# -*- coding: utf-8 -*-
"""
scan_last_month_setups.py
════════════════════════════════════════════════════════════════════
أداة مسح ميكانيكي بحتة (صفر AI، صفر نظر للمستقبل) لاكتشاف نقاط دخول
محتملة بمنهجية مايكل عبر آخر شهر من بيانات ETH/USDT الحقيقية.

⚠️ المنهجية الصارمة (بطلب صريح من المستخدم):
  - عند كل نقطة زمنية مرشحة، نستخدم فقط البيانات المتاحة **حتى تلك
    اللحظة بالضبط** (نفس مبدأ منع تسريب المستقبل المستخدم بكل مكان
    آخر بالمشروع - fetch_ohlcv_up_to).
  - لا فحص "هل تحرك السعر فعلاً بعدها" في هذه المرحلة إطلاقاً - هذا
    يخالف الشرط الصريح: "ما يغش حاله ويتطلع عالشموع المستقبلية إلا
    بعد ما يخلص تحليل". النتيجة الفعلية تُحسب لاحقاً بعد اكتمال تحليل
    كل نقطة (multi_pass_analysis) بمرحلة منفصلة تماماً.
  - معيار الاكتشاف: نفس أدوات مايكل الميكانيكية الموجودة أصلاً بالمشروع
    (evaluate_all_entry_models من ict_entry_checklist_engine.py) - نفس
    الشيء بالضبط الذي يستخدمه البوت الحي، لا معيار مستقل مخترع.
  - الانحياز (daily_bias) يُحسب ميكانيكياً بحتاً (compute_mechanical_
    bias_anchor - نفس أداة المشروع) بدل استدعاء AI لكل نقطة (يوفر
    وقت/حصة API بمرحلة الاكتشاف، ويبقيها 100% حتمية قابلة لإعادة التنفيذ).
"""
import json
import logging
import sys
sys.path.insert(0, ".")
logging.basicConfig(level=logging.WARNING)

from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor
from ict_entry_checklist_engine import evaluate_all_entry_models

brain = BrainCore()

SYMBOL = "ETH/USDT"
EXEC_TF = "15m"
STEP_CANDLES = 4  # نفحص كل 4 شموع 15m (=ساعة واحدة) لتوفير وقت المسح، لا كل شمعة منفردة
MIN_LOOKBACK_FOR_CHECK = 150  # أقل عدد شموع سابقة مطلوب لفحص معقول

# نجلب كامل بيانات آخر شهر (فريم تنفيذ) مرة واحدة
full_data = brain.data_manager.get_ohlcv(SYMBOL, EXEC_TF, 3000, output_format="dict")
n = len(full_data["closes"])
print(f"إجمالي الشموع المتاحة ({EXEC_TF}): {n}")

import datetime
start_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][0]/1000, tz=datetime.timezone.utc)
end_dt = datetime.datetime.fromtimestamp(full_data["timestamps"][-1]/1000, tz=datetime.timezone.utc)
print(f"النطاق الزمني: {start_dt} -> {end_dt}")

candidates = []

for i in range(MIN_LOOKBACK_FOR_CHECK, n, STEP_CANDLES):
    # ⚠️ فقط البيانات حتى هذه النقطة (i inclusive) - محاكاة "ماذا لو
    # كنا نحلل الآن، بلا أي معرفة بما سيحدث بعدها"
    window_data = {
        "opens": full_data["opens"][:i+1],
        "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1],
        "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }

    try:
        anchor = compute_mechanical_bias_anchor(window_data)
    except Exception:
        continue

    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"):
        continue  # لا انحياز حتمي واضح عند هذه اللحظة - نتجاوز

    try:
        result = evaluate_all_entry_models(window_data, daily_bias)
    except Exception as e:
        continue

    if result.get("final_status") in ("READY", "PENDING_SETUP"):
        chosen = result["chosen_model"]
        ts = full_data["timestamps"][i]
        dt = datetime.datetime.fromtimestamp(ts/1000, tz=datetime.timezone.utc)
        candidates.append({
            "index": i,
            "timestamp": ts,
            "datetime_utc": dt.isoformat(),
            "mechanical_bias": daily_bias,
            "bias_strength": anchor.get("strength"),
            "model": chosen["model"],
            "status": result["final_status"],
            "plan": chosen["plan"],
        })

print(f"\n=== إجمالي النقاط المكتشفة (بلا أي نظر للمستقبل): {len(candidates)} ===\n")
for c in candidates:
    print(f"  [{c['index']}] {c['datetime_utc']}  bias={c['mechanical_bias']}({c['bias_strength']})  model={c['model']}  status={c['status']}")

with open("/tmp/last_month_candidates.json", "w") as f:
    json.dump(candidates, f, indent=2, default=str)
