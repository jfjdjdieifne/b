import sys, json, os, time
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
os.chdir("/home/user/test/extracted/trading_bot_project")
from nemotron_backtest_driver import run_one_backtest

KEY6 = "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"
FAILED = [1, 9, 10, 12, 13, 16, 17, 18, 19]
trades = json.load(open("/home/user/human_trades/all_human_trades_with_outcomes.json"))
trades_by_id = {t["id"]: t for t in trades}

OUT_DIR = "/home/user/human_trades/backtest_results"

for tid in FAILED:
    t = trades_by_id[tid]
    label = f"RETRY_HUMAN_TRADE_{tid:02d}_{t['symbol'].replace('/','')}_{t['publish_date']}"
    print(f"\n### RETRY Trade {tid}: {label}")
    try:
        result = run_one_backtest(
            symbol=t["symbol"], timeframe="1h", end_ts=t["publish_ts"],
            api_key=KEY6, label=label, max_tokens=4000, timeout=200,
            backup_keys=[],
        )
    except Exception as e:
        print("EXC", e)
        continue
    if not isinstance(result, dict):
        print("no result")
        continue
    result["human_trade_data"] = t
    sig = (result.get("result") or {}).get("signal")
    print("-> signal:", sig, "stopped_at:", (result.get("result") or {}).get("stopped_at_gate"))
    # فقط نستبدل الملف لو نجح فعلياً (مو فشل تقني مطابق لنفس السبب القديم)
    narrative = (result.get("result") or {}).get("narrative", "")
    if sig and "لا رد صالح" not in narrative:
        with open(f"{OUT_DIR}/trade_{tid:02d}.json", "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False, default=str)
        print(f"✅ استبدلنا trade_{tid:02d}.json بنتيجة ناجحة فعلياً")
    else:
        print(f"⚠️ ما زالت تفشل تقنياً - نبقي الملف القديم")
    time.sleep(5)
