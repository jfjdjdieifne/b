# -*- coding: utf-8 -*-
"""
يحسب النتيجة الفعلية لكل "صفقة اقترحها البوت" (Entry/SL/TP يلي حددهن
Nemotron بمرحلة التنفيذ)، بنفس منهجية calc_outcomes.py الأصلية
المستخدمة للصفقات البشرية - لضمان مقارنة عادلة 100% (نفس المصدر:
OKX 1H candles، نفس منطق "أيهم انضرب أول SL أو TP").
"""
import json
import requests
import time
from datetime import datetime, timezone


def fetch_okx_range(inst_id, bar, start_ts, end_ts):
    url = "https://www.okx.com/api/v5/market/history-candles"
    all_candles = []
    after = end_ts + 1
    for _ in range(60):
        params = {"instId": inst_id, "bar": bar, "limit": "100", "after": str(after)}
        r = requests.get(url, params=params, timeout=20)
        d = r.json()
        batch = d.get("data", [])
        if not batch:
            break
        all_candles.extend(batch)
        oldest_ts = int(batch[-1][0])
        if oldest_ts <= start_ts:
            break
        after = oldest_ts
        time.sleep(0.12)
    filtered = [c for c in all_candles if start_ts <= int(c[0]) <= end_ts]
    filtered.sort(key=lambda c: int(c[0]))
    return filtered


def calc_bot_trade_outcome(symbol, publish_ts, entry, sl, tp, is_short, max_days=25):
    inst_id = symbol.replace("/USDT", "-USDT")
    start_ts = publish_ts
    end_ts = start_ts + max_days * 24 * 3600 * 1000
    candles = fetch_okx_range(inst_id, "1H", start_ts, end_ts)
    if not candles:
        return {"error": "NO_DATA"}

    # نفترض دخول عند سعر الإغلاق لأقرب شمعة عند لحظة النشر (بلا فرق بسيط زي
    # البشري لأن البوت يعطي سعر دخول واحد محدد فقط، لا نطاق)
    entry_idx = None
    for i, c in enumerate(candles):
        lo, hi = float(c[3]), float(c[2])
        if lo <= entry <= hi:
            entry_idx = i
            break

    result = {
        "candles_fetched": len(candles),
        "price_range": [min(float(c[3]) for c in candles), max(float(c[2]) for c in candles)],
    }

    # ⚠️ تصليح خطأ حقيقي (اكتُشف فعلياً بصفقتي BTC #11 و #15): لو نقطة
    # دخول البوت ما انلمست إطلاقاً خلال نافذة المراقبة (مثلاً السعر قفز
    # فوق/تحت نقطة الدخول بالكامل ولم يرجع لمسها)، لا يجوز افتراض "دخلنا
    # بالشمعة الأولى" (كان هذا الخطأ بالنسخة السابقة - أنتج TP_HIT وهمي
    # لصفقة لم تُنفَّذ عملياً إطلاقاً). الصح: تصنيفها ENTRY_NEVER_HIT بلا
    # أي حساب ربح/خسارة - تماماً نفس منطق calc_outcomes.py للصفقات البشرية.
    if entry_idx is None:
        result["entry_hit"] = False
        result["outcome"] = "ENTRY_NEVER_HIT"
        return result
    result["entry_hit"] = True

    exit_price = None
    outcome = None
    exit_time = None
    for j in range(entry_idx, len(candles)):
        lo, hi = float(candles[j][3]), float(candles[j][2])
        if not is_short:
            hit_sl = lo <= sl
            hit_tp = hi >= tp
        else:
            hit_sl = hi >= sl
            hit_tp = lo <= tp

        if hit_sl and hit_tp:
            outcome = "AMBIGUOUS_SAME_CANDLE"
            exit_price = sl
            exit_time = candles[j][0]
            break
        elif hit_sl:
            outcome = "SL_HIT"
            exit_price = sl
            exit_time = candles[j][0]
            break
        elif hit_tp:
            outcome = "TP_HIT"
            exit_price = tp
            exit_time = candles[j][0]
            break

    if outcome is None:
        outcome = "NEITHER_HIT_WITHIN_WINDOW"
        exit_price = float(candles[-1][4])
        exit_time = candles[-1][0]

    result["outcome"] = outcome
    result["exit_price"] = exit_price
    result["exit_time"] = datetime.fromtimestamp(int(exit_time) / 1000, tz=timezone.utc).isoformat()
    result["is_short"] = is_short

    if not is_short:
        pnl_pct = (exit_price - entry) / entry * 100
    else:
        pnl_pct = (entry - exit_price) / entry * 100
    result["pnl_pct"] = round(pnl_pct, 3)

    return result


if __name__ == "__main__":
    summary = json.load(open("/home/user/human_trades/master_summary.json"))
    bot_results = []
    for s in summary:
        sid = s["id"]
        sig = s["bot_signal"]
        if sig not in ("BUY", "SELL") or not s["bot_entry"] or not s["bot_sl"] or not s["bot_tp"]:
            print(f"#{sid}: skip (signal={sig}, no full trade plan)")
            bot_results.append({**s, "bot_actual_outcome": None})
            continue

        is_short = sig == "SELL"
        trades = json.load(open("/home/user/human_trades/all_human_trades_with_outcomes.json"))
        publish_ts = next(t["publish_ts"] for t in trades if t["id"] == sid)

        print(f"#{sid} {s['symbol']} bot={sig} entry={s['bot_entry']} sl={s['bot_sl']} tp={s['bot_tp']}...")
        try:
            r = calc_bot_trade_outcome(
                s["symbol"], publish_ts, float(s["bot_entry"]), float(s["bot_sl"]), float(s["bot_tp"]),
                is_short,
            )
        except Exception as e:
            r = {"error": str(e)}
        print(f"   -> {r.get('outcome', r.get('error'))} pnl%={r.get('pnl_pct')}")
        bot_results.append({**s, "bot_actual_outcome": r})

    json.dump(bot_results, open("/home/user/human_trades/master_summary_with_bot_outcomes.json", "w"),
               indent=2, ensure_ascii=False, default=str)
    print("\nDone.")
