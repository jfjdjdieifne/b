# -*- coding: utf-8 -*-
"""
retest_after_fixes.py
════════════════════════════════════════════════════════════════════
جاهز للتشغيل الفوري بمجرد رجوع حصة OpenRouter اليومية (00:00 UTC).
يعيد اختبار نفس الصفقات العشرة اللي كان عندها قرار بوت فعلي (BUY/SELL)
بالجولة الأولى، بعد 4 إصلاحات جذرية:
  1. خطأ فصل الأقسام (DUAL_TARGET_MANAGEMENT كان يبتلع 6 أقسام أخرى)
  2. خطأ توجيه STAGE_4_ENTRY (RISK_ENGINE/ENTRY_MODELS لم تكن تصل
     لمرحلة entry الحقيقية - كانت تصل لمرحلة h1 بالغلط)
  3. تدقيق آلي جديد لتصنيفات HH/HL/LH/LL (audit_structure_labels)
     مدموج بـ_verify_and_retry_daily_math
  4. تحقق ميكانيكي جديد لمسافة SL (audit >= 1.5xATR و >= الحد الأدنى
     بالنسبة) مدموج بدالة جديدة _verify_and_retry_sl_distance

يقارن النتيجة الجديدة بالنتيجة القديمة المحفوظة صراحة، ويحسب هل تحسّن
شيء فعلياً (لا افتراض - نتيجة حقيقية جديدة من API حقيقي).
"""
import json
import sys
import time
import os

sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
os.chdir("/home/user/test/extracted/trading_bot_project")

from nemotron_backtest_driver import run_one_backtest

ALL_KEYS = [
    "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",  # جديد (حساب مختلف تماماً)
    "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",
    "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",
    "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",
    "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",
    "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",
    "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",
]

TRADES_FILE = "/home/user/human_trades/all_human_trades_with_outcomes.json"
OLD_RESULTS_DIR = "/home/user/human_trades/backtest_results"
NEW_RESULTS_DIR = "/home/user/human_trades/backtest_results_after_fixes"
os.makedirs(NEW_RESULTS_DIR, exist_ok=True)

# نفس العشرة صفقات اللي كان عندها قرار فعلي بالجولة الأولى - هدول
# بالضبط اللي نبي نشوف هل SL انصلح فيهم / هل الاتجاه اتحسّن
TARGET_IDS = [1, 3, 4, 6, 7, 8, 9, 10, 11, 15]


def main(max_trades_this_run=None, only_ids=None):
    trades = json.load(open(TRADES_FILE))
    by_id = {t["id"]: t for t in trades}
    ids_to_run = only_ids or TARGET_IDS

    key_idx = 0
    processed = 0
    for tid in ids_to_run:
        if max_trades_this_run and processed >= max_trades_this_run:
            print(f"⏸️ وصلنا حد {max_trades_this_run} - نوقف هون")
            break
        out_path = f"{NEW_RESULTS_DIR}/trade_{tid:02d}.json"
        if os.path.exists(out_path):
            print(f"⏭️ trade {tid} خلص فعلاً بتشغيلة سابقة، تخطي")
            continue

        t = by_id[tid]
        label = f"AFTER_FIXES_TRADE_{tid:02d}_{t['symbol'].replace('/', '')}_{t['publish_date']}"
        primary_key = ALL_KEYS[key_idx % len(ALL_KEYS)]
        backup_keys = ALL_KEYS[(key_idx + 1) % len(ALL_KEYS):] + ALL_KEYS[:(key_idx + 1) % len(ALL_KEYS)]
        key_idx += 1

        print(f"\n{'#'*70}\n# RETEST Trade {tid}: {label}\n{'#'*70}", flush=True)
        try:
            result = run_one_backtest(
                symbol=t["symbol"], timeframe="1h", end_ts=t["publish_ts"],
                api_key=primary_key, label=label, max_tokens=4000, timeout=200,
                backup_keys=backup_keys,
            )
        except Exception as e:
            print(f"❌ EXCEPTION: {e}", flush=True)
            result = {"label": label, "error": str(e)}

        if not isinstance(result, dict):
            result = {"label": label, "error": "None returned"}
        result["human_trade_data"] = t

        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False, default=str)

        # مقارنة فورية بالنتيجة القديمة
        old_path = f"{OLD_RESULTS_DIR}/trade_{tid:02d}.json"
        old = json.load(open(old_path)) if os.path.exists(old_path) else {}
        old_r = old.get("result", {})
        new_r = result.get("result", {})
        print(f"\n📊 مقارنة صفقة {tid}:")
        print(f"   قديم: signal={old_r.get('signal')} entry={old_r.get('entry')} sl={old_r.get('stop_loss')} tp={old_r.get('tp')}")
        print(f"   جديد: signal={new_r.get('signal')} entry={new_r.get('entry')} sl={new_r.get('stop_loss')} tp={new_r.get('tp')}")
        sl_audit = new_r.get("_sl_distance_audit")
        if sl_audit:
            print(f"   SL audit: {sl_audit}")
        daily_audit = (new_r.get("multi_pass_stage_log", {}).get("daily", {}) or {}).get("_daily_math_audit")
        if daily_audit:
            print(f"   Daily structure audit: {daily_audit}")

        processed += 1
        time.sleep(5)

    print("\n\n✅ انتهت إعادة الاختبار لهذه الدفعة.")


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--max", type=int, default=None)
    p.add_argument("--ids", type=str, default=None, help="comma-separated trade ids, e.g. 6,9,15")
    args = p.parse_args()
    only_ids = [int(x) for x in args.ids.split(",")] if args.ids else None
    main(max_trades_this_run=args.max, only_ids=only_ids)
