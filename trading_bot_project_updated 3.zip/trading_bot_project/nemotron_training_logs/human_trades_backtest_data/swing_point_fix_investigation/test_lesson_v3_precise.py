"""
الدرس الدقيق الثالث والأصح - مبني على تحقق كامل بالأرقام الخام:
اكتشفنا أن صفقة صالحة تماماً (SL<=2.5%, RR>=3:1) كانت ممكنة فعلياً
لو استُخدم القاع الحقيقي الصامد كـSL (بدل القاع المكسور) *مع* تعديل
TP لهدف أبعد يحافظ على RR>=3 (بدل الإبقاء على نفس TP القريب القديم).
البوت بعد الدرس السابق أصلح جزءاً واحداً (SL) لكن لم يربطه بتعديل TP
المطلوب معه - فانتهى لـHOLD رغم وجود حل صالح فعلياً.
"""
import sys, json
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
import os
os.chdir("/home/user/test/extracted/trading_bot_project")

from nemotron_openrouter_client import NemotronClient
import lesson_learning

KEY = "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"

trade_context = {
    "symbol": "BTC/USDT",
    "signal": "BUY then corrected attempt resulted in HOLD",
    "sequence_of_events": (
        "Attempt 1: SL placed too tight (below RISK_ENGINE minimum "
        "distance/ATR requirement) -> rejected by validation. "
        "Attempt 2 (correction): SL widened correctly to sit below the "
        "actual most-recent structural low, which fixed the SL distance "
        "problem - BUT the take-profit target was left UNCHANGED at the "
        "same nearby level used in attempt 1. With the wider SL and the "
        "same nearby TP, R:R dropped below the required 3:1 minimum, so "
        "the model gave up and output HOLD instead of re-deriving a "
        "farther, still-genuine take-profit target that would restore "
        "R:R >= 3:1."
    ),
}

outcome_summary = {
    "outcome": "VERIFIED_MISSED_OPPORTUNITY",
    "detail": (
        "Independent verification against the actual subsequent price "
        "data confirmed that a fully valid trade plan DID exist at this "
        "exact moment: an entry with a stop-loss correctly placed below "
        "the genuine most-recent structural low (satisfying both the "
        "minimum distance requirement and the maximum SL% cap), combined "
        "with a FARTHER take-profit target at a genuine liquidity level "
        "beyond the nearby one initially chosen, would have produced "
        "R:R above the 3:1 minimum AND would have reached that farther "
        "target - price actually moved well beyond it afterward. "
        "The model incorrectly treated 'the nearby take-profit level is "
        "fixed' as a constraint when only the entry and stop-loss were "
        "actually being corrected; it should have re-evaluated ALL THREE "
        "numbers (entry, SL, AND TP) together as one coherent package "
        "whenever any one of them changes, rather than fixing two "
        "numbers and declaring failure because the third no longer "
        "produces an acceptable ratio."
    ),
    "was_decision_correct_in_hindsight": False,
    "correct_resolution_existed": True,
}

nc = NemotronClient(KEY, reasoning_effort="none", max_tokens=1500, timeout=120)
print("جارٍ استخراج الدرس الدقيق الثالث...")
lesson = lesson_learning.extract_lesson(nc, trade_context, outcome_summary)

if lesson:
    print()
    print("=== الدرس الجديد (الدقيق) ===")
    print(json.dumps(lesson, indent=2, ensure_ascii=False))
    with open("/home/user/human_trades/lesson_v3_extracted.json", "w", encoding="utf-8") as f:
        json.dump(lesson, f, indent=2, ensure_ascii=False)
else:
    print("❌ فشل الاستخراج")
