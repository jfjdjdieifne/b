"""
اختبار حي كامل لنظام "التعلّم من الدرس" - يستخدم صفقة BTC #1 الحقيقية
(خسرت فعلياً - SL_HIT بعد 12 ساعة كما وثّقنا) لاستخراج درس تحليلي عام
حقيقي (بالموديل الفعلي Nemotron)، حفظه، ثم إعادة تشغيل نفس الصفقة
لمشاهدة هل الدرس تم حقنه فعلياً وهل أثّر بالتحليل.
"""
import sys, json
sys.path.insert(0, "/home/user/test/extracted/trading_bot_project")
import os
os.chdir("/home/user/test/extracted/trading_bot_project")

from nemotron_openrouter_client import NemotronClient
import lesson_learning

KEY = "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"

# ═══ الخطوة 1: نبني سياق الصفقة (ماذا رأى/قرر البوت) من نتيجة الاختبار
# الحي الفعلية المحفوظة مسبقاً (test_new_key_result.json) ═══
bot_result = json.load(open("/home/user/human_trades/test_new_key_result.json"))
r = bot_result["result"]

trade_context = {
    "symbol": "BTC/USDT",
    "daily_bias": "BULLISH",
    "signal": r.get("signal"),
    "entry_model": r.get("entry_model"),
    "reasoning_summary": r.get("reasoning", "")[:800],
    "cross_reference_check": r.get("cross_reference_check", "")[:500],
    "confidence": r.get("confidence"),
}

# ═══ الخطوة 2: النتيجة الفعلية الحقيقية (ground truth من OKX، محسوبة
# مسبقاً فعلياً بـcalc_bot_outcomes.py) ═══
outcome_summary = {
    "outcome": "SL_HIT",
    "detail": (
        "Entry filled, then SL was hit only ~12 hours later - price "
        "reversed against the position quickly after entry, without "
        "the 1H timeframe having actually confirmed a bullish CHoCH/MSS "
        "at the time of entry (the entry was forced by backtest-mode "
        "rules despite Step 4/5 (1H tactical) explicitly reporting "
        "entry_ready=false / no confirmed structural shift yet)."
    ),
    "was_decision_correct_in_hindsight": False,
}

print("=== سياق الصفقة (ماذا رأى/قرر البوت) ===")
print(json.dumps(trade_context, indent=2, ensure_ascii=False)[:1000])
print()
print("=== النتيجة الفعلية ===")
print(json.dumps(outcome_summary, indent=2, ensure_ascii=False))
print()

nc = NemotronClient(KEY, reasoning_effort="none", max_tokens=1500, timeout=120)

print("جارٍ استخراج الدرس من الموديل الفعلي...")
lesson = lesson_learning.extract_lesson(nc, trade_context, outcome_summary)

if lesson:
    print()
    print("=== الدرس المُستخرَج (بعد اجتياز فحص 'عدم الغش') ===")
    print(json.dumps(lesson, indent=2, ensure_ascii=False))
    stored = lesson_learning.store_lesson(lesson, source_trade_id=1)
    print()
    print("=== تم الحفظ ===")
    print(json.dumps(stored, indent=2, ensure_ascii=False))
else:
    print("❌ فشل استخراج درس صالح (إما فشل الاتصال أو فشل فحص الغش بعد كل المحاولات)")

print()
print("=== إحصائية الدروس الحالية ===")
print(json.dumps(lesson_learning.get_lessons_stats(), indent=2, ensure_ascii=False))
