import sys, json
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import detect_mss, compute_displacement

brain = BrainCore()
trades = json.load(open("human_trades/all_human_trades_with_outcomes.json"))
trade = [t for t in trades if t["id"] == 7][0]
symbol = trade["symbol"]
end_ts = trade["publish_ts"]

daily_data = brain.data_manager.fetch_ohlcv_up_to(symbol, "1d", end_ts, limit=90)
n = len(daily_data["closes"])

# idx -4 هو حيث انكسر القاع تحت 59,111 (أعمق قاع بمنطقة الاستنزاف)
# نتحقق: هل صار CHoCH (كسر هيكلي صاعد) خلال 1-8 شموع بعده؟
mss = detect_mss(daily_data)
bullish_breaks = [b for b in mss["breaks_found"] if b["direction"] == "BULLISH"]
print("كل الكسور الصاعدة (BULLISH) المكتشفة على Daily:")
for b in bullish_breaks:
    print(f"  broke {b['broken_level']} @ idx={b['broken_level_index_from_end']}  "
          f"break_candle_idx={b['break_candle_index_from_end']}  displacement={b['displacement_confirmed']}")

print()
print("=== هل صار انعكاس فعلي (CHoCH) خلال 1-8 شموع بعد idx -4 (القاع 59,111)؟ ===")
spring_break_idx = -4
window_end = spring_break_idx + 8  # يعني حتى idx -... ضمن 8 شموع لاحقة (لكن end_ts وقف عند -1 اللي هو آخر شمعة متاحة وقت النشر)
print(f"نافذة التأكيد المسموحة: من idx {spring_break_idx} إلى idx {min(0, window_end)} (بحد أقصى آخر شمعة متاحة = idx -1)")
recent_bullish = [b for b in bullish_breaks if spring_break_idx <= b['break_candle_index_from_end'] <= 0]
print("كسور صاعدة ضمن هذه النافذة:", recent_bullish if recent_bullish else "لا يوجد - Spring غير مؤكد بعد وقت النشر")

print()
print("=== الاندفاع (Displacement) خلال هذه الشموع ===")
disp = compute_displacement(daily_data, lookback=10)
for d in disp["displacement_candles"]:
    print(f"  idx={d['index_from_end']}  direction={d['direction']}  body_pct={d['body_pct']}%  body/ATR={d['body_atr_ratio']}x")
