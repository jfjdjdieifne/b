# -*- coding: utf-8 -*-
import json
import os
import uuid
import logging
from datetime import datetime
from config import Config


class SignalRepository:
    """
    حفظ وإدارة الصفقات المقترحة.
    """

    def __init__(self, file_path="data/proposed_signals.json"):
        self.logger = logging.getLogger("SignalRepository")
        self.file_path = file_path
        Config.ensure_data_dir()
        self.signals = self._load()

    def _load(self):
        if os.path.exists(self.file_path):
            try:
                with open(self.file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return data
            except Exception as e:
                self.logger.error(f"Failed to load signals file: {e}")
        return []

    def _save(self):
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(self.signals, f, ensure_ascii=False, indent=2)

    def add_signal(self, symbol, timeframe, indicators, ai_analysis):
        signal_id = str(uuid.uuid4())[:8]

        item = {
            "id": signal_id,
            "symbol": symbol,
            "timeframe": timeframe,
            "created_at": str(datetime.now()),
            "status": "proposed",
            "checked": False,
            "entry": ai_analysis.get("entry", 0),
            "stop_loss": ai_analysis.get("stop_loss", 0),
            "tp1": ai_analysis.get("tp1", 0),
            "tp2": ai_analysis.get("tp2", 0),
            "tp3": ai_analysis.get("tp3", 0),
            "signal": ai_analysis.get("signal", "HOLD"),
            "confidence": ai_analysis.get("confidence", 0),
            "reasoning": ai_analysis.get("reasoning", ""),
            "bias": ai_analysis.get("bias", ""),
            "indicators": indicators,
            "evaluation": None
        }

        self.signals.append(item)
        self._save()
        return item

    def get_unchecked_signals(self):
        return [s for s in self.signals if not s.get("checked", False)]

    def mark_checked(self, signal_id, evaluation):
        for s in self.signals:
            if s["id"] == signal_id:
                s["checked"] = True
                s["status"] = "evaluated"
                s["evaluation"] = evaluation
                break
        self._save()

    def get_all(self):
        return self.signals