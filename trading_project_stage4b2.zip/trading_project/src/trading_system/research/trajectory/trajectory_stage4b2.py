"""Module 6.2A-4 V1 Stage 4B-2: Shared Entity & Lifecycle Surfaces.

Four shared, hypothesis-independent factual surfaces over the CLOSED public engines:

- Liquidity        (CLOSED 2.2)   — consumes CLOSED Stage 4B-1 structure surface
- Order Block      (CLOSED 4.1)   — consumes CLOSED Stage 4B-1 structure surface
- FVG              (CLOSED 4.2A)  — structure-independent (OHLC only)
- Dealing Range    (CLOSED 4.2B)  — consumes CLOSED Stage 4B-1 structure surface

Design guarantees (per accepted design + design patches):

- ONE authoritative structural input (the CLOSED Stage4B1StructureSurface) for Liquidity / OB /
  Dealing Range; verified via verify_surface_integrity + identity binding; NO private 2.1A→2.1B→2.1C
  reconstruction inside Stage 4B-2. Stronger reconstruction verification is audit/test-only.
- Passthrough market columns actually consumed by each CLOSED engine are verified equal to the
  authoritative sealed market_history BEFORE domain-engine execution (Stage 4B-1 self-integrity does
  not cover passthrough columns).
- FVG is independent: bound to the sealed timeline/market directly.
- Complete CLOSED factual result bound (bar surface derived columns + event/range table), discovered
  dynamically from the CLOSED output (never trusted from a copied design summary).
- Normalized entity representation (Liquidity/OB/FVG derived from *_CREATED rows; Dealing Range uses
  the original CLOSED range table) is labeled STAGE-4B-2-DERIVED where derived.
- Same-bar lifecycle ambiguity: a derived `same_information_batch_order_unknown` flag is added to the
  normalized event representation; mechanical serialization is NOT intrabar chronology.
- Self-integrity: every mutable DataFrame is recomputed/verified from CURRENT content before
  consumption. Historical generating-input provenance remains NOT_CERTIFIED / UNVERIFIABLE.

RESEARCH-DEBT-020/021/022/023/024/025 remain OPEN.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, Optional, Tuple

import pandas as pd

from trading_system.research.hashing import canonical_sha256
from trading_system.research.information_time import (
    InformationKey,
    InformationPhase,
    PositionalTimelineAdapter,
    TimeIndexedTimelineAdapter,
    TimelineAdapterError,
)
from trading_system.research.trajectory.trajectory_contract import (
    MarketObservationTimeline,
    TIMELINE_ADAPTER_KIND,
    TrajectoryContractError,
    TrajectoryDataError,
)
from trading_system.research.trajectory import trajectory_stage4b1 as s4b1
from trading_system.research.trajectory.trajectory_stage4b1 import Stage4B1StructureSurface

from trading_system.liquidity.liquidity_map import (
    CausalLiquidityMapEngine,
    LiquidityMapError,
)
from trading_system.zones.order_blocks import (
    CausalOrderBlockEngine,
    OrderBlockError,
)
from trading_system.zones.fvg import (
    CausalFVGEngine,
    FVGError,
)
from trading_system.zones.dealing_range import (
    CausalDealingRangeEngine,
    RangeError,
)

TimelineAdapter = PositionalTimelineAdapter | TimeIndexedTimelineAdapter

TRAJECTORY_STAGE4B2_CONTRACT_VERSION: Final = "CAUSAL_SHARED_ENTITY_LIFECYCLE_SURFACE_V1"

DOMAIN_LIQUIDITY: Final = "LIQUIDITY"
DOMAIN_ORDER_BLOCK: Final = "ORDER_BLOCK"
DOMAIN_FVG: Final = "FVG"
DOMAIN_DEALING_RANGE: Final = "DEALING_RANGE"

CONTRACT_LIQUIDITY: Final = "MODULE_2_2_V1_1"
CONTRACT_ORDER_BLOCK: Final = "MODULE_4_1_V1_1"
CONTRACT_FVG: Final = "MODULE_4_2A_V1_1"
CONTRACT_DEALING_RANGE: Final = "MODULE_4_2B_V1_1"

_SUPPORTED_DOMAINS: Final = frozenset(
    {DOMAIN_LIQUIDITY, DOMAIN_ORDER_BLOCK, DOMAIN_FVG, DOMAIN_DEALING_RANGE}
)

# Exact passthrough market inputs each CLOSED engine actually consumes (from its required columns).
_PASSTHROUGH_MARKET_COLUMNS: Final = {
    DOMAIN_LIQUIDITY: ("high", "low", "close"),
    DOMAIN_ORDER_BLOCK: ("open", "high", "low", "close"),
    DOMAIN_FVG: ("open", "high", "low", "close"),
    DOMAIN_DEALING_RANGE: ("close",),
}

# CLOSED creation-event type per entity domain (for normalized entity derivation).
_CREATION_EVENT_TYPE: Final = {
    DOMAIN_LIQUIDITY: "LEVEL_CREATED",
    DOMAIN_ORDER_BLOCK: "ZONE_CREATED",
    DOMAIN_FVG: "FVG_CREATED",
}

# Entity identity column + derived entity columns (only fields the CLOSED creation event exposes).
_ENTITY_COLUMNS: Final = {
    DOMAIN_LIQUIDITY: ("level_id", "side", "immutable_level_price",
                       "source_origin_position", "source_confirmation_position", "source_class"),
    DOMAIN_ORDER_BLOCK: ("zone_id", "direction", "origin_position", "creation_position",
                         "search_boundary_position", "source_break_event",
                         "full_zone_low", "full_zone_high", "body_low", "body_high",
                         "displacement_fraction", "displacement_percentile",
                         "displacement_history_count", "origin_prior_use_count"),
    DOMAIN_FVG: ("fvg_id", "direction", "origin_position", "middle_position", "creation_position",
                 "zone_low", "zone_high", "midpoint", "gap_width", "gap_width_fraction",
                 "gap_width_percentile", "gap_width_history_count",
                 "middle_body_fraction", "middle_signed_body_fraction"),
    DOMAIN_DEALING_RANGE: ("range_id", "creation_position", "direction",
                           "first_endpoint_side", "first_endpoint_origin_position",
                           "first_endpoint_confirmation_position", "first_endpoint_price",
                           "first_endpoint_class", "second_endpoint_side",
                           "second_endpoint_origin_position", "second_endpoint_confirmation_position",
                           "second_endpoint_price", "second_endpoint_class",
                           "range_low", "range_high", "range_width", "midpoint"),
}

_AMBIGUITY_COLUMN: Final = "same_information_batch_order_unknown"

_LEGAL_BOUNDARY_PHASES: Final = frozenset(
    {
        InformationPhase.COMPLETED_ROW_AVAILABLE,
        InformationPhase.RESEARCH_SNAPSHOT_AVAILABLE,
    }
)


# ---------------------------------------------------------------------------
# Surface types
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Stage4B2DomainSurface:
    """One shared entity/lifecycle domain surface (Liquidity / OB / FVG / Dealing Range).

    `bar_frame` = the CLOSED engine's bar surface (with derived factual columns);
    `event_frame` = the CLOSED normalized event table (or the range table for Dealing Range);
    `normalized_entity_frame` = the normalized entity representation (derived from *_CREATED rows for
    Liquidity/OB/FVG; the original range table for Dealing Range);
    `normalized_event_frame` = the event table augmented with the derived
    `same_information_batch_order_unknown` column.

    All DataFrames are mutable; every consumer must call verify_surface_integrity first.
    """

    domain: str
    contract_version: str
    timeline_id: str
    timeline_hash: str
    adapter_kind: TIMELINE_ADAPTER_KIND
    structure_surface_id: Optional[str]  # bound Stage 4B-1 identity (None for FVG)
    reconstruction_input_hash: str
    bar_columns: Tuple[str, ...]
    event_columns: Tuple[str, ...]
    entity_columns: Tuple[str, ...]
    complete_result_hash: str
    normalized_entity_hash: str
    normalized_event_hash: str
    surface_id: str
    bar_frame: pd.DataFrame
    event_frame: pd.DataFrame
    normalized_entity_frame: pd.DataFrame
    normalized_event_frame: pd.DataFrame


@dataclass(frozen=True)
class Stage4B2PrefixBinding:
    """Compact reference to a shared domain surface + immutable prefix identity through a boundary."""

    domain: str
    surface_id: str
    boundary_position: int
    boundary_key: InformationKey
    prefix_hash: str
    prefix_row_count: int


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _canonical_hash(domain: str, payload) -> str:
    try:
        return canonical_sha256(domain=domain, payload=payload)
    except Exception as exc:
        raise TrajectoryDataError(f"Stage 4B-2 hash failed ({domain}): {exc}") from exc


def _new_columns(result: pd.DataFrame, input_frame: pd.DataFrame) -> Tuple[str, ...]:
    existing = set(input_frame.columns)
    return tuple(c for c in result.columns if c not in existing)


def _reconstruct_adapter(surface: Stage4B2DomainSurface) -> TimelineAdapter:
    if surface.adapter_kind is TIMELINE_ADAPTER_KIND.POSITIONAL:
        return PositionalTimelineAdapter(surface.timeline_id)
    if surface.adapter_kind is TIMELINE_ADAPTER_KIND.TIME_INDEXED:
        return TimeIndexedTimelineAdapter(surface.timeline_id)
    raise TrajectoryDataError(f"unsupported adapter kind: {surface.adapter_kind}")


def _verify_structure_input(
    *,
    structure_surface: Stage4B1StructureSurface,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    domain: str,
) -> None:
    """Verify the CLOSED Stage 4B-1 structural input + passthrough market columns.

    Order: (A) verify_structure_integrity; (B) timeline identity match; (C) CLOSED timeline
    verify; (D) exact passthrough market equality for the columns this domain engine consumes.
    """
    if not isinstance(structure_surface, Stage4B1StructureSurface):
        raise TrajectoryContractError("structure_surface must be a Stage4B1StructureSurface")
    # A. CLOSED self-integrity on the structural surface
    s4b1.verify_surface_integrity(structure_surface)
    # B. timeline identity match
    if structure_surface.timeline_id != timeline.timeline_id:
        raise TrajectoryDataError("structure surface timeline_id mismatch")
    if structure_surface.timeline_hash != timeline.timeline_hash:
        raise TrajectoryDataError("structure surface timeline_hash mismatch")
    # C. authoritative timeline verification
    timeline.verify(adapter=adapter, market_history=market_history)
    # D. exact passthrough market equality for the consumed columns
    for col in _PASSTHROUGH_MARKET_COLUMNS[domain]:
        if col not in structure_surface.frame.columns:
            raise TrajectoryDataError(f"structure frame missing passthrough column: {col}")
        frame_col = structure_surface.frame[col].reset_index(drop=True)
        market_col = market_history[col].reset_index(drop=True)
        if not frame_col.equals(market_col):
            raise TrajectoryDataError(
                f"structure frame passthrough column {col} differs from authoritative market_history"
            )


def _with_ambiguity(event_frame: pd.DataFrame) -> pd.DataFrame:
    """Add the derived same-information-batch-unknown flag (STAGE-4B-2-derived, not CLOSED)."""
    frame = event_frame.copy(deep=True)
    if "event_position" in frame.columns:
        dup = frame["event_position"].duplicated(keep=False)
        frame[_AMBIGUITY_COLUMN] = dup
    else:
        # no event_position (should not happen for these engines); default False
        frame[_AMBIGUITY_COLUMN] = False
    return frame


def _derive_entity_frame(
    domain: str,
    event_frame: pd.DataFrame,
    creation_event_type: Optional[str],
) -> pd.DataFrame:
    """Derive a normalized entity table from *_CREATED event rows (STAGE-4B-2-DERIVED)."""
    cols = list(_ENTITY_COLUMNS[domain])
    if creation_event_type is None:
        # Dealing Range: the event_frame IS the range table; entity == event rows (no event_type col)
        return event_frame[cols].copy(deep=True)
    created = event_frame[event_frame["event_type"] == creation_event_type].copy(deep=True)
    # entity id column name differs per domain; keep the CLOSED id column present in cols
    return created[cols].reset_index(drop=True)


def _build_surface(
    *,
    domain: str,
    contract_version: str,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    structure_surface: Optional[Stage4B1StructureSurface],
    input_frame: pd.DataFrame,
    bar_result: pd.DataFrame,
    event_result: pd.DataFrame,
) -> Stage4B2DomainSurface:
    """Common assembly: defensive copies + identity binding + self-integrity call."""
    owned_bar = bar_result.copy(deep=True)
    owned_event = event_result.copy(deep=True)

    bar_columns = _new_columns(owned_bar, input_frame)
    event_columns = _new_columns(owned_event, input_frame)
    # event table columns are the full result minus any passthrough present in the input frame
    if not event_columns:
        # event/range tables typically share no passthrough columns; fall back to all columns
        event_columns = tuple(owned_event.columns)

    creation_type = _CREATION_EVENT_TYPE.get(domain)
    normalized_entity = _derive_entity_frame(domain, owned_event, creation_type)
    normalized_event = _with_ambiguity(owned_event)

    reconstruction_payload = {
        "domain": domain,
        "contract_version": contract_version,
        "timeline_id": timeline.timeline_id,
        "timeline_hash": timeline.timeline_hash,
        "structure_surface_id": structure_surface.surface_id if structure_surface is not None else None,
    }
    reconstruction_input_hash = _canonical_hash("STAGE4B2_RECONSTRUCTION_INPUT_BINDING_V1", reconstruction_payload)

    complete_result_hash = _canonical_hash(
        "STAGE4B2_COMPLETE_RESULT_V1",
        {"bar": owned_bar.loc[:, list(bar_columns)], "event": owned_event.loc[:, list(event_columns)]},
    )
    normalized_entity_hash = _canonical_hash(
        "STAGE4B2_NORMALIZED_ENTITY_V1", normalized_entity
    )
    normalized_event_hash = _canonical_hash(
        "STAGE4B2_NORMALIZED_EVENT_V1", normalized_event
    )

    surface_id = _canonical_hash(
        "STAGE4B2_SURFACE_IDENTITY_V1",
        {
            "domain": domain,
            "contract_version": contract_version,
            "timeline_id": timeline.timeline_id,
            "timeline_hash": timeline.timeline_hash,
            "adapter_kind": timeline.adapter_kind,
            "structure_surface_id": structure_surface.surface_id if structure_surface is not None else None,
            "reconstruction_input_hash": reconstruction_input_hash,
            "complete_result_hash": complete_result_hash,
            "normalized_entity_hash": normalized_entity_hash,
            "normalized_event_hash": normalized_event_hash,
        },
    )

    surface = Stage4B2DomainSurface(
        domain=domain,
        contract_version=contract_version,
        timeline_id=timeline.timeline_id,
        timeline_hash=timeline.timeline_hash,
        adapter_kind=timeline.adapter_kind,
        structure_surface_id=structure_surface.surface_id if structure_surface is not None else None,
        reconstruction_input_hash=reconstruction_input_hash,
        bar_columns=bar_columns,
        event_columns=event_columns,
        entity_columns=tuple(_ENTITY_COLUMNS[domain]),
        complete_result_hash=complete_result_hash,
        normalized_entity_hash=normalized_entity_hash,
        normalized_event_hash=normalized_event_hash,
        surface_id=surface_id,
        bar_frame=owned_bar,
        event_frame=owned_event,
        normalized_entity_frame=normalized_entity,
        normalized_event_frame=normalized_event,
    )
    verify_surface_integrity(surface)
    return surface


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------

def build_liquidity_surface(
    *,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    structure_surface: Stage4B1StructureSurface,
) -> Stage4B2DomainSurface:
    _verify_structure_input(
        structure_surface=structure_surface, timeline=timeline, adapter=adapter,
        market_history=market_history, domain=DOMAIN_LIQUIDITY,
    )
    try:
        bar, events = CausalLiquidityMapEngine().analyze(structure_surface.frame)
    except LiquidityMapError as exc:
        raise TrajectoryDataError(f"liquidity engine rejected input: {exc}") from exc
    return _build_surface(
        domain=DOMAIN_LIQUIDITY, contract_version=CONTRACT_LIQUIDITY,
        timeline=timeline, adapter=adapter, structure_surface=structure_surface,
        input_frame=structure_surface.frame, bar_result=bar, event_result=events,
    )


def build_order_block_surface(
    *,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    structure_surface: Stage4B1StructureSurface,
) -> Stage4B2DomainSurface:
    _verify_structure_input(
        structure_surface=structure_surface, timeline=timeline, adapter=adapter,
        market_history=market_history, domain=DOMAIN_ORDER_BLOCK,
    )
    try:
        bar, events = CausalOrderBlockEngine().analyze(structure_surface.frame)
    except OrderBlockError as exc:
        raise TrajectoryDataError(f"order-block engine rejected input: {exc}") from exc
    return _build_surface(
        domain=DOMAIN_ORDER_BLOCK, contract_version=CONTRACT_ORDER_BLOCK,
        timeline=timeline, adapter=adapter, structure_surface=structure_surface,
        input_frame=structure_surface.frame, bar_result=bar, event_result=events,
    )


def build_fvg_surface(
    *,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
) -> Stage4B2DomainSurface:
    timeline.verify(adapter=adapter, market_history=market_history)
    try:
        bar, events = CausalFVGEngine().analyze(market_history)
    except FVGError as exc:
        raise TrajectoryDataError(f"fvg engine rejected input: {exc}") from exc
    return _build_surface(
        domain=DOMAIN_FVG, contract_version=CONTRACT_FVG,
        timeline=timeline, adapter=adapter, structure_surface=None,
        input_frame=market_history, bar_result=bar, event_result=events,
    )


def build_dealing_range_surface(
    *,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    structure_surface: Stage4B1StructureSurface,
) -> Stage4B2DomainSurface:
    _verify_structure_input(
        structure_surface=structure_surface, timeline=timeline, adapter=adapter,
        market_history=market_history, domain=DOMAIN_DEALING_RANGE,
    )
    try:
        bar, range_table = CausalDealingRangeEngine().analyze(structure_surface.frame)
    except RangeError as exc:
        raise TrajectoryDataError(f"dealing-range engine rejected input: {exc}") from exc
    return _build_surface(
        domain=DOMAIN_DEALING_RANGE, contract_version=CONTRACT_DEALING_RANGE,
        timeline=timeline, adapter=adapter, structure_surface=structure_surface,
        input_frame=structure_surface.frame, bar_result=bar, event_result=range_table,
    )


# ---------------------------------------------------------------------------
# Self-integrity
# ---------------------------------------------------------------------------

def verify_surface_integrity(surface: Stage4B2DomainSurface) -> None:
    if not isinstance(surface, Stage4B2DomainSurface):
        raise TrajectoryContractError("surface must be a Stage4B2DomainSurface")
    if surface.domain not in _SUPPORTED_DOMAINS:
        raise TrajectoryDataError(f"unsupported domain: {surface.domain}")
    expected_contract = {
        DOMAIN_LIQUIDITY: CONTRACT_LIQUIDITY,
        DOMAIN_ORDER_BLOCK: CONTRACT_ORDER_BLOCK,
        DOMAIN_FVG: CONTRACT_FVG,
        DOMAIN_DEALING_RANGE: CONTRACT_DEALING_RANGE,
    }[surface.domain]
    if surface.contract_version != expected_contract:
        raise TrajectoryDataError(f"contract version mismatch: {surface.contract_version} vs {expected_contract}")
    if not isinstance(surface.timeline_id, str) or not surface.timeline_id:
        raise TrajectoryDataError("timeline_id must be non-empty")
    if not isinstance(surface.timeline_hash, str) or not surface.timeline_hash:
        raise TrajectoryDataError("timeline_hash must be non-empty")
    if surface.adapter_kind not in (TIMELINE_ADAPTER_KIND.POSITIONAL, TIMELINE_ADAPTER_KIND.TIME_INDEXED):
        raise TrajectoryDataError(f"invalid adapter_kind: {surface.adapter_kind}")
    if surface.domain != DOMAIN_FVG and not isinstance(surface.structure_surface_id, str):
        raise TrajectoryDataError("structure-dependent domain requires a structure_surface_id")
    if surface.entity_columns != tuple(_ENTITY_COLUMNS[surface.domain]):
        raise TrajectoryDataError("entity_columns schema mismatch")

    for frame, label in (
        (surface.bar_frame, "bar_frame"),
        (surface.event_frame, "event_frame"),
        (surface.normalized_entity_frame, "normalized_entity_frame"),
        (surface.normalized_event_frame, "normalized_event_frame"),
    ):
        if not isinstance(frame, pd.DataFrame):
            raise TrajectoryDataError(f"{label} must be a DataFrame")
        if frame.columns.has_duplicates:
            raise TrajectoryDataError(f"{label} has duplicate columns")

    for col in surface.bar_columns:
        if col not in surface.bar_frame.columns:
            raise TrajectoryDataError(f"bar column missing: {col}")
    for col in surface.event_columns:
        if col not in surface.event_frame.columns:
            raise TrajectoryDataError(f"event column missing: {col}")
    if _AMBIGUITY_COLUMN not in surface.normalized_event_frame.columns:
        raise TrajectoryDataError("normalized event frame missing ambiguity column")

    recomputed_complete = _canonical_hash(
        "STAGE4B2_COMPLETE_RESULT_V1",
        {
            "bar": surface.bar_frame.loc[:, list(surface.bar_columns)],
            "event": surface.event_frame.loc[:, list(surface.event_columns)],
        },
    )
    if recomputed_complete != surface.complete_result_hash:
        raise TrajectoryDataError("self-integrity: complete_result_hash stale")

    recomputed_entity = _canonical_hash("STAGE4B2_NORMALIZED_ENTITY_V1", surface.normalized_entity_frame)
    if recomputed_entity != surface.normalized_entity_hash:
        raise TrajectoryDataError("self-integrity: normalized_entity_hash stale")
    recomputed_event = _canonical_hash("STAGE4B2_NORMALIZED_EVENT_V1", surface.normalized_event_frame)
    if recomputed_event != surface.normalized_event_hash:
        raise TrajectoryDataError("self-integrity: normalized_event_hash stale")

    recomputed_surface_id = _canonical_hash(
        "STAGE4B2_SURFACE_IDENTITY_V1",
        {
            "domain": surface.domain,
            "contract_version": surface.contract_version,
            "timeline_id": surface.timeline_id,
            "timeline_hash": surface.timeline_hash,
            "adapter_kind": surface.adapter_kind,
            "structure_surface_id": surface.structure_surface_id,
            "reconstruction_input_hash": surface.reconstruction_input_hash,
            "complete_result_hash": recomputed_complete,
            "normalized_entity_hash": recomputed_entity,
            "normalized_event_hash": recomputed_event,
        },
    )
    if recomputed_surface_id != surface.surface_id:
        raise TrajectoryDataError("self-integrity: surface_id stale")


# ---------------------------------------------------------------------------
# Prefix projection
# ---------------------------------------------------------------------------

def project_domain_prefix(
    *,
    surface: Stage4B2DomainSurface,
    boundary_key: InformationKey,
) -> Stage4B2PrefixBinding:
    if not isinstance(surface, Stage4B2DomainSurface):
        raise TrajectoryContractError("surface must be a Stage4B2DomainSurface")
    verify_surface_integrity(surface)
    if not isinstance(boundary_key, InformationKey):
        raise TrajectoryContractError("boundary_key must be an InformationKey")
    if boundary_key.information_phase not in _LEGAL_BOUNDARY_PHASES:
        raise TrajectoryContractError(
            f"boundary key phase not legally observable: {boundary_key.information_phase}"
        )
    adapter = _reconstruct_adapter(surface)
    try:
        adapter.validate_key(boundary_key, surface.bar_frame.index)
    except TimelineAdapterError as exc:
        raise TrajectoryDataError(f"boundary key invalid for surface: {exc}") from exc

    position = boundary_key.bar_position
    n = len(surface.bar_frame)
    if position < 0 or position >= n:
        raise TrajectoryDataError(f"boundary position {position} outside surface range [0, {n - 1}]")

    prefix_bar = surface.bar_frame.loc[:, list(surface.bar_columns)].iloc[: position + 1]
    prefix_hash = _canonical_hash("STAGE4B2_PREFIX_IDENTITY_V1", prefix_bar)

    return Stage4B2PrefixBinding(
        domain=surface.domain,
        surface_id=surface.surface_id,
        boundary_position=position,
        boundary_key=boundary_key,
        prefix_hash=prefix_hash,
        prefix_row_count=position + 1,
    )


# ---------------------------------------------------------------------------
# Manifest
# ---------------------------------------------------------------------------

def trajectory_stage4b2_manifest() -> pd.DataFrame:
    rows = [
        ("CONTRACT", "VERSION", TRAJECTORY_STAGE4B2_CONTRACT_VERSION),
        ("SURFACE", "ARCHITECTURE", "FOUR_STRONGLY_SEPARATED_DOMAIN_SURFACES_SHARED_PER_IDENTITY"),
        ("SURFACE", "IDENTITY", "DETERMINISTIC_RECONSTRUCTION_DERIVATION_WITNESS_NOT_HISTORICAL_PROVENANCE"),
        ("SURFACE", "SELF_INTEGRITY", "VERIFY_RECOMPUTES_ALL_HASHES_FROM_CURRENT_CONTENT"),
        ("DOMAIN", "LIQUIDITY", "SUPPORTED_CLOSED_2_2_CONSUMES_STAGE4B1"),
        ("DOMAIN", "ORDER_BLOCK", "SUPPORTED_CLOSED_4_1_CONSUMES_STAGE4B1"),
        ("DOMAIN", "FVG", "SUPPORTED_CLOSED_4_2A_STRUCTURE_INDEPENDENT"),
        ("DOMAIN", "DEALING_RANGE", "SUPPORTED_CLOSED_4_2B_CONSUMES_STAGE4B1"),
        ("AMBIGUITY", "SAME_BATCH", "DERIVED_FLAG_NOT_INTRABAR_CHRONOLOGY"),
        ("ENTITY", "NORMALIZED", "STAGE4B2_DERIVED_FROM_CREATION_EVENTS_OR_ORIGINAL_RANGE_TABLE"),
        ("INFORMATION_TIME", "ORIGIN", "ORIGIN_NEVER_USED_AS_AVAILABILITY_NO_FORGED_INFORMATIONKEY"),
        ("OUT_OF_SCOPE", "STAGE4C", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "DESCRIPTORS", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "ESTIMANDS", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "MODEL", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "GEOMETRY", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "EXECUTION", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "WIN_LOSS", "FORBIDDEN"),
        ("DEBT", "RESEARCH-DEBT-020", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-021", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-022", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-023", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-024", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-025", "OPEN"),
    ]
    return pd.DataFrame(
        [{"record_type": a, "name": b, "value": c, "serialization_order": i} for i, (a, b, c) in enumerate(rows)]
    )
