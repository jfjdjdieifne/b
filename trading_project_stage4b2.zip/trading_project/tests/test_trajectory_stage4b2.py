"""Tests for Module 6.2A-4 V1 Stage 4B-2: Shared Entity & Lifecycle Surfaces.

Covers: entity-ID prefix stability (REAL CLOSED engines), non-vacuous lifecycle events, availability
(event invisible before its factual row), passthrough-market binding, self-integrity mutation
rejection, prefix invariance, wrong-domain rejection, boundary legality, numeric/schema, and firewall.
"""

from __future__ import annotations

import dataclasses
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from trading_system.research.information_time import (
    INFORMATION_KEY_VERSION,
    InformationKey,
    InformationPhase,
    PositionalTimelineAdapter,
)
from trading_system.research.trajectory.trajectory_contract import (
    MarketObservationTimeline,
    TrajectoryContractError,
    TrajectoryDataError,
)
from trading_system.research.trajectory import trajectory_stage4b1 as s4b1
from trading_system.research.trajectory import trajectory_stage4b2 as s4b2
from trading_system.research.trajectory.trajectory_stage4b2 import (
    Stage4B2DomainSurface,
    Stage4B2PrefixBinding,
    DOMAIN_LIQUIDITY,
    DOMAIN_ORDER_BLOCK,
    DOMAIN_FVG,
    DOMAIN_DEALING_RANGE,
)
from trading_system.structure.swing_detector import EmpiricalConfirmationPolicy


# ---------------------------------------------------------------------------
# Helpers — rich fixture (REAL swings / BOS / lifecycle for all four domains)
# ---------------------------------------------------------------------------

def _policy():
    priors = tuple(0.01 * i for i in range(1, 50))
    return EmpiricalConfirmationPolicy(quantile=0.1, prior_continuation_reversals=priors)


def _market(n=90):
    """Staircase rise + terminal collapse: a function of index only (prefix-identical across n).

    `collapse_at` is FIXED (not n-dependent), so a shorter prefix is byte-identical to the
    same-length prefix of a longer build. Verified to produce real confirmed swings, BOS_UP, and
    lifecycle events for Liquidity / OB / FVG / Dealing Range.
    """
    o, h, l, c = [], [], [], []
    level = 100.0
    i = 0
    collapse_at = 65  # fixed, independent of n
    while i < n:
        if i < collapse_at:
            if i % 7 < 4:
                o.append(level); c.append(level + 5.0); level = c[-1]
            else:
                o.append(level); c.append(level - 3.0); level = c[-1]
        else:
            o.append(level); c.append(level - 6.0); level = c[-1]
        h.append(max(o[-1], c[-1]) + 1.0)
        l.append(min(o[-1], c[-1]) - 1.0)
        i += 1
    return pd.DataFrame({"open": o, "high": h, "low": l, "close": c}, index=pd.RangeIndex(n), dtype=float)


def _seal_and_struct(n=90, tid="s4b2"):
    market = _market(n)
    adapter = PositionalTimelineAdapter(tid)
    timeline = MarketObservationTimeline.seal(adapter=adapter, market_history=market)
    struct = s4b1.build_structure_surface(timeline=timeline, adapter=adapter, market_history=market, swing_policy=_policy())
    return market, adapter, timeline, struct


def _surfaces(n=90, tid="s4b2"):
    market, adapter, timeline, struct = _seal_and_struct(n, tid)
    liq = s4b2.build_liquidity_surface(timeline=timeline, adapter=adapter, market_history=market, structure_surface=struct)
    ob = s4b2.build_order_block_surface(timeline=timeline, adapter=adapter, market_history=market, structure_surface=struct)
    fvg = s4b2.build_fvg_surface(timeline=timeline, adapter=adapter, market_history=market)
    dr = s4b2.build_dealing_range_surface(timeline=timeline, adapter=adapter, market_history=market, structure_surface=struct)
    return market, adapter, timeline, struct, {"LIQ": liq, "OB": ob, "FVG": fvg, "DR": dr}


def _key(adapter, market, position, phase=InformationPhase.COMPLETED_ROW_AVAILABLE):
    return adapter.key_for_position(market.index, position, phase, 0)


def _entity_id_column(domain):
    return {
        DOMAIN_LIQUIDITY: "level_id",
        DOMAIN_ORDER_BLOCK: "zone_id",
        DOMAIN_FVG: "fvg_id",
        DOMAIN_DEALING_RANGE: "range_id",
    }[domain]


def _creation_position_column(domain):
    return {
        DOMAIN_LIQUIDITY: "source_confirmation_position",
        DOMAIN_ORDER_BLOCK: "creation_position",
        DOMAIN_FVG: "creation_position",
        DOMAIN_DEALING_RANGE: "creation_position",
    }[domain]


# ---------------------------------------------------------------------------
# §10 non-vacuous: fixtures actually produce real entities + lifecycle events
# ---------------------------------------------------------------------------

def test_fixture_produces_real_entities_and_lifecycle():
    _, _, _, _, surfs = _surfaces(90)
    # each domain must have real entities
    for nm in ("LIQ", "OB", "FVG", "DR"):
        assert len(surfs[nm].normalized_entity_frame) >= 1, f"{nm} has no entities"
    # lifecycle events beyond creation for the event-table domains
    liq_types = set(surfs["LIQ"].event_frame["event_type"])
    assert "LEVEL_CREATED" in liq_types and "FIRST_TOUCH" in liq_types
    ob_types = set(surfs["OB"].event_frame["event_type"])
    assert "ZONE_CREATED" in ob_types and "FIRST_TOUCH" in ob_types
    fvg_types = set(surfs["FVG"].event_frame["event_type"])
    assert "FVG_CREATED" in fvg_types and "FIRST_TOUCH" in fvg_types
    # dealing range: real range entities
    assert "range_id" in surfs["DR"].normalized_entity_frame.columns
    assert len(surfs["DR"].normalized_entity_frame) >= 1


def test_ambiguity_flag_marks_same_batch_collisions():
    _, _, _, _, surfs = _surfaces(90)
    # liquidity has same-bar collisions in the rich fixture
    ne = surfs["LIQ"].normalized_event_frame
    assert "same_information_batch_order_unknown" in ne.columns
    assert ne["same_information_batch_order_unknown"].any(), "fixture should produce same-bar collisions"


# ---------------------------------------------------------------------------
# §9 entity-ID prefix stability (REAL CLOSED engines)
# ---------------------------------------------------------------------------

_DOMAIN_PARAMS = [
    (DOMAIN_LIQUIDITY, "LIQ"),
    (DOMAIN_ORDER_BLOCK, "OB"),
    (DOMAIN_FVG, "FVG"),
    (DOMAIN_DEALING_RANGE, "DR"),
]


@pytest.mark.parametrize("domain,short", _DOMAIN_PARAMS)
def test_entity_id_prefix_stability(domain, short):
    short_n, long_n = 70, 90
    m_s, a_s, t_s, struct_s, surf_s = _surfaces(short_n, f"s_{short}_short")
    m_l, a_l, t_l, struct_l, surf_l = _surfaces(long_n, f"s_{short}_long")
    # prefix identical
    assert m_s.equals(m_l.iloc[:short_n])

    T = 60  # boundary before the collapse; entities created through T exist
    s_entity = surf_s[short].normalized_entity_frame
    l_entity = surf_l[short].normalized_entity_frame
    id_col = _entity_id_column(domain)
    pos_col = _creation_position_column(domain)
    # assert real entities exist through T
    s_through = s_entity[s_entity[pos_col] <= T]
    assert len(s_through) >= 1, f"{domain}: no entity created through T (vacuous)"
    # IDs must be identical for entities created through T
    s_ids = s_through[id_col].tolist()
    l_through = l_entity[l_entity[pos_col] <= T]
    l_ids = l_through[id_col].tolist()
    assert s_ids == l_ids, f"{domain}: entity IDs differ under future extension"


# ---------------------------------------------------------------------------
# §11 availability: event invisible before its factual row, visible at it
# ---------------------------------------------------------------------------

def test_lifecycle_event_availability():
    market, adapter, _, _, surfs = _surfaces(90)
    # pick the first FIRST_TOUCH event in liquidity; its event_position is its factual row
    ev = surfs["LIQ"].event_frame
    touch = ev[ev["event_type"] == "FIRST_TOUCH"]
    assert len(touch) >= 1
    pos = int(touch["event_position"].iloc[0])
    # the bar-surface first-touch aggregate at pos-1 must not include this event's contribution
    # (the event is at bar pos), and the prefix through pos-1 must exclude bar pos
    k_before = _key(adapter, market, pos - 1)
    p_before = s4b2.project_domain_prefix(surface=surfs["LIQ"], boundary_key=k_before)
    assert p_before.prefix_row_count == pos  # rows 0..pos-1
    k_at = _key(adapter, market, pos)
    p_at = s4b2.project_domain_prefix(surface=surfs["LIQ"], boundary_key=k_at)
    assert p_at.prefix_row_count == pos + 1
    assert p_before.prefix_hash != p_at.prefix_hash


# ---------------------------------------------------------------------------
# §3 passthrough market binding: mutation inside structure frame must reject
# ---------------------------------------------------------------------------

def test_passthrough_market_mutation_rejected():
    market, adapter, timeline, struct, _ = _surfaces(90)
    # mutate close inside structure_surface.frame (passthrough for liquidity)
    mutated_frame = struct.frame.copy(deep=True)
    mutated_frame.iloc[10, mutated_frame.columns.get_loc("close")] = 99999.0
    mutated_struct = dataclasses.replace(struct, frame=mutated_frame)
    # Stage 4B-1 self-integrity still passes (derived columns unchanged)
    s4b1.verify_surface_integrity(mutated_struct)
    # but the passthrough equality check rejects BEFORE domain consumption
    with pytest.raises(TrajectoryDataError, match="passthrough"):
        s4b2.build_liquidity_surface(timeline=timeline, adapter=adapter, market_history=market, structure_surface=mutated_struct)


def test_structure_derived_mutation_rejected():
    market, adapter, timeline, struct, _ = _surfaces(90)
    # mutate a derived structure column (swing_high_confirmed) by flipping its value
    mutated_frame = struct.frame.copy(deep=True)
    col = "swing_high_confirmed"
    current = bool(mutated_frame.iloc[5].loc[col])
    mutated_frame.iloc[5, mutated_frame.columns.get_loc(col)] = not current
    mutated_struct = dataclasses.replace(struct, frame=mutated_frame)
    with pytest.raises(TrajectoryDataError, match="self-integrity"):
        s4b2.build_liquidity_surface(timeline=timeline, adapter=adapter, market_history=market, structure_surface=mutated_struct)


# ---------------------------------------------------------------------------
# §14 self-integrity mutation rejection
# ---------------------------------------------------------------------------

def test_surface_bar_mutation_rejected():
    _, _, _, _, surfs = _surfaces(90)
    surf = surfs["LIQ"]
    s4b2.verify_surface_integrity(surf)  # valid
    frame = surf.bar_frame.copy(deep=True)
    frame.iloc[3, frame.columns.get_loc("liquidity_level_created")] = True
    tampered = dataclasses.replace(surf, bar_frame=frame)
    with pytest.raises(TrajectoryDataError, match="self-integrity"):
        s4b2.verify_surface_integrity(tampered)


def test_surface_event_mutation_rejected():
    _, _, _, _, surfs = _surfaces(90)
    surf = surfs["LIQ"]
    frame = surf.event_frame.copy(deep=True)
    frame.iloc[0, frame.columns.get_loc("event_type")] = "FIRST_TOUCH"
    tampered = dataclasses.replace(surf, event_frame=frame)
    with pytest.raises(TrajectoryDataError, match="self-integrity"):
        s4b2.verify_surface_integrity(tampered)


def test_forged_surface_id_rejected():
    _, _, _, _, surfs = _surfaces(90)
    surf = surfs["LIQ"]
    forged = dataclasses.replace(surf, surface_id="0" * 64)
    with pytest.raises(TrajectoryDataError, match="self-integrity"):
        s4b2.verify_surface_integrity(forged)


# ---------------------------------------------------------------------------
# §2 wrong-domain substitution rejected at runtime
# ---------------------------------------------------------------------------

def test_wrong_domain_rejected():
    _, _, _, _, surfs = _surfaces(90)
    # an FVG surface must not pass as a Liquidity surface: domain field mismatch
    forged = dataclasses.replace(surfs["FVG"], domain=DOMAIN_LIQUIDITY)
    with pytest.raises(TrajectoryDataError):
        s4b2.verify_surface_integrity(forged)


def test_contract_version_mismatch_rejected():
    _, _, _, _, surfs = _surfaces(90)
    forged = dataclasses.replace(surfs["LIQ"], contract_version="WRONG")
    with pytest.raises(TrajectoryDataError, match="contract version"):
        s4b2.verify_surface_integrity(forged)


# ---------------------------------------------------------------------------
# §13 prefix identity
# ---------------------------------------------------------------------------

def test_full_surface_identity_changes_on_append_prefix_preserved():
    m_s, a_s, t_s, struct_s, surf_s = _surfaces(70, "p_short")
    m_l, a_l, t_l, struct_l, surf_l = _surfaces(90, "p_long")
    assert m_s.equals(m_l.iloc[:70])
    T = 60
    for domain in ("LIQ", "OB", "FVG", "DR"):
        full_s = surf_s[domain].surface_id
        full_l = surf_l[domain].surface_id
        assert full_s != full_l, f"{domain}: full surface identity should change on append"
        k_s = _key(a_s, m_s, T)
        k_l = _key(a_l, m_l, T)
        p_s = s4b2.project_domain_prefix(surface=surf_s[domain], boundary_key=k_s)
        p_l = s4b2.project_domain_prefix(surface=surf_l[domain], boundary_key=k_l)
        assert p_s.prefix_hash == p_l.prefix_hash, f"{domain}: prefix through T must be preserved"


def test_prefix_mutation_at_or_before_T_rejected():
    market, adapter, _, _, surfs = _surfaces(90)
    surf = surfs["LIQ"]
    k = _key(adapter, market, 60)
    frame = surf.bar_frame.copy(deep=True)
    frame.iloc[30, frame.columns.get_loc("liquidity_level_created")] = True
    tampered = dataclasses.replace(surf, bar_frame=frame)
    with pytest.raises(TrajectoryDataError, match="self-integrity"):
        s4b2.project_domain_prefix(surface=tampered, boundary_key=k)


# ---------------------------------------------------------------------------
# §12 boundary legality
# ---------------------------------------------------------------------------

def test_bar_pre_close_rejected():
    market, adapter, _, _, surfs = _surfaces(90)
    k = _key(adapter, market, 30, InformationPhase.BAR_PRE_CLOSE)
    with pytest.raises(TrajectoryContractError, match="not legally observable"):
        s4b2.project_domain_prefix(surface=surfs["LIQ"], boundary_key=k)


def test_cross_timeline_rejected():
    market, adapter, _, _, surfs = _surfaces(90)
    other = PositionalTimelineAdapter("other_timeline")
    k = other.key_for_position(market.index, 30, InformationPhase.COMPLETED_ROW_AVAILABLE, 0)
    with pytest.raises(TrajectoryDataError, match="wrong timeline"):
        s4b2.project_domain_prefix(surface=surfs["LIQ"], boundary_key=k)


def test_positional_fabricated_timestamp_rejected():
    market, adapter, _, _, surfs = _surfaces(90)
    fabricated = InformationKey(
        information_key_version=INFORMATION_KEY_VERSION,
        timeline_id="s4b2",
        bar_position=30,
        event_time_utc=pd.Timestamp("2026-01-01", tz="UTC"),
        information_phase=InformationPhase.COMPLETED_ROW_AVAILABLE,
        deterministic_sequence=0,
    )
    with pytest.raises(TrajectoryDataError, match="timestamp"):
        s4b2.project_domain_prefix(surface=surfs["LIQ"], boundary_key=fabricated)


# ---------------------------------------------------------------------------
# §17 state / storage
# ---------------------------------------------------------------------------

def test_input_immutability():
    market, adapter, timeline, struct, _ = _surfaces(90)
    m_before = market.copy(deep=True)
    s_before = struct.frame.copy(deep=True)
    s4b2.build_liquidity_surface(timeline=timeline, adapter=adapter, market_history=market, structure_surface=struct)
    s4b2.build_fvg_surface(timeline=timeline, adapter=adapter, market_history=market)
    pd.testing.assert_frame_equal(market, m_before)
    pd.testing.assert_frame_equal(struct.frame, s_before)


def test_two_hypotheses_share_physical_surface():
    market, adapter, _, _, surfs = _surfaces(90)
    surf = surfs["LIQ"]
    # two different boundaries reference the SAME surface object (no duplication)
    k1 = _key(adapter, market, 30)
    k2 = _key(adapter, market, 60)
    p1 = s4b2.project_domain_prefix(surface=surf, boundary_key=k1)
    p2 = s4b2.project_domain_prefix(surface=surf, boundary_key=k2)
    assert p1.surface_id == p2.surface_id == surf.surface_id
    assert p1.prefix_hash != p2.prefix_hash


def test_no_duplication_in_prefix_binding():
    market, adapter, _, _, surfs = _surfaces(90)
    p = s4b2.project_domain_prefix(surface=surfs["LIQ"], boundary_key=_key(adapter, market, 30))
    for f in dataclasses.fields(p):
        assert not isinstance(getattr(p, f.name), pd.DataFrame), f"{f.name} must not be a DataFrame"


# ---------------------------------------------------------------------------
# §15 numeric / schema
# ---------------------------------------------------------------------------

def test_normalized_entity_is_derived_not_original():
    _, _, _, _, surfs = _surfaces(90)
    # liquidity entity table derives from LEVEL_CREATED rows; columns are only CLOSED-exposed fields
    liq_entity = surfs["LIQ"].normalized_entity_frame
    assert "level_id" in liq_entity.columns
    assert "immutable_level_price" in liq_entity.columns
    # no fabricated fields (e.g. no invented lifecycle state)
    assert "first_touch" not in liq_entity.columns


def test_dealing_range_uses_original_range_table():
    _, _, _, _, surfs = _surfaces(90)
    dr_entity = surfs["DR"].normalized_entity_frame
    assert "range_low" in dr_entity.columns and "range_high" in dr_entity.columns
    assert "midpoint" in dr_entity.columns


# ---------------------------------------------------------------------------
# §18 firewall / out of scope
# ---------------------------------------------------------------------------

def test_firewall_live_modules_do_not_import_stage4b2():
    live_roots = [
        Path("src/trading_system/structure"),
        Path("src/trading_system/zones"),
        Path("src/trading_system/liquidity"),
        Path("src/trading_system/orderflow"),
        Path("src/trading_system/multitimeframe"),
        Path("src/trading_system/decision"),
        Path("src/trading_system/core"),
        Path("src/trading_system/environment"),
    ]
    for root in live_roots:
        if not root.exists():
            continue
        for py_file in root.rglob("*.py"):
            content = py_file.read_text(encoding="utf-8", errors="ignore")
            for forb in ("trajectory_stage4b2", "research.trajectory"):
                assert forb not in content, f"Firewall violation: {py_file} imports {forb}"


def test_stage4b2_no_out_of_scope_implementations():
    path = Path("src/trading_system/research/trajectory/trajectory_stage4b2.py")
    content = path.read_text(encoding="utf-8", errors="ignore")
    forbidden = [
        "def build_htf", "def build_mtf", "def build_descriptor", "def build_estimand",
        "def build_model", "def build_scorer", "def build_geometry", "def build_execution",
        "PROBABILITY", "SCORER",
    ]
    for forb in forbidden:
        assert forb not in content, f"forbidden marker: {forb}"


def test_stage4b2_manifest_declares_out_of_scope_and_open_debts():
    manifest = s4b2.trajectory_stage4b2_manifest()
    assert s4b2.TRAJECTORY_STAGE4B2_CONTRACT_VERSION == "CAUSAL_SHARED_ENTITY_LIFECYCLE_SURFACE_V1"
    vals = dict(zip(manifest["name"], manifest["value"]))
    assert vals["WIN_LOSS"] == "FORBIDDEN"
    assert vals["STAGE4C"] == "NOT_IMPLEMENTED"
    for d in ("RESEARCH-DEBT-020", "RESEARCH-DEBT-021", "RESEARCH-DEBT-022", "RESEARCH-DEBT-023", "RESEARCH-DEBT-024", "RESEARCH-DEBT-025"):
        assert vals.get(d) == "OPEN"
