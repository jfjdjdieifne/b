BTC_MAY2026 COMPLETE MASTER BUNDLE — 2026-09-30
==============================================

CONTENTS (read in this order):

1) BTC_MAY2026_FIELD_PACKAGE/   — SEALLED FIELD RUNNER PACKAGE.
   Byte-identical to deliverable 35 (WINDOWS REPORTING PATCHED).
   = EXACT PERFORMANCE V2 COMPLETE + WINDOWS REPORTING PATCH.
   Verify inside it:  sha256sum -c FILE_INVENTORY.sha256   (expect 238 OK / 0 FAILED)

2) MUF_DESIGN_DOCS/  — MUF-V1 DESIGN CHAIN (design only; NOT code, NOT build-authorized):
   36 MARKET UNDERSTANDING FOUNDATION V1 MASTER DESIGN
   37 FINAL HARDENED DESIGN
   38 FINAL DESIGN PATCH D1
   39 FINAL DESIGN PATCH D2
   40 D2 CORRECTION-1
   41 INDEPENDENT DESIGN AUDIT        (decision: PATCH REQUIRED, 1 blocker)
   42 INDEPENDENT AUDIT PATCH AP-1    (PATCHED - PENDING RE-AUDIT)

3) BUNDLE_CONTENTS.sha256  — inventory of EVERY file in this bundle
   (paths relative to this bundle root). Verify:
   sha256sum -c BUNDLE_CONTENTS.sha256

HOW TO RUN (owner PC, from inside BTC_MAY2026_FIELD_PACKAGE):
   run_btc_may_2026.bat
   One command only. See README_OWNER.txt and PATCH_NOTES_WINDOWS_REPORTING_2026-09-29.txt.

STATUS:
   Field runner : READY FOR OWNER RUN (logs-only verify_manifest; owner is the runner).
   MUF design   : PATCHED - PENDING RE-AUDIT. BUILD NOT AUTHORIZED.
   NB-1..NB-4   : RECORD ONLY (not patched).

