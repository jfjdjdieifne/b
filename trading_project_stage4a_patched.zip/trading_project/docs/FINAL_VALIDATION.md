# Current Authoritative Validation — Through Module 6.2A-4 V1 Stage 3 Closure

## Collected tests

```text
tests/test_absorption.py: 18
tests/test_adaptive_confluence_calibration.py: 27
tests/test_adaptive_confluence_calibration_integration.py: 2
tests/test_causal_adaptive_smoothing.py: 37
tests/test_causal_htf.py: 10
tests/test_causal_percentile.py: 13
tests/test_confluence_matrix.py: 9
tests/test_dealing_range.py: 11
tests/test_dynamic_volatility.py: 20
tests/test_evidence_family_reasoning.py: 34
tests/test_evidence_family_reasoning_integration.py: 1
tests/test_evidence_family_reasoning_v1_1.py: 30
tests/test_evidence_vector.py: 54
tests/test_fvg.py: 11
tests/test_liquidity_map.py: 20
tests/test_narrative.py: 48
tests/test_order_blocks.py: 12
tests/test_research_dataset_builder.py: 22
tests/test_research_dataset_integration.py: 1
tests/test_research_eligibility.py: 25
tests/test_research_eligibility_integration.py: 1
tests/test_research_hashing.py: 14
tests/test_research_information_time.py: 16
tests/test_research_manifest_identity.py: 17
tests/test_research_outcome_integration.py: 2
tests/test_research_outcome_observer.py: 55
tests/test_research_visibility.py: 44
tests/test_session_context.py: 26
tests/test_structural_breaks.py: 25
tests/test_swing_detector.py: 28
tests/test_swing_sequence.py: 31
tests/test_trajectory_contract.py: 18
tests/test_trajectory_stage2.py: 36
tests/test_trajectory_stage3.py: 81
tests/test_volume_delta.py: 19
TOTAL: 818
```

## Exact pytest result

```text
........................................................................ [ 10%]
........................................................................ [ 21%]
........................................................................ [ 31%]
........................................................................ [ 42%]
........................................................................ [ 52%]
........................................................................ [ 63%]
........................................................................ [ 73%]
........................................................................ [ 84%]
........................................................................ [ 94%]
...................................                                      [100%]
```

```text
818 collected
818 passed
exit code 0
```

## Status

```text
Layers 0–5: CLOSED
D1/D1.1: PRELIMINARY SOURCE AUDIT — ACCEPTED / APPLIED
Module 6.1A V1.3: CLOSED
Module 6.1B V1.2: CLOSED
Module 6.2A-0 V1.2: CLOSED
Module 6.2A-1 V1.2: CLOSED
Module 6.2A-2 V1: CLOSED
Module 6.2A-3 V1.1: CLOSED
Module 6.2A-4 V1 Stage 1: CLOSED
Module 6.2A-4 V1 Stage 2: CLOSED
Module 6.2A-4 V1 Stage 3: CLOSED
Module 6.2B-0 V1.2: CLOSED
Module 6.2B-1 V1.1: CLOSED
6.2A-4 Stage 4 trajectory domains (volatility/liquidity/OB/FVG/orderflow/session/HTF/MTF): NOT STARTED
6.2C geometry / 6.2D execution / model / scorer / signals: NOT STARTED
QualificationObjective: NOT DEFINED
```

## Module 6.2B-0 closure boundary

Closure certifies within tested scope:

1. exact hypothesis-creation same-row `InformationKey` boundary;
2. rejection of prior/future rows and future semantic payload before use within the representable parent envelope;
3. exact revalidation of the CLOSED creation snapshot integrity hashes;
4. no current source upgraded to predictive `SUPPORT`;
5. explicit orthogonal semantic states and MTF directional-conflict preservation;
6. separate ACTUAL and PROXY epistemic classes;
7. three-state open-world provenance: certified shared, certified distinct, or not certified;
8. deterministic derivation kept orthogonal to provenance and co-derivation;
9. formula-faithful 6.1A availability lineage with COUNT_SUPPORT excluded from value parents;
10. formula-faithful CLOSED 5.2 MTF DAG without manifest-order inference;
11. no false statistical-independence admission (`included_for_independent_calibration=False` for all current records);
12. final record hash, family semantic hash, global semantic reasoning hash, and exact upstream storage hash separation;
13. canonical source-order-insensitive semantic identity;
14. stateless A→A, A→B→A, fresh-instance, prefix/future-history invariance, and full caller-input immutability;
15. reasoning firewall: no outcomes, model, scorer, geometry, or execution dependencies.

Closure does not certify:

- predictive support or edge;
- statistical independence or incremental predictive information;
- confluence strength or score;
- learned weights or calibration;
- qualification threshold or probability;
- preprocessing, model, estimator, classifier, or scorer;
- entity-level geometry adapter;
- entry, stop, target, fill, execution, or trade lifecycle;
- BUY/SELL signals or PnL/WIN/LOSS;
- overlapping-hypothesis dependence resolution.

## Module 6.2B-1 closure boundary

Closure certifies within tested scope:

1. TRAIN-only descriptive calibration/reference foundation;
2. authoritative CLOSED 6.2A-3 source-fold verification (full fold seal) before any TRAIN projection;
3. canonical TRAIN sample binding through CLOSED `_sample_id`;
4. authoritative B-0 reasoning re-analysis/membership for every admitted sample;
5. exact TRAIN raw feature row binding;
6. TEST/OOS descriptive-content firewall: TEST cannot alter TRAIN calibration content;
7. descriptive empirical CDFs labelled `TRAIN_EMPIRICAL_CDF_NOT_PROBABILITY`;
8. descriptive observation coverage labelled not semantic or predictive SUPPORT;
9. explicit NULL / SIMPLE / FULL baseline and FAMILY_ABLATION admission contracts;
10. chained experiment accounting with an external trusted-head boundary;
11. caller-reported OOS-access accounting explicitly NOT access-control proof;
12. separated source-fold provenance, TRAIN content identity, and final artifact identity;
13. public artifact verification recomputing all component/content/artifact hashes without TEST payload access;
14. ACTUAL/PROXY separation and UNKNOWN/UNAVAILABLE separation with no zero-fill or renormalization;
15. `DEPENDENCE_NOT_RESOLVED` for unresolved overlap/non-IID semantics;
16. no target-conditioned fitting while the objective is undefined.

Closure does not certify:

- predictive edge or predictive SUPPORT;
- feature importance or learned confluence weights;
- a qualification objective or threshold;
- probability or profitability;
- statistical independence or effective independent sample size;
- untouched OOS merely from caller-reported access count;
- geometry, entry/stop/target, execution/fills, signals, or PnL/WIN/LOSS;
- future live performance.

## Module 6.2A-4 Stage 1 closure boundary

Closure certifies within tested scope:

1. shared authenticated `MarketObservationTimeline` foundation with no per-hypothesis market duplication;
2. decision/outcome two-clock semantics: `observation_information_key` may precede `factual_available_at_information_key`, and visibility uses the available-at key;
3. decision anchor contains no future information and no future feature preselection;
4. creation bar excluded from the post-hypothesis path `(decision_batch, end_inclusive]`;
5. FACTUAL_EVENT vs STATE_OBSERVATION distinction, hash-bound;
6. deterministic as-of projection;
7. immutable prior as-of snapshots (later facts create new identities, never rewrite earlier ones);
8. shared timeline storage rather than per-hypothesis market copies;
9. OHLC source-resolution limitations (no intrabar chronology, no tick/L2 claims);
10. integrity sealing explicitly not integrity binding (not issuer authentication);
11. literal terminal lifecycle semantics with no success/profit interpretation;
12. canonical identities/hashing via the project serializer;
13. research/live firewall (no live module imports the trajectory package).

Closure does not certify:

- actual domain trajectory observations (liquidity / OB / FVG / flow / MTF ingestion);
- path descriptors;
- learning estimands;
- predictive edge, probabilities, or any model/scorer;
- geometry, entry/stop/target, execution, or profitability.

## Module 6.2A-4 Stage 2 closure boundary

Closure certifies within tested scope:

1. per-bar favorable/adverse excursion formulas per CLOSED 6.2A-1 orientation;
2. running maximum favorable/adverse with strict-greater tie preservation (first occurrence);
3. SAME_INFORMATION_BATCH_ORDER_UNKNOWN when both extremes in same OHLC bar;
4. close displacement = (close - ref) / ref, bar offset = bar_position - decision_bar_position;
5. new-running-extreme flags, extreme price/position/InformationKey capture;
6. shared timeline architecture preserved (no per-hypothesis market copy);
7. consumed CLOSED 2.1A→2.1B→2.1C structure chain with prefix causality (market_history truncated to interval end);
8. swing origin < confirmation enforced, confirmation is factual-available-at;
9. full taxonomy from CLOSED contracts: SWING, SEQUENCE, BREACH, BREAK, STATE transition;
10. consumed CLOSED 6.1B lifecycle ledger with literal terminal states only: CONTRADICTED, SUPERSEDED, OBSERVED_DIRECTION_ESTABLISHED;
11. no second state machine, no price-inferred terminal;
12. mature interval boundary at terminal factual-availability, unresolved as-of returns empty;
13. SUCCESS/WIN/LOSS/PROFIT rejected as terminal states;
14. two-clock semantics, creation bar exclusion, input immutability, determinism, firewall preserved.

Closure does NOT certify:

- true_range / normalized true range / volatility trajectory;
- liquidity / OB / FVG / dealing range / volume delta / absorption trajectory;
- session / HTF / MTF trajectory;
- censor-series implementation (Stage 3);
- path descriptors, quality, efficiency;
- learning estimands;
- predictive model, scorer, weights, probabilities;
- geometry, entry/stop/target, execution, PnL;
- WIN/LOSS/SUCCESS interpretation.

## Module 6.2A-4 Stage 3 closure boundary

Closure certifies within tested scope:

1. immutable mature terminal snapshot and immutable right-censored-as-of snapshot;
2. append-only as-of snapshot series (strictly increasing research-as-of, prior snapshots unchanged);
3. CLOSED 6.2A-1 as authoritative for mature-vs-censored classification, `factual_outcome_id`,
   `research_snapshot_id`, terminal state, and terminal position;
4. CLOSED Stage 2 as authoritative for the PRICE / STRUCTURE / LIFECYCLE trajectory prefix;
5. complete Stage 2 public-result deterministic-equivalence verification
   (`STAGE2_PUBLIC_RESULT_EQUIVALENCE_V1`) over `price.price_bars` + price final scalars +
   `structure.structure_events` + `lifecycle.lifecycle_events` + lifecycle terminal fields +
   envelope count + envelope prefix hash;
6. envelope-context verification: every supplied and reconstructed envelope proven to belong to
   the expected timeline / timeline_hash / anchor / interval (with CLOSED `envelope.verify()`);
7. separation of terminal factual availability from research as-of (two distinct InformationKeys);
8. compact snapshot identity (hashes/counts only; no raw market, no full envelope tuple, no
   duplicated running payloads);
9. reconstruction / derivation-witness semantics;
10. origin preserved exactly from the supplied Stage 2 artifact's own embedded lifecycle rows
    (Int64 position, not a manufactured InformationKey);
11. literal terminal states only (CONTRADICTED, SUPERSEDED, OBSERVED_DIRECTION_ESTABLISHED);
12. right-censor semantics `RIGHT_CENSORED_AS_OF_BOUNDARY` only, matching CLOSED 6.2A-1;
13. positional and time-indexed timelines (timezone-aware, DST/irregular UTC), cross-timeline
    rejection, same-information-batch determinism;
14. determinism (A→A, A→B→A, fresh-instance), caller-input immutability, frozen snapshots;
15. research/live firewall (no live module imports Stage 3).

Closure does NOT certify:

- the historical generating-input identity of a supplied Stage 2 artifact
  (`reconstruction_swing_policy_hash`, `reconstruction_ledger_seal`,
  `stage2_reconstruction_binding_hash` are derivation witnesses only; generating-input
  provenance remains NOT CERTIFIED / UNVERIFIABLE);
- Stage 4 trajectory domains (volatility / liquidity / OB / FVG / dealing range / orderflow /
  session / HTF / MTF trajectory);
- path descriptors;
- learning estimands;
- hazard / survival model, competing-risk probabilities, or any censor estimand;
- predictive model, scorer, weights, probabilities, confluence scores;
- geometry, entry/stop/target, execution, fills, trade lifecycle;
- PnL, WIN/LOSS/SUCCESS semantics, signals;
- fixed horizons;
- statistical independence or overlapping-hypothesis dependence resolution.

## Important identity boundary

Module 6.2A-3 remains:

```text
module release: V1.1
dataset contract string: CAUSAL_RESEARCH_DATASET_V1
```

This naming mismatch is preserved as an explicit known boundary; it was not silently patched.

## Open research debts

```text
RESEARCH-DEBT-020 — Hypothesis Lifecycle Termination Semantics
RESEARCH-DEBT-021 — Evidence-Bearing Calibration
RESEARCH-DEBT-022 — Entity-Level Narrative Provenance Contract
RESEARCH-DEBT-023 — Outcome Censoring and Competing-Risk Estimand
RESEARCH-DEBT-024 — Overlapping Hypothesis Dependence / Non-IID Samples
RESEARCH-DEBT-025 — Reference-Price and Market-Time Alignment
```

No debt above is claimed solved by closure.
