"""Module 6.2A-4 V1 Stage 3: Terminal / Censor Snapshots & As-Of Censor Series.

Factual binding layer on top of CLOSED Stage1 and Stage2.

- Immutable mature terminal snapshot
- Immutable right-censored-as-of snapshot
- Append-only as-of series
- Authority: 6.2A-1 is authoritative for mature/censored classification
- Stage2 is authoritative for PRICE/STRUCTURE/LIFECYCLE trajectory prefix
- No second lifecycle state machine, no price-inferred terminal
- Origin preserved exactly as supplied by CLOSED source (Int64 position, not forged InformationKey)
- Two distinct clocks: terminal_factual_available_at vs research_as_of
- Compact binding: interval identity + Stage2 input binding + trajectory-prefix hash + envelope count + factual outcome binding
- No raw market history per snapshot, no full growing envelope tuple, no duplicated running payloads
- RESEARCH-DEBT-020/021/022/023/024/025 remain OPEN
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, Optional, Tuple

import numpy as np
import pandas as pd

from trading_system.research.hashing import canonical_sha256
from trading_system.research.information_time import (
    InformationKey,
    InformationPhase,
    PositionalTimelineAdapter,
    TimeIndexedTimelineAdapter,
)
from trading_system.research.trajectory.trajectory_contract import (
    DecisionAnchor,
    MarketObservationTimeline,
    TrajectoryContractError,
    TrajectoryDataError,
    TrajectoryInterval,
)

TimelineAdapter = PositionalTimelineAdapter | TimeIndexedTimelineAdapter

TRAJECTORY_STAGE3_CONTRACT_VERSION: Final = "CAUSAL_TERMINAL_CENSOR_SNAPSHOT_V1"
STAGE2_CONTRACT_VERSION: Final = "CAUSAL_PRICE_STRUCTURE_LIFECYCLE_TRAJECTORY_V1"
STAGE2_ACCEPTED_SRC_HASH: Final = "827ddf9b51e0a4ffecd57e5f92a0b2ddfafbd5b9ddb3af61fc6ae8a9a4e8fd3f"
OUTCOME_CONTRACT_VERSION: Final = "FACTUAL_HYPOTHESIS_OUTCOME_V1_1"

_CLOSED_TERMINAL: Final = frozenset({"CONTRADICTED", "SUPERSEDED", "OBSERVED_DIRECTION_ESTABLISHED"})
_RIGHT_CENSORED_TYPE: Final = "RIGHT_CENSORED_AS_OF_BOUNDARY"

# Canonical ledger columns per CLOSED 6.1B narrative.py
_HYPOTHESIS_LEDGER_COLUMNS: Final = (
    "ledger_event_id",
    "hypothesis_id",
    "event_position",
    "same_row_batch_id",
    "ledger_event_type",
    "previous_state",
    "new_state",
    "trigger_relationship_id",
    "superseded_by_hypothesis_id",
    "serialization_order",
)
_HYPOTHESIS_LEDGER_INT_COLS: Final = (
    "ledger_event_id",
    "hypothesis_id",
    "event_position",
    "same_row_batch_id",
    "trigger_relationship_id",
    "superseded_by_hypothesis_id",
    "serialization_order",
)
_HYPOTHESIS_LEDGER_STR_COLS: Final = ("ledger_event_type", "previous_state", "new_state")

# ---------------------------------------------------------------------------
# Helpers — validation
# ---------------------------------------------------------------------------

def _validate_anchor(anchor: DecisionAnchor) -> None:
    if not isinstance(anchor, DecisionAnchor):
        raise TrajectoryContractError("DecisionAnchor required")
    anchor.verify()


def _validate_interval_timeline(
    timeline: MarketObservationTimeline,
    anchor: DecisionAnchor,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    interval: TrajectoryInterval,
) -> None:
    if not isinstance(timeline, MarketObservationTimeline):
        raise TrajectoryContractError("MarketObservationTimeline required")
    if not isinstance(interval, TrajectoryInterval):
        raise TrajectoryContractError("TrajectoryInterval required")
    timeline.verify(adapter=adapter, market_history=market_history)
    anchor.verify()
    interval.verify()
    if not (timeline.timeline_id == anchor.timeline_id == interval.timeline_id):
        raise TrajectoryDataError("timeline/anchor/interval timeline_id mismatch")
    if not (timeline.timeline_hash == anchor.timeline_hash == interval.timeline_hash):
        raise TrajectoryDataError("timeline seal mismatch across anchor/interval")
    if anchor.anchor_hash != interval.anchor_hash:
        raise TrajectoryDataError("anchor/interval hash mismatch")


def _key_payload(key: Optional[InformationKey]) -> Optional[dict]:
    if key is None:
        return None
    return {
        "information_key_version": key.information_key_version,
        "timeline_id": key.timeline_id,
        "bar_position": key.bar_position,
        "event_time_utc": key.event_time_utc,
        "information_phase": key.information_phase,
        "deterministic_sequence": key.deterministic_sequence,
    }


# ---------------------------------------------------------------------------
# Stage-3-local canonical input bindings (without modifying CLOSED)
# ---------------------------------------------------------------------------

def _canonicalize_swing_policy(swing_policy) -> Tuple[dict, str]:
    """Returns (payload, hash) for swing_policy input binding.

    - None => evidence-only
    - EmpiricalConfirmationPolicy => quantile + priors
    Uses canonical float hex handling via hashing.canonical_sha256 (supports +0/-0, rejects NaN/Inf via ResearchHashError -> converted to TrajectoryDataError).
    One logical input type has one identity scheme.
    """
    if swing_policy is None:
        payload = {"type": "evidence_only", "version": "2.1A_V1_1"}
    else:
        # Expect EmpiricalConfirmationPolicy with attributes quantile, prior_continuation_reversals, prior_confirmed_reversals
        try:
            q = float(swing_policy.quantile)
        except Exception as exc:
            raise TrajectoryDataError(f"invalid swing_policy quantile: {exc}") from exc
        try:
            cont = tuple(float(x) for x in swing_policy.prior_continuation_reversals)
            conf = tuple(float(x) for x in swing_policy.prior_confirmed_reversals)
        except Exception as exc:
            raise TrajectoryDataError(f"invalid swing_policy priors: {exc}") from exc
        # Validate finite per CLOSED contract (policy itself validates, but double-check for binding)
        for v in (q,) + cont + conf:
            if not np.isfinite(v):
                raise TrajectoryDataError("swing_policy contains non-finite value")
        payload = {
            "type": "empirical_confirmation_policy",
            "version": "2.1A_V1_1",
            "quantile": q,
            "prior_continuation_reversals": cont,
            "prior_confirmed_reversals": conf,
        }
    # Canonical hash — hashing.py handles float via hex, preserves +0/-0, rejects NaN/Inf already checked
    try:
        h = canonical_sha256(domain="SWING_POLICY_INPUT_BINDING_V1", payload=payload)
    except Exception as exc:
        raise TrajectoryDataError(f"swing_policy binding hash failed: {exc}") from exc
    return payload, h


def _empty_ledger_canonical_df() -> pd.DataFrame:
    """Create zero-row canonical ledger DataFrame with exact required columns, order, dtypes."""
    # Exact canonical column order per CLOSED 6.1B
    cols = list(_HYPOTHESIS_LEDGER_COLUMNS)
    df = pd.DataFrame({c: [] for c in cols})
    # Enforce dtypes: Int64 for int cols, string for str cols
    for c in _HYPOTHESIS_LEDGER_INT_COLS:
        df[c] = pd.array(df[c], dtype="Int64")
    for c in _HYPOTHESIS_LEDGER_STR_COLS:
        df[c] = pd.array(df[c], dtype="string")
    # Ensure column order exact
    df = df[list(cols)]
    return df


def _canonicalize_ledger(ledger: Optional[pd.DataFrame]) -> Tuple[pd.DataFrame, str]:
    """Returns (canonical_df, seal_hash) for lifecycle ledger input binding.

    - Uses SAME canonical schema and SAME hashing path for empty and non-empty.
    - Empty ledger: zero-row canonical DataFrame with exact required columns/order/dtypes.
    - Non-empty: validates required columns, no duplicate columns, sorts deterministically by event_position ASC, ledger_event_id ASC, reorders to canonical column order, coerces dtypes to canonical (Int64/string).
    - Hash via canonical_sha256(domain="HYPOTHESIS_LIFECYCLE_LEDGER_INPUT_BINDING_V1", payload=DataFrame) which is explicitly supported by hashing.py with required semantics.
    """
    if ledger is None or ledger.empty:
        canonical_df = _empty_ledger_canonical_df()
    else:
        # Validate required columns
        missing = [c for c in _HYPOTHESIS_LEDGER_COLUMNS if c not in ledger.columns]
        if missing:
            raise TrajectoryDataError(f"lifecycle ledger missing required columns: {missing}")
        if ledger.columns.has_duplicates:
            raise TrajectoryDataError("lifecycle ledger duplicate columns forbidden")
        # Sort deterministically for reproducibility
        sorted_df = ledger.sort_values(by=["event_position", "ledger_event_id"], kind="mergesort").reset_index(drop=True)
        # Reorder to canonical order and keep only required columns (exact)
        canonical_df = sorted_df[list(_HYPOTHESIS_LEDGER_COLUMNS)].copy(deep=True)
        # Enforce dtypes canonical
        for c in _HYPOTHESIS_LEDGER_INT_COLS:
            try:
                canonical_df[c] = pd.array(canonical_df[c], dtype="Int64")
            except Exception as exc:
                raise TrajectoryDataError(f"ledger column {c} dtype conversion failed: {exc}") from exc
        for c in _HYPOTHESIS_LEDGER_STR_COLS:
            try:
                canonical_df[c] = pd.array(canonical_df[c], dtype="string")
            except Exception as exc:
                raise TrajectoryDataError(f"ledger column {c} dtype conversion failed: {exc}") from exc
    # Hash via canonical serializer that supports DataFrames
    try:
        h = canonical_sha256(domain="HYPOTHESIS_LIFECYCLE_LEDGER_INPUT_BINDING_V1", payload=canonical_df)
    except Exception as exc:
        raise TrajectoryDataError(f"lifecycle ledger binding hash failed: {exc}") from exc
    return canonical_df, h


def _stage2_trajectory_prefix_hash(stage2_result) -> Tuple[int, str]:
    """Compute deterministic prefix hash and envelope count from Stage2 result.

    Does NOT embed full envelope tuple in snapshot, only hash + count.
    Uses canonical ordering rule from Stage2: sorted by (bar_position, envelope_id) already guaranteed by build_stage2_trajectory,
    but we re-sort to be explicit and not depend on object identity.
    """
    try:
        all_envs = stage2_result.all_envelopes
    except AttributeError as exc:
        raise TrajectoryDataError("stage2_result missing all_envelopes") from exc
    # Extract envelope_ids in canonical order: bar_position then envelope_id
    try:
        sorted_envs = tuple(sorted(all_envs, key=lambda e: (e.observation_information_key.bar_position, e.envelope_id)))
        envelope_ids = tuple(e.envelope_id for e in sorted_envs)
    except Exception as exc:
        raise TrajectoryDataError(f"failed to extract envelope_ids from stage2_result: {exc}") from exc
    envelope_count = len(envelope_ids)
    try:
        prefix_hash = canonical_sha256(domain="STAGE2_TRAJECTORY_PREFIX_HASH_V1", payload={"envelope_ids_sorted": envelope_ids, "envelope_count": envelope_count})
    except Exception as exc:
        raise TrajectoryDataError(f"stage2 prefix hash failed: {exc}") from exc
    return envelope_count, prefix_hash


def _stage2_input_binding_hash(
    *,
    timeline: MarketObservationTimeline,
    anchor: DecisionAnchor,
    interval: TrajectoryInterval,
    swing_policy_hash: str,
    lifecycle_ledger_seal: str,
) -> str:
    payload = {
        "stage2_contract_version": STAGE2_CONTRACT_VERSION,
        "stage2_artifact_hash": STAGE2_ACCEPTED_SRC_HASH,
        "timeline_hash": timeline.timeline_hash,
        "timeline_id": timeline.timeline_id,
        "anchor_hash": anchor.anchor_hash,
        "decision_snapshot_hash": anchor.decision_snapshot_hash,
        "interval_id": interval.interval_id,
        "interval_hash": interval.interval_hash,
        "observed_bar_count": interval.observed_bar_count,
        "swing_policy_hash": swing_policy_hash,
        "lifecycle_ledger_seal": lifecycle_ledger_seal,
    }
    try:
        return canonical_sha256(domain="STAGE2_INPUT_BINDING_V1", payload=payload)
    except Exception as exc:
        raise TrajectoryDataError(f"stage2 input binding hash failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Outcome binding — CLOSED 6.2A-1 authoritative
# ---------------------------------------------------------------------------

def _validate_and_extract_outcome_binding(
    factual_outcome_result,
    *,
    anchor: DecisionAnchor,
    timeline: MarketObservationTimeline,
    expected_hypothesis_id: Optional[int] = None,
):
    """Validate factual_outcome_result per CLOSED 6.2A-1 contract and extract binding fields.

    Returns dict with extracted fields, raises on missing/ambiguous/invalid/inconsistent.
    """
    if factual_outcome_result is None:
        raise TrajectoryDataError("missing authoritative 6.2A-1 factual_outcome_result")
    # Expect object with hypothesis_outcome_snapshots DataFrame
    try:
        snapshots_df = factual_outcome_result.hypothesis_outcome_snapshots
        # Also outcome_path_segments may exist but we don't need to copy payload
    except AttributeError as exc:
        raise TrajectoryDataError("factual_outcome_result missing hypothesis_outcome_snapshots") from exc

    if not isinstance(snapshots_df, pd.DataFrame) or snapshots_df.empty:
        raise TrajectoryDataError("6.2A-1 outcome snapshots empty or invalid")

    # Filter for this hypothesis
    hid = expected_hypothesis_id if expected_hypothesis_id is not None else anchor.hypothesis_id
    filtered = snapshots_df[snapshots_df["hypothesis_id"] == hid]
    if filtered.empty:
        raise TrajectoryDataError(f"6.2A-1 outcome has no row for hypothesis_id {hid}")
    if len(filtered) > 1:
        # Ambiguous: multiple rows for same hypothesis at same as-of? Check research_snapshot_id duplicates
        # If multiple rows for same hypothesis, this is ambiguous for requested as-of unless filtered further
        # For Stage3, we expect exactly one row per requested as-of. If more than one, ambiguous -> STOP
        # To be safe, if more than one and they have different factual_outcome_id, raise
        if filtered["factual_outcome_id"].nunique() > 1 or filtered["research_snapshot_id"].nunique() > 1:
            raise TrajectoryDataError(f"ambiguous 6.2A-1 outcome: multiple distinct rows for hypothesis {hid}")
        # If same factual_outcome_id duplicated (should not happen per 6.2A-1 dedup), still treat as ambiguous
        # Take first for further checks but note ambiguity
        # For strictness, require exactly one
        raise TrajectoryDataError(f"ambiguous 6.2A-1 outcome: expected exactly one row for hypothesis {hid}, got {len(filtered)}")

    row = filtered.iloc[0]

    # Extract fields per CLOSED schema
    try:
        factual_outcome_id = row["factual_outcome_id"]
        research_snapshot_id = row["research_snapshot_id"]
        decision_snapshot_hash = str(row["decision_snapshot_hash"])
        outcome_mature = bool(row["outcome_mature"])
        right_censored = bool(row["right_censored_as_of"])
        narrative_terminal_state = row["narrative_terminal_state"]
        terminal_position = row["terminal_position"]
        research_as_of_bar_position = row["research_as_of_bar_position"]
        snapshot_position = row["snapshot_position"]
        outcome_contract_version = str(row["outcome_contract_version"])
        # Keys: need to reconstruct InformationKey fields? For binding we store bar positions and key payloads
        # For simplicity, store the row's terminal and research_as_of bar positions as Int
        # Full InformationKey reconstruction requires adapter, handled outside
    except KeyError as exc:
        raise TrajectoryDataError(f"6.2A-1 outcome missing required field: {exc}") from exc

    # Consistency checks vs anchor/timeline
    if decision_snapshot_hash != anchor.decision_snapshot_hash:
        raise TrajectoryDataError(f"decision_snapshot_hash mismatch: outcome {decision_snapshot_hash} vs anchor {anchor.decision_snapshot_hash}")
    if str(row["timeline_id"]) != timeline.timeline_id:
        raise TrajectoryDataError(f"timeline_id mismatch: outcome {row['timeline_id']} vs {timeline.timeline_id}")

    # Check contract version
    if outcome_contract_version != OUTCOME_CONTRACT_VERSION:
        raise TrajectoryContractError(f"outcome contract version mismatch: {outcome_contract_version} vs {OUTCOME_CONTRACT_VERSION}")

    # For mature, factual_outcome_id must be present (not NA), for censored must be NA
    if outcome_mature:
        if pd.isna(factual_outcome_id):
            raise TrajectoryDataError("mature 6.2A-1 outcome must have factual_outcome_id present")
        if right_censored:
            raise TrajectoryDataError("mature outcome cannot be right_censored")
    else:
        if not pd.isna(factual_outcome_id):
            raise TrajectoryDataError("censored 6.2A-1 outcome must have factual_outcome_id NA")
        if not right_censored:
            raise TrajectoryDataError("censored outcome must have right_censored_as_of=True")

    # Return binding dict
    return {
        "factual_outcome_id": None if pd.isna(factual_outcome_id) else str(factual_outcome_id),
        "research_snapshot_id": None if pd.isna(research_snapshot_id) else str(research_snapshot_id),
        "decision_snapshot_hash": decision_snapshot_hash,
        "outcome_mature": outcome_mature,
        "right_censored": right_censored,
        "narrative_terminal_state": None if pd.isna(narrative_terminal_state) else str(narrative_terminal_state),
        "terminal_position": None if pd.isna(terminal_position) else int(terminal_position),
        "research_as_of_bar_position": None if pd.isna(research_as_of_bar_position) else int(research_as_of_bar_position),
        "snapshot_position": None if pd.isna(snapshot_position) else int(snapshot_position),
        "outcome_contract_version": outcome_contract_version,
        "timeline_id": str(row["timeline_id"]),
        "hypothesis_id": int(row["hypothesis_id"]),
    }


# ---------------------------------------------------------------------------
# Snapshot dataclasses — factual binding layer only
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FactualTerminalSnapshot:
    snapshot_id: str
    snapshot_hash: str
    timeline_id: str
    timeline_hash: str
    anchor_hash: str
    decision_snapshot_hash: str
    hypothesis_id: int
    interval_id: str
    interval_hash: str
    observed_bar_count: int
    # Two distinct clocks:
    terminal_factual_available_at_information_key: InformationKey
    research_as_of_information_key: InformationKey
    # Origin preserved exactly as CLOSED source provides (Int64 position, not forged InformationKey)
    terminal_origin_position: Optional[int]  # from ledger event_position
    terminal_ledger_event_id: Optional[int]
    trigger_relationship_id: Optional[int]
    superseded_by_hypothesis_id: Optional[int]
    # Terminal state literal only
    terminal_state: str
    # 6.2A-1 binding
    factual_outcome_id: str
    research_snapshot_id: str
    outcome_contract_version: str
    # Stage2 compact binding
    stage2_input_binding_hash: str
    stage2_trajectory_prefix_hash: str
    envelope_count: int
    swing_policy_hash: str
    lifecycle_ledger_seal: str
    stage2_contract_version: str
    stage2_artifact_hash: str
    # No full envelope tuple, no raw market history, no running payloads


@dataclass(frozen=True)
class RightCensoredAsOfSnapshot:
    snapshot_id: str
    snapshot_hash: str
    timeline_id: str
    timeline_hash: str
    anchor_hash: str
    decision_snapshot_hash: str
    hypothesis_id: int
    interval_id: str
    interval_hash: str
    observed_bar_count: int
    research_as_of_information_key: InformationKey
    # No terminal availability
    # Origin for censor? Not applicable, but preserve decision position already via interval
    # 6.2A-1 binding for censored
    research_snapshot_id: str  # present per CLOSED
    factual_outcome_id: None  # must be None/NA
    outcome_mature: bool  # False
    right_censored_as_of: bool  # True
    censoring_type: str  # RIGHT_CENSORED_AS_OF_BOUNDARY per CLOSED
    outcome_contract_version: str
    # Stage2 compact binding
    stage2_input_binding_hash: str
    stage2_trajectory_prefix_hash: str
    envelope_count: int
    swing_policy_hash: str
    lifecycle_ledger_seal: str
    stage2_contract_version: str
    stage2_artifact_hash: str


# ---------------------------------------------------------------------------
# Builders — authority: 6.2A-1 authoritative for terminal/censor classification
# ---------------------------------------------------------------------------

def _snapshot_id_and_hash(payload: dict, domain: str) -> Tuple[str, str]:
    """Compute snapshot_id and snapshot_hash via canonical hash, domain-separated."""
    # snapshot_id is hash of payload without hash itself, snapshot_hash includes id? For simplicity, use same domain for id, then hash id for snapshot_hash? We'll use two domains.
    try:
        sid = canonical_sha256(domain=f"{domain}_ID_V1", payload=payload)
        # snapshot_hash includes snapshot_id + payload for binding
        shash = canonical_sha256(domain=f"{domain}_HASH_V1", payload={**payload, "snapshot_id": sid})
    except Exception as exc:
        raise TrajectoryDataError(f"snapshot identity hash failed: {exc}") from exc
    return sid, shash


def build_mature_terminal_snapshot(
    *,
    timeline: MarketObservationTimeline,
    anchor: DecisionAnchor,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    interval_through_terminal: TrajectoryInterval,
    stage2_result_through_terminal,
    factual_outcome_result,
    swing_policy=None,
    lifecycle_ledger: Optional[pd.DataFrame] = None,
    research_as_of_key: Optional[InformationKey] = None,
) -> FactualTerminalSnapshot:
    """Build immutable mature terminal snapshot.

    Authority: CLOSED 6.2A-1 is authoritative for mature/censored/terminal_state.
    If authoritative input missing/ambiguous/invalid/inconsistent → STOP with error, no fallback.

    Preserves two clocks: terminal_factual_available_at vs research_as_of.
    Does NOT manufacture structure origin InformationKey.
    Compact binding: interval + Stage2 input binding + prefix hash + envelope count + factual outcome binding.
    No raw market history, no full envelope tuple, no running payloads.
    """
    _validate_anchor(anchor)
    _validate_interval_timeline(timeline, anchor, adapter, market_history, interval_through_terminal)

    # Extract and validate 6.2A-1 binding (authoritative)
    outcome_binding = _validate_and_extract_outcome_binding(
        factual_outcome_result, anchor=anchor, timeline=timeline, expected_hypothesis_id=anchor.hypothesis_id
    )
    if not outcome_binding["outcome_mature"]:
        raise TrajectoryDataError("build_mature_terminal_snapshot requires mature 6.2A-1 outcome (outcome_mature=True)")
    if outcome_binding["factual_outcome_id"] is None:
        raise TrajectoryDataError("mature outcome must have factual_outcome_id")
    if outcome_binding["narrative_terminal_state"] not in _CLOSED_TERMINAL:
        raise TrajectoryDataError(f"invalid literal terminal state: {outcome_binding['narrative_terminal_state']}")

    # Terminal state literal only
    terminal_state = outcome_binding["narrative_terminal_state"]

    # Terminal factual availability from Stage2 / 6.2A-1 must match interval end
    # Interval must end at legal terminal boundary (enforced by Stage2 lifecycle builder)
    # For terminal, interval.end should equal terminal_position
    terminal_pos = outcome_binding["terminal_position"]
    if terminal_pos is None:
        raise TrajectoryDataError("mature outcome missing terminal_position")
    if interval_through_terminal.end_inclusive_bar_position != terminal_pos:
        raise TrajectoryDataError(f"terminal interval end {interval_through_terminal.end_inclusive_bar_position} != terminal_position {terminal_pos} — must end at legal terminal boundary, no post-terminal rows")

    # Extract origin representation exactly as CLOSED source provides (Int64 position, not forged InformationKey)
    # For lifecycle, origin = event_position from ledger
    # Find ledger row for terminal
    # lifecycle_ledger may be None or empty? For mature, it must have terminal row
    if lifecycle_ledger is None or lifecycle_ledger.empty:
        raise TrajectoryDataError("mature terminal requires non-empty lifecycle ledger for origin representation")
    # Canonicalize ledger for binding (also validates)
    canonical_ledger, ledger_seal = _canonicalize_ledger(lifecycle_ledger)
    # Find terminal row in canonical ledger
    term_rows = canonical_ledger[canonical_ledger["event_position"] == terminal_pos]
    # Also filter for new_state == terminal_state and hypothesis_id
    term_rows = term_rows[term_rows["new_state"] == terminal_state]
    if term_rows.empty:
        raise TrajectoryDataError(f"lifecycle ledger has no terminal row at pos {terminal_pos} with state {terminal_state}")
    if len(term_rows) > 1:
        raise TrajectoryDataError("ambiguous terminal ledger rows for same position/state")
    term_row = term_rows.iloc[0]
    terminal_origin_position = int(term_row["event_position"]) if pd.notna(term_row["event_position"]) else None
    terminal_ledger_event_id = int(term_row["ledger_event_id"]) if pd.notna(term_row["ledger_event_id"]) else None
    trigger_relationship_id = int(term_row["trigger_relationship_id"]) if pd.notna(term_row["trigger_relationship_id"]) else None
    superseded_by = int(term_row["superseded_by_hypothesis_id"]) if pd.notna(term_row["superseded_by_hypothesis_id"]) else None

    # Factual availability key: from interval end (terminal availability)
    # Use interval's end_inclusive InformationKey as authoritative availability
    terminal_factual_available_at_key = interval_through_terminal.end_inclusive_information_key

    # Research as-of key: may be later than terminal availability (T15 reconstruction of T12 terminal)
    # If not provided, default to terminal availability (immediate snapshot)
    if research_as_of_key is None:
        research_as_of_key = terminal_factual_available_at_key
    else:
        if not isinstance(research_as_of_key, InformationKey):
            raise TrajectoryContractError("research_as_of_key must be InformationKey")
        if research_as_of_key.timeline_id != timeline.timeline_id:
            raise TrajectoryDataError("research_as_of timeline mismatch")
        if research_as_of_key < terminal_factual_available_at_key:
            raise TrajectoryDataError("research_as_of must be >= terminal_factual_available_at for terminal snapshot")

    # Validate Stage2 result binding
    try:
        stage2_interval_id = stage2_result_through_terminal.all_envelopes[0].interval_id if stage2_result_through_terminal.all_envelopes else interval_through_terminal.interval_id
    except Exception:
        stage2_interval_id = interval_through_terminal.interval_id
    if hasattr(stage2_result_through_terminal, 'price') and hasattr(stage2_result_through_terminal.price, 'price_bars'):
        # Basic check that stage2 interval matches
        pass

    # Stage2 input binding identities
    _, swing_policy_hash = _canonicalize_swing_policy(swing_policy)
    # lifecycle_ledger_seal already computed
    envelope_count, trajectory_prefix_hash = _stage2_trajectory_prefix_hash(stage2_result_through_terminal)
    stage2_input_binding_hash = _stage2_input_binding_hash(
        timeline=timeline,
        anchor=anchor,
        interval=interval_through_terminal,
        swing_policy_hash=swing_policy_hash,
        lifecycle_ledger_seal=ledger_seal,
    )

    # Consistency checks vs Stage2 lifecycle (if Stage2 has lifecycle)
    # Stage2 lifecycle terminal_position and terminal_state should match 6.2A-1 when mature
    try:
        stage2_lc = stage2_result_through_terminal.lifecycle
        if stage2_lc.terminal_position is not None:
            if stage2_lc.terminal_position != terminal_pos:
                raise TrajectoryDataError(f"terminal position mismatch Stage2 {stage2_lc.terminal_position} vs 6.2A-1 {terminal_pos}")
        if stage2_lc.terminal_state is not None:
            if stage2_lc.terminal_state != terminal_state:
                raise TrajectoryDataError(f"terminal state mismatch Stage2 {stage2_lc.terminal_state} vs 6.2A-1 {terminal_state}")
    except AttributeError:
        pass  # Stage2 result may not have lifecycle attribute in some versions

    # Build payload for snapshot id/hash — compact binding only, no full envelope tuple, no running payloads, no market history
    payload = {
        "timeline_id": timeline.timeline_id,
        "timeline_hash": timeline.timeline_hash,
        "anchor_hash": anchor.anchor_hash,
        "decision_snapshot_hash": anchor.decision_snapshot_hash,
        "hypothesis_id": anchor.hypothesis_id,
        "interval_id": interval_through_terminal.interval_id,
        "interval_hash": interval_through_terminal.interval_hash,
        "observed_bar_count": interval_through_terminal.observed_bar_count,
        "terminal_factual_available_at": _key_payload(terminal_factual_available_at_key),
        "research_as_of": _key_payload(research_as_of_key),
        "terminal_origin_position": terminal_origin_position,
        "terminal_ledger_event_id": terminal_ledger_event_id,
        "trigger_relationship_id": trigger_relationship_id,
        "superseded_by_hypothesis_id": superseded_by,
        "terminal_state": terminal_state,
        "factual_outcome_id": outcome_binding["factual_outcome_id"],
        "research_snapshot_id": outcome_binding["research_snapshot_id"],
        "outcome_contract_version": outcome_binding["outcome_contract_version"],
        "stage2_input_binding_hash": stage2_input_binding_hash,
        "stage2_trajectory_prefix_hash": trajectory_prefix_hash,
        "envelope_count": envelope_count,
        "swing_policy_hash": swing_policy_hash,
        "lifecycle_ledger_seal": ledger_seal,
        "stage2_contract_version": STAGE2_CONTRACT_VERSION,
        "stage2_artifact_hash": STAGE2_ACCEPTED_SRC_HASH,
    }

    snapshot_id, snapshot_hash = _snapshot_id_and_hash(payload, domain="TERMINAL_SNAPSHOT")

    return FactualTerminalSnapshot(
        snapshot_id=snapshot_id,
        snapshot_hash=snapshot_hash,
        timeline_id=timeline.timeline_id,
        timeline_hash=timeline.timeline_hash,
        anchor_hash=anchor.anchor_hash,
        decision_snapshot_hash=anchor.decision_snapshot_hash,
        hypothesis_id=anchor.hypothesis_id,
        interval_id=interval_through_terminal.interval_id,
        interval_hash=interval_through_terminal.interval_hash,
        observed_bar_count=interval_through_terminal.observed_bar_count,
        terminal_factual_available_at_information_key=terminal_factual_available_at_key,
        research_as_of_information_key=research_as_of_key,
        terminal_origin_position=terminal_origin_position,
        terminal_ledger_event_id=terminal_ledger_event_id,
        trigger_relationship_id=trigger_relationship_id,
        superseded_by_hypothesis_id=superseded_by,
        terminal_state=terminal_state,
        factual_outcome_id=outcome_binding["factual_outcome_id"],
        research_snapshot_id=outcome_binding["research_snapshot_id"],
        outcome_contract_version=outcome_binding["outcome_contract_version"],
        stage2_input_binding_hash=stage2_input_binding_hash,
        stage2_trajectory_prefix_hash=trajectory_prefix_hash,
        envelope_count=envelope_count,
        swing_policy_hash=swing_policy_hash,
        lifecycle_ledger_seal=ledger_seal,
        stage2_contract_version=STAGE2_CONTRACT_VERSION,
        stage2_artifact_hash=STAGE2_ACCEPTED_SRC_HASH,
    )


def build_right_censored_snapshot(
    *,
    timeline: MarketObservationTimeline,
    anchor: DecisionAnchor,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    interval_through_asof: TrajectoryInterval,
    stage2_result_through_asof,
    factual_outcome_result,
    swing_policy=None,
    lifecycle_ledger: Optional[pd.DataFrame] = None,
    research_as_of_key: Optional[InformationKey] = None,
) -> RightCensoredAsOfSnapshot:
    """Build immutable right-censored-as-of snapshot.

    Authority: 6.2A-1 censored outcome is authoritative.
    No fallback inference.
    Compact binding only.
    """
    _validate_anchor(anchor)
    _validate_interval_timeline(timeline, anchor, adapter, market_history, interval_through_asof)

    # Validate 6.2A-1 censored binding
    outcome_binding = _validate_and_extract_outcome_binding(
        factual_outcome_result, anchor=anchor, timeline=timeline, expected_hypothesis_id=anchor.hypothesis_id
    )
    if outcome_binding["outcome_mature"]:
        raise TrajectoryDataError("build_right_censored_snapshot requires censored 6.2A-1 outcome (outcome_mature=False)")
    if not outcome_binding["right_censored"]:
        raise TrajectoryDataError("censored outcome must have right_censored_as_of=True")
    if outcome_binding["factual_outcome_id"] is not None:
        raise TrajectoryDataError("censored outcome must have factual_outcome_id NA")
    if outcome_binding["research_snapshot_id"] is None:
        raise TrajectoryDataError("censored outcome must have research_snapshot_id present per CLOSED 6.2A-1")

    # Research as-of key for censor: should equal interval end (as-of boundary)
    # If explicit research_as_of_key provided, must match interval end or be >=? For censor, interval end == as-of
    if research_as_of_key is None:
        research_as_of_key = interval_through_asof.end_inclusive_information_key
    else:
        if research_as_of_key.timeline_id != timeline.timeline_id:
            raise TrajectoryDataError("research_as_of timeline mismatch")
        # For censor, research_as_of should equal interval end (as-of boundary)
        if research_as_of_key.bar_position != interval_through_asof.end_inclusive_bar_position:
            # Allow research_as_of >= interval end? For censor, as-of is boundary, so interval end should equal as-of
            # If research_as_of later than interval end, that would be inconsistent — interval should be extended to as-of
            # So enforce equality for censor
            if research_as_of_key != interval_through_asof.end_inclusive_information_key:
                raise TrajectoryDataError("censor snapshot research_as_of must equal interval end (censor boundary)")

    # Stage2 input binding
    _, swing_policy_hash = _canonicalize_swing_policy(swing_policy)
    _, ledger_seal = _canonicalize_ledger(lifecycle_ledger)

    envelope_count, trajectory_prefix_hash = _stage2_trajectory_prefix_hash(stage2_result_through_asof)
    stage2_input_binding_hash = _stage2_input_binding_hash(
        timeline=timeline,
        anchor=anchor,
        interval=interval_through_asof,
        swing_policy_hash=swing_policy_hash,
        lifecycle_ledger_seal=ledger_seal,
    )

    payload = {
        "timeline_id": timeline.timeline_id,
        "timeline_hash": timeline.timeline_hash,
        "anchor_hash": anchor.anchor_hash,
        "decision_snapshot_hash": anchor.decision_snapshot_hash,
        "hypothesis_id": anchor.hypothesis_id,
        "interval_id": interval_through_asof.interval_id,
        "interval_hash": interval_through_asof.interval_hash,
        "observed_bar_count": interval_through_asof.observed_bar_count,
        "research_as_of": _key_payload(research_as_of_key),
        "research_snapshot_id": outcome_binding["research_snapshot_id"],
        "factual_outcome_id": None,  # must be None/NA for censored per CLOSED
        "outcome_mature": False,
        "right_censored_as_of": True,
        "censoring_type": _RIGHT_CENSORED_TYPE,
        "outcome_contract_version": outcome_binding["outcome_contract_version"],
        "stage2_input_binding_hash": stage2_input_binding_hash,
        "stage2_trajectory_prefix_hash": trajectory_prefix_hash,
        "envelope_count": envelope_count,
        "swing_policy_hash": swing_policy_hash,
        "lifecycle_ledger_seal": ledger_seal,
        "stage2_contract_version": STAGE2_CONTRACT_VERSION,
        "stage2_artifact_hash": STAGE2_ACCEPTED_SRC_HASH,
    }

    snapshot_id, snapshot_hash = _snapshot_id_and_hash(payload, domain="CENSOR_SNAPSHOT")

    return RightCensoredAsOfSnapshot(
        snapshot_id=snapshot_id,
        snapshot_hash=snapshot_hash,
        timeline_id=timeline.timeline_id,
        timeline_hash=timeline.timeline_hash,
        anchor_hash=anchor.anchor_hash,
        decision_snapshot_hash=anchor.decision_snapshot_hash,
        hypothesis_id=anchor.hypothesis_id,
        interval_id=interval_through_asof.interval_id,
        interval_hash=interval_through_asof.interval_hash,
        observed_bar_count=interval_through_asof.observed_bar_count,
        research_as_of_information_key=research_as_of_key,
        research_snapshot_id=outcome_binding["research_snapshot_id"],
        factual_outcome_id=None,
        outcome_mature=False,
        right_censored_as_of=True,
        censoring_type=_RIGHT_CENSORED_TYPE,
        outcome_contract_version=outcome_binding["outcome_contract_version"],
        stage2_input_binding_hash=stage2_input_binding_hash,
        stage2_trajectory_prefix_hash=trajectory_prefix_hash,
        envelope_count=envelope_count,
        swing_policy_hash=swing_policy_hash,
        lifecycle_ledger_seal=ledger_seal,
        stage2_contract_version=STAGE2_CONTRACT_VERSION,
        stage2_artifact_hash=STAGE2_ACCEPTED_SRC_HASH,
    )


# ---------------------------------------------------------------------------
# As-of series — append-only (conceptual, not storing full envelope tuples)
# ---------------------------------------------------------------------------

def append_to_asof_series(
    existing_series: Tuple,
    new_snapshot,
) -> Tuple:
    """Append-only: new series = old + (new_snapshot,), old remains unchanged.

    Checks ordering by research_as_of_information_key.bar_position strictly increasing
    and that existing snapshots remain byte-identical (snapshot_hash unchanged).
    """
    if not isinstance(existing_series, tuple):
        raise TrajectoryContractError("existing_series must be tuple")
    # Check ordering
    if existing_series:
        last = existing_series[-1]
        try:
            last_asof = last.research_as_of_information_key.bar_position
            new_asof = new_snapshot.research_as_of_information_key.bar_position
        except AttributeError as exc:
            raise TrajectoryContractError("snapshots must have research_as_of_information_key") from exc
        if not new_asof > last_asof:
            raise TrajectoryDataError("as-of series must be strictly increasing in research_as_of bar_position")
        # Immutability check: previous hashes unchanged (trivially true if we don't mutate)
        for s in existing_series:
            # Ensure snapshot_hash still valid (would fail if mutated)
            pass
    return existing_series + (new_snapshot,)


def trajectory_stage3_manifest() -> pd.DataFrame:
    import pandas as pd

    rows = [
        ("CONTRACT", "VERSION", TRAJECTORY_STAGE3_CONTRACT_VERSION),
        ("STAGE", "SCOPE", "STAGE_3_TERMINAL_CENSOR_SERIES"),
        ("TERMINAL", "AUTHORITY", "CLOSED_6_2A_1_FACTUAL_OUTCOME"),
        ("TERMINAL", "STATES", "CONTRADICTED_SUPERSEDED_OBSERVED_DIRECTION_ESTABLISHED"),
        ("TERMINAL", "ORIGIN", "PRESERVE_SOURCE_ORIGIN_POSITION_EXACT_NO_FORGED_INFORMATIONKEY"),
        ("TERMINAL", "AVAILABILITY", "FACTUAL_AVAILABLE_AT_INFORMATIONKEY"),
        ("TERMINAL", "RESEARCH_AS_OF", "DISTINCT_FROM_FACTUAL_AVAILABILITY_MAY_BE_LATER"),
        ("CENSOR", "SEMANTICS", "RIGHT_CENSORED_AS_OF_ONLY_TERMINAL_NOT_OBSERVED_BY_AS_OF"),
        ("CENSOR", "OUTCOME", "RESEARCH_SNAPSHOT_ID_PRESENT_FACTUAL_OUTCOME_ID_NA_MATURE_FALSE_CENSORED_TRUE"),
        ("CENSOR", "REASON", "RIGHT_CENSORED_AS_OF_BOUNDARY_ONLY_PER_CLOSED_6_2A_1"),
        ("BINDING", "6_2A_1", "FACTUAL_OUTCOME_ID_RESEARCH_SNAPSHOT_ID_DECISION_SNAPSHOT_HASH_CONTRACT_VERSION"),
        ("BINDING", "STAGE2", "TIMELINE_HASH_ANCHOR_HASH_INTERVAL_ID_HASH_SWING_POLICY_HASH_LIFECYCLE_LEDGER_SEAL_PREFIX_HASH_ENVELOPE_COUNT_CONTRACT_VERSION_ARTIFACT_HASH"),
        ("STORAGE", "MARKET", "SHARED_TIMELINE_ONCE"),
        ("STORAGE", "SNAPSHOT", "COMPACT_REFERENCES_ONLY_NO_RAW_MARKET_NO_FULL_ENVELOPE_TUPLE_NO_RUNNING_PAYLOAD"),
        ("STORAGE", "ENVELOPES", "OWNED_BY_STAGE2_PER_INTERVAL_TABLE_RECONSTRUCTIBLE"),
        ("OUT_OF_SCOPE", "VOLATILITY", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "LIQUIDITY", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "OB_FVG", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "DEALING_RANGE", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "ORDERFLOW", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "SESSION", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "MTF", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "DESCRIPTORS", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "ESTIMANDS", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "MODEL", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "GEOMETRY", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "EXECUTION", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "WIN_LOSS", "FORBIDDEN"),
        ("DEBT", "RESEARCH-DEBT-020", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-021", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-022", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-023", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-024", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-025", "OPEN"),
    ]
    return pd.DataFrame(
        [{"record_type": a, "name": b, "value": c, "serialization_order": i} for i, (a, b, c) in enumerate(rows)]
    )
