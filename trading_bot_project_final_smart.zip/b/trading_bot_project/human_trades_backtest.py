
def compute_trade_outcome(brain, symbol, publish_ts, entry, sl, tp, is_short, max_days=25):
    from ict_math_engine import check_order_invalidated_before_fill
    import datetime
    try:
        start_ts = publish_ts
        end_ts = start_ts + max_days * 24 * 3600 * 1000
        
        def _fetch_5m_fwd(b, sym, st, en):
            data = b.data_manager.get_ohlcv(sym, "5m", 8000, output_format="dict")
            if not data or not data.get("closes"): return None
            idx = [i for i, t in enumerate(data["timestamps"]) if st <= t <= en]
            if not idx: return None
            return {
                "timestamps": [data["timestamps"][i] for i in idx],
                "opens": [data["opens"][i] for i in idx],
                "highs": [data["highs"][i] for i in idx],
                "lows": [data["lows"][i] for i in idx],
                "closes": [data["closes"][i] for i in idx]
            }

        data = _fetch_5m_fwd(brain, symbol, start_ts, end_ts)
        if not data: return {"error": "NO_DATA"}
        
        timestamps = data["timestamps"]
        highs = data["highs"]
        lows = data["lows"]
        closes = data["closes"]
        
        result = {"candles_checked": len(closes)}
        
        entry_idx = None
        for i in range(len(closes)):
            if lows[i] <= entry <= highs[i]:
                entry_idx = i
                break
                
        if entry_idx is None:
            result["entry_hit"] = False
            result["outcome"] = "ENTRY_NEVER_HIT"
            return result
            
        result["entry_hit"] = True
        
        risk = abs(sl - entry)
        if risk == 0: return {"outcome": "ERROR", "pnl_pct": 0}
        
        current_sl = sl
        be_activated = False
        tp1_hit = False
        outcome_code = "OPEN"
        exit_price = closes[-1]
        exit_time_ms = timestamps[-1]
        max_favorable = entry
        
        for i in range(entry_idx, len(closes)):
            h = highs[i]
            l = lows[i]
            
            if is_short:
                if l < max_favorable: max_favorable = l
                
                if h >= current_sl:
                    exit_price = current_sl
                    exit_time_ms = timestamps[i]
                    if current_sl == sl: outcome_code = "SL_HIT"
                    elif current_sl == entry: outcome_code = "BREAK_EVEN_HIT"
                    else: outcome_code = "DYNAMIC_TRAIL_HIT"
                    break
                    
                if l <= tp and not tp1_hit:
                    tp1_hit = True
                    current_sl = entry
                    be_activated = True
                    
                if l <= (entry - 1.5*risk) and not be_activated:
                    current_sl = entry
                    be_activated = True
                    
                if i >= 2 and highs[i-1] > highs[i-2] and highs[i-1] > highs[i]:
                    swing_high = highs[i-1]
                    if l < lows[i-1] and swing_high < current_sl and be_activated:
                        new_sl = swing_high + (risk * 0.1)
                        if new_sl < current_sl: current_sl = new_sl
            else:
                if h > max_favorable: max_favorable = h
                
                if l <= current_sl:
                    exit_price = current_sl
                    exit_time_ms = timestamps[i]
                    if current_sl == sl: outcome_code = "SL_HIT"
                    elif current_sl == entry: outcome_code = "BREAK_EVEN_HIT"
                    else: outcome_code = "DYNAMIC_TRAIL_HIT"
                    break
                    
                if h >= tp and not tp1_hit:
                    tp1_hit = True
                    current_sl = entry
                    be_activated = True
                    
                if h >= (entry + 1.5*risk) and not be_activated:
                    current_sl = entry
                    be_activated = True
                    
                if i >= 2 and lows[i-1] < lows[i-2] and lows[i-1] < lows[i]:
                    swing_low = lows[i-1]
                    if h > highs[i-1] and swing_low > current_sl and be_activated:
                        new_sl = swing_low - (risk * 0.1)
                        if new_sl > current_sl: current_sl = new_sl
                        
        if outcome_code == "OPEN" and tp1_hit:
            outcome_code = "PARTIAL_TP_HIT_THEN_OPEN"
        elif outcome_code == "BREAK_EVEN_HIT" and tp1_hit:
            outcome_code = "TP1_THEN_BE"
            
        result["outcome"] = outcome_code
        result["exit_price"] = exit_price
        result["max_favorable_excursion"] = max_favorable
        
        if outcome_code == "SL_HIT": 
            result["pnl_pct"] = -abs(sl - entry) / entry * 100
        elif outcome_code == "BREAK_EVEN_HIT": 
            result["pnl_pct"] = 0.0
        elif outcome_code in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]:
            pnl_pct = (abs(tp - entry) / entry * 100) * 0.8
            result["pnl_pct"] = pnl_pct
        elif outcome_code == "DYNAMIC_TRAIL_HIT" or outcome_code == "OPEN":
            pnl_pct = (abs(tp - entry) / entry * 100) * 0.8 
            rem_pct = (entry - exit_price)/entry*100 if is_short else (exit_price - entry)/entry*100
            result["pnl_pct"] = pnl_pct + (rem_pct * 0.2)
        else:
            result["pnl_pct"] = 0.0
            
        return result
    except Exception as e:
        return {"error": str(e)}
