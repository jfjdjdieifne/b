import sys, datetime
sys.path.insert(0, ".")
from brain_core import BrainCore
from authenticity_engine import AuthenticityEngine

brain = BrainCore()
ae = AuthenticityEngine()

print("ما هي السيولة التي ينتظرها البوت الآن ليضربها؟ (مستويات المراقبة)")

SYMBOL = "BTC/USDT"
full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 1000, output_format="dict")
sig = ae.detect_significant_swings(full_data, swing_window=1, lookback_candles=150)

print(f"\n🪙 {SYMBOL} (الانحياز: BULLISH)")
print("البوت ينتظر بصمت أن يهبط السعر لضرب إحدى هذه القيعان (Sell-Side Liquidity) ليشتري:")
lows = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
for l in lows[:3]:
    print(f" - قاع عند {l['price']:.2f} (تم تشكيله قبل {abs(l['index_from_end'])} شمعة)")

print("\n---")
SYMBOL = "SOL/USDT"
full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 1000, output_format="dict")
sig = ae.detect_significant_swings(full_data, swing_window=1, lookback_candles=150)

print(f"\n🪙 {SYMBOL} (الانحياز: BEARISH)")
print("البوت ينتظر أن يصعد السعر صعوداً وهمياً لضرب إحدى هذه القمم (Buy-Side Liquidity) ليبيع:")
highs = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
for h in highs[:3]:
    print(f" - قمة عند {h['price']:.2f} (تم تشكيلها قبل {abs(h['index_from_end'])} شمعة)")
