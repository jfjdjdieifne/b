import sys, datetime, time
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
import pytz

brain = BrainCore()
ae = AuthenticityEngine()
ny_tz = pytz.timezone('America/New_York')

now_ny = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz)
print(f"=== تحديث مباشر من محرك ICT للعملات الكبرى ===")
print(f"توقيت نيويورك الآن: {now_ny.strftime('%H:%M:%S')}\n")

for SYMBOL in ["BTC/USDT", "ETH/USDT", "BNB/USDT", "XRP/USDT", "ADA/USDT"]:
    try:
        data_15m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "15m", int(time.time()*1000), limit=200)
        if not data_15m or not data_15m['closes']: continue
        
        current_price = data_15m['closes'][-1]
        
        # 1. الاتجاه
        anchor = compute_mechanical_bias_anchor(data_15m, lookback=150)
        bias = anchor.get("anchor_direction")
        
        print(f"🪙 {SYMBOL}:")
        print(f"   السعر اللحظي: {current_price:.4f}")
        
        if bias not in ["BULLISH", "BEARISH"]:
            print("   الوضع: 🛑 متذبذب (CHOP) - لا يوجد ترند. البوت (HOLD).")
            print("-" * 50)
            continue
            
        print(f"   الاتجاه (Bias): {bias}")
        
        # 2. أهداف السيولة
        sig = ae.detect_significant_swings(data_15m, swing_window=1, lookback_candles=150)
        
        if bias == "BULLISH":
            lows = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
            if lows:
                target = lows[0]['price']
                dist = current_price - target
                pct = (dist / current_price) * 100
                print(f"   الخطة: البوت ينتظر هبوطاً لضرب قاع (SSL) عند {target:.4f} ليشتري.")
                print(f"   المسافة للهدف: {dist:.4f} دولار ({pct:.2f}%)")
            else:
                print("   الخطة: لا توجد قيعان سيولة واضحة قريبة. البوت يراقب.")
        else:
            highs = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
            if highs:
                target = highs[0]['price']
                dist = target - current_price
                pct = (dist / current_price) * 100
                print(f"   الخطة: البوت ينتظر صعوداً لضرب قمة (BSL) عند {target:.4f} ليبيع.")
                print(f"   المسافة للهدف: {dist:.4f} دولار ({pct:.2f}%)")
            else:
                print("   الخطة: لا توجد قمم سيولة واضحة قريبة. البوت يراقب.")
                
        print("-" * 50)
    except Exception as e:
        pass

