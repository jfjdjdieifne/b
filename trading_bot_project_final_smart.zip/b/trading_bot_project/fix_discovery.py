import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore

brain = BrainCore()
SYMBOL = "ETH/USDT"
full_data = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "15m", 1783641600000, limit=3000)
n = len(full_data["closes"])
print(f"Data length: {n}")
if n > 0:
    print(f"First candle: {datetime.datetime.fromtimestamp(full_data['timestamps'][0]/1000, tz=datetime.timezone.utc)}")
    print(f"Last candle: {datetime.datetime.fromtimestamp(full_data['timestamps'][-1]/1000, tz=datetime.timezone.utc)}")

