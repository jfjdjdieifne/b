import json, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
brain = BrainCore()
SYMBOL = "ETH/USDT"
sweep_ts = 1781189100000 
from ict_entry_checklist_engine import evaluate_all_entry_models

for k in range(0, 10):
    sim_ts = sweep_ts + (k*5*60*1000)
    data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
    res = evaluate_all_entry_models(data_5m, "BEARISH")
    for k2, v2 in res.items():
        if isinstance(v2, dict) and v2.get("status") in ["PENDING_SETUP", "READY"]:
            print(f"Candle +{k}: {k2} -> {v2.get('status')} - Conditions: {[c['name'] for c in v2.get('conditions', []) if not c['status']]}")
