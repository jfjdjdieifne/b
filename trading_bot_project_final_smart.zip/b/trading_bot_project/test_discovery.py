import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import classify_sweep_or_run

brain = BrainCore()
SYMBOL = "ETH/USDT"
# Let's write a very loose scanner to prove we can get sweeps without any bias restrictions.
full_data = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "15m", 1783641600000, limit=3000)
n = len(full_data["closes"])
sweeps = 0

for i in range(500, n):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }
    
    # Check if current low sweeps any low in the last 50 candles
    current_low = window_data["lows"][-1]
    
    # very dumb sweep check: did it go below the lowest low of the last 20 candles, but close above it?
    recent_lows = window_data["lows"][-20:-1]
    min_recent_low = min(recent_lows)
    
    if current_low < min_recent_low and window_data["closes"][-1] > min_recent_low:
        sweeps += 1

print(f"Found {sweeps} simple sweeps in the last month.")
