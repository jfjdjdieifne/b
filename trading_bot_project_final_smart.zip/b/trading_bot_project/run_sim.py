import json, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome

brain = BrainCore()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_USD = ACCOUNT_BALANCE * 0.01

with open('/tmp/month_candidates_real.json') as f:
    candidates = json.load(f)

results = []
account = ACCOUNT_BALANCE

print("جاري محاكاة الصفقات...")

for idx, cand in enumerate(candidates):
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    
    found_trade = False
    for k in range(0, 24): # 2 ساعة كحد أقصى لتفعيل الأمر
        sim_ts = sweep_ts + (k * 5 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                chosen = res.get("chosen_model", {})
                plan = chosen.get("plan", {})
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                tp1 = plan.get("tp")
                model = chosen.get("model")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    outcome = compute_trade_outcome(brain, SYMBOL, sim_ts, entry, sl, tp1, is_short)
                    if outcome and outcome.get("outcome") != "PENDING":
                        out_code = outcome.get("outcome")
                        
                        sl_dist_pct = abs(entry - sl) / entry
                        pos_size_usd = RISK_USD / sl_dist_pct if sl_dist_pct > 0 else 0
                        
                        profit_usd = 0.0
                        if out_code in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]:
                            tp1_dist_pct = abs(tp1 - entry) / entry
                            profit_usd = (tp1_dist_pct * pos_size_usd) * 0.5 
                        elif out_code == "SL_HIT":
                            profit_usd = -RISK_USD
                            
                        account += profit_usd
                        
                        results.append({
                            "num": idx + 1,
                            "date": cand['datetime_utc'],
                            "bias": bias,
                            "sweep_type": cand['sweep_type'],
                            "entry": entry,
                            "sl": sl,
                            "tp1": tp1,
                            "outcome": out_code,
                            "profit": profit_usd,
                            "balance": account
                        })
                        found_trade = True
                        break
        except Exception:
            pass
            
    if not found_trade:
        results.append({
            "num": idx + 1,
            "date": cand['datetime_utc'],
            "outcome": "HOLD"
        })

print("\n" + "="*80)
print("سجل الصفقات الكامل:")
for r in results:
    if r.get('outcome') == "HOLD":
        print(f"[{r['num']}] {r['date']} | تجاهل (HOLD)")
    else:
        out_str = r['outcome']
        if out_str in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]: out_str = "ربح جزئي وتأمين 🎯🛡️"
        elif out_str == "BREAK_EVEN_HIT": out_str = "خروج عالدخول 🛡️"
        elif out_str == "SL_HIT": out_str = "ستوب لوس ❌"
        elif out_str == "ORDER_INVALIDATED_BEFORE_FILL": out_str = "ألغيت 🚫"
        elif out_str == "ENTRY_NEVER_HIT": out_str = "لم تتفعل ⏳"
        
        print(f"[{r['num']}] {r['date']} | {r['bias']} | دخول: {r['entry']:.2f} | النتيجة: {out_str} | الربح: {r['profit']:.2f}$ | الرصيد: {r['balance']:.2f}$")

wins = sum(1 for r in results if r.get('profit', 0) > 0)
losses = sum(1 for r in results if r.get('profit', 0) < 0)
print(f"\nإجمالي الصفقات المنفذة الرابحة: {wins}")
print(f"إجمالي الصفقات الخاسرة: {losses}")
print(f"الرصيد النهائي: {account:.2f}$")

