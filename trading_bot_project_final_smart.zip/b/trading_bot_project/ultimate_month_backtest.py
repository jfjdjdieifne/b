import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01

print("جاري المسح العميق لآخر 30 يوماً (كل شمعة بشمعتها)...")

# 30 يوم * 24 ساعة * 4 شموع = 2880 شمعة
# سنجلب 4000 ليكون لدينا بيانات سابقة للتحليل لليوم الأول
full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 5000, output_format="dict")
n = len(full_data["closes"])
start_idx = max(500, n - 2880)

candidates = []
reported_days = set()

# مسح دقيق: نفحص شمعة كل ساعة (step=4) لعدم إضاعة الوقت مع التقاط سحوبات الـ 4 شموع الماضية
for i in range(start_idx, n, 4):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }

    # 1. الانحياز
    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
    except Exception: continue
    bias = anchor.get("anchor_direction")
    if bias not in ("BULLISH", "BEARISH"): continue

    # 2. السيولة
    try:
        sig = ae.detect_significant_swings(window_data, swing_window=1, lookback_candles=150)
    except Exception: continue

    current_ts = window_data["timestamps"][-1]

    # منع الدخول أكثر من مرة في نفس جلسة 12 ساعة لتجنب التخبيص
    if any(abs(c["timestamp"] - current_ts) < 12*3600*1000 for c in candidates):
        continue

    # 3. السحب (Sweep)
    is_swept = False
    swept_level = 0
    if bias == "BULLISH":
        lows = [s for s in sig.get("all_lows_tiered", [])]
        for cand in lows:
            res = classify_sweep_or_run(window_data, cand["price"], level_is_high=False, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -4:
                is_swept, swept_level = True, cand["price"]
                break
    else:
        highs = [s for s in sig.get("all_highs_tiered", [])]
        for cand in highs:
            res = classify_sweep_or_run(window_data, cand["price"], level_is_high=True, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") >= -4:
                is_swept, swept_level = True, cand["price"]
                break

    if is_swept:
        dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
        candidates.append({
            "timestamp": current_ts, "datetime_utc": dt.isoformat(),
            "bias": bias, "sweep_level": swept_level
        })

candidates.sort(key=lambda c: c["timestamp"])

results = []
account = ACCOUNT_BALANCE

for cand in candidates:
    sweep_ts = cand['timestamp']
    bias = cand['bias']
    
    found_trade = False
    for k in range(0, 12): # ننتظر حتى 3 ساعات لتشكل الفجوة والدخول
        sim_ts = sweep_ts + (k * 15 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                chosen = res.get("chosen_model", {})
                plan = chosen.get("plan", {})
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                tp1 = plan.get("tp")
                model = chosen.get("model")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    outcome = compute_trade_outcome(brain, SYMBOL, sim_ts, entry, sl, tp1, is_short)
                    
                    if outcome and outcome.get("outcome") != "PENDING" and outcome.get("outcome") != "ENTRY_NEVER_HIT":
                        out_code = outcome.get("outcome")
                        
                        # الحساب المالي
                        sl_dist = abs(entry - sl)
                        risk_amount = account * RISK_PCT
                        pos_size = risk_amount / sl_dist if sl_dist > 0 else 0
                        
                        profit = 0.0
                        if out_code in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]:
                            tp1_dist = abs(tp1 - entry)
                            # ربح 80% من الكمية عند الهدف الأول
                            profit = (tp1_dist * pos_size) * 0.8 
                        elif out_code == "SL_HIT":
                            profit = -risk_amount
                        elif out_code == "BREAK_EVEN_HIT":
                            profit = 0.0
                            
                        account += profit
                        
                        results.append({
                            "date": cand['datetime_utc'][:16].replace('T', ' '),
                            "bias": "بيع 🔴" if is_short else "شراء 🟢",
                            "entry": entry,
                            "sl": sl,
                            "tp1": tp1,
                            "outcome": out_code,
                            "profit": profit,
                            "balance": account
                        })
                        found_trade = True
                        break
        except Exception:
            pass

print("\n=== التقرير الشامل لآخر 30 يوماً (رصيد 100$ | مخاطرة 1% تراكمية) ===")
for r in results:
    out_label = r['outcome']
    if out_label in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]: out_label = "ربح جزئي (80%) وتأمين الباقي 🎯"
    elif out_label == "SL_HIT": out_label = "ضرب ستوب لوس ❌"
    elif out_label == "BREAK_EVEN_HIT": out_label = "خروج على الدخول (أمان) 🛡️"
    elif out_label == "ORDER_INVALIDATED_BEFORE_FILL": out_label = "إلغاء الأمر (كسر هيكل) 🚫"
    
    print(f"{r['date']} | {r['bias']} | الدخول: {r['entry']:>7.2f} | النتيجة: {out_label:<30} | الربح: {r['profit']:>5.2f}$ | الرصيد: {r['balance']:.2f}$")

wins = sum(1 for r in results if r['profit'] > 0)
losses = sum(1 for r in results if r['profit'] < 0)
bes = sum(1 for r in results if r['profit'] == 0 and r['outcome'] != "ORDER_INVALIDATED_BEFORE_FILL")

print("="*80)
print(f"إجمالي الصفقات المنفذة فعلياً: {wins + losses + bes} صفقة (تم استبعاد الإشارات الملغاة والتي لم تتفعل).")
print(f"✅ صفقات رابحة: {wins}")
print(f"🛡️ صفقات تعادل (Break-Even): {bes}")
print(f"❌ صفقات خاسرة: {losses}")
print(f"نسبة النجاح (استبعاد التعادل): {wins/(wins+losses)*100 if (wins+losses)>0 else 0:.1f}%")
print(f"الرصيد النهائي: {account:.2f}$ (صافي الربح: {account-100:.2f}$)")
print("="*80)

