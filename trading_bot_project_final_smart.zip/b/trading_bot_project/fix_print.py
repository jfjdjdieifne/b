import re
with open("get_30_fast.py", "r") as f:
    content = f.read()

# Fix the KeyError by using dict.get()
content = content.replace("r['bias']", "r.get('bias', 'UNKNOWN')")

with open("get_30_fast.py", "w") as f:
    f.write(content)
