import json, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
brain = BrainCore()
SYMBOL = "ETH/USDT"
sweep_ts = 1781189100000 
sim_ts = sweep_ts + (2*5*60*1000)
data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
from ict_entry_checklist_engine import evaluate_all_entry_models
res = evaluate_all_entry_models(data_5m, "BEARISH")
for k, v in res.items():
    if isinstance(v, dict) and v.get("status") in ["PENDING_SETUP", "READY"]:
         print(k)
         print(json.dumps(v.get("plan"), indent=2))
