import sys, datetime, time
sys.path.insert(0, ".")
from brain_core import BrainCore
import pytz
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine

brain = BrainCore()
ae = AuthenticityEngine()
ny_tz = pytz.timezone('America/New_York')

print("=== 📡 تحديث رادار ICT للعملتين الساخنتين (SOL و XRP) ===")
now_ny = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz)
print(f"توقيت نيويورك الآن: {now_ny.strftime('%H:%M:%S')}\n")

# أهداف السيولة المتوقعة
targets = {
    "SOL/USDT": {"price": 78.49, "bias": "BEARISH", "type": "BSL_SWEPT_HIGH"},
    "XRP/USDT": {"price": 1.0867, "bias": "BULLISH", "type": "SSL_SWEPT_LOW"}
}

for sym, info in targets.items():
    try:
        data = brain.data_manager.fetch_ohlcv_up_to(sym, "15m", int(time.time()*1000), limit=250)
        current = data['closes'][-1]
        
        # التأكد من الانحياز الحالي
        anchor = compute_mechanical_bias_anchor(data, lookback=150)
        current_bias = anchor.get("anchor_direction")
        
        # استخراج الأهداف (TP1 و TP2) من الهيكل
        sig = ae.detect_significant_swings(data, swing_window=1, lookback_candles=150)
        
        tp1 = None
        tp2_price = "مفتوح (Trailing)" # الافتراضي
        
        if current_bias == "BULLISH":
            highs = [s for s in sig.get("all_highs_tiered", []) if s['price'] > info['price']]
            if highs:
                tp1 = min(highs, key=lambda x: x['price'])['price']
                # TP2 هو أبعد قمة هيكلية قوية أو مسبح سيولة مزدوج
                major_highs = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE") and s['price'] > tp1]
                if major_highs:
                    tp2_price = f"{max(major_highs, key=lambda x: x['price'])['price']:.4f}"
        else:
            lows = [s for s in sig.get("all_lows_tiered", []) if s['price'] < info['price']]
            if lows:
                tp1 = max(lows, key=lambda x: x['price'])['price']
                major_lows = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE") and s['price'] < tp1]
                if major_lows:
                    tp2_price = f"{min(major_lows, key=lambda x: x['price'])['price']:.4f}"

        # حساب المسافة
        distance = current - info['price'] if current > info['price'] else info['price'] - current
        pct_away = (distance / current) * 100
        
        print(f"🪙 {sym}:")
        print(f"   الاتجاه الحالي (Bias): {current_bias}")
        print(f"   السعر اللحظي الآن: {current:.4f}")
        print(f"   🎯 الفخ المنتظر ضربه (Sweep Target): {info['price']:.4f}")
        print(f"   📏 المسافة المتبقية لضرب الفخ: {distance:.4f} دولار ({pct_away:.2f}%)")
        
        if tp1:
            print(f"   🟢 الهدف الأول (TP1 - لجني 80%): {tp1:.4f}")
        print(f"   🚀 الهدف النهائي (TP2 - للكمية المتبقية 20%): {tp2_price}")
        print("-" * 50)
        
    except Exception as e:
        pass

