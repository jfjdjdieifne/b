import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_USD = ACCOUNT_BALANCE * 0.01

full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 8000, output_format="dict")
n = len(full_data["closes"])
candidates = []
reported_days = set()

for i in range(2000, n, 50): 
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }

    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=100)
    except Exception:
        continue
    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"): continue

    current_ts = window_data["timestamps"][-1]
    day_str = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc).strftime('%Y-%m-%d')
    if day_str in reported_days: continue

    try:
        sig = ae.detect_significant_swings(window_data, swing_window=1, lookback_candles=100)
    except Exception:
        continue

    if daily_bias == "BULLISH":
        important_levels = [s for s in sig.get("all_lows_tiered", [])]
        for candidate in important_levels:
            res = classify_sweep_or_run(window_data, candidate["price"], level_is_high=False, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                reported_days.add(day_str)
                break
    else:
        important_levels = [s for s in sig.get("all_highs_tiered", [])]
        for candidate in important_levels:
            res = classify_sweep_or_run(window_data, candidate["price"], level_is_high=True, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP":
                dt = datetime.datetime.fromtimestamp(current_ts/1000, tz=datetime.timezone.utc)
                candidates.append({"timestamp": current_ts, "datetime_utc": dt.isoformat(), "mechanical_bias": daily_bias})
                reported_days.add(day_str)
                break

candidates.sort(key=lambda c: c["timestamp"])
if len(candidates) > 30: candidates = candidates[-30:]

results = []
account = ACCOUNT_BALANCE

def smart_manage_trade(brain, symbol, entry_ts, entry, sl, is_short):
    data_5m = brain.data_manager.fetch_ohlcv_up_to(symbol, "5m", entry_ts + 24*3600*1000, limit=200)
    risk = abs(sl - entry)
    if risk == 0: return 0
    
    current_sl = sl
    in_trade = True
    realized_rr = 0.0
    
    for i in range(len(data_5m['closes'])):
        if data_5m['timestamps'][i] < entry_ts: continue
        
        h = data_5m['highs'][i]
        l = data_5m['lows'][i]
        
        if is_short:
            if h >= current_sl:
                realized_rr = (entry - current_sl) / risk
                break
            
            # Trail logic
            if l < (entry - 5*risk):
                smart_sl = entry - 3.5*risk
                if smart_sl < current_sl: current_sl = smart_sl
            elif l < (entry - 3*risk):
                smart_sl = entry - 1.5*risk
                if smart_sl < current_sl: current_sl = smart_sl
            elif l < (entry - 1.5*risk):
                smart_sl = entry
                if smart_sl < current_sl: current_sl = smart_sl
                
        else:
            if l <= current_sl:
                realized_rr = (current_sl - entry) / risk
                break
                
            if h > (entry + 5*risk):
                smart_sl = entry + 3.5*risk
                if smart_sl > current_sl: current_sl = smart_sl
            elif h > (entry + 3*risk):
                smart_sl = entry + 1.5*risk
                if smart_sl > current_sl: current_sl = smart_sl
            elif h > (entry + 1.5*risk):
                smart_sl = entry
                if smart_sl > current_sl: current_sl = smart_sl

    return realized_rr


for idx, cand in enumerate(candidates):
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    
    for k in range(0, 4):
        sim_ts = sweep_ts + (k * 15 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                chosen = res.get("chosen_model", {})
                plan = chosen.get("plan", {})
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                tp1 = plan.get("tp")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    # Using the SMART manager instead of the dumb backtester
                    rr_gained = smart_manage_trade(brain, SYMBOL, sim_ts, entry, sl, is_short)
                    
                    if rr_gained != 0 or True: # log all
                        profit_usd = rr_gained * RISK_USD
                        account += profit_usd
                        
                        out_label = "ستوب لوس ❌" if rr_gained == -1 else "خروج عالدخول 🛡️" if rr_gained == 0 else "قنص ذكي وتتبع للربح 🧠🎯"
                        print(f"[{cand['datetime_utc'][:10]}] {bias} | النتيجة: {out_label} | الربح: {profit_usd:+.2f}$ (R:R = {rr_gained:+.2f}) | الرصيد: {account:.2f}$")
                        break
        except Exception: pass
