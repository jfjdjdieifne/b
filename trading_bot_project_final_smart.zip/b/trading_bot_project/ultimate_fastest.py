import json, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome

brain = BrainCore()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_PCT = 0.01

with open("/tmp/month_candidates_real.json", "r") as f:
    candidates = json.load(f)

results = []
account = ACCOUNT_BALANCE

for cand in candidates[-30:]: 
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    
    for k in range(0, 4):
        sim_ts = sweep_ts + (k * 15 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                plan = res.get("chosen_model", {}).get("plan", {})
                entry, sl, tp1 = plan.get("entry"), plan.get("stop_loss"), plan.get("tp")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    outcome = compute_trade_outcome(brain, SYMBOL, sim_ts, entry, sl, tp1, is_short)
                    
                    if outcome and outcome.get("outcome") not in ["PENDING", "ENTRY_NEVER_HIT", "ORDER_INVALIDATED_BEFORE_FILL"]:
                        out_code = outcome.get("outcome")
                        
                        sl_dist = abs(entry - sl)
                        risk_amount = account * RISK_PCT
                        pos_size = risk_amount / sl_dist if sl_dist > 0 else 0
                        
                        profit = 0.0
                        if out_code in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]:
                            profit = (abs(tp1 - entry) * pos_size) * 0.8 
                        elif out_code == "SL_HIT":
                            profit = -risk_amount
                            
                        account += profit
                        results.append({
                            "date": cand['datetime_utc'][:16].replace('T', ' '),
                            "bias": "بيع 🔴" if is_short else "شراء 🟢",
                            "entry": entry,
                            "outcome": out_code,
                            "profit": profit,
                            "balance": account
                        })
                        break
        except Exception: pass

print("="*90)
print(f"{'التاريخ':<18} | {'الاتجاه':<8} | {'الدخول':<8} | {'النتيجة':<35} | {'الربح':<8} | {'الرصيد':<8}")
print("="*90)

for r in results:
    out_label = r['outcome']
    if out_label in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]: out_label = "ربح جزئي وتأمين הבاقي 🎯"
    elif out_label == "SL_HIT": out_label = "ضرب ستوب لوس ❌"
    elif out_label == "BREAK_EVEN_HIT": out_label = "خروج على الدخول (أمان) 🛡️"
    
    print(f"{r['date']:<18} | {r['bias']:<8} | {r['entry']:>7.2f} | {out_label:<35} | {r['profit']:>6.2f}$ | {r['balance']:>6.2f}$")

wins = sum(1 for r in results if r['profit'] > 0)
losses = sum(1 for r in results if r['profit'] < 0)
bes = sum(1 for r in results if r['profit'] == 0)

print("="*90)
print(f"إجمالي الصفقات المنفذة فعلياً: {len(results)} صفقة.")
print(f"✅ صفقات رابحة: {wins}")
print(f"🛡️ صفقات تعادل (Break-Even): {bes}")
print(f"❌ صفقات خاسرة: {losses}")
print(f"نسبة النجاح (استبعاد التعادل): {wins/(wins+losses)*100 if (wins+losses)>0 else 0:.1f}%")
print(f"الرصيد النهائي: {account:.2f}$ (صافي الربح: +{((account-100)/100)*100:.2f}%)")
print("="*90)
