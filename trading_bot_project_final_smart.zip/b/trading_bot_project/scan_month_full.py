import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_math_engine import compute_mechanical_bias_anchor, classify_sweep_or_run
from authenticity_engine import AuthenticityEngine
from ict_entry_checklist_engine import evaluate_all_entry_models
from human_trades_backtest import compute_trade_outcome

brain = BrainCore()
ae = AuthenticityEngine()
SYMBOL = "ETH/USDT"
ACCOUNT_BALANCE = 100.0
RISK_USD = ACCOUNT_BALANCE * 0.01

print("جاري مسح شهر كامل لاستخراج الصفقات من 11 إلى 15...")
full_data = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "15m", 1783641600000, limit=4000)
n = len(full_data["closes"])
candidates = []
already_reported = set()

# مسح كل الشموع 
for i in range(500, n):
    window_data = {
        "opens": full_data["opens"][:i+1], "highs": full_data["highs"][:i+1],
        "lows": full_data["lows"][:i+1], "closes": full_data["closes"][:i+1],
        "timestamps": full_data["timestamps"][:i+1],
    }

    try:
        anchor = compute_mechanical_bias_anchor(window_data, lookback=250)
    except Exception:
        continue
    daily_bias = anchor.get("anchor_direction")
    if daily_bias not in ("BULLISH", "BEARISH"):
        continue

    try:
        sig = ae.detect_significant_swings(window_data, swing_window=2, lookback_candles=150)
    except Exception:
        continue

    n_window = len(window_data["closes"])

    if daily_bias == "BULLISH":
        important_levels = [s for s in sig.get("all_lows_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
        for candidate in important_levels:
            level_price = candidate["price"]
            key = round(level_price, 2)
            if key in already_reported:
                continue
            res = classify_sweep_or_run(window_data, level_price, level_is_high=False, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") == -1:
                already_reported.add(key)
                ts = full_data["timestamps"][i]
                dt = datetime.datetime.fromtimestamp(ts/1000, tz=datetime.timezone.utc)
                candidates.append({
                    "timestamp": ts, "datetime_utc": dt.isoformat(),
                    "mechanical_bias": daily_bias, "sweep_type": "SSL_SWEPT_LOW", "swept_level_price": level_price
                })
    else:
        important_levels = [s for s in sig.get("all_highs_tiered", []) if s.get("tier") in ("MAJOR", "MODERATE")]
        for candidate in important_levels:
            level_price = candidate["price"]
            key = round(level_price, 2)
            if key in already_reported:
                continue
            res = classify_sweep_or_run(window_data, level_price, level_is_high=True, check_from_idx=i)
            if res.get("found") and res.get("classification") == "GENUINE_REVERSAL_SWEEP" and res.get("candle_index_from_end") == -1:
                already_reported.add(key)
                ts = full_data["timestamps"][i]
                dt = datetime.datetime.fromtimestamp(ts/1000, tz=datetime.timezone.utc)
                candidates.append({
                    "timestamp": ts, "datetime_utc": dt.isoformat(),
                    "mechanical_bias": daily_bias, "sweep_type": "BSL_SWEPT_HIGH", "swept_level_price": level_price
                })

candidates.sort(key=lambda c: c["timestamp"])
print(f"تم العثور على {len(candidates)} نقطة خلال الشهر.")

# نأخذ الصفقات من 11 إلى 15 (indices 10 to 14)
if len(candidates) >= 15:
    batch = candidates[10:15]
else:
    batch = candidates[-5:]

results = []
for idx, cand in enumerate(batch):
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    
    found_trade = False
    for k in range(0, 36):
        sim_ts = sweep_ts + (k * 5 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                chosen = res.get("chosen_model", {})
                plan = chosen.get("plan", {})
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                tp1 = plan.get("tp")
                model = chosen.get("model")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    outcome = compute_trade_outcome(brain, SYMBOL, sim_ts, entry, sl, tp1, is_short)
                    if outcome and outcome.get("outcome") != "PENDING":
                        out_code = outcome.get("outcome")
                        
                        sl_dist_pct = abs(entry - sl) / entry
                        pos_size_usd = RISK_USD / sl_dist_pct if sl_dist_pct > 0 else 0
                        
                        profit_usd = 0.0
                        if out_code in ["TP1_THEN_BE", "PARTIAL_TP_HIT_THEN_OPEN"]:
                            tp1_dist_pct = abs(tp1 - entry) / entry
                            profit_usd = (tp1_dist_pct * pos_size_usd) * 0.5 
                        elif out_code == "SL_HIT":
                            profit_usd = -RISK_USD
                            
                        results.append({
                            "num": 11 + idx if len(candidates) >= 15 else len(candidates) - 5 + idx + 1,
                            "date": cand['datetime_utc'],
                            "bias": bias,
                            "sweep_type": cand['sweep_type'],
                            "sweep_level": cand['swept_level_price'],
                            "model": model,
                            "entry": entry,
                            "sl": sl,
                            "tp1": tp1,
                            "outcome": out_code,
                            "profit_usd": profit_usd,
                            "mfe": outcome.get('max_favorable_excursion')
                        })
                        found_trade = True
                        break
        except Exception as e:
            pass
            
    if not found_trade:
        results.append({
            "num": 11 + idx if len(candidates) >= 15 else len(candidates) - 5 + idx + 1,
            "date": cand['datetime_utc'],
            "outcome": "HOLD"
        })

for r in results:
    print(r)

