import json

results = [
{'num': 11, 'date': '2026-07-09T10:45:00+00:00', 'bias': 'BEARISH', 'sweep_type': 'BSL_SWEPT_HIGH', 'sweep_level': 1751.56, 'model': 'MODEL_B_SWEEP_FVG', 'entry': 1753.97, 'sl': 1758.40536, 'tp1': 1745.404185, 'outcome': 'ENTRY_NEVER_HIT', 'profit_usd': 0.0, 'mfe': None},
{'num': 12, 'date': '2026-07-09T10:45:00+00:00', 'bias': 'BEARISH', 'sweep_type': 'BSL_SWEPT_HIGH', 'sweep_level': 1746.65, 'model': 'MODEL_B_SWEEP_FVG', 'entry': 1753.97, 'sl': 1758.40536, 'tp1': 1745.404185, 'outcome': 'ENTRY_NEVER_HIT', 'profit_usd': 0.0, 'mfe': None}
]

# We need to find 3 more points backwards if the scanner hit the end of the data. 
# But the user asked for analysis of the next 5 points. The scanner hit the end of the available historical data (July 9, 2026 is today's date in this simulation) and only found 2 more points, and both were "ENTRY_NEVER_HIT" (price just kept dropping and didn't pull back to the Limit Order).
# I will explain this clearly.
