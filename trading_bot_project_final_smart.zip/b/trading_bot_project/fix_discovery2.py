import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
brain = BrainCore()
SYMBOL = "ETH/USDT"

# نجلب 15000 شمعة
full_data = brain.data_manager.get_ohlcv(SYMBOL, "15m", 15000, output_format="dict")
n = len(full_data["closes"])
print(f"Data length: {n}")
if n > 0:
    print(f"First candle: {datetime.datetime.fromtimestamp(full_data['timestamps'][0]/1000, tz=datetime.timezone.utc)}")
    print(f"Last candle: {datetime.datetime.fromtimestamp(full_data['timestamps'][-1]/1000, tz=datetime.timezone.utc)}")

