import json, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
brain = BrainCore()
SYMBOL = "ETH/USDT"
sweep_ts = 1781189100000 
from ict_entry_checklist_engine import evaluate_all_entry_models
import datetime

print("محاكاة دقيقة للنقطة الرابعة - Model C او B؟")
data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sweep_ts, limit=150)

# نمررها للكود الميكانيكي 
res = evaluate_all_entry_models(data_5m, "BEARISH")
chosen = res.get("chosen_model", {})

print(json.dumps(chosen, indent=2))
