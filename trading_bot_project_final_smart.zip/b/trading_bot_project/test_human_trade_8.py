import sys
import json
sys.path.insert(0, ".")
from nemotron_backtest_driver import run_one_backtest
out = run_one_backtest("ETH/USDT", "5m", 1780517700000, 
                api_key="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", 
                label="test_trade", max_tokens=4000)
with open("/tmp/test_trade_8.json", "w") as f:
    json.dump(out, f, indent=2, default=str)
