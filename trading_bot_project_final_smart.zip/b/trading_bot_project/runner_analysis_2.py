import sys
sys.path.insert(0, ".")
from brain_core import BrainCore

brain = BrainCore()
SYMBOL = "ETH/USDT"
# وقت الشمعة الانفجارية: 13:30 UTC
ts_breakout = 1781098200000 

print("=== ماذا رأى البوت وتصرف بعد شمعة 09:30 (نيويورك) الانفجارية؟ ===")
# نجلب البيانات من 13:30 وما بعدها لنرى حركة السعر بدقة
data_15m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "15m", ts_breakout + 4*3600*1000, limit=20)

import datetime
import pytz
ny_tz = pytz.timezone('America/New_York')

for i in range(-16, 0):
    ts = data_15m['timestamps'][i]
    if ts >= ts_breakout:
        utc_dt = datetime.datetime.fromtimestamp(ts/1000, tz=datetime.timezone.utc)
        ny_dt = utc_dt.astimezone(ny_tz)
        
        o = data_15m['opens'][i]
        h = data_15m['highs'][i]
        l = data_15m['lows'][i]
        c = data_15m['closes'][i]
        
        print(f"[{ny_dt.strftime('%H:%M')}] O: {o:.2f} | H: {h:.2f} | L: {l:.2f} | C: {c:.2f}")

