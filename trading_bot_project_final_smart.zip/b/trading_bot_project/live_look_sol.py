import sys, datetime, time
sys.path.insert(0, ".")
from brain_core import BrainCore
import pytz

brain = BrainCore()
SYMBOL = "SOL/USDT"

print(f"=== تحديث مباشر لحركة سعر {SYMBOL} ===")
data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", int(time.time()*1000), limit=20)
current_price = data_5m['closes'][-1]
target_sweep = 76.28

distance = current_price - target_sweep
pct = (distance / current_price) * 100

ny_tz = pytz.timezone('America/New_York')
now_ny = datetime.datetime.now(datetime.timezone.utc).astimezone(ny_tz)

print(f"توقيت نيويورك الآن: {now_ny.strftime('%H:%M:%S')}")
print(f"السعر اللحظي الآن: {current_price:.2f}")
print(f"القاع المستهدف (الفخ): {target_sweep}")
print(f"المسافة المتبقية لضرب الفخ: {distance:.2f} دولار ({pct:.2f}%)")

print("\n--- آخر 5 شموع 5 دقائق ---")
for i in range(-5, 0):
    o = data_5m['opens'][i]
    h = data_5m['highs'][i]
    l = data_5m['lows'][i]
    c = data_5m['closes'][i]
    ts = datetime.datetime.fromtimestamp(data_5m['timestamps'][i]/1000, tz=datetime.timezone.utc).astimezone(ny_tz)
    print(f"[{ts.strftime('%H:%M')}] Open: {o:.2f} | High: {h:.2f} | Low: {l:.2f} | Close: {c:.2f}")

