import json, datetime, sys
sys.path.insert(0, ".")
from brain_core import BrainCore
from ict_entry_checklist_engine import evaluate_all_entry_models

brain = BrainCore()
SYMBOL = "ETH/USDT"

with open('/tmp/last_month_final_unique.json') as f:
    candidates = json.load(f)[:5]

for idx, cand in enumerate(candidates):
    sweep_ts = cand['timestamp']
    bias = cand['mechanical_bias']
    
    found = False
    for k in range(0, 36):
        sim_ts = sweep_ts + (k * 5 * 60 * 1000)
        data_5m = brain.data_manager.fetch_ohlcv_up_to(SYMBOL, "5m", sim_ts, limit=150)
        try:
            res = evaluate_all_entry_models(data_5m, bias)
            status = res.get("final_status")
            if status in ["READY", "PENDING_SETUP"]:
                chosen = res.get("chosen_model", {})
                plan = chosen.get("plan", {})
                entry = plan.get("entry")
                sl = plan.get("stop_loss")
                tp1 = plan.get("tp")
                
                if entry and sl and tp1:
                    is_short = (bias == "BEARISH")
                    sl_dist = abs(entry - sl)
                    tp1_dist = abs(entry - tp1)
                    print(f"Trade {idx+1}: SL dist={sl_dist:.2f}, TP1 dist={tp1_dist:.2f}, R:R={tp1_dist/sl_dist:.2f}")
                    found = True
                    break
        except Exception as e:
            pass
