import pandas as pd
import numpy as np
import datetime

class QuantumSimulator:
    def __init__(self, initial_capital=10000.0, maker_fee=0.000, taker_fee=0.001):
        self.initial_capital = initial_capital
        self.capital = initial_capital
        self.taker_fee = taker_fee 
        
        self.position = 0.0
        self.entry_price = 0.0
        self.bars_held = 0 
        self.highest_price_since_entry = 0.0
        self.trade_history = []
        self.detailed_log = []
        
        self.realized_capital = initial_capital
        self.initial_trade_capital = 0.0
        self.structural_stop_price = 0.0
        
    def estimate_market_impact_slippage(self, base_price, order_usd_size, bar_dollar_vol, is_market_buy):
        base_slip = 0.00015 
        safe_bar_vol = max(bar_dollar_vol, 1.0)
        participation_rate = order_usd_size / safe_bar_vol
        
        if participation_rate > 0.10: 
            impact = 0.0005 * np.sqrt(participation_rate)
        else:
            impact = 0.0
            
        slippage_pct = base_slip + impact
        return base_price * (1 + slippage_pct) if is_market_buy else base_price * (1 - slippage_pct)

    def log_trade_details(self, action, timestamp, price, reason, context_bar, net_pnl_pct=None):
        dt = pd.to_datetime(timestamp, unit='ms')
        log_entry = f"[{dt}] ACTION: {action} @ ${price:,.4f}\n"
        log_entry += f"   > REASON: {reason}\n"
        
        if action == "BUY":
            log_entry += f"   > ENTRY SIZE: 10.0% of Capital (ICT Risk Model)\n"
            log_entry += f"   > ICT CONTEXT AT TRIGGER:\n"
            log_entry += f"     - Sweep Low Protected Level: ${self.structural_stop_price:,.4f}\n"
            log_entry += f"     - Current Pullback VPIN: {context_bar['vpin']:.4f} (Safe < 0.40)\n"
            log_entry += f"     - Current ATR: ${context_bar['atr']:,.4f}\n"
            log_entry += f"   > ENGINE DECISION: Valid ICT Sequence Detected (Sweep -> Momentum Displacement -> Low-Toxicity Pullback). Executing Long.\n"
        
        elif action == "SELL":
            log_entry += f"   > NET EXIT PnL: {net_pnl_pct*100:.2f}% (After ALL Fees)\n"
            log_entry += f"   > ICT CONTEXT AT EXIT:\n"
            log_entry += f"     - Highest Price Reached: ${self.highest_price_since_entry:,.4f}\n"
            log_entry += f"     - Current ATR: ${context_bar['atr']:,.4f}\n"
            log_entry += f"     - Volume Bars Held: {self.bars_held}\n"
                
        log_entry += "-" * 70 + "\n"
        self.detailed_log.append(log_entry)

    def run_simulation(self, df_signals, risk_manager):
        print(f"[*] Executing ICT Cognitive Simulation (Capital: ${self.capital:,.2f})")
        df = df_signals.reset_index(drop=True)
        
        for i in range(len(df) - 1):
            current_bar = df.iloc[i]
            next_bar = df.iloc[i+1]
            
            if self.position > 0:
                self.highest_price_since_entry = max(self.highest_price_since_entry, current_bar['high'])
                self.bars_held += 1 
                
                exit_flag, reason = risk_manager.evaluate_position(
                    entry_price=self.entry_price,
                    structural_stop_price=self.structural_stop_price,
                    bars_held=self.bars_held,
                    current_price=current_bar['close'],
                    current_atr=current_bar['atr'],
                    highest_price_since_entry=self.highest_price_since_entry
                )
                    
                if exit_flag:
                    usd_size_to_sell = self.position * next_bar['open']
                    fill_price = self.estimate_market_impact_slippage(next_bar['open'], usd_size_to_sell, current_bar['total_vol'], False)
                    
                    gross_exit_value = self.position * fill_price
                    exit_fee = gross_exit_value * self.taker_fee
                    net_exit_value = gross_exit_value - exit_fee
                    
                    net_pnl_pct = (net_exit_value - self.initial_trade_capital) / self.initial_trade_capital
                    self.log_trade_details("SELL", next_bar['timestamp'], fill_price, reason, current_bar, net_pnl_pct=net_pnl_pct)
                    self.capital += net_exit_value
                    
                    self.trade_history.append({
                        'type': 'SELL',
                        'price': fill_price,
                        'reason': reason,
                        'pnl_pct': net_pnl_pct,  
                        'capital': self.capital,
                        'bars_held': self.bars_held
                    })
                    self.position = 0.0
                    self.entry_price = 0.0
                    self.bars_held = 0
                    self.highest_price_since_entry = 0.0
                    self.structural_stop_price = 0.0
            
            elif self.position == 0:
                if current_bar['buy_signal']:
                    
                    # نظام الـ 10% الثابت لحماية الـ Market Impact
                    position_sizing_pct = 0.10  
                    usd_to_buy = self.capital * position_sizing_pct
                    
                    if usd_to_buy < 10.0:
                        continue
                        
                    fill_price = self.estimate_market_impact_slippage(next_bar['open'], usd_to_buy, current_bar['total_vol'], True)
                    
                    fee = usd_to_buy * self.taker_fee
                    investable_capital = usd_to_buy - fee
                    
                    self.position = investable_capital / fill_price
                    self.entry_price = fill_price
                    self.bars_held = 0
                    self.highest_price_since_entry = fill_price
                    self.initial_trade_capital = usd_to_buy
                    self.capital -= usd_to_buy
                    self.structural_stop_price = current_bar['structural_stop_level']
                    
                    self.log_trade_details("BUY", next_bar['timestamp'], fill_price, "ICT Setup Confirmed", current_bar)
                    
                    total_equity = self.capital + usd_to_buy
                    self.trade_history.append({
                        'type': 'BUY',
                        'price': fill_price,
                        'reason': "ICT Setup",
                        'capital': total_equity,
                        'vpin_at_entry': current_bar['vpin']
                    })
                    
        return pd.DataFrame(self.trade_history), self.detailed_log
