class RiskManager:
    def __init__(self, max_hold_bars=20):
        # نمنح الصفقة 20 شمعة حجمية لتنضج (لأن הارتداد قد يأخذ وقتاً)
        self.max_hold_bars = max_hold_bars 
        
    def evaluate_position(self, entry_price, structural_stop_price, bars_held, current_price, current_atr, highest_price_since_entry):
        
        # 1. Structural Hard Stop (The ICT Invalidation)
        # الסטوب هو أسفل قاع الـ Sweep מضافاً إليه buffer صغير جداً (0.2x ATR)
        hard_stop = structural_stop_price - (0.2 * current_atr)
        # حماية ضد الأخطاء: إذا كان الסטوب قريباً جداً، נجبره على أن يكون 1.5x ATR كحد أدنى
        min_stop_distance = current_atr * 1.5
        if (entry_price - hard_stop) < min_stop_distance:
            hard_stop = entry_price - min_stop_distance
            
        if current_price < hard_stop:
            return True, "Structural Invalidation (Sweep Low Broken)"
            
        # 2. Momentum Exhaustion (Time Stop)
        if bars_held >= self.max_hold_bars:
            # إذا لم نحقق ربحاً يعادل الـ ATR (حركة واضحة) بعد 20 شمعة، نخرج
            if current_price <= entry_price + current_atr:
                return True, "Momentum Exhaustion (Failed to Displace)"
                
        # 3. Breakeven / Partial Profit (ICT Target 1)
        # إذا وصلنا للقمة المقابلة (حوالي 2x ATR)، نأمن الصفقة
        if highest_price_since_entry >= entry_price + (2.0 * current_atr):
            breakeven_stop = entry_price + (0.2 * current_atr) # تأمين الرسوم
            if current_price < breakeven_stop:
                return True, "Breakeven Lock Triggered (Saved from reversal)"
                
        # 4. The Runner (Chandelier Trailing Exit)
        # نترك الباقي يركض ونعلق הـ Stop تحت القمة
        if highest_price_since_entry > entry_price + (3.0 * current_atr):
            trailing_stop = highest_price_since_entry - (1.5 * current_atr)
            if current_price < trailing_stop:
                return True, "Trailing Exit (Trend exhausted)"
                
        return False, "Hold"
