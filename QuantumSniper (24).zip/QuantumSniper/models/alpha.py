import pandas as pd
import numpy as np

class AlphaModels:
    def __init__(self):
        pass

    def calculate_macro_bias(self, df_bars, slow_window=200, fast_window=50):
        """
        تحديد الانحياز الأكبر (HTF Bias) لعدم الوقوف في وجه القطار.
        """
        ema_fast = df_bars['close'].ewm(span=fast_window, min_periods=1).mean()
        ema_slow = df_bars['close'].ewm(span=slow_window, min_periods=1).mean()
        # نطلب أن يكون الماكرو صاعداً أو في مرحلة تجميع (هامش 0.5% لأسفل مقبول)
        return ema_fast > (ema_slow * 0.995)

    def calculate_flexible_swing_lows(self, df_bars, window=30):
        """
        المفهوم المرن للسيولة (Elastic Liquidity Zones)
        بدلاً من نقطة جامدة، نحدد أدنى قاع حديث ونعطيه هامشاً (Buffer).
        """
        recent_low = df_bars['low'].rolling(window=window, min_periods=1).min().shift(1)
        # 5 نقاط أساس كمنطقة سماحية (Tolerance Zone) - 0.05%
        buffer_zone = recent_low * 1.0005 
        return recent_low, buffer_zone

    def calculate_ofi_ratio(self, df_bars):
        """
        صافي تدفق الأوامر كنسبة محصورة بين -1 و 1.
        """
        return (df_bars['buy_vol'] - df_bars['sell_vol']) / (df_bars['total_vol'] + 1e-9)

    def calculate_vpin(self, df_bars, window=50):
        """مؤشر سمية الأوامر اللحظية"""
        abs_imbalance = (df_bars['buy_vol'] - df_bars['sell_vol']).abs()
        rolling_imb = abs_imbalance.rolling(window=window, min_periods=1).sum()
        rolling_vol = df_bars['total_vol'].rolling(window=window, min_periods=1).sum()
        return rolling_imb / (rolling_vol + 1e-9)

    def generate_signals(self, df_bars):
        df = df_bars.copy()
        
        # 1. المؤشرات الهجينة
        df['macro_bullish'] = self.calculate_macro_bias(df)
        df['swing_low_exact'], df['swing_low_zone'] = self.calculate_flexible_swing_lows(df)
        df['ofi'] = self.calculate_ofi_ratio(df)
        df['vpin'] = self.calculate_vpin(df)
        df['atr'] = (df['high'] - df['low']).rolling(14, min_periods=1).mean()
        
        # 2. الحدث الأول: سحب السيولة بمرونة (Liquidity Purge)
        # إذا دخل السعر منطقة القاع أو كسره
        df['is_purge'] = df['low'] <= df['swing_low_zone']
        
        # 3. الحدث الثاني: الانفجار المؤسساتي (Displacement)
        # إغلاق قوي + تدفق أوامر شرائي هائل (> 60% من الحجم الكلي للشمعة هو شراء ماركت)
        df['is_displacement'] = (df['close'] > df['open']) & (df['ofi'] > 0.60)
        
        # =========================================================================
        # 🧠 ICT Cognitive Engine (محرك الإدراك الزمني)
        # =========================================================================
        
        buy_signals = np.zeros(len(df))
        stop_levels = np.zeros(len(df))
        
        # نبحث عن تسلسل الأحداث (Purge -> Displacement -> Pullback)
        for i in range(5, len(df)):
            if not df['macro_bullish'].iloc[i]:
                continue # نتجاهل السوق المنهار
                
            # هل السعر الحالي في حالة تصحيح (Pullback)؟
            if df['close'].iloc[i] < df['close'].iloc[i-1]:
                
                # فحص آخر 10 شموع للبحث عن قصة ICT
                window_purge = df['is_purge'].iloc[i-10:i]
                window_disp = df['is_displacement'].iloc[i-10:i]
                
                # يجب أن نجد Purge، ثم يليه Displacement
                if window_purge.any() and window_disp.any():
                    idx_purge = window_purge[::-1].idxmax() # آخر Purge
                    idx_disp = window_disp[::-1].idxmax()   # آخر Displacement
                    
                    # الـ Displacement يجب أن يحدث *بعد* أو *مع* الـ Purge
                    if idx_disp >= idx_purge:
                        
                        # הتأكيد النهائي (Confirmation):
                        # 1. السعر الحالي يتراجع ليلمس نصف شمعة الـ Displacement (Order Block Mitigation)
                        ob_midpoint = (df['high'].iloc[idx_disp] + df['low'].iloc[idx_disp]) / 2.0
                        if df['low'].iloc[i] <= ob_midpoint:
                            
                            # 2. الـ VPIN (السمية) في شمعة الهبوط الحالية منخفض (أقل من 0.40)
                            # أي أن ההبوط הוא מجرد جني أرباح وليس بيعاً حوتياً!
                            if df['vpin'].iloc[i] < 0.40:
                                buy_signals[i] = 1
                                # נحفظ קاع הסיولة الحقيقي لنضع تحته הـ Stop Loss
                                stop_levels[i] = df['swing_low_exact'].iloc[idx_purge]
                                
        df['buy_signal'] = buy_signals
        df['structural_stop_level'] = stop_levels
        
        return df
