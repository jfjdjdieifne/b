import numpy as np
import pandas as pd
from numba import njit

@njit
def generate_dollar_volume_bars(timestamps, prices, sizes, is_sell_initiator, target_dollar_volume):
    n = len(prices)
    out_ts = np.zeros(n, dtype=np.int64)
    out_open = np.zeros(n, dtype=np.float64)
    out_high = np.zeros(n, dtype=np.float64)
    out_low = np.zeros(n, dtype=np.float64)
    out_close = np.zeros(n, dtype=np.float64)
    out_buy_vol = np.zeros(n, dtype=np.float64)
    out_sell_vol = np.zeros(n, dtype=np.float64)
    
    bar_idx = 0
    current_dollar_vol = 0.0
    current_buy_vol = 0.0
    current_sell_vol = 0.0
    current_high = -np.inf
    current_low = np.inf
    current_open = 0.0
    is_new_bar = True
    
    for i in range(n):
        price = prices[i]
        size = sizes[i]
        dollar_size = price * size 
        is_sell = is_sell_initiator[i]
        
        if is_new_bar:
            current_open = price
            current_high = price
            current_low = price
            is_new_bar = False
            
        current_high = max(current_high, price)
        current_low = min(current_low, price)
        
        vol_needed = target_dollar_volume - current_dollar_vol
        
        if dollar_size < vol_needed:
            current_dollar_vol += dollar_size
            if is_sell:
                current_sell_vol += dollar_size
            else:
                current_buy_vol += dollar_size
        else:
            fill_size = vol_needed
            remainder = dollar_size - vol_needed
            
            if is_sell:
                current_sell_vol += fill_size
            else:
                current_buy_vol += fill_size
                
            out_ts[bar_idx] = timestamps[i]
            out_open[bar_idx] = current_open
            out_high[bar_idx] = current_high
            out_low[bar_idx] = current_low
            out_close[bar_idx] = price
            out_buy_vol[bar_idx] = current_buy_vol
            out_sell_vol[bar_idx] = current_sell_vol
            bar_idx += 1
            
            while remainder >= target_dollar_volume:
                out_ts[bar_idx] = timestamps[i]
                out_open[bar_idx] = price
                out_high[bar_idx] = price
                out_low[bar_idx] = price
                out_close[bar_idx] = price
                if is_sell:
                    out_buy_vol[bar_idx] = 0.0
                    out_sell_vol[bar_idx] = target_dollar_volume
                else:
                    out_buy_vol[bar_idx] = target_dollar_volume
                    out_sell_vol[bar_idx] = 0.0
                bar_idx += 1
                remainder -= target_dollar_volume
                
            current_dollar_vol = remainder
            if is_sell:
                current_sell_vol = remainder
                current_buy_vol = 0.0
            else:
                current_buy_vol = remainder
                current_sell_vol = 0.0
                
            current_open = price
            current_high = price
            current_low = price
            is_new_bar = (current_dollar_vol == 0)
                 
    return (out_ts[:bar_idx], out_open[:bar_idx], out_high[:bar_idx], 
            out_low[:bar_idx], out_close[:bar_idx], 
            out_buy_vol[:bar_idx], out_sell_vol[:bar_idx])

def create_quantum_bars(tick_df):
    ts = tick_df['timestamp'].values
    prices = tick_df['price'].values
    sizes = tick_df['size'].values
    is_sell = tick_df['is_buyer_maker'].values
    
    total_dollar_volume = np.sum(prices * sizes)
    
    # ---------------------------------------------------------------------------------
    # الإصلاح الجذري 2: تكبير الصناديق لسحق الضوضاء (Noise Filtering)
    # خفضنا الرقم إلى 400. هذا سيجعل الشمعة الواحدة تبتلع 20 إلى 40 مليون دولار 
    # في البيتكوين. ستقضي تماماً على الشذوذ الميكروي ותعطي مساحة لـ ATR هائل ورؤية أوضح للترند.
    # ---------------------------------------------------------------------------------
    num_bars_target = 400.0
    dynamic_target_volume = total_dollar_volume / num_bars_target
    
    print(f"[*] Intelligent Data Compression: Targeting ~{int(num_bars_target)} Bars")
    print(f"    -> Dynamic Bar Size set to: ${dynamic_target_volume:,.2f}")

    t, o, h, l, c, bv, sv = generate_dollar_volume_bars(ts, prices, sizes, is_sell, dynamic_target_volume)
    
    df_bars = pd.DataFrame({
        'timestamp': t,
        'open': o,
        'high': h,
        'low': l,
        'close': c,
        'buy_vol': bv,
        'sell_vol': sv,
        'total_vol': bv + sv,
    })
    
    df_bars['ofi_ratio'] = (df_bars['buy_vol'] - df_bars['sell_vol']) / (df_bars['total_vol'] + 1e-9)
    df_bars['datetime'] = pd.to_datetime(df_bars['timestamp'], unit='ms', errors='coerce')
    
    return df_bars
