import os
import glob
import pandas as pd
import numpy as np
from data.data_processor import create_quantum_bars
from models.alpha import AlphaModels
from models.risk import RiskManager
from engine.simulator import QuantumSimulator

def scan_for_binance_csv(data_dir="data"):
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    return glob.glob(os.path.join(data_dir, "*.csv"))

def load_local_binance_data(csv_path):
    print(f"\n[*] Loading REAL Binance Data from: {csv_path}...")
    try:
        df = pd.read_csv(csv_path, header=None)
    except Exception as e:
        print(f"[!] Error reading the CSV file: {e}")
        return pd.DataFrame() 
        
    df = df[[5, 1, 2, 6]]
    df.columns = ['timestamp', 'price', 'size', 'is_buyer_maker']
    
    df['timestamp'] = pd.to_numeric(df['timestamp'], errors='coerce')
    df = df.dropna(subset=['timestamp'])
    df['timestamp'] = df['timestamp'].astype(np.int64)
    
    mask_micro = df['timestamp'] > 10_000_000_000_000 
    df.loc[mask_micro, 'timestamp'] = df.loc[mask_micro, 'timestamp'] // 1000
    
    mask_valid = (df['timestamp'] > 1262304000000) & (df['timestamp'] < 2051222400000)
    df = df[mask_valid]
    
    df['price'] = df['price'].astype(float)
    df['size'] = df['size'].astype(float)
    df['is_buyer_maker'] = df['is_buyer_maker'].astype(bool)
    
    df = df.sort_values('timestamp').reset_index(drop=True)
    print(f"[*] SUCCESS: Loaded {len(df):,} LIVE TICK events into memory!")
    return df

def interactive_file_selector():
    files = scan_for_binance_csv("data")
    if not files:
        print("\n[!] CRITICAL ERROR: No CSV files found in the 'data' folder.")
        return None
    if len(files) == 1:
        print(f"\n[*] Auto-detected data file: {files[0]}")
        return files[0]
        
    print("\n" + "="*60)
    print(" 📂 MULTIPLE DATA FILES DETECTED 📂")
    print("="*60)
    for i, file_path in enumerate(files):
        size_mb = os.path.getsize(file_path) / (1024 * 1024)
        print(f"  [{i+1}] {os.path.basename(file_path)} (Size: {size_mb:.1f} MB)")
        
    while True:
        try:
            choice = int(input(f"\nSelect a file to load (1-{len(files)}): "))
            if 1 <= choice <= len(files):
                return files[choice-1]
            print("[!] Invalid choice. Try again.")
        except ValueError:
            print("[!] Please enter a valid number.")

def run_pipeline(csv_file_path):
    df_ticks = load_local_binance_data(csv_file_path)
    if df_ticks.empty:
        return None, None, []
        
    print(f"\n[*] Processing Ticks into DOLLAR-Volume Bars (Numba JIT Engine running)...")
    df_bars = create_quantum_bars(df_ticks)
    
    print(f"\n[*] Calculating Probabilistic Quant Indicators (Fuzzy Logic, HMM Proxies, Smoothing)...")
    alpha = AlphaModels()
    df_signals = alpha.generate_signals(df_bars)
    
    buy_bars = df_signals[df_signals['buy_signal'] == 1]
    if not buy_bars.empty:
        print(f"\n[*] SUCCESS: Context-Aware Engine found {len(buy_bars)} Sniping Opportunities.")
    else:
        print("\n[!] STANDBY: Engine found 0 opportunities. Market did not meet probabilistic conviction scores.")
        
    risk_manager = RiskManager(max_hold_bars=10)
    simulator = QuantumSimulator(initial_capital=10000.0)
    
    results_df, detailed_log = simulator.run_simulation(df_signals, risk_manager)
    
    return results_df, simulator, detailed_log

def print_backtest_stats(results_df, simulator):
    print("\n" + "="*60)
    print(" 📊 PERFORMANCE METRICS (Probabilistic Payoff) 📊")
    print("="*60)
    
    if len(results_df) > 0:
        trades = results_df[results_df['type'] == 'SELL']
        
        if len(trades) > 0:
            win_rate = (trades['pnl_pct'] > 0).mean() * 100 
            total_pnl = simulator.capital - simulator.initial_capital
            
            # Gross approximation based on dynamic sizing (10% to 30%)
            gross_profit = trades[trades['pnl_pct'] > 0]['pnl_pct'].sum() * (simulator.initial_capital * 0.20)
            gross_loss = abs(trades[trades['pnl_pct'] < 0]['pnl_pct'].sum() * (simulator.initial_capital * 0.20))
            profit_factor = gross_profit / gross_loss if gross_loss != 0 else float('inf')
            
            equity_curve = results_df[results_df['type'] == 'SELL']['capital']
            peak = equity_curve.cummax()
            drawdown = (equity_curve - peak) / peak
            max_drawdown = drawdown.min() * 100 if not drawdown.empty else 0
            
            print(f"Final Capital:   ${simulator.capital:,.2f}")
            print(f"Net PnL:         ${total_pnl:,.2f} ({(total_pnl/simulator.initial_capital)*100:.2f}%)")
            print(f"Total Trades:    {len(trades)}")
            print(f"Win Rate:        {win_rate:.2f}%")
            print(f"Profit Factor:   {profit_factor:.2f}")
            print(f"Max Drawdown:    {max_drawdown:.2f}%")
            
            # حفظ تلقائي لملف הلوج
            with open("detailed_trade_logs.txt", 'w') as f:
                for log in simulator.detailed_log:
                    f.write(log + "\n")
            print("\n[*] Full detailed trade logic exported to -> detailed_trade_logs.txt")
        else:
            print("[!] Positions are currently OPEN.")
    else:
        print("[!] No trades were executed.")

def interactive_menu():
    results_df, simulator, detailed_log = None, None, []
    
    while True:
        print("\n" + "="*60)
        print(" 🧠 THE MASTER QUANTUM ENGINE - COMMAND CENTER 🧠")
        print("="*60)
        print("  [1] Load Data & Run Fuzzy Logic Backtest")
        print("  [2] View Latest Trade Log (The 'Why' and 'How')")
        print("  [3] Export Full Trade History to CSV")
        print("  [4] Exit")
        print("="*60)
        
        choice = input("Enter your choice (1-4): ")
        
        if choice == '1':
            csv_file = interactive_file_selector()
            if csv_file:
                results_df, simulator, detailed_log = run_pipeline(csv_file)
                if simulator:
                    print_backtest_stats(results_df, simulator)
                    
        elif choice == '2':
            if not detailed_log:
                print("\n[!] Please run the Backtest (Option 1) first to generate logs.")
            else:
                print("\n" + "="*70)
                print(" 📜 QUANTUM LOGIC & TRADE JUSTIFICATIONS 📜")
                print("="*70)
                # عرض آخر 10 أسطر כي لا يزدحم הکونسول، بينما الـ txt یحفظ الكُل
                for log in detailed_log[-10:]: 
                    print(log)
                    
        elif choice == '3':
            if results_df is None or results_df.empty:
                print("\n[!] Please run the Backtest (Option 1) first.")
            else:
                filename = "quantum_results.csv"
                results_df.to_csv(filename, index=False)
                print(f"\n[*] SUCCESS: Trade history exported to -> {filename}")
                
        elif choice == '4':
            print("\n[*] Shutting down Quantum Engine. Stay Asymmetric.")
            break
        else:
            print("\n[!] Invalid choice. Please try again.")

if __name__ == "__main__":
    # تشغيل لوحة التحكم התفاعلية
    interactive_menu()
