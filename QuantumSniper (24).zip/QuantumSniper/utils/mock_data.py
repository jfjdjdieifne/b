import numpy as np
import pandas as pd

def generate_realistic_tick_data(num_ticks=1000000):
    print("[*] Generating 1,000,000 Microstructure Ticks for Audit...")
    np.random.seed(42)
    
    start_time = 1672531200000
    time_increments = np.random.exponential(scale=50, size=num_ticks).astype(np.int64)
    timestamps = start_time + np.cumsum(time_increments)
    
    returns = np.random.normal(0.000001, 0.00001, num_ticks)
    
    crash_start = 800000
    crash_end = 805000     
    reversal_end = 810000  

    # الهبوط הקوي لكسر הـ VAL
    returns[crash_start:crash_end] -= 0.005 
    
    # الارتداد החوتي העنيف 
    returns[crash_end:reversal_end] += 0.007 
    
    prices = 20000.0 * np.exp(np.cumsum(returns))
    
    is_buyer_maker = np.where(returns < 0, 
                              np.random.choice([True, False], p=[0.7, 0.3], size=num_ticks),
                              np.random.choice([True, False], p=[0.3, 0.7], size=num_ticks))
                              
    is_buyer_maker[crash_end:reversal_end] = np.random.choice([True, False], p=[0.01, 0.99], size=(reversal_end - crash_end))
    
    base_sizes = np.random.exponential(scale=1.0, size=num_ticks) 
    
    df = pd.DataFrame({
        'timestamp': timestamps,
        'price': prices,
        'size': base_sizes,
        'is_buyer_maker': is_buyer_maker
    })
    
    return df
