import os
import glob
import pandas as pd
import numpy as np

def scan_for_binance_csv(data_dir="data"):
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    return glob.glob(os.path.join(data_dir, "*.csv"))

def load_local_binance_data(csv_path):
    print(f"\n[*] Loading REAL Binance Data from: {csv_path}...")
    
    try:
        df = pd.read_csv(csv_path, header=None)
    except Exception as e:
        print(f"[!] Error reading the CSV file: {e}")
        return pd.DataFrame() 
        
    df = df[[5, 1, 2, 6]]
    df.columns = ['timestamp', 'price', 'size', 'is_buyer_maker']
    
    df['price'] = df['price'].astype(float)
    df['size'] = df['size'].astype(float)
    
    # ---------------------------------------------------------------------------------
    # الإصلاح المعماري الجذري: "التحويل الذكي للتوقيت" (Smart Timestamp Casting)
    # ---------------------------------------------------------------------------------
    # في بايثون، عندما يتم تخزين رقم كبير جداً في CSV ويقرأه Pandas،
    # قد يقوم بتحويله إلى Scientific Notation أو Float.
    # الخطأ حدث لأننا قمنا بمقارنة الأرقام قبل معالجة نوعها (Type Casting).
    
    # أولاً: نجبر العامود أن يكون رقماً (Numeric) ونتجاهل النصوص التالفة
    df['timestamp'] = pd.to_numeric(df['timestamp'], errors='coerce')
    
    # ثانياً: نحذف الأسطر التي أصبحت NaN
    df = df.dropna(subset=['timestamp'])
    
    # ثالثاً والأهم: نحول الرقم إلى صيغة صحيحة (Int64) لنتمكن من مقارنته
    df['timestamp'] = df['timestamp'].astype(np.int64)
    
    # رابعاً: الفحص الذكي للمايكروثانية 
    # (إذا كان الرقم أكبر من 10 تريليون، فهو غالباً بالمايكروثانية)
    mask_micro = df['timestamp'] > 10_000_000_000_000 
    df.loc[mask_micro, 'timestamp'] = df.loc[mask_micro, 'timestamp'] // 1000
    
    # خامساً: الآن فقط، نقوم بالحماية من الأرقام الشاذة (السنة < 2010 أو > 2035)
    # 2010 = 1262304000000 ms
    # 2035 = 2051222400000 ms
    mask_valid = (df['timestamp'] > 1262304000000) & (df['timestamp'] < 2051222400000)
    
    invalid_rows = len(df) - mask_valid.sum()
    if invalid_rows > 0:
        print(f"[!] WARNING: Found {invalid_rows} out-of-bounds timestamps. Dropping them.")
    
    df = df[mask_valid]
    df['is_buyer_maker'] = df['is_buyer_maker'].astype(bool)
    
    print("[*] Chronological sorting (Critical for Quantum Bars)...")
    df = df.sort_values('timestamp').reset_index(drop=True)
    
    print(f"[*] SUCCESS: Loaded {len(df):,} VALID LIVE TICK events into memory!")
    return df
