# Video Factory — Secure Kaggle MVP

A secure, resumable orchestrator that launches an official Kaggle GPU kernel to render one 5-second Wan/FastWan scene. Secrets are never stored in source code.

## What this MVP automates

1. A scene job is placed in `jobs/`.
2. GitHub Actions wakes every 15 minutes (no always-on server needed).
3. The orchestrator launches a private Kaggle GPU kernel using the official Kaggle CLI.
4. Kaggle installs WanGP, renders a 5-second scene, and exposes it as kernel output.
5. A later orchestrator tick downloads the MP4 to the Actions runner and marks the job done.

The current MVP proves secure orchestration. Production extensions still required: persistent Wan weights as a Kaggle Model/Dataset, object storage for MP4 files, story/script generation, visual QA, assembly, TTS, and YouTube OAuth publishing.

## Security first

Never paste tokens into chat or code. Revoke any token already exposed.

Create repository secrets:

- `KAGGLE_API_TOKEN`
- `KAGGLE_USERNAME`

The code supports **one authorized Kaggle account**. It does not rotate free accounts or bypass platform quotas.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Fill `.env` locally without committing it.

## Create a 5-second scene job

Text-to-video:

```bash
python scripts/new_job.py \
  "A continuous cinematic tracking shot of a child walking toward a mysterious glowing door in a foggy forest. The child takes two natural steps, plants sway, fog drifts, and the door begins to open."
```

Image-to-video, using a publicly reachable image URL:

```bash
python scripts/new_job.py \
  "The child walks naturally toward the door; the handle turns and the door opens." \
  --image-url "https://example.com/master.png"
```

Commit the new JSON under `jobs/`, then manually run the GitHub workflow or wait for cron.

## GitHub deployment

1. Create a GitHub repository and push this project.
2. Add `KAGGLE_API_TOKEN` and `KAGGLE_USERNAME` under Settings → Secrets and variables → Actions.
3. Enable Actions.
4. Use `workflow_dispatch` for the first test.

## Important limitations

- Kaggle availability and quotas are not guaranteed.
- The first worker version downloads models unless you attach a persistent Kaggle Model/Dataset.
- GitHub Actions should not store large videos in Git. Add object storage or upload directly to YouTube in the production phase.
- Full unattended publishing requires a one-time YouTube OAuth setup and robust content/rights checks.
