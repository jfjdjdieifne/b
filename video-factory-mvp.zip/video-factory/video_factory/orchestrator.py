from __future__ import annotations

import json
import logging
from pathlib import Path

from video_factory.config import ROOT, load_config
from video_factory.jobs import SceneJob
from video_factory.providers import KaggleProvider

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
LOG = logging.getLogger("video-factory")


def job_files() -> list[Path]:
    return sorted((ROOT / "jobs").glob("*.json"))


def run_once() -> int:
    config = load_config()
    provider = KaggleProvider(config)
    jobs = [(path, SceneJob.load(path)) for path in job_files()]

    active = [(p, j) for p, j in jobs if j.status in {"submitted", "running"}]
    if active:
        path, job = active[0]
        state = provider.status()
        LOG.info("Job %s provider status: %s", job.id, state)
        if state in {"pending", "running"}:
            job.status = "running"
            job.save(path)
            return 0
        if state == "complete":
            try:
                output = provider.collect(job)
                job.status = "done"
                job.output_path = str(output.relative_to(ROOT))
                job.error = None
            except Exception as exc:
                job.status = "failed"
                job.error = str(exc)
            job.save(path)
            return 0
        job.status = "failed"
        job.error = "Kaggle run failed"
        job.save(path)
        return 1

    queued = [(p, j) for p, j in jobs if j.status == "queued"]
    if not queued:
        LOG.info("No queued jobs")
        return 0

    path, job = queued[0]
    if job.attempt >= job.max_attempts:
        job.status = "blocked"
        job.error = "Retry limit reached"
        job.save(path)
        return 1

    job.attempt += 1
    job.provider = "kaggle"
    try:
        job.provider_job_id = provider.submit(job)
        job.status = "submitted"
        job.error = None
    except Exception as exc:
        job.status = "failed" if job.attempt >= job.max_attempts else "queued"
        job.error = str(exc)
    job.save(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(run_once())
