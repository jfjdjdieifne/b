"""Video Factory: secure, resumable video-job orchestration."""
__version__ = "0.1.0"
