from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

from video_factory.config import ROOT, required_secret
from video_factory.jobs import SceneJob


class KaggleProvider:
    """One authorized Kaggle account, controlled through Kaggle's official CLI."""

    def __init__(self, config: dict[str, Any]):
        self.config = config
        self.username = required_secret("KAGGLE_USERNAME")
        self.token = required_secret("KAGGLE_API_TOKEN")
        self.slug = os.getenv("KAGGLE_KERNEL_SLUG", config["kaggle"]["kernel_slug"])
        self.kernel_id = f"{self.username}/{self.slug}"
        self.worker_dir = ROOT / "workers" / "kaggle"
        self.runtime_dir = ROOT / ".work" / "kaggle"
        self.env = os.environ.copy()
        self.env["KAGGLE_API_TOKEN"] = self.token

    def _run(self, args: list[str], timeout: int = 300) -> subprocess.CompletedProcess:
        return subprocess.run(
            args,
            env=self.env,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=True,
        )

    def submit(self, job: SceneJob) -> str:
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        for name in ("kernel.py",):
            shutil.copy2(self.worker_dir / name, self.runtime_dir / name)

        (self.runtime_dir / "job_payload.json").write_text(
            json.dumps(job.__dict__, ensure_ascii=False, indent=2)
        )
        metadata = {
            "id": self.kernel_id,
            "title": "Wan Video Worker",
            "code_file": "kernel.py",
            "language": "python",
            "kernel_type": "script",
            "is_private": True,
            "enable_gpu": True,
            "enable_internet": True,
            "dataset_sources": [],
            "competition_sources": [],
            "kernel_sources": [],
            "model_sources": [],
        }
        (self.runtime_dir / "kernel-metadata.json").write_text(json.dumps(metadata, indent=2))
        self._run(
            [
                "kaggle", "kernels", "push", "-p", str(self.runtime_dir),
                "--accelerator", self.config["kaggle"]["accelerator"],
                "--timeout", "300",
            ],
            timeout=360,
        )
        return self.kernel_id

    def status(self) -> str:
        result = self._run(["kaggle", "kernels", "status", self.kernel_id])
        text = (result.stdout + "\n" + result.stderr).lower()
        if "complete" in text:
            return "complete"
        if "error" in text or "cancel" in text:
            return "failed"
        if "running" in text:
            return "running"
        return "pending"

    def collect(self, job: SceneJob) -> Path:
        out_dir = ROOT / ".work" / "downloads" / job.id
        out_dir.mkdir(parents=True, exist_ok=True)
        self._run(
            ["kaggle", "kernels", "output", self.kernel_id, "-p", str(out_dir), "--force"],
            timeout=900,
        )
        result_file = out_dir / "result.json"
        if result_file.exists():
            result = json.loads(result_file.read_text())
            if result.get("status") != "done":
                raise RuntimeError(result.get("error", "Kaggle worker failed"))
        videos = sorted(out_dir.rglob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not videos:
            raise RuntimeError("Kaggle completed but returned no MP4")
        final_dir = ROOT / "outputs" / job.id
        final_dir.mkdir(parents=True, exist_ok=True)
        final = final_dir / "scene.mp4"
        shutil.copy2(videos[0], final)
        return final
