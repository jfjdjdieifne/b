# README — LAST STATE (for independent auditor)

Project: Causal Trading Intelligence
Snapshot date: 2026-09-15

## Lifecycle state

```text
Stage 1        CLOSED
Stage 2        CLOSED
Stage 3        CLOSED
Stage 4A       CLOSED
Stage 4B-1     CLOSED
Stage 4B-2     CLOSED                 (independent final audit: ACCEPTED FOR CLOSURE; owner-authorized CLOSURE ONLY executed)
Stage 4C-1     IMPLEMENTED — PENDING AUDIT   (THIS SNAPSHOT — newest active artifact)
Stage 4C-2     NOT STARTED            (HTF structure / transitions / MTF confluence — blocked on a legitimate confirmation-policy contract)
```

## Latest active module

Module: 6.2A-4 V1 Stage 4C-1
Name: Shared causal HTF raw observation surface (completed HTF OHLC + optional cadence-grid
coverage metadata + causal as-of projection). Derived-only frames, no market passthrough.
Status: IMPLEMENTED — PENDING AUDIT (builder does not close; no closure docs/manifest change yet).

Scope V1 (4C-1): completed HTF bucket observations from CLOSED 5.1, cadence-grid set-comparison
coverage (optional), strict causal as-of projection, exact-boundary same-batch semantics,
four/five coverage statuses with no feed/market-completeness claim, prefix invariance under
future append. NO HTF structure, NO transitions, NO 5.2 confluence production, NO quantile /
swing policy / default, NO HTF volume, NO HTF liquidity/OB/FVG/dealing-range, NO model /
geometry / execution / PnL / signals.

## Artifacts for audit (SHA-256) — the two NEW files

```text
e8fa0854a89ac2ec97c6cc691720860babf9d918f1746d489ed0093b08590475  trading_project/src/trading_system/research/trajectory/trajectory_stage4c.py
7bfe704a89c6d2155521556fc657cdaf5e2fa48f0a83dd86536f57927f32bd6c  trading_project/tests/test_trajectory_stage4c.py
```

Public API under audit: `HtfScaleSpec`, `CadenceGridContract`, `Stage4CHtfScaleSurface`,
`Stage4C1PrefixBinding`, `build_htf_scale_surface`, `verify_surface_integrity`,
`project_htf_scale_prefix`, `trajectory_stage4c_manifest`.
Dedicated tests: 36. Full suite this snapshot: **1000 collected / 1000 passed**
(964 post-4B-2-closure baseline + 36 new).

## Validation (this snapshot)

```text
Stage 4C-1 targeted tests : 36 / 36 passed
Full suite                : 1000 collected / 1000 passed
sha256sum -c MANIFEST.sha256 : 170 / 170 OK
MANIFEST.sha256 SHA-256   : 1a21753f2de85bfbb56d0ae2ba4bcc7a5273cb9c42a2e6b9010d4a57ac469a12
```

MANIFEST is intentionally UNCHANGED from the Stage 4B-2 CLOSED baseline: the two Stage 4C-1
files are not closed, so (per project constitution) they are NOT listed in MANIFEST yet. They
enter MANIFEST only at a future owner-authorized closure (+ seal + milestone). MANIFEST being
170/170 with the two new files present-but-untracked is the EXPECTED pre-audit state, not a
defect.

## Stage 4B-2 closure (already completed before this snapshot)

```text
Independent final audit decision: ACCEPTED FOR CLOSURE
Closure (CLOSURE ONLY) changed docs + MANIFEST only; src/tests were not touched during closure.
MANIFEST went 166 -> 170 lines (added 4B-2 src + test + seal + milestone; re-hashed STATUS + FINAL_VALIDATION).
New release files:
  trading_project/docs/releases/MILESTONE_6_2A_4_V1_STAGE4B2_CLOSED.md
  trading_project/docs/releases/MODULE_6_2A_4_V1_STAGE4B2_ACCEPTED_SRC_TESTS.sha256
4B-2 accepted hashes (now inside MANIFEST):
  ce6fe481064c672538df63f9560493506c3b532de0de30714f71c8c4cf9ab563  trajectory_stage4b2.py
  3315a6ac5c427b413f6eb510abe2486839b21d3c5a2bd0c8fde1beccf21d620b  test_trajectory_stage4b2.py
```

## Key causal-semantic positions the auditor should attack

1. `first_observed_asof_*` (a CLOSED 5.1 field) is explicitly defined as sealed-timeline
   PROJECTABILITY only — NOT feed-arrival provenance and NOT historical market availability.
   A dedicated test forbids semantic inflation in API/manifest/docstrings.
2. Exact boundary: a completed bucket is projectable at the observed LTF row whose timestamp
   equals the bucket close (interval (start, end]) only in phase COMPLETED_ROW_AVAILABLE on the
   same timeline; BAR_PRE_CLOSE rejected; close_batch_order_unknown=True; no intra-batch
   chronology asserted.
3. In-progress (not-yet-observed) bucket and its high/low/close (incl. spikes) are invisible;
   projection is gated by the first OBSERVED as-of position, so a feed gap delays visibility to
   the first observed row at/after the close (fixture proves theoretical 08:15 vs observed 08:17).
4. Coverage compares timestamp SETS against an optional declared grid (never counts alone), and
   claims completeness only of sealed observations vs the declared grid — never feed/market
   completeness. Partial bucket OHLC remains observation truth with metadata (no fill, no drop).
5. All frames are derived-only with exact whole-frame schema equality (no passthrough injection
   surface). Dynamic mirror rejects a CLOSED 5.1 that adds/drops/reorders a public column.
6. Mutation proof (documented in the builder report): changing the boundary rule
   right->left in an external copy fails test_exact_boundary_phase_and_post_boundary_stability;
   the probe was external and deleted; the final artifact is the correct (right) rule.

## Builder-declared deviations / limitations (see BUILDER_REPORT for full list)

- No `mirror_verification_hash` exists (owner correction): a pass/fail is not a hashable witness;
  mirroring is enforced live by schema equality and projection recomputation.
- The observed-asof walk-back guard is semantically redundant over genuine CLOSED 5.1 outputs
  (proven by an external deletion probe) but is retained as defense-in-depth.
- Sealed-timeline presence of optional `volume` changes timeline/surface identity legitimately;
  the Stage 4C-1 DERIVED content is byte-identical and never carries volume.
- Coherent witness-token forgery remains outside self-integrity scope (same accepted convention
  as 4A/4B-1/4B-2); derived-only whole-frame equality plus content hashes plus projection
  recomputation narrow it materially.
- Historical generating-input provenance remains NOT_CERTIFIED / UNVERIFIABLE.

## CLOSED modules (protected — must remain unchanged; all inside MANIFEST 170/170)

```text
Stage 4B-2: ce6fe481…ab563 / 3315a6ac…d620b
Stage 4B-1: bc393fe4ffb8dec9bdb16e4ae8e0036f22faefdecc8dc67345a5a881207bb708  trajectory_stage4b1.py
             7e0c572d56074775b807278485a31a02ed6a6ec8e5bc941c638c586e2a401271  test_trajectory_stage4b1.py
```

## Open / not done

- Stage 4C-1 NOT accepted / NOT closed — independent read-only audit required now.
- Stage 4C-2 NOT STARTED (needs a legitimate, non-invented swing confirmation contract; an
  empirical quantile is calibration and is forbidden inside Raw Future Truth).
- No descriptors / estimands / ML / scoring / geometry / execution / PnL / signals.
- RESEARCH-DEBT-020 … RESEARCH-DEBT-025 remain OPEN.

## Reports

See `reports/` — latest relevant:
- `BUILDER_REPORT_6_2A_4_V1_STAGE4C1.md` (this build, deviations, mutation proof)
- `CLOSURE_REPORT_6_2A_4_V1_STAGE4B2.md` (prior owner-authorized closure)
- `AUDIT_6_2A_4_V1_STAGE4B2_FINAL.md` (the independent ACCEPTED FOR CLOSURE decision)
- earlier 4B-2 design/patch/builder reports for history

## Reproduce

```bash
cd trading_project
python -m pip install -e ".[dev]"      # if not already installed
sha256sum -c MANIFEST.sha256           # expect 170/170 OK
PYTHONPATH=src python3 -m pytest tests/test_trajectory_stage4c.py -o addopts="" -q   # 36 passed
PYTHONPATH=src python3 -m pytest -o addopts="" -q                                   # 1000 passed
```
