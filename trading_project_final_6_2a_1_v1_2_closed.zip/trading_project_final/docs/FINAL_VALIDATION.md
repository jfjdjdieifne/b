# Current Authoritative Validation — Through Module 6.2A-1 V1.2 Closure

## Collected tests

```text
tests/test_absorption.py: 18
tests/test_causal_adaptive_smoothing.py: 37
tests/test_causal_htf.py: 10
tests/test_causal_percentile.py: 13
tests/test_confluence_matrix.py: 9
tests/test_dealing_range.py: 11
tests/test_dynamic_volatility.py: 20
tests/test_evidence_vector.py: 54
tests/test_fvg.py: 11
tests/test_liquidity_map.py: 20
tests/test_narrative.py: 48
tests/test_order_blocks.py: 12
tests/test_research_hashing.py: 14
tests/test_research_information_time.py: 16
tests/test_research_manifest_identity.py: 17
tests/test_research_outcome_integration.py: 2
tests/test_research_outcome_observer.py: 55
tests/test_research_visibility.py: 44
tests/test_session_context.py: 26
tests/test_structural_breaks.py: 25
tests/test_swing_detector.py: 28
tests/test_swing_sequence.py: 31
tests/test_volume_delta.py: 19
TOTAL: 540
```

## Exact pytest result

```text
........................................................................ [ 13%]
........................................................................ [ 26%]
........................................................................ [ 40%]
........................................................................ [ 53%]
........................................................................ [ 66%]
........................................................................ [ 80%]
........................................................................ [ 93%]
....................................                                     [100%]
```

```text
540 collected
540 passed
exit code 0
```

## Status

```text
Layers 0–5: CLOSED
D1/D1.1: PRELIMINARY SOURCE AUDIT — ACCEPTED / APPLIED
Module 6.1A V1.3: CLOSED
Module 6.1B V1.2: CLOSED
Module 6.2A-0 V1.2: CLOSED
Module 6.2A-1 V1.2: CLOSED
Module 6.2A-1 history: V1 -> V1.1 -> V1.2 -> CLOSED
Module 6.2A-2: NOT STARTED
Scorer / model: NOT STARTED
```

## Module 6.2A-1 closure boundary

Closure certifies only, within tested scope:

- factual post-hypothesis outcome observation;
- as-of censoring facts;
- non-executable reference-mark timing;
- post-creation path segmentation;
- exact mature outcome identity;
- future/as-of isolation;
- absence of trade interpretation.

Closure does not certify:

- training eligibility;
- an estimator;
- a model;
- predictive edge;
- profitability;
- scorer;
- weights;
- signals.

## Runtime invariants verified at closure

```text
Censored:
    outcome_mature == False
    factual_outcome_id missing
    final_outcome_known missing

Mature:
    outcome_mature == True
    factual_outcome_id nonmissing
    final_outcome_known == exact terminal InformationKey

B1/B2:
    same decision_snapshot_hash
    same decision_input_slice_hash
    different research_snapshot_id
    different research_outcome_hash

Mature later-as-of:
    factual_outcome_id stable
    path facts stable
    terminal linkage stable
```

Forged `VisibleAsOfBundle` inputs are rejected by exact CLOSED 6.2A-0 reseal
validation before semantic observation. Multiple terminal lifecycle events are
rejected. Creation-row high/low are excluded from reference identity,
decision-snapshot identity, and post-creation path measurements.

## Import and vocabulary boundaries

Production code under `trading_system/decision/` imports no
`trading_system.research` code. Public output schemas contain no trade
interpretation fields such as win/loss/PnL/profit/target/stop/trade result,
entry/fill, probability, or score. The reference remains explicitly a
non-executable research mark.

## Open research debts

The following remain open and are not claimed solved:

```text
RESEARCH-DEBT-020
RESEARCH-DEBT-021
RESEARCH-DEBT-022
RESEARCH-DEBT-023
RESEARCH-DEBT-025
```

`RESEARCH-DEBT-024` has not been created.
