# Trading Intelligence Project — Clean Project Snapshot

هذه الحزمة تحتوي الحالة المعتمدة حتى Module 2.1A V1.1، إضافةً إلى Module 2.1B V1 المنفّذ حالياً بانتظار التدقيق.

لا تحتوي على مسودات Liquidity أو Order Flow أو Order Blocks أو FVG، ولا تحتوي على `causal_kernels.py` القديم أو pipeline قديم.

## الحالة الرسمية

| Layer | Module | Version | Status |
|---|---|---:|---|
| 0 | Causal & State Audit Framework | V3.1 | ✅ CLOSED |
| 0 | Causal Percentile Tracker | V1 | ✅ CLOSED |
| 0 | Causal Adaptive Smoothing / Memory Kernel | V1.1 | ✅ CLOSED |
| 1 | Dynamic Volatility Engine | V1.1 | ✅ CLOSED |
| 1 | Causal Session Context Engine | V1 | ✅ CLOSED |
| 2 | Causal Adaptive Swing Detector (2.1A) | V1.1 | ✅ CLOSED |
| 2 | Confirmed Swing Sequence Structure (2.1B) | V1 | ✅ CLOSED |
| 2 | Causal Structural Break Engine (2.1C) | V1.1 | ✅ CLOSED |
| 2 | Causal Liquidity Map / Level Lifecycle (2.2) | V1.1 | ✅ CLOSED |
| 3 | Causal Volume Delta / Order-Flow Evidence (3.1) | V1.1 | ✅ CLOSED |
| 3 | Aggression / Price-Response / Absorption Evidence (3.2) | V1.1 | ✅ CLOSED |
| 4 | Causal Order-Block Candidate & Lifecycle (4.1) | V1.1 | ✅ CLOSED |
| 4 | Causal FVG Candidate & Lifecycle (4.2A) | V1.1 | ✅ CLOSED |
| 4 | Causal Dealing Range & Premium/Discount (4.2B) | V1.1 | ✅ CLOSED |
| 5 | Causal Higher-Timeframe Aggregator (5.1) | V1.1 | ✅ CLOSED |
| 5 | Causal Multi-Scale Confluence Matrix (5.2) | V1.1 | ✅ CLOSED |
| 6 | Causal Evidence Vector / Feature Contract (6.1A) | V1.3 | ✅ CLOSED |
| 6 | Causal Market Narrative / Hypothesis Engine (6.1B) | V1.2 | ✅ CLOSED |
| 6/Research | Research Information-Time / As-Of Visibility Firewall (6.2A-0) | V1.2 | ✅ CLOSED |
| 6/Research | Factual Hypothesis Outcome Observer (6.2A-1) | V1.2 | ✅ CLOSED |

### نطاقات مهمة

- شهادة Module 0.1 تشمل **Primary DataFrame output فقط**؛ auxiliary registries ليست ضمن نطاقها.
- Module 1.1 يقدّم **causal instantaneous volatility evidence**، وليس latent/smoothed volatility-state estimator.
- `candidate_side` في Module 2.1A يعني HIGH/LOW candidate المتتبعة فقط، وليس trend أو market direction.
- “Adaptive” في Module 2.1A يعني empirical calibration من **PRIOR continuation episodes** عند وجود confirmation policy صريحة. لا يعني parameter-free أو automatically optimal أو self-bootstrapping أو التعلم من المستقبل.
- إغلاق Module 6.1B V1.2 يصدّق causal descriptive narrative behavior، deterministic hypothesis lifecycle، exact provenance، وzero-lookahead replay contract ضمن النطاق المختبر فقط.
- الإغلاق لا يصدّق predictive edge أو profitability أو ICT canonical fidelity beyond D1/D1.1 أو scorer quality أو weights أو probabilities أو entries أو exits أو entity-level liquidity/zone narratives.
- تبقى `RESEARCH-DEBT-020` و`RESEARCH-DEBT-021` و`RESEARCH-DEBT-022` مفتوحة وغير محلولة.
- إغلاق Module 6.2A-0 V1.2 يصدّق information-time/as-of visibility firewall ضمن النطاق المختبر فقط. لا يصدّق outcomes أو censoring/maturity أو labels أو training eligibility أو models أو scorer أو predictive edge أو profitability.
- `COMPLETED_ROW_AVAILABLE` logical causal dependency serialization وليس measured exchange/feed/runtime micro-latency. كما أن `6.1B serialization_order` bookkeeping فقط ولا ينشئ intrabar information order.
- إغلاق Module 6.2A-1 V1.2 يصدّق factual post-hypothesis observation وas-of censoring facts وnon-executable reference-mark timing وpost-creation path segmentation وexact mature outcome identity وfuture/as-of isolation ضمن النطاق المختبر فقط. لا يصدّق training eligibility أو estimator أو model أو predictive edge أو profitability أو scorer أو weights أو signals.
- تبقى `RESEARCH-DEBT-020` و`021` و`022` و`023` و`025` مفتوحة؛ لم يتم إنشاء `RESEARCH-DEBT-024`.

## البنية النظيفة

```text
src/
├── causal_state.py                         # compatibility shim فقط
└── trading_system/
    ├── audit/
    │   └── causal_state.py                 # Module 0.1 الحقيقي
    ├── core/
    │   ├── causal_percentile.py            # Module 0.2
    │   └── causal_adaptive_smoothing.py    # Module 0.3
    ├── environment/
    │   ├── dynamic_volatility.py           # Module 1.1
    │   └── session_context.py              # Module 1.2
    └── structure/
        └── swing_detector.py               # Module 2.1A
```

## التثبيت والاختبار

```bash
python -m pip install -e ".[dev]"
pytest -q
```

تشغيل self-verification لكل Module:

```bash
python -m trading_system.audit.causal_state
python -m trading_system.core.causal_percentile
python -m trading_system.core.causal_adaptive_smoothing
python -m trading_system.environment.dynamic_volatility
python -m trading_system.environment.session_context
python -m trading_system.structure.swing_detector
```

## Technical / Research Debt

- `docs/technical_debt/PERFORMANCE-DEBT-001.md`
- `docs/technical_debt/RESEARCH-DEBT-002.md`

لا تغيّر هذه الديون الحالة السببية المعتمدة؛ الأولى تخص قابلية التوسع، والثانية تخص احتمال duration bias في continuation baseline.

## سلامة النسخة

`MANIFEST.sha256` يحتوي SHA-256 لكل ملف داخل الحزمة، باستثناء ملف الـmanifest نفسه. يمكن التحقق عبر:

```bash
sha256sum -c MANIFEST.sha256
```

## Domain source audit status

```text
D1/D1.1: PRELIMINARY SOURCE AUDIT — ACCEPTED
```

Module 2.1C `BOS_*` and `CHOCH_*` fields are stable **project operational labels**, not claims of canonical ICT/Huddleston terminology. Outstanding official-primary review is tracked in `docs/domain_audit/PRIMARY_REVIEW_BACKLOG.md`. Existing factual modules may enter later empirical testing only under project semantics; concepts not implemented are blocked from Layer 6 weighting.
