# Footage credits — The Sealed Chamber

The following moving-image sources are used in `ancient-mystery-15s.mp4`. All were downloaded from Wikimedia Commons. They were trimmed, vertically reframed, color-graded, and combined with original narration, captions, motion graphics, score, and sound design.

## dunes
- **Title:** Aerial view of quad bikes in sand dunes.webm
- **Creator:** The Aerial Project
- **Source:** https://commons.wikimedia.org/wiki/File:Aerial_view_of_quad_bikes_in_sand_dunes.webm
- **License:** CC0 — http://creativecommons.org/publicdomain/zero/1.0/deed.en
- **Downloaded version:** 480p.vp9.webm

## excavation_wide
- **Title:** B-roll Video - Rimrock Draw Rockshelter (29440718542).webm
- **Creator:** BLM Oregon & Washington
- **Source:** https://commons.wikimedia.org/wiki/File:B-roll_Video_-_Rimrock_Draw_Rockshelter_(29440718542).webm
- **License:** Public domain
- **Downloaded version:** original

## excavation_detail
- **Title:** B-roll Video - Rimrock Draw Rockshelter (29550075485).webm
- **Creator:** BLM Oregon & Washington
- **Source:** https://commons.wikimedia.org/wiki/File:B-roll_Video_-_Rimrock_Draw_Rockshelter_(29550075485).webm
- **License:** Public domain
- **Downloaded version:** 480p.vp9.webm

## inscriptions_vertical
- **Title:** Religious drawings and writings made by ancient people on stones.webm
- **Creator:** Elchin Ahmadov
- **Source:** https://commons.wikimedia.org/wiki/File:Religious_drawings_and_writings_made_by_ancient_people_on_stones.webm
- **License:** CC BY-SA 4.0 — https://creativecommons.org/licenses/by-sa/4.0
- **Downloaded version:** 480p.vp9.webm

## cave_walk_vertical
- **Title:** Walking in the Postojna Cave 2025.webm
- **Creator:** Kevin O'Brien
- **Source:** https://commons.wikimedia.org/wiki/File:Walking_in_the_Postojna_Cave_2025.webm
- **License:** CC BY-SA 4.0 — https://creativecommons.org/licenses/by-sa/4.0
- **Downloaded version:** 1080p.vp9.webm

## cave_train_vertical
- **Title:** On the train in the Postojna Cave 2025.webm
- **Creator:** Kevin O'Brien
- **Source:** https://commons.wikimedia.org/wiki/File:On_the_train_in_the_Postojna_Cave_2025.webm
- **License:** CC BY-SA 4.0 — https://creativecommons.org/licenses/by-sa/4.0
- **Downloaded version:** 1080p.vp9.webm

## Adaptation notice

This prototype contains CC BY-SA 4.0 footage and is shared under **CC BY-SA 4.0** to the extent required by those source licenses. Public-domain and CC0 sources retain their original status. Narration, procedural score, sound design, captions, and editorial assembly were created specifically for this prototype.
