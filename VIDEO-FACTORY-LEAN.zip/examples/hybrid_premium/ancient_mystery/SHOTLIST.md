# Shot list — The Sealed Chamber

| # | Timeline | Duration | Visual beat | Source |
|---:|---:|---:|---|---|
| 1 | 00.00–01.10 | 1.10s | Empty dune crest, angle A | dunes |
| 2 | 01.10–02.25 | 1.15s | Empty dune crest, angle B | dunes |
| 3 | 02.25–03.35 | 1.10s | Archaeologist recording the dig | excavation wide |
| 4 | 03.35–04.30 | 0.95s | Central excavation pit | excavation wide |
| 5 | 04.30–05.20 | 0.90s | Sealed earthen wall | excavation wide |
| 6 | 05.20–05.90 | 0.70s | Sifting detail | excavation detail |
| 7 | 05.90–06.85 | 0.95s | Team overhead / no identifier | excavation wide |
| 8 | 06.85–07.70 | 0.85s | Blank stone marker | inscriptions |
| 9 | 07.70–08.55 | 0.85s | Geometric marker | inscriptions |
| 10 | 08.55–09.30 | 0.75s | Dark sealed arch / warning | inscriptions |
| 11 | 09.30–10.10 | 0.80s | Impact flash into chamber | cave train |
| 12 | 10.10–11.15 | 1.05s | Moving through the interior | cave walk |
| 13 | 11.15–12.20 | 1.05s | Ceiling reveal | cave train |
| 14 | 12.20–13.45 | 1.25s | Passage movement | cave walk |
| 15 | 13.45–15.00 | 1.55s | Breathing darkness | cave train + animated luminance |

All horizontal shots use deliberate vertical reframing. Short optical reframes sit on top of genuine source motion; no shot is a still-image zoom.
