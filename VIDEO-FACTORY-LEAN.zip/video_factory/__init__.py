"""Video Factory: secure, resumable video-job orchestration."""
__version__ = "0.2.0"
