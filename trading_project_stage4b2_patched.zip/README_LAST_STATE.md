# آخر حالة — مشروع التداول السببي (Causal Trading Intelligence)

التاريخ: 2026-08-21 (أحدث إصدار — Stage 4B-2 بعد PATCH)

## الحالة الرسمية

```text
Stage 1        CLOSED
Stage 2        CLOSED
Stage 3        CLOSED          (818 passed)
Stage 4A       CLOSED          (890 passed)
Stage 4B-1     CLOSED          (927 passed)
Stage 4B-2     PATCHED / IMPLEMENTED — PENDING RE-AUDIT   (35 tests مخصصة، 962 إجمالي)
Stage 4C       NOT STARTED
```

## MANIFEST

```text
MANIFEST: 166 / 166 OK
MANIFEST SHA-256: 1583cde0beb68969a49866614c9e4e5b9243bb31cf846ad816eb69397341879a
```

## بصمات Stage 4B-2 (للتدقيق — PENDING RE-AUDIT، بعد إصلاح BLOCKERين)

```text
trajectory_stage4b2.py   e5eaaa00881285f9ffd1d00b57b1675c08ed803290786c9f92823a804567871c
test_trajectory_stage4b2.py  9111de52bd8dc51843fefaa94d255eed2f86505f3011bc75ecdb163e831e6842
```

## بصمات الملفات المغلقة (لم تتغير)

```text
trajectory_stage2.py    827ddf9b51e0a4ffecd57e5f92a0b2ddfafbd5b9ddb3af61fc6ae8a9a4e8fd3f
trajectory_stage3.py    e79a61cf85ce0ba5cb3dfcd3db63b8fcdbe8d53243bb28855eb0bc91dad2dc8e
trajectory_stage4a.py   19034dfff4ca4007921bdd7b3bd16c8afc5048b3601f2538d02510ba27edc26e
trajectory_stage4b1.py  bc393fe4ffb8dec9bdb16e4ae8e0036f22faefdecc8dc67345a5a881207bb708
```

## الاختبارات

```text
Stage 4B-2 مخصصة: 35 / 35
المجموع الكامل: 962 collected / 962 passed
```

## آخر تغيير (PATCH — إصلاح BLOCKERين)

1. BLOCKER 1 (cross-domain substitution): 4 dataclasses منفصلة + schema enforcement من frozen CLOSED mirrors.
2. BLOCKER 2 (prefix ناقص): الـ prefix يربط bar + event + entity + normalized event.
التفاصيل في reports/PATCH_REPORT_6_2A_4_V1_STAGE4B2.md.

## أوامر التحقق

```bash
cd trading_project
sha256sum -c MANIFEST.sha256
PYTHONPATH=src python3 -m pytest --no-header -o addopts="" -q
PYTHONPATH=src python3 -m pytest tests/test_trajectory_stage4b2.py --no-header -o addopts="" -q
```
