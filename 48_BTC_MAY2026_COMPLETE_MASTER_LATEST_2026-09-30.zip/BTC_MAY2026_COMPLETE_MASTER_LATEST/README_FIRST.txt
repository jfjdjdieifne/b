BTC_MAY2026 COMPLETE MASTER — LATEST UPDATE — 2026-09-30
=======================================================

THIS REPLACES deliverable 43 (which contained the PRE-CLOSURE baseline).

CONTENTS:

1) BTC_MAY2026_FIELD_PACKAGE/ — CURRENT working package (latest state):
   - trading_project/   POST-CLOSURE CLEAN BASELINE + MUF S0 ADDITIONS
       MANIFEST.sha256 = 12c66abe6f18300f2e00cb5c4befeafe1e3dc67c2ca50bc71db74db9ba8b367d
       185 lines / 185 OK / 0 stale / 0 missing / 1072 historical + 37 S0 tests
       (S0 files are unmanifested build artifacts pending audit — by design)
   - field_runner/      baseline guard RE-PINNED to the clean post-closure state
       (test_runner_guards.py sha 7bb599f0276a31f919c788a50f7bb51337664aa122d8d5f42e22ef4baf5801c2)
   - run_btc_may_2026.bat / run_btc_may_2026.py + notes + data + reports
   Verify package:  sha256sum -c FILE_INVENTORY.sha256   (inside BTC_MAY2026_FIELD_PACKAGE)
   Verify baseline: cd trading_project && sha256sum -c MANIFEST.sha256   (expect 185 OK)

2) MUF_DESIGN_DOCS/ — MUF-V1 design chain 36..42 (AP-1 last authority)

3) DELIVERABLE_REPORTS/ — closure + integration + S0 build reports 44..47

4) BUNDLE_CONTENTS.sha256 — inventory of EVERY file in this bundle
   (sha256sum -c BUNDLE_CONTENTS.sha256 from this folder)

HOW TO RUN (owner PC, from inside BTC_MAY2026_FIELD_PACKAGE):
   run_btc_may_2026.bat

STATUS (2026-09-30):
   Unified performance closure ......... CLOSED (1072/1072 baseline)
   Baseline integration seal ........... SEALED
   MUF S0 core contracts ............... IMPLEMENTED — PENDING AUDIT (37 dedicated tests)
   MUF design .......................... ACCEPTED FOR S0 BUILD AUTHORIZATION only
   Later MUF stages (S1+) .............. NOT AUTHORIZED
   NB-1..NB-4 .......................... RECORD ONLY
