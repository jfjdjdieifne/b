"""Benchmark harness: OLD closed tracker vs prototypes at synthetic scales.

Reports per (primitive, n): wall time, op count, implied complexity ratio,
tracemalloc peak during the run, and process peak RSS delta.
"""

from __future__ import annotations

import os
import sys
import time
import tracemalloc

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np

from trading_system.core.causal_percentile import CausalPercentileTracker
from prototypes import BisectListTracker, NumpyBufferTracker, TreapTracker, load_native

SCALES = [1000, 5000, 10000, 20000, 44640]
EXTRA_SCALES = [100000, 250000, 1000000]


def bench_stream(cls, stream, nan_policy="skip"):
    tr = cls(nan_policy=nan_policy)
    tracemalloc.start()
    t0 = time.perf_counter()
    for x in stream:
        tr.observe(x)
    dt = time.perf_counter() - t0
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return dt, peak


def bench_percentile_value(cls, stream, q=0.5):
    tr = cls(nan_policy="skip")
    for x in stream:
        tr.push(x)
    t0 = time.perf_counter()
    for _ in range(20):
        tr.percentile_value(q)
    return (time.perf_counter() - t0) / 20.0


def main():
    rng = np.random.default_rng(12345)
    classes = [CausalPercentileTracker, BisectListTracker, NumpyBufferTracker, TreapTracker]
    Native = load_native()
    if Native:
        classes.append(Native)
    else:
        print("NOTE: native_rank.so not loaded — P5 skipped")

    print("== observe() stream benchmark (time s, tracemalloc peak KiB) ==")
    header = f"{'n':>8} " + " ".join(f"{getattr(c,'name','P0_closed'):>26}" for c in classes)
    print(header)
    cache = {}
    for n in SCALES + EXTRA_SCALES:
        stream = list(rng.normal(size=n))
        cache[n] = stream
        row = f"{n:>8} "
        for cls in classes:
            if cls is CausalPercentileTracker and n > 44640:
                row += f"{'(old projected O(n^2))':>26} "
                continue
            dt, peak = bench_stream(cls, stream)
            row += f"{f'{dt:8.3f}s /{peak/1024:8.0f}K':>26} "
        print(row, flush=True)

    print("\n== percentile_value(q=0.5) single-call latency after n pushes ==")
    print(f"{'n':>8} " + " ".join(f"{getattr(c,'name','P0_closed'):>18}" for c in classes))
    for n in (10000, 44640):
        stream = cache[n]
        row = f"{n:>8} "
        for cls in classes:
            if cls is CausalPercentileTracker and n > 44640:
                row += f"{'-':>18} "
                continue
            dt = bench_percentile_value(cls, stream)
            row += f"{dt*1000:14.3f}ms "
        print(row, flush=True)

    print("\n== old-tracker scaling ratios (complexity confirmation) ==")
    times = {}
    for n in (1000, 5000, 10000, 20000, 44640):
        times[n], _ = bench_stream(CausalPercentileTracker, cache[n])
    ns = sorted(times)
    for a, b in zip(ns, ns[1:]):
        print(f"  old n {a}->{b}: time x{times[b]/times[a]:.2f} for n x{b/a:.2f} (quadratic predicts x{(b/a)**2:.2f})")


if __name__ == "__main__":
    main()
