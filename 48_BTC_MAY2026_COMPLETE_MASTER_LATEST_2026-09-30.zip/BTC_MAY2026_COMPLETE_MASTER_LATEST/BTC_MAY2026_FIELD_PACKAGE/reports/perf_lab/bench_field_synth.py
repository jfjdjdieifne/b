"""EXACT PERFORMANCE V2 — composed field-runner synthetic benchmark.

Runs the CLOSED field-runner pipeline (load_sources -> seal_timeline ->
run_engines -> build_evidence_and_narrative) on a deterministic SYNTHETIC
44,640-minute fixture (TEST-FIXTURE-ONLY, no owner data) in five module
modes:

    baseline         : pre-patch causal_percentile + fvg + narrative
    percentile-only  : patched causal_percentile only
    fvg-only         : patched fvg only
    narrative-only   : patched narrative only
    all-three        : all three patches

Mode is applied by installing the verbatim pre-patch reference copies under
their real module names BEFORE any lazy import resolves (subprocess isolation
per mode). Outputs are compared across modes for exact equality (same fixture).

Run: python3 bench_field_synth.py --mode baseline
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import sys
import time
from pathlib import Path

PROJECT = Path("/home/user/project/trading_project")
sys.path.insert(0, str(PROJECT / "src"))
sys.path.insert(0, "/home/user/field_runner")

REF_DIR = PROJECT / "tests" / "_patch_reference_src"
FIXTURE_DIR = Path("/home/user/perf_lab/field_fixture_44640")
RESULT_DIR = Path("/home/user/perf_lab/field_results")

PATCHED = {
    "causal_percentile": "trading_system.core.causal_percentile",
    "fvg": "trading_system.zones.fvg",
    "narrative": "trading_system.decision.narrative",
}


def install_reference(name: str):
    real_name = PATCHED[name]
    spec = importlib.util.spec_from_file_location(
        real_name, REF_DIR / f"{name}_pre.py"
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[real_name] = module
    spec.loader.exec_module(module)
    return module


def apply_mode(mode: str) -> None:
    # Warm the real packages first so package __init__ re-entrancy cannot see a
    # half-initialized reference module during exec_module.
    import trading_system.core.causal_percentile as _real_cp  # noqa: F401
    import trading_system.zones.fvg as real_fvg  # noqa: F401
    import trading_system.decision.evidence_vector  # noqa: F401
    import trading_system.decision.narrative  # noqa: F401

    # Order matters afterwards: causal_percentile first (fvg_pre imports it).
    if mode in ("baseline", "fvg-only", "narrative-only"):
        install_reference("causal_percentile")
    if mode in ("baseline", "percentile-only", "narrative-only"):
        install_reference("fvg")
    if mode in ("baseline", "percentile-only", "fvg-only"):
        install_reference("narrative")
    if mode == "fvg-only":
        # Real fvg stays active; re-bind its tracker global to the old tracker
        # so ONLY the fvg patch is live in this composition.
        real_fvg.CausalPercentileTracker = sys.modules[
            "trading_system.core.causal_percentile"
        ].CausalPercentileTracker


def ensure_fixture(n_minutes: int = 44640) -> dict:
    marker = FIXTURE_DIR / "fixture_meta.json"
    if marker.exists():
        meta = json.loads(marker.read_text())
        if meta.get("n_minutes") == n_minutes:
            return meta
    FIXTURE_DIR.mkdir(parents=True, exist_ok=True)
    t0 = time.perf_counter()
    from fixtures import write_fixture

    out = write_fixture(str(FIXTURE_DIR), n_minutes=n_minutes)
    meta = {
        "n_minutes": n_minutes,
        "facts_path": out["facts_path"],
        "sidecar_path": out["sidecar_path"],
        "klines_csv_path": out["klines_csv_path"],
        "facts_sha256": out["facts_sha256"],
        "klines_sha256": out["klines_sha256"],
        "source_sha256": out["source_sha256"],
        "converter_sha256": out["converter_sha256"],
        "build_seconds": time.perf_counter() - t0,
    }
    marker.write_text(json.dumps(meta, indent=1))
    return meta


def frame_fingerprint(frames: dict) -> str:
    digest = hashlib.sha256()
    for key in sorted(frames):
        frame = frames[key]
        if frame is None:
            digest.update(f"{key}:None|".encode())
            continue
        try:
            payload = frame.to_csv(index=True).encode()
        except Exception:
            payload = repr(frame).encode()
        digest.update(key.encode())
        digest.update(payload)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode",
        required=True,
        choices=["baseline", "percentile-only", "fvg-only", "narrative-only", "all-three"],
    )
    parser.add_argument("--n", type=int, default=44640)
    args = parser.parse_args()
    mode = args.mode

    apply_mode(mode)

    import pandas as pd
    import pipeline as pl

    meta = ensure_fixture(args.n)
    config = pl.FieldRunConfig.from_dict(
        {
            "symbol": "FIXTURESYM",
            "year_month": "2026-05",
            "period_start_utc": "2026-05-01T00:00:00Z",
            "period_end_utc": "2026-06-01T00:00:00Z",
        }
    )
    statuses: list = []

    timings = {}
    t0 = time.perf_counter()
    sources = pl.load_sources(
        facts_csv=meta["facts_path"],
        facts_sidecar=meta["sidecar_path"],
        klines_csv=meta["klines_csv_path"],
        config=config,
    )
    timings["load_sources"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    timeline, adapter, market_history = pl.seal_timeline(
        sources["bundle"], timeline_id="bench-field-synth-44640"
    )
    timings["seal_timeline"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    engine_out = pl.run_engines(
        market_history=market_history, flow=sources["flow"], config=config, statuses=statuses
    )
    timings["run_engines"] = time.perf_counter() - t0

    t0 = time.perf_counter()
    evidence_out = pl.build_evidence_and_narrative(
        market_history=market_history,
        engine_out=engine_out,
        config=config,
        statuses=statuses,
    )
    timings["evidence_and_narrative"] = time.perf_counter() - t0

    timings["total_after_load"] = (
        timings["seal_timeline"] + timings["run_engines"] + timings["evidence_and_narrative"]
    )

    # Fingerprint outputs (bars + fvg + fvg_events + evidence + narrative frames).
    frames = {
        "market_history": market_history,
        "volatility": engine_out["volatility"],
        "fvg": engine_out["fvg"],
        "fvg_events": engine_out["fvg_events"],
        "flow_proxy": engine_out["flow_proxy"],
        "flow_actual": engine_out.get("flow_actual"),
    }
    for key, value in (evidence_out or {}).items():
        if isinstance(value, pd.DataFrame):
            frames[f"evidence::{key}"] = value
    fingerprint = frame_fingerprint(frames)

    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    result = {
        "mode": mode,
        "timings": timings,
        "fingerprint": fingerprint,
        "status_count": len(statuses),
    }
    (RESULT_DIR / f"{mode}.json").write_text(json.dumps(result, indent=1))
    print(json.dumps(result, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
