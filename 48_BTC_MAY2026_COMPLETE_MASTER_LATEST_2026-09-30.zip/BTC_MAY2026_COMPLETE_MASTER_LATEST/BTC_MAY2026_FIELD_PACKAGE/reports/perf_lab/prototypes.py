"""EXACT online expanding-rank prototypes — LAB ONLY (outside CLOSED).

Every prototype reproduces the CLOSED CausalPercentileTracker observables EXACTLY
(read-before-push, mid-rank ties, NaN/inf policy, warm-up NaN, np.quantile
'linear' percentile_value). No future information is read or fitted anywhere;
all structures are built strictly from the observed stream prefix.

P1: bisect sorted list (C memmove insert, Python binary search)
P2: numpy float64 buffer (C memmove insert + np.searchsorted)
P3: treap with multiplicities + subtree sizes (pure Python tree)
P5: native C sorted buffer via ctypes (optional, compiled separately)
"""

from __future__ import annotations

import bisect
import math

import numpy as np

# Exceptions are the CLOSED ones (imported, not copied) so error semantics match.
import sys as _sys
import os as _os
_proj = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))),
                      "project", "trading_project", "src")
if _proj not in _sys.path:
    _sys.path.insert(0, _proj)
from trading_system.core.causal_percentile import (  # noqa: E402
    CausalPercentileConfigError,
    CausalPercentileDataError,
    PercentileObservation,
)


def _coerce(value, *, allow_nan: bool) -> float:
    if isinstance(value, (bool, np.bool_)):
        raise CausalPercentileDataError("Boolean observations are not valid numerical market features.")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise CausalPercentileDataError(f"Observation must be a scalar real number. Got {value!r}.") from exc
    if math.isnan(result):
        if allow_nan:
            return result
        raise CausalPercentileDataError("NaN observation is not permitted in this operation.")
    if math.isinf(result):
        raise CausalPercentileDataError("Infinite observations are rejected.")
    return result


def _validate_q(percentile) -> float:
    if isinstance(percentile, (bool, np.bool_)):
        raise CausalPercentileConfigError("percentile must be a finite number in [0, 1].")
    try:
        q = float(percentile)
    except (TypeError, ValueError, OverflowError) as exc:
        raise CausalPercentileConfigError(f"Invalid percentile: {percentile!r}.") from exc
    if not math.isfinite(q):
        raise CausalPercentileConfigError("percentile must be finite.")
    if not 0.0 <= q <= 1.0:
        raise CausalPercentileConfigError(f"percentile must lie in [0,1]. Got {q}.")
    return q


class BisectListTracker:
    """P1: sorted Python list + bisect. Supports max_history (lazy FIFO eviction)."""

    name = "P1_bisect_list"

    def __init__(self, *, max_history=None, nan_policy="skip"):
        if max_history is not None:
            if isinstance(max_history, (bool, np.bool_)) or not isinstance(max_history, (int, np.integer)) or int(max_history) <= 0:
                raise CausalPercentileConfigError("max_history must be None or a positive integer.")
            max_history = int(max_history)
        if nan_policy not in ("skip", "raise"):
            raise CausalPercentileConfigError("nan_policy must be 'skip' or 'raise'.")
        self._max_history = max_history
        self._nan_policy = nan_policy
        self._sorted: list = []
        self._fifo: list = []  # insertion order for eviction
        self._total_pushed = 0
        self._total_skipped = 0
        self._min = math.inf
        self._max = -math.inf

    @property
    def sample_count(self):
        return len(self._sorted)

    @property
    def total_pushed(self):
        return self._total_pushed

    @property
    def total_skipped(self):
        return self._total_skipped

    def rank(self, value):
        x = _coerce(value, allow_nan=True)
        if math.isnan(x):
            if self._nan_policy == "raise":
                raise CausalPercentileDataError("NaN encountered with nan_policy='raise'.")
            return PercentileObservation(value=float("nan"), percentile=float("nan"),
                                         sample_count=len(self._sorted), less_count=0, equal_count=0,
                                         greater_count=0, history_min=float("nan"),
                                         history_max=float("nan"), accepted=False)
        n = len(self._sorted)
        if n == 0:
            return PercentileObservation(value=x, percentile=float("nan"), sample_count=0,
                                         less_count=0, equal_count=0, greater_count=0,
                                         history_min=float("nan"), history_max=float("nan"), accepted=True)
        s = self._sorted
        less = bisect.bisect_left(s, x)
        greater_i = bisect.bisect_right(s, x)
        equal = greater_i - less
        greater = n - less - equal
        percentile = (less + 0.5 * equal) / n
        if self._max_history is not None:
            hmin, hmax = self._scan_extrema()
        else:
            hmin, hmax = self._min, self._max
        return PercentileObservation(value=x, percentile=float(percentile), sample_count=n,
                                     less_count=less, equal_count=equal, greater_count=greater,
                                     history_min=hmin, history_max=hmax, accepted=True)

    def _scan_extrema(self):
        # exact clone of the CLOSED scan: strict compare, first-inserted wins ties
        hmin = math.inf
        hmax = -math.inf
        for v in self._fifo:
            if v < hmin:
                hmin = v
            if v > hmax:
                hmax = v
        return hmin, hmax

    def push(self, value) -> bool:
        x = _coerce(value, allow_nan=True)
        if math.isnan(x):
            if self._nan_policy == "raise":
                raise CausalPercentileDataError("NaN encountered with nan_policy='raise'.")
            self._total_skipped += 1
            return False
        bisect.insort(self._sorted, x)
        self._fifo.append(x)
        self._total_pushed += 1
        if self._max_history is None:
            # strict compare: on tie the first-inserted extreme keeps its sign bit
            if x < self._min:
                self._min = x
            if x > self._max:
                self._max = x
        if self._max_history is not None and len(self._fifo) > self._max_history:
            old = self._fifo.pop(0)
            pos = bisect.bisect_left(self._sorted, old)
            self._sorted.pop(pos)
        return True

    def observe(self, value):
        result = self.rank(value)
        self.push(value)
        return result

    def percentile_value(self, percentile) -> float:
        q = _validate_q(percentile)
        if not self._sorted:
            return float("nan")
        values = np.asarray(self._sorted, dtype=np.float64)
        return float(np.quantile(values, q, method="linear"))

    def reset(self) -> None:
        self._sorted.clear()
        self._fifo.clear()
        self._total_pushed = 0
        self._total_skipped = 0
        self._min = math.inf
        self._max = -math.inf

    def history_snapshot(self):
        return tuple(self._fifo)


class NumpyBufferTracker:
    """P2: preallocated float64 buffer; C memmove insert + np.searchsorted.

    Expanding history only (the ONLY mode the CLOSED engines use). The fast
    path never reads anything outside the observed prefix.
    """

    name = "P2_numpy_buffer"

    def __init__(self, *, max_history=None, nan_policy="skip"):
        if max_history is not None:
            raise CausalPercentileConfigError("P2 lab prototype covers expanding mode only")
        if nan_policy not in ("skip", "raise"):
            raise CausalPercentileConfigError("nan_policy must be 'skip' or 'raise'.")
        self._nan_policy = nan_policy
        self._cap = 64
        self._buf = np.empty(self._cap, dtype=np.float64)
        self._n = 0
        self._total_pushed = 0
        self._total_skipped = 0
        self._min = math.inf
        self._max = -math.inf

    @property
    def sample_count(self):
        return self._n

    @property
    def total_pushed(self):
        return self._total_pushed

    @property
    def total_skipped(self):
        return self._total_skipped

    def _view(self):
        return self._buf[: self._n]

    def rank(self, value):
        x = _coerce(value, allow_nan=True)
        if math.isnan(x):
            if self._nan_policy == "raise":
                raise CausalPercentileDataError("NaN encountered with nan_policy='raise'.")
            return PercentileObservation(value=float("nan"), percentile=float("nan"),
                                         sample_count=self._n, less_count=0, equal_count=0,
                                         greater_count=0, history_min=float("nan"),
                                         history_max=float("nan"), accepted=False)
        n = self._n
        if n == 0:
            return PercentileObservation(value=x, percentile=float("nan"), sample_count=0,
                                         less_count=0, equal_count=0, greater_count=0,
                                         history_min=float("nan"), history_max=float("nan"), accepted=True)
        view = self._view()
        less = int(np.searchsorted(view, x, side="left"))
        greater_i = int(np.searchsorted(view, x, side="right"))
        equal = greater_i - less
        greater = n - less - equal
        percentile = (less + 0.5 * equal) / n
        return PercentileObservation(value=x, percentile=float(percentile), sample_count=n,
                                     less_count=less, equal_count=equal, greater_count=greater,
                                     history_min=self._min, history_max=self._max, accepted=True)

    def push(self, value) -> bool:
        x = _coerce(value, allow_nan=True)
        if math.isnan(x):
            if self._nan_policy == "raise":
                raise CausalPercentileDataError("NaN encountered with nan_policy='raise'.")
            self._total_skipped += 1
            return False
        if self._n == self._cap:
            self._cap *= 2
            grown = np.empty(self._cap, dtype=np.float64)
            grown[: self._n] = self._buf[: self._n]
            self._buf = grown
        view = self._view()
        pos = int(np.searchsorted(view, x, side="left"))
        self._buf[pos + 1 : self._n + 1] = self._buf[pos : self._n]
        self._buf[pos] = x
        self._n += 1
        self._total_pushed += 1
        if x < self._min:
            self._min = x
        if x > self._max:
            self._max = x
        return True

    def observe(self, value):
        result = self.rank(value)
        self.push(value)
        return result

    def percentile_value(self, percentile) -> float:
        q = _validate_q(percentile)
        if self._n == 0:
            return float("nan")
        return float(np.quantile(self._view().copy(), q, method="linear"))

    def reset(self) -> None:
        self._n = 0
        self._total_pushed = 0
        self._total_skipped = 0
        self._min = math.inf
        self._max = -math.inf

    def history_snapshot(self):
        return tuple(float(v) for v in self._view())


class _TreapNode:
    __slots__ = ("key", "prio", "cnt", "size", "left", "right")

    def __init__(self, key, prio):
        self.key = key
        self.prio = prio
        self.cnt = 1
        self.size = 1
        self.left = None
        self.right = None


def _tsize(node):
    return node.size if node is not None else 0


def _tupdate(node):
    node.size = node.cnt + _tsize(node.left) + _tsize(node.right)


def _trotate_right(y):
    x = y.left
    y.left = x.right
    x.right = y
    _tupdate(y)
    _tupdate(x)
    return x


def _trotate_left(x):
    y = x.right
    x.right = y.left
    y.left = x
    _tupdate(x)
    _tupdate(y)
    return y


class TreapTracker:
    """P3: randomized-priority treap, multiplicities + subtree sizes.

    Rank RESULTS are shape-independent (depend only on the multiset), so the
    deterministic seed below makes runs reproducible; outputs are deterministic
    regardless of priorities.
    """

    name = "P3_treap"

    def __init__(self, *, max_history=None, nan_policy="skip", seed=1234567):
        if max_history is not None:
            raise CausalPercentileConfigError("P3 lab prototype covers expanding mode only")
        if nan_policy not in ("skip", "raise"):
            raise CausalPercentileConfigError("nan_policy must be 'skip' or 'raise'.")
        self._nan_policy = nan_policy
        self._rng = np.random.default_rng(seed)
        self._root = None
        self._n = 0
        self._total_pushed = 0
        self._total_skipped = 0

    @property
    def sample_count(self):
        return self._n

    @property
    def total_pushed(self):
        return self._total_pushed

    @property
    def total_skipped(self):
        return self._total_skipped

    def _insert(self, node, key, prio):
        if node is None:
            return _TreapNode(key, prio)
        if key == node.key:
            node.cnt += 1
            _tupdate(node)
            return node
        if key < node.key:
            node.left = self._insert(node.left, key, prio)
            if node.left.prio < node.prio:
                node = _trotate_right(node)
        else:
            node.right = self._insert(node.right, key, prio)
            if node.right.prio < node.prio:
                node = _trotate_left(node)
        _tupdate(node)
        return node

    def _counts(self, node, x):
        less = equal = 0
        while node is not None:
            if x < node.key:
                node = node.left
            elif x == node.key:
                less += _tsize(node.left)
                equal = node.cnt
                break
            else:
                less += _tsize(node.left) + node.cnt
                node = node.right
        return less, equal

    def _extrema(self):
        if self._root is None:
            return float("nan"), float("nan")
        node = self._root
        while node.left is not None:
            node = node.left
        lo = node.key
        node = self._root
        while node.right is not None:
            node = node.right
        return lo, node.key

    def _inorder(self, node, out):
        if node is None:
            return
        self._inorder(node.left, out)
        out.extend([node.key] * node.cnt)
        self._inorder(node.right, out)

    def rank(self, value):
        x = _coerce(value, allow_nan=True)
        if math.isnan(x):
            if self._nan_policy == "raise":
                raise CausalPercentileDataError("NaN encountered with nan_policy='raise'.")
            return PercentileObservation(value=float("nan"), percentile=float("nan"),
                                         sample_count=self._n, less_count=0, equal_count=0,
                                         greater_count=0, history_min=float("nan"),
                                         history_max=float("nan"), accepted=False)
        n = self._n
        if n == 0:
            return PercentileObservation(value=x, percentile=float("nan"), sample_count=0,
                                         less_count=0, equal_count=0, greater_count=0,
                                         history_min=float("nan"), history_max=float("nan"), accepted=True)
        less, equal = self._counts(self._root, x)
        greater = n - less - equal
        percentile = (less + 0.5 * equal) / n
        lo, hi = self._extrema()
        return PercentileObservation(value=x, percentile=float(percentile), sample_count=n,
                                     less_count=less, equal_count=equal, greater_count=greater,
                                     history_min=lo, history_max=hi, accepted=True)

    def push(self, value) -> bool:
        x = _coerce(value, allow_nan=True)
        if math.isnan(x):
            if self._nan_policy == "raise":
                raise CausalPercentileDataError("NaN encountered with nan_policy='raise'.")
            self._total_skipped += 1
            return False
        prio = int(self._rng.integers(0, 2**62))
        self._root = self._insert(self._root, x, prio)
        self._n += 1
        self._total_pushed += 1
        return True

    def observe(self, value):
        result = self.rank(value)
        self.push(value)
        return result

    def percentile_value(self, percentile) -> float:
        q = _validate_q(percentile)
        if self._n == 0:
            return float("nan")
        out: list = []
        self._inorder(self._root, out)
        values = np.asarray(out, dtype=np.float64)
        return float(np.quantile(values, q, method="linear"))

    def reset(self) -> None:
        self._root = None
        self._n = 0
        self._total_pushed = 0
        self._total_skipped = 0

    def history_snapshot(self):
        out: list = []
        self._inorder(self._root, out)
        return tuple(out)  # sorted order (multiset content identical)


def load_native():
    """P5: ctypes binding to the compiled C primitive (sorted buffer)."""
    import ctypes

    lib_path = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "native_rank.so")
    if not _os.path.isfile(lib_path):
        return None
    lib = ctypes.CDLL(lib_path)
    lib.rank_new.restype = ctypes.c_void_p
    lib.rank_new.argtypes = []
    lib.rank_free.argtypes = [ctypes.c_void_p]
    lib.rank_insert.argtypes = [ctypes.c_void_p, ctypes.c_double]
    lib.rank_insert.restype = ctypes.c_int
    lib.rank_counts.argtypes = [ctypes.c_void_p, ctypes.c_double,
                                ctypes.POINTER(ctypes.c_long), ctypes.POINTER(ctypes.c_long),
                                ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double)]
    lib.rank_counts.restype = ctypes.c_int
    lib.rank_n.argtypes = [ctypes.c_void_p]
    lib.rank_n.restype = ctypes.c_long

    class NativeBufferTracker:
        name = "P5_native_c"

        def __init__(self, *, max_history=None, nan_policy="skip"):
            if max_history is not None:
                raise CausalPercentileConfigError("P5 covers expanding mode only")
            if nan_policy not in ("skip", "raise"):
                raise CausalPercentileConfigError("nan_policy must be 'skip' or 'raise'.")
            self._nan_policy = nan_policy
            self._h = lib.rank_new()
            self._total_pushed = 0
            self._total_skipped = 0
            self._min = math.inf
            self._max = -math.inf

        @property
        def sample_count(self):
            return int(lib.rank_n(self._h))

        @property
        def total_pushed(self):
            return self._total_pushed

        @property
        def total_skipped(self):
            return self._total_skipped

        def rank(self, value):
            x = _coerce(value, allow_nan=True)
            if math.isnan(x):
                if self._nan_policy == "raise":
                    raise CausalPercentileDataError("NaN encountered with nan_policy='raise'.")
                return PercentileObservation(value=float("nan"), percentile=float("nan"),
                                             sample_count=self.sample_count, less_count=0, equal_count=0,
                                             greater_count=0, history_min=float("nan"),
                                             history_max=float("nan"), accepted=False)
            less = ctypes.c_long(0)
            equal = ctypes.c_long(0)
            lo = ctypes.c_double(0.0)
            hi = ctypes.c_double(0.0)
            n = int(lib.rank_counts(self._h, float(x), ctypes.byref(less), ctypes.byref(equal),
                                    ctypes.byref(lo), ctypes.byref(hi)))
            if n == 0:
                return PercentileObservation(value=x, percentile=float("nan"), sample_count=0,
                                             less_count=0, equal_count=0, greater_count=0,
                                             history_min=float("nan"), history_max=float("nan"), accepted=True)
            l = int(less.value)
            e = int(equal.value)
            g = n - l - e
            percentile = (l + 0.5 * e) / n
            return PercentileObservation(value=x, percentile=float(percentile), sample_count=n,
                                         less_count=l, equal_count=e, greater_count=g,
                                         history_min=self._min, history_max=self._max, accepted=True)

        def push(self, value) -> bool:
            x = _coerce(value, allow_nan=True)
            if math.isnan(x):
                if self._nan_policy == "raise":
                    raise CausalPercentileDataError("NaN encountered with nan_policy='raise'.")
                self._total_skipped += 1
                return False
            lib.rank_insert(self._h, float(x))
            self._total_pushed += 1
            if x < self._min:
                self._min = x
            if x > self._max:
                self._max = x
            return True

        def observe(self, value):
            result = self.rank(value)
            self.push(value)
            return result

        def percentile_value(self, percentile) -> float:
            q = _validate_q(percentile)
            n = self.sample_count
            if n == 0:
                return float("nan")
            arr = np.empty(n, dtype=np.float64)
            # native dump of sorted buffer
            lib.rank_dump.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
            lib.rank_dump(self._h, arr.ctypes.data_as(ctypes.POINTER(ctypes.c_double)))
            return float(np.quantile(arr, q, method="linear"))

        def reset(self) -> None:
            lib.rank_free(self._h)
            self._h = lib.rank_new()
            self._total_pushed = 0
            self._total_skipped = 0
            self._min = math.inf
            self._max = -math.inf

        def history_snapshot(self):
            n = self.sample_count
            arr = np.empty(n, dtype=np.float64)
            lib.rank_dump.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_double)]
            lib.rank_dump(self._h, arr.ctypes.data_as(ctypes.POINTER(ctypes.c_double)))
            return tuple(float(v) for v in arr)

    return NativeBufferTracker
