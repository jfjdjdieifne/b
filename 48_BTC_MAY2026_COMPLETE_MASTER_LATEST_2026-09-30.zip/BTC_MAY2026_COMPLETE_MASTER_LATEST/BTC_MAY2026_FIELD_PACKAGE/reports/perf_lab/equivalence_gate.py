"""EQUIVALENCE GATE — every prototype vs the CLOSED tracker, field-by-field.

Standard of equivalence taken FROM the closed contract itself:
- counts/percentile: exact integers + (less + 0.5*equal)/n — require BITWISE
  equality of the resulting float64 (same arithmetic on same counts).
- percentile_value: the contract pins NumPy's 'linear' estimator — we call the
  SAME numpy function on the SAME multiset; require bitwise equality.
- exceptions: same CLOSED exception classes on the same inputs.
No invented tolerance anywhere; any divergence is printed literally.
"""

from __future__ import annotations

import math
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np

from trading_system.core.causal_percentile import (
    CausalPercentileTracker,
    CausalPercentileDataError,
    CausalPercentileConfigError,
)
from prototypes import BisectListTracker, NumpyBufferTracker, TreapTracker, load_native

CASES = {}


def case(name):
    def deco(fn):
        CASES[name] = fn
        return fn
    return deco


@case("empty")
def _():
    return []


@case("one_row")
def _():
    return [3.5]


@case("duplicates_mixed")
def _():
    return [1.0, 1.0, 2.0, 1.0, 2.0, 2.0, 3.0]


@case("all_equal")
def _():
    return [7.25] * 50


@case("monotonic_increasing")
def _():
    return list(np.arange(0.0, 200.0, 0.5))


@case("monotonic_decreasing")
def _():
    return list(np.arange(200.0, 0.0, -0.75))


@case("alternating")
def _():
    return [10.0, -10.0] * 100


@case("random_seeded")
def _():
    return list(np.random.default_rng(42).normal(size=500))


@case("extreme_magnitudes")
def _():
    return [0.0, 1e308, -1e308, 5e-324, 1e-308, 1.0, -0.0, 2.2250738585072014e-308,
            1.7976931348623157e308, -5e-324, 0.0]


@case("exact_ties_heavy")
def _():
    return [1.0, 2.0, 2.0, 2.0, 3.0, 3.0, 1.0, 1.0] * 30


@case("signed_zero_mix")
def _():
    return [0.0, -0.0, 0.0, -0.0, 1.0, -1.0, -0.0, 0.0]


@case("nan_inf_policy_skip_stream")
def _():
    return [1.0, float("nan"), 2.0, float("nan"), 3.0]


def compare_trackers(stream, nan_policy="skip", use_percentiles=True):
    """Run identical streams through CLOSED original + prototypes; compare all
    contractually observable fields BITWISE (float.hex on every float)."""
    results = {}
    classes = [CausalPercentileTracker, BisectListTracker, NumpyBufferTracker, TreapTracker]
    Native = load_native()
    if Native is not None:
        classes.append(Native)
    errors = {}
    for cls in classes:
        tr = cls(nan_policy=nan_policy)
        obs_rows = []
        try:
            for x in stream:
                obs_rows.append(tr.observe(x))
        except (CausalPercentileDataError, CausalPercentileConfigError) as exc:
            errors[cls if not hasattr(cls, "name") else cls.name] = type(exc).__name__
            results[cls] = obs_rows
            continue
        results[cls] = obs_rows
    base_cls = CausalPercentileTracker
    base_rows = results[base_cls]
    base_err = errors.get(base_cls)
    problems = []
    for cls in classes:
        name = getattr(cls, "name", "P0_closed_original")
        if cls is base_cls:
            continue
        if errors.get(name) != base_err:
            problems.append(f"{name}: exception mismatch ({errors.get(name)} vs {base_err})")
            continue
        rows = results[cls]
        if len(rows) != len(base_rows):
            problems.append(f"{name}: row count {len(rows)} != {len(base_rows)}")
            continue
        for i, (a, b) in enumerate(zip(base_rows, rows)):
            for field in ("value", "percentile", "history_min", "history_max"):
                fa, fb = getattr(a, field), getattr(b, field)
                if math.isnan(fa) and math.isnan(fb):
                    continue
                if float(fa).hex() != float(fb).hex():
                    problems.append(f"{name} row {i} field {field}: {float(fa).hex()} != {float(fb).hex()}")
            for field in ("sample_count", "less_count", "equal_count", "greater_count", "accepted"):
                if getattr(a, field) != getattr(b, field):
                    problems.append(f"{name} row {i} field {field}: {getattr(a, field)} != {getattr(b, field)}")
    # percentile_value equivalence (the np.quantile 'linear' contract)
    if use_percentiles and not base_err:
        base_tr = CausalPercentileTracker(nan_policy=nan_policy)
        protos = [cls(nan_policy=nan_policy) for cls in classes if cls is not base_cls]
        protos = {getattr(cls, "name"): inst for cls, inst in zip([c for c in classes if c is not base_cls], protos)}
        for x in stream:
            base_tr.push(x)
            for inst in protos.values():
                inst.push(x)
        for q in (0.0, 0.25, 0.5, 0.77, 1.0):
            bv = base_tr.percentile_value(q)
            for name, inst in protos.items():
                pv = inst.percentile_value(q)
                if math.isnan(bv) and math.isnan(pv):
                    continue
                if float(bv).hex() != float(pv).hex():
                    problems.append(f"{name} percentile_value({q}): {float(bv).hex()} != {float(pv).hex()}")
    return problems


def run():
    total = 0
    failed = 0
    for name, fn in CASES.items():
        stream = fn()
        for policy in ("skip", "raise"):
            if policy == "raise" and any(isinstance(x, float) and math.isnan(x) for x in stream):
                # NaN under raise: exception path — still compared
                pass
            problems = compare_trackers(stream, nan_policy=policy)
            total += 1
            status = "PASS" if not problems else "FAIL"
            if problems:
                failed += 1
            print(f"[{status}] {name} nan_policy={policy}" + ("" if not problems else " :: " + "; ".join(problems[:6])))
    # error-type cases (closed contract)
    for bad, expect in ((True, "BOOL"), (float("inf"), "INF"), (float("nan"), "NAN_RAISE")):
        tr = CausalPercentileTracker(nan_policy="raise" if expect == "NAN_RAISE" else "skip")
        try:
            tr.observe(bad)
            print(f"[FAIL] error case {expect}: no exception")
            failed += 1
        except CausalPercentileDataError:
            print(f"[PASS] error case {expect}: CausalPercentileDataError")
        total += 1
        for P in (BisectListTracker, NumpyBufferTracker, TreapTracker):
            tr2 = P(nan_policy="raise" if expect == "NAN_RAISE" else "skip")
            try:
                tr2.observe(bad)
                print(f"[FAIL] {P.name} error case {expect}: no exception")
                failed += 1
            except CausalPercentileDataError:
                pass
            total += 1
    print(f"\nEQUIVALENCE GATE: {total - failed}/{total} PASS" + ("" if not failed else f" — {failed} FAIL"))
    return failed


if __name__ == "__main__":
    sys.exit(1 if run() else 0)
