"""EXACT PERFORMANCE V2 — unit-level old-vs-new benchmarks.

Measures, on identical synthetic fixtures:
  1. tracker observe() stream (models the volatility/rank hotspot),
  2. percentile_value() query batches (models the swings hotspot),
  3. FVG analyze() old vs new,
  4. narrative analyze() old vs new.

Primitive sizes: 1k/5k/10k/20k/44,640/100k/250k/1m (observe stream) and
percentile_value batches at 1k..44,640. Engine sizes: 1k/5k/10k/20k/44,640
(FVG) and evidence rows 1k/2k/6k/12k (narrative).

Run: python3 bench_units.py [--quick]
"""
from __future__ import annotations

import argparse
import importlib.util
import statistics
import sys
import time
from pathlib import Path

import numpy as np

PROJECT = Path("/home/user/project/trading_project")
sys.path.insert(0, str(PROJECT / "src"))

REF_DIR = PROJECT / "tests" / "_patch_reference_src"


def _load_ref(name: str):
    spec = importlib.util.spec_from_file_location(
        f"_bench_ref_{name}", REF_DIR / f"{name}_pre.py"
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def timed(fn):
    t0 = time.perf_counter()
    out = fn()
    return time.perf_counter() - t0, out


def stream_values(n: int) -> list[float]:
    rng = np.random.default_rng(1234 + n)
    # deterministic, ties + duplicates + occasional zeros (feature-like)
    base = np.round(rng.normal(0.5, 0.25, size=n), 2)
    base[::97] = 0.0
    base[::311] = base[::311]  # keep values
    return [float(x) for x in base]


def bench_observe(sizes):
    from trading_system.core.causal_percentile import CausalPercentileTracker as NewT

    ref = _load_ref("causal_percentile")
    rows = []
    for n in sizes:
        values = stream_values(n)

        def run(cls):
            tracker = cls()
            t0 = time.perf_counter()
            for v in values:
                tracker.observe(v)
            return time.perf_counter() - t0

        t_new = run(NewT)
        if n <= 100_000:
            t_old = run(ref.CausalPercentileTracker)
        else:
            # Old rank() is O(n) per observe => quadratic; measured at smaller
            # sizes, projected here via (n/n_ref)^2.
            t_old = float("nan")
        speedup = t_old / t_new if t_old == t_old else float("nan")
        rows.append(("observe_stream", n, t_old, t_new, speedup))
        print(
            f"observe_stream n={n:>7} old={t_old:8.3f}s new={t_new:8.3f}s "
            f"speedup={speedup:7.1f}x",
            flush=True,
        )
    return rows


def bench_percentile_value(sizes):
    from trading_system.core.causal_percentile import CausalPercentileTracker as NewT

    ref = _load_ref("causal_percentile")
    rows = []
    queries = [i / 64.0 for i in range(65)]
    for n in sizes:
        values = stream_values(n)
        for label, cls in (("new", NewT), ("old", ref.CausalPercentileTracker)):
            tracker = cls()
            for v in values:
                tracker.push(v)
            t0 = time.perf_counter()
            for q in queries:
                tracker.percentile_value(q)
            t = time.perf_counter() - t0
            if label == "new":
                t_new = t
            else:
                t_old = t
        rows.append(("percentile_value_x65", n, t_old, t_new, t_old / t_new if t_new else float("inf")))
        print(f"percentile_value(65q) n={n:>7} old={t_old:8.4f}s new={t_new:8.4f}s speedup={t_old / max(t_new, 1e-12):7.1f}x", flush=True)
    return rows


def fvg_frame(n: int):
    import pandas as pd

    rng = np.random.default_rng(77 + n)
    price = 100.0
    rows = []
    for _ in range(n):
        jump = rng.normal(0, 0.9)
        if rng.random() < 0.18:
            jump += rng.choice([-1.0, 1.0]) * rng.uniform(1.2, 2.6)
        o = price
        c = o + jump
        h = max(o, c) + abs(rng.normal(0, 0.35))
        l = min(o, c) - abs(rng.normal(0, 0.35))
        rows.append((round(o, 8), round(h, 8), round(l, 8), round(c, 8)))
        price = c
    return pd.DataFrame(rows, columns=["open", "high", "low", "close"], dtype=float)


def bench_fvg(sizes):
    from trading_system.zones.fvg import CausalFVGEngine as NewE

    ref_fvg = _load_ref("fvg")
    rows = []
    for n in sizes:
        frame = fvg_frame(n)
        t_new, _ = timed(lambda: NewE().analyze(frame.copy()))
        t_old, _ = timed(lambda: ref_fvg.CausalFVGEngine().analyze(frame.copy()))
        rows.append(("fvg_analyze", n, t_old, t_new, t_old / t_new))
        print(f"fvg_analyze      n={n:>7} old={t_old:8.3f}s new={t_new:8.3f}s speedup={t_old / t_new:7.1f}x", flush=True)
    return rows


def narrative_frames(n: int):
    sys.path.insert(0, "/home/user/project/trading_project/tests")
    import test_narrative as tn

    states = []
    events = []
    rng = np.random.default_rng(31 + n)
    for i in range(n):
        r = rng.random()
        states.append("UP_STRUCTURE" if r < 0.4 else ("DOWN_STRUCTURE" if r < 0.8 else "MIXED"))
        events.append("BOS_UP" if (i % 23 == 5) else ("BOS_DOWN" if i % 37 == 11 else "NONE"))
    source = tn.structural_source(states, events)
    source = tn.add_multiscale(source, list(rng.normal(0, 0.5, size=n)))
    source = tn.add_range(source, list(rng.random(n)))
    evidence, manifest = tn.evidence_from_source(source, tn.config(multiscale=True, dealing_range=True))
    return evidence, manifest


def bench_narrative(sizes):
    from trading_system.decision.narrative import CausalMarketNarrativeEngine as NewE

    ref_nar = _load_ref("narrative")
    rows = []
    for n in sizes:
        evidence, manifest = narrative_frames(n)
        t_new, _ = timed(lambda: NewE().analyze(evidence.copy(), manifest.copy()))
        t_old, _ = timed(lambda: ref_nar.CausalMarketNarrativeEngine().analyze(evidence.copy(), manifest.copy()))
        rows.append(("narrative_analyze", n, t_old, t_new, t_old / t_new))
        print(f"narrative_analyze n={n:>7} old={t_old:8.3f}s new={t_new:8.3f}s speedup={t_old / t_new:7.1f}x", flush=True)
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    primitive_sizes = [1_000, 5_000, 10_000, 20_000, 44_640]
    if not args.quick:
        primitive_sizes += [100_000, 250_000, 1_000_000]
    engine_sizes = [1_000, 5_000, 10_000, 20_000, 44_640]
    if args.quick:
        engine_sizes = [1_000, 5_000]
        primitive_sizes = [1_000, 5_000]

    all_rows = []
    all_rows += bench_observe(primitive_sizes)
    all_rows += bench_percentile_value([n for n in primitive_sizes if n <= 44_640])
    all_rows += bench_fvg([n for n in engine_sizes if n <= 20_000] + ([44_640] if not args.quick else []))
    all_rows += bench_narrative([1_000, 2_000, 6_000, 12_000])

    out = Path("/home/user/perf_lab/bench_units_results.txt")
    with out.open("w") as fh:
        fh.write("unit, n, old_s, new_s, speedup\n")
        for row in all_rows:
            fh.write(f"{row[0]}, {row[1]}, {row[2]:.6f}, {row[3]:.6f}, {row[4]:.3f}\n")
    print(f"\nresults -> {out}")


if __name__ == "__main__":
    main()
