"""CAUSALITY GATE — prefix invariance under future suffix (no future knowledge)."""

from __future__ import annotations

import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np

from trading_system.core.causal_percentile import CausalPercentileTracker
from prototypes import BisectListTracker, NumpyBufferTracker, TreapTracker, load_native


def stream_observables(cls, stream, nan_policy="skip"):
    tr = cls(nan_policy=nan_policy)
    rows = []
    for x in stream:
        o = tr.observe(x)
        rows.append((float(o.value).hex(), float(o.percentile).hex(), o.sample_count,
                     o.less_count, o.equal_count, o.greater_count,
                     float(o.history_min).hex(), float(o.history_max).hex(), o.accepted))
    return rows


def run():
    rng = np.random.default_rng(7)
    prefix = list(rng.normal(size=300)) + [1.0, 1.0, 2.0, 2.0, float("nan")]
    suffix_a = []
    suffix_b = [5e5, -5e5, 0.0, 3.3] * 50
    classes = [CausalPercentileTracker, BisectListTracker, NumpyBufferTracker, TreapTracker]
    Native = load_native()
    if Native:
        classes.append(Native)
    failures = 0
    checks = 0
    for cls in classes:
        name = getattr(cls, "name", "P0_closed_original")
        base = stream_observables(cls, prefix + suffix_a)
        with_suffix = stream_observables(cls, prefix + suffix_b)
        checks += 1
        if base[: len(prefix)] != with_suffix[: len(prefix)]:
            failures += 1
            print(f"[FAIL] {name}: future suffix changed a prefix output")
        else:
            print(f"[PASS] {name}: outputs <= T invariant under two different future suffixes")
        # repeated run determinism
        again = stream_observables(cls, prefix + suffix_a)
        checks += 1
        if again != base:
            failures += 1
            print(f"[FAIL] {name}: repeated run not bitwise identical")
        else:
            print(f"[PASS] {name}: repeated run bitwise identical")
        # prefix truncation: observing only the prefix gives the same first rows
        trunc = stream_observables(cls, prefix)
        checks += 1
        if trunc != base[: len(prefix)]:
            failures += 1
            print(f"[FAIL] {name}: prefix truncation changed outputs")
        else:
            print(f"[PASS] {name}: prefix truncation exact")
    print(f"\nCAUSALITY GATE: {checks - failures}/{checks} PASS")
    return failures


if __name__ == "__main__":
    sys.exit(1 if run() else 0)
