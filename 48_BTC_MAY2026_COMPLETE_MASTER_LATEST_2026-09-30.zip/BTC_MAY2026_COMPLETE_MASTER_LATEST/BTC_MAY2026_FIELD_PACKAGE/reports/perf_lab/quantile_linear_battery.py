"""EXACT PERFORMANCE V2 — bitwise battery for the combined percentile_value algorithm.

Production algorithm (PATCH-1 fast path):
  * selection by exact virtual index: numpy `_QuantileMethods['linear']` is
    `(n - 1) * q` (NOT the generic Hyndman-Fan expression),
    bounds per `_get_indexes`, gamma per `_get_gamma` (identity fix_gamma),
  * interpolation by the scalar replica of `numpy._lerp` (branch t >= 0.5),
  * ONLY when the current window contains BOTH -0.0 and +0.0 AND a selected
    endpoint is zero, the ORIGINAL literal path is used:
    np.quantile(np.fromiter(deque), q, method="linear").
    Reason: np.sort tie-permutation of mixed signed zeros is unstable and not
    reproducible incrementally; every other case has a unique sorted layout.

Battery compares the combined algorithm against np.quantile(method="linear")
float-for-float (float.hex()). ANY mismatch rejects the patch.

Run: python3 quantile_linear_battery.py
"""
from __future__ import annotations

import math

import numpy as np


def lerp_scalar(a: float, b: float, t: float) -> float:
    # numpy _lerp scalar equivalent (IEEE-754 binary64 op order preserved).
    diff_b_a = b - a
    if t >= 0.5:
        return b - diff_b_a * (1 - t)
    return a + diff_b_a * t


def quantile_combined(values: list[float], q: float) -> float:
    """Combined production algorithm; `values` = current history (any order)."""
    # ---- original literal fallback path (deque-order array + np.quantile)
    def fallback() -> float:
        arr = np.fromiter(values, dtype=np.float64, count=len(values))
        return float(np.quantile(arr, q, method="linear"))

    # ---- incremental state equivalents
    s = sorted(values)  # stable; equals keep input order (as bisect inserts do)
    neg_zero = sum(1 for v in values if v == 0.0 and math.copysign(1.0, v) < 0)
    pos_zero = sum(1 for v in values if v == 0.0 and math.copysign(1.0, v) > 0)

    n = len(s)
    virtual = (n - 1) * q
    if virtual >= n - 1:
        prev_index = -1
        next_index = -1
        gamma = virtual - (-1.0)
    elif virtual < 0.0:
        prev_index = 0
        next_index = 0
        gamma = virtual
    else:
        floor_virtual = math.floor(virtual)
        prev_index = int(floor_virtual)
        next_index = prev_index + 1
        gamma = virtual - float(floor_virtual)
    a = s[prev_index]
    b = s[next_index]
    if neg_zero and pos_zero and (a == 0.0 or b == 0.0):
        return fallback()
    return lerp_scalar(a, b, gamma)


def run_battery() -> int:
    zeros = [0.0, -0.0]
    finite_small = [
        1.0, -1.0, 2.0, -2.0, 0.5, -0.5, 1e-3, -1e-3, 3.5, -3.5, 10.0, -10.0,
    ]
    subnormals = [5e-324, -5e-324, 2.2250738585072014e-308, -2.2250738585072014e-308]
    large = [1e308, -1e308, 1.7976931348623157e308, -1.7976931348623157e308]
    weird = [
        math.nextafter(1.0, 2.0), math.nextafter(1.0, 0.0),
        math.nextafter(0.0, 1.0), math.nextafter(0.0, -1.0),
        0.1, 0.2, 0.3, 0.1 + 0.2,
    ]
    corpora: list[list[float]] = []
    rng = np.random.default_rng(20260929)
    for n in (1, 2, 3, 4, 5, 7, 8, 9, 15, 16, 17, 31, 32, 64, 100, 127, 1000):
        corpora.append([0.0] * n)
        corpora.append([-0.0] * n)
        corpora.append([0.0 if i % 2 == 0 else -0.0 for i in range(n)])
        corpora.append([-0.0 if i % 2 == 0 else 0.0 for i in range(n)])
        corpora.append([1.0] * n)
        corpora.append(list(rng.normal(size=n)))
        corpora.append(list(rng.normal(size=n) * 1e12))
        corpora.append(list(rng.normal(size=n) * 1e-12))
        corpora.append(list(np.round(rng.normal(size=n), 1)))
        corpora.append([float(i) for i in range(n)])
        corpora.append([-float(i) for i in range(n)])
        corpora.append(list(rng.choice(np.array(finite_small + zeros, dtype=float), size=n)))
        corpora.append(list(rng.choice(np.array(subnormals + zeros + finite_small, dtype=float), size=n)))
        corpora.append(list(rng.choice(np.array(large + finite_small + zeros, dtype=float), size=n)))
        corpora.append(list(rng.choice(np.array(weird + zeros + finite_small, dtype=float), size=n)))
        corpora.append(list(np.round(rng.normal(size=n), 0)))
        base = list(rng.normal(size=n))
        for k in range(min(n, 5)):
            base[k * n // max(1, min(n, 5))] = [0.0, -0.0][k % 2]
        corpora.append(base)
    corpora += [
        [-0.0, 0.0], [0.0, -0.0],
        [-0.0, 0.0, -0.0, 0.0],
        [1.0, -0.0, 0.0, 2.0, -0.0],
        [0.0, -0.0, 5e-324, -5e-324, 1.0, -1.0],
        [-0.0, 0.0, 0.0, -0.0, 1.0, 1.0, -0.0],
        [1e308, 1e308, -1e308, -1e308, 0.0, -0.0],
        [0.3, 0.1, 0.2, 0.1 + 0.2, 0.0, -0.0],
    ]

    qs = [0.0, 1.0, 0.5, 1.0 / 3.0, 2.0 / 3.0, 0.1, 0.2, 0.7, 0.9, 0.99, 0.05, 0.95]
    for n in (2, 3, 4, 5, 7, 10, 16, 17, 33, 100, 1000):
        h_target = n // 2
        qs.append(h_target / (n - 1) if n > 1 else 0.5)
        if n > 1:
            qs.append(math.nextafter(h_target / (n - 1), 0.0))
            qs.append(math.nextafter(h_target / (n - 1), 1.0))
            qs.append((h_target + 0.5) / (n - 1))
    qs += [float(x) for x in rng.random(64)]
    qs += [0.1 + 0.2, math.nextafter(0.5, 0.0), math.nextafter(0.5, 1.0)]

    seen = set()
    q_list = []
    for q in qs:
        if not (0.0 <= q <= 1.0) or not math.isfinite(q):
            continue
        key = float(q).hex()
        if key not in seen:
            seen.add(key)
            q_list.append(float(q))

    mismatches = []
    comparisons = 0
    for ci, corpus in enumerate(corpora):
        arr = np.array(corpus, dtype=np.float64)
        for q in q_list:
            expected = float(np.quantile(arr, q, method="linear"))
            got = quantile_combined(list(corpus), q)
            comparisons += 1
            if float(got).hex() != float(expected).hex():
                mismatches.append((ci, len(corpus), float(q).hex(),
                                   float(got).hex(), float(expected).hex()))
                if len(mismatches) >= 25:
                    break
        if len(mismatches) >= 25:
            break

    print(f"corpora: {len(corpora)}  q-values: {len(q_list)}  comparisons: {comparisons}")
    if mismatches:
        print(f"BATTERY MISMATCHES: {len(mismatches)}")
        for m in mismatches[:25]:
            print("  corpus#", m[0], "n=", m[1], "q=", m[2], "manual=", m[3], "numpy=", m[4])
        return 1
    print("BATTERY PASSED: combined algorithm is bitwise-equal to np.quantile(method='linear') on this battery.")
    return 0


if __name__ == "__main__":
    raise SystemExit(run_battery())
