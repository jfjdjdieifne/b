"""FVG old-vs-new with TRUE stacks (A: old tracker+old fvg, B: new tracker+old fvg, C: new tracker+new fvg)."""
from __future__ import annotations
import importlib.util, sys, time
from pathlib import Path
import numpy as np, pandas as pd

PROJECT = Path("/home/user/project/trading_project")
sys.path.insert(0, str(PROJECT / "src"))
REF_DIR = PROJECT / "tests" / "_patch_reference_src"

def _load_ref(name):
    spec = importlib.util.spec_from_file_location(f"_bench_ref_{name}", REF_DIR / f"{name}_pre.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

ref_cp = _load_ref("causal_percentile")
ref_fvg = _load_ref("fvg")

from trading_system.core.causal_percentile import CausalPercentileTracker as NewT
from trading_system.zones.fvg import CausalFVGEngine as NewE

def fvg_frame(n, gap_prob, seed):
    rng = np.random.default_rng(seed)
    price = 100.0; rows = []
    for _ in range(n):
        jump = rng.normal(0, 0.5 if gap_prob < 0.1 else 0.9)
        if rng.random() < gap_prob:
            jump += rng.choice([-1.0, 1.0]) * rng.uniform(1.2, 2.6)
        o = price; c = o + jump
        h = max(o, c) + abs(rng.normal(0, 0.35)); l = min(o, c) - abs(rng.normal(0, 0.35))
        rows.append((round(o, 8), round(h, 8), round(l, 8), round(c, 8)))
        price = c
    return pd.DataFrame(rows, columns=["open", "high", "low", "close"], dtype=float)

def run_analyze(engine_factory, frame):
    t0 = time.perf_counter()
    engine_factory().analyze(frame.copy())
    return time.perf_counter() - t0

def bench(sizes, fixture_label, gap_prob, seed):
    out_rows = []
    for n in sizes:
        frame = fvg_frame(n, gap_prob, seed + n)
        # A: true baseline = old fvg wired to OLD tracker
        ref_fvg.CausalPercentileTracker = ref_cp.CausalPercentileTracker
        tA = run_analyze(ref_fvg.CausalFVGEngine, frame)
        # B: PATCH-1 only = old fvg wired to NEW tracker
        ref_fvg.CausalPercentileTracker = NewT
        tB = run_analyze(ref_fvg.CausalFVGEngine, frame)
        # C: all = new fvg (uses new tracker)
        tC = run_analyze(NewE, frame)
        row = (fixture_label, n, tA, tB, tC)
        out_rows.append(row)
        print(f"fvg[{fixture_label}] n={n:>6} A_old={tA:8.3f}s  B_pct-only={tB:8.3f}s  C_all={tC:8.3f}s  speedup_A/C={tA/tC:5.2f}x  (B/A={tB/tA:.2f} C/B={tC/tB:.2f})", flush=True)
    return out_rows

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(); p.add_argument("--phase", required=True)
    args = p.parse_args()
    phases = {
        "a": ([1000, 5000, 10000], ),
        "b": ([20000], ),
        "c": ([44640], ),
    }
    sizes = phases[args.phase][0]
    rows = []
    rows += bench(sizes, "realistic", 0.05, 77)
    rows += bench(sizes, "dense", 0.18, 77)
    with open(f"bench_fvg_{args.phase}.txt", "w") as fh:
        fh.write("fixture, n, A_old_s, B_pctonly_s, C_all_s\n")
        for r in rows:
            fh.write(f"{r[0]}, {r[1]}, {r[2]:.6f}, {r[3]:.6f}, {r[4]:.6f}\n")
    print(f"PHASE-{args.phase.upper()} DONE")
