"""S0 records tests: immutability, append-only events, typed causal references.

Attacks covered: 01, 11, 12, 19. Generic foundations only; no market-specific
S1+ event semantics.
"""
import pandas as pd
import pytest

from trading_system.market_understanding.availability import InformationAxis
from trading_system.market_understanding.contracts import (
    IllegalCausalReference,
    ImmutabilityViolation,
    InformationKeyViolation,
    SchemaIdentity,
    SchemaViolation,
    TypedState,
)
from trading_system.market_understanding.records import (
    AppendOnlyEventLedger,
    AvailabilityReference,
    CausalRecordReference,
    EventKind,
    EventRecord,
    PublishedRecord,
    validate_reference_at,
    validate_reference_type,
)
from trading_system.research.information_time import (
    INFORMATION_KEY_VERSION,
    InformationKey,
    InformationPhase,
)


def _key(timeline_id="TL", bar_position=0, phase=InformationPhase.COMPLETED_ROW_AVAILABLE,
         sequence=0, event_time_utc=None):
    return InformationKey(
        information_key_version=INFORMATION_KEY_VERSION,
        timeline_id=timeline_id,
        bar_position=bar_position,
        event_time_utc=event_time_utc,
        information_phase=phase,
        deterministic_sequence=sequence,
    )


_SCHEMA = SchemaIdentity("RECORD_DOMAIN", "RECORD_V1")


def _record(timeline_id="TL", bar_position=0, **overrides):
    fields = dict(
        record_identity="rec-1",
        record_type="GENERIC_FACTUAL_RECORD",
        schema_identity=_SCHEMA,
        timeline_id=timeline_id,
        availability_key=_key(timeline_id=timeline_id, bar_position=bar_position),
        content={"value": "v", "state": TypedState.NOT_CONFIGURED},
    )
    fields.update(overrides)
    return PublishedRecord(**fields)


def _reference(timeline_id="TL", bar_position=0, **overrides):
    fields = dict(
        referenced_record_identity="rec-1",
        referenced_record_type="GENERIC_FACTUAL_RECORD",
        referenced_schema_identity=_SCHEMA,
        timeline_id=timeline_id,
        availability=_key(timeline_id=timeline_id, bar_position=bar_position),
    )
    fields.update(overrides)
    return CausalRecordReference(**fields)


def test_attack01_cross_timeline_causal_reference_rejected():
    reference = _reference(timeline_id="TL_A", bar_position=0)
    at_key = _key(timeline_id="TL_B", bar_position=5)
    with pytest.raises(IllegalCausalReference):
        validate_reference_at(reference=reference, at_key=at_key)
    with pytest.raises(InformationKeyViolation):
        _reference(
            timeline_id="TL_A",
            availability=_key(timeline_id="TL_B"),
        )
    validate_reference_at(
        reference=_reference(timeline_id="TL_A", bar_position=0),
        at_key=_key(timeline_id="TL_A", bar_position=5),
    )


def test_attack11_published_record_mutation_rejected():
    record = _record()
    assert record.content["state"] is TypedState.NOT_CONFIGURED
    with pytest.raises(ImmutabilityViolation):
        record.record_identity = "rec-2"
    with pytest.raises(ImmutabilityViolation):
        record.content = {}
    with pytest.raises(ImmutabilityViolation):
        del record.record_identity
    with pytest.raises(TypeError):
        record.content["value"] = "mutated"


def test_attack12_overwrite_rejected_new_event_required():
    record = _record()
    ledger = AppendOnlyEventLedger()
    replacement = _record(record_identity="rec-2")
    with pytest.raises(ImmutabilityViolation):
        ledger.overwrite("rec-1", replacement)
    supersession = EventRecord(
        event_identity="ev-supersede-1",
        event_kind=EventKind.SUPERSESSION_EVENT,
        subject_record_identity="rec-1",
        event_key=_key(bar_position=1),
        event_payload={"superseded_by": "rec-2"},
    )
    ledger.append(supersession)
    assert record.record_identity == "rec-1"
    assert record.content["value"] == "v"
    assert ledger.project_supersession("rec-1") == "rec-2"
    with pytest.raises(SchemaViolation):
        ledger.append(supersession)


def test_attack19_future_append_cannot_mutate_record():
    record = _record()
    ledger = AppendOnlyEventLedger()
    ledger.append(
        EventRecord(
            event_identity="ev-1",
            event_kind=EventKind.STATUS_EVENT,
            subject_record_identity="rec-1",
            event_key=_key(bar_position=1),
            event_payload={"status": "ACTIVE"},
        )
    )
    with pytest.raises(ImmutabilityViolation):
        record.__init__(
            record_identity="rec-hijacked",
            record_type="GENERIC_FACTUAL_RECORD",
            schema_identity=_SCHEMA,
            timeline_id="TL",
            availability_key=_key(),
            content={},
        )
    assert record.record_identity == "rec-1"
    events_before = ledger.events()
    ledger.append(
        EventRecord(
            event_identity="ev-2",
            event_kind=EventKind.MEMBERSHIP_EVENT,
            subject_record_identity="rec-1",
            event_key=_key(bar_position=2),
            event_payload={"member_of": "set-1"},
        )
    )
    assert events_before == ledger.events()[:1]
    assert record.record_identity == "rec-1"


def test_ledger_append_only_projection_from_events():
    ledger = AppendOnlyEventLedger()
    assert ledger.project_status("rec-1") is TypedState.UNDEFINED
    assert ledger.project_supersession("rec-1") is TypedState.NOT_APPLICABLE
    ledger.append(
        EventRecord(
            event_identity="ev-a",
            event_kind=EventKind.STATUS_EVENT,
            subject_record_identity="rec-1",
            event_key=_key(bar_position=1),
            event_payload={"status": "ACTIVE"},
        )
    )
    ledger.append(
        EventRecord(
            event_identity="ev-b",
            event_kind=EventKind.STATUS_EVENT,
            subject_record_identity="rec-1",
            event_key=_key(bar_position=2),
            event_payload={"status": "SUPERSEDED_PENDING"},
        )
    )
    assert ledger.project_status("rec-1") == "SUPERSEDED_PENDING"
    assert len(ledger.events()) == 2
    with pytest.raises(SchemaViolation):
        ledger.append("not-an-event")


def test_future_record_cannot_masquerade_as_visible():
    reference = _reference(bar_position=5)
    at_key = _key(bar_position=3)
    with pytest.raises(IllegalCausalReference):
        validate_reference_at(reference=reference, at_key=at_key)
    validate_reference_at(reference=_reference(bar_position=3), at_key=_key(bar_position=5))


def test_reference_type_and_schema_validation():
    reference = _reference()
    validate_reference_type(
        reference=reference,
        expected_record_type="GENERIC_FACTUAL_RECORD",
        expected_schema_identity=_SCHEMA,
    )
    with pytest.raises(IllegalCausalReference):
        validate_reference_type(
            reference=reference,
            expected_record_type="OTHER_RECORD",
            expected_schema_identity=_SCHEMA,
        )
    with pytest.raises(IllegalCausalReference):
        validate_reference_type(
            reference=reference,
            expected_record_type="GENERIC_FACTUAL_RECORD",
            expected_schema_identity=SchemaIdentity("RECORD_DOMAIN", "RECORD_V2"),
        )


def test_unresolved_availability_reference_fails_closed():
    pointer = AvailabilityReference(
        availability_record_identity="avail-1",
        schema_identity=SchemaIdentity("AVAIL_DOMAIN", "AVAIL_V1"),
        timeline_id="TL",
    )
    reference = _reference(availability=pointer)
    with pytest.raises(IllegalCausalReference):
        validate_reference_at(reference=reference, at_key=_key(bar_position=5))
    with pytest.raises(SchemaViolation):
        _reference(timeline_id="TL", availability=42)
