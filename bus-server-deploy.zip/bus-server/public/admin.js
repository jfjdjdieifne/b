/* ==== لوحة إدارة الجامعة ==== */
var token=localStorage.getItem('sct_token');
var routes=[], buses=[], settings={}, students=[], S_editStu=null;
var liveMap=null, liveMarkers={}, liveStarted=false;

function api(p,o){ o=o||{}; o.headers=Object.assign({'Authorization':'Bearer '+token,'Content-Type':'application/json'},o.headers||{}); return fetch(p,o).then(function(r){ if(r.status===401){window.location.href='index.html';} return r.json().then(function(j){ if(!r.ok && j && j.error){throw new Error(j.error);} return j; }); }); }
function toast(msg,err){ var t=document.createElement('div'); t.className='toast show'+(err?' err':''); t.textContent=msg; document.body.appendChild(t); setTimeout(function(){t.classList.remove('show');},2400); }

async function boot(){
  var me=await api('api/me'); if(me.role!=='admin'){ window.location.href='index.html'; return; }
  document.getElementById('who').textContent='🏛️ '+esc(me.name||'إدارة الجامعة');
  await load(); fillRouteSelects(); renderStudents(); renderRouteCards(); go('students');
}
async function load(){ var m=await api('api/admin/meta'); routes=m.routes; buses=m.buses; settings=m.settings; }
function go(t){ document.querySelectorAll('.nav-btn').forEach(function(b){b.classList.toggle('active',b.dataset.t===t);}); document.querySelectorAll('.panel').forEach(function(p){p.classList.remove('active');}); document.getElementById('p-'+t).classList.add('active'); var ti={students:['الطلاب','إدارة وإضافة'],live:['الخريطة الحية','لحظة بلحظة'],routes:['الخطوط','عرض فقط'],timetables:['المواعيد','جدول الرحلات']}; document.getElementById('pageTitle').textContent=ti[t][0]; document.getElementById('pageSub').textContent=ti[t][1]; if(t==='live')startLive(); if(t==='timetables')renderTimetables(); }

function fillRouteSelects(){
  var sr=document.getElementById('stRoute');
  sr.innerHTML=routes.map(function(r){return '<option value="'+r.id+'">'+esc(r.name)+'</option>';}).join('');
  if(S_editStu) sr.value=S_editStu.routeId;
  fillStops(sr.value);
  var fr=document.getElementById('filterRoute'); fr.innerHTML='<option value="">كل الخطوط</option>'+routes.map(function(r){return '<option value="'+r.id+'">'+esc(r.name)+'</option>';}).join('');
}
function fillStops(routeId){
  var r=routes.find(function(x){return x.id===routeId;}); var sel=document.getElementById('stStop');
  sel.innerHTML=r?r.stops.map(function(s,i){return '<option value="'+i+'">موقف '+(i+1)+' — '+esc(s.name)+'</option>';}).join(''):'<option>لا مواقف</option>';
  if(S_editStu){ sel.value=S_editStu.stopIdx; }
  fillBus(routeId);
}
function fillBus(routeId){
  var sel=document.getElementById('stBus'); if(!sel)return;
  var busesForRoute=buses.filter(function(b){return b.routeId===routeId;});
  if(!busesForRoute.length){ sel.innerHTML='<option value="">— لا باصات (أضف باصاً) —</option>'; return; }
  sel.innerHTML=busesForRoute.map(function(b){return '<option value="'+b.id+'">'+esc(b.name)+' (السعة '+b.capacity+')</option>';}).join('');
  if(busesForRoute.length===1) sel.value=busesForRoute[0].id;
  if(S_editStu && S_editStu.busId) sel.value=S_editStu.busId;
}
document.getElementById('stRoute').addEventListener('change',function(){ fillStops(this.value); });
async function renderStudents(){
  var q=document.getElementById('stSearch').value.trim(); var rid=document.getElementById('filterRoute').value;
  var rows=await api('api/admin/students?q='+encodeURIComponent(q)+(rid?'&routeId='+rid:''));
  students=rows;
  var tb=document.getElementById('stuRows');
  tb.innerHTML=rows.map(function(s){ var r=routes.find(function(x){return x.id===s.routeId;}); var stopName=r&&r.stops[s.stopIdx]?r.stops[s.stopIdx].name:'—'; return '<tr><td><b>'+esc(s.universityId)+'</b></td><td>'+esc(s.name)+'</td><td>'+esc(r?r.name:'—')+'</td><td>'+esc(stopName)+'</td><td class="actions"><button class="btn sm ghost" onclick="editStudent(\''+s.id+'\')">تعديل</button><button class="btn sm ghost" title="إعادة تعيين كلمة المرور" onclick="resetStuPass(\''+s.id+'\')">🔑</button><button class="btn sm red" onclick="deleteStudent(\''+s.id+'\')">حذف</button></td></tr>'; }).join('')||'<tr><td colspan="5" style="text-align:center" class="muted">لا طلاب.</td></tr>';
  document.getElementById('countLbl').textContent='إجمالي '+rows.length+' طالب';
}
document.getElementById('stSearch').addEventListener('input',renderStudents);
document.getElementById('filterRoute').addEventListener('change',renderStudents);

function resetStForm(){ document.getElementById('stForm')?null:null; document.getElementById('stSaveBtn').textContent='إضافة'; document.getElementById('stCancelBtn').style.display='none'; S_editStu=null; document.getElementById('stId').value=''; document.getElementById('stName').value=''; document.getElementById('stPass').value=''; }
function renderStFormHeading(){
  // stub to keep S_editStu sync
}
function editStudent(id){ var s=students.find(function(x){return x.id===id;}); if(!s)return; S_editStu=s; document.getElementById('stId').value=s.universityId; document.getElementById('stName').value=s.name; document.getElementById('stPass').value=s.password; document.getElementById('stRoute').value=s.routeId||(routes[0]&&routes[0].id); fillStops(s.routeId||(routes[0]&&routes[0].id)); document.getElementById('stStop').value=s.stopIdx; document.getElementById('stSaveBtn').textContent='💾 حفظ'; document.getElementById('stCancelBtn').style.display=''; }
async function saveStudent(){
  var routeId=document.getElementById('stRoute').value; var stopIdx=+document.getElementById('stStop').value;
  var busSel=document.getElementById('stBus'); var body={universityId:document.getElementById('stId').value.trim(), name:document.getElementById('stName').value.trim(), password:document.getElementById('stPass').value.trim()||settings.studentDefaultPass, routeId:routeId, stopIdx:stopIdx, busId:(busSel&&busSel.value)||null};
  try{
    if(S_editStu){ await api('api/admin/student/'+S_editStu.id,{method:'PUT',body:JSON.stringify(body)}); } else { await api('api/admin/student',{method:'POST',body:JSON.stringify(body)}); }
    toast('تم حفظ الطالب'); resetStForm(); renderStudents();
  }catch(e){ toast(e.message,true); }
}
async function deleteStudent(id){ if(!confirm('حذف الطالب؟'))return; await api('api/admin/student/'+id,{method:'DELETE'}); renderStudents(); toast('حُذف'); }

function importCsv(){ document.getElementById('csvFile').click(); }
document.getElementById('csvFile').addEventListener('change',function(ev){
  var f=ev.target.files[0]; if(!f)return; var rd=new FileReader();
  rd.onload=async function(){
    var lines=String(rd.result).split(/\r?\n/).map(function(l){return l.trim();}).filter(Boolean);
    var parsed=[];
    lines.forEach(function(l){
      // تنسيق: الرقم الجامعي, الاسم, اسم الخط (أو routeId), رقم الموقف (1-based)
      var p=l.split(',').map(function(x){return x.trim();}); if(p.length<2)return;
      var row={universityId:p[0], name:p[1], routeId:p[2]||null, stopIdx:(p[3]?+p[3]-1:0)||0};
      if(row.routeId && !routes.some(function(r){return r.id===row.routeId;})){
        var rr=routes.find(function(r){return r.name===row.routeId;}); row.routeId=rr?rr.id:null;
      }
      parsed.push(row);
    });
    if(!parsed.length){ toast('لا صفوف صالحة',true); return; }
    try{ var j=await api('api/admin/students/import',{method:'POST',body:JSON.stringify({students:parsed})}); toast('أُضيف '+j.added+' · مكرر '+j.duplicate+' · الإجمالي '+j.total); renderStudents(); }catch(e){ toast(e.message,true); }
  };
  rd.readAsText(f);
});

function renderRouteCards(){ document.getElementById('routeCards').innerHTML=routes.map(function(r){ var nb=buses.filter(function(b){return b.routeId===r.id;}).length; var ns=students.filter(function(s){return s.routeId===r.id;}).length; return '<div class="card"><div style="display:flex;align-items:center;gap:9px"><span class="dot" style="background:'+r.color+';width:13px;height:13px"></span><b>'+esc(r.name)+'</b></div><div class="lbl" style="color:var(--muted);font-size:13px;margin-top:8px">'+r.stops.length+' موقف</div><div class="sub">💺 '+nb+' باص · 🎒 '+ns+' طالب</div></div>'; }).join('')||'<div class="hint">لا خطوط.</div>'; }

function startLive(){ if(!liveMap){ liveMap=L.map('liveMap',{zoomControl:true}).setView([33.51,36.28],13); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(liveMap); document.getElementById('liveLegend').innerHTML=routes.map(function(r){return '<span class="item"><span class="sw" style="background:'+r.color+'"></span>'+esc(r.name)+'</span>';}).join(''); } if(!liveStarted){ liveStarted=true; pollLive(); setInterval(pollLive,2000); } setTimeout(function(){liveMap.invalidateSize();},120); }
function pollLive(){ api('api/live').then(function(live){ var seen={}; live.forEach(function(p){ seen[p.busId]=true; if(p.lat==null)return; var color=p.phase==='return'?'#d97706':(p.routeColor||'#6366f1'); var ic=L.divIcon({className:'',html:'<div style="width:32px;height:32px;border-radius:50%;background:'+color+';color:#fff;font-weight:800;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:16px">🚌</div>',iconSize:[32,32]}); if(!liveMarkers[p.busId])liveMarkers[p.busId]=L.marker([p.lat,p.lng],{icon:ic}).addTo(liveMap); else { liveMarkers[p.busId].setLatLng([p.lat,p.lng]); liveMarkers[p.busId].setIcon(ic); } liveMarkers[p.busId].bindPopup('<b>'+esc(p.name)+'</b><br>'+(p.phase==='return'?'↩️ إياب':'🌅 ذهاب')+' · '+esc(p.nextStop||'—')); }); Object.keys(liveMarkers).forEach(function(id){ if(!seen[id]){ liveMap.removeLayer(liveMarkers[id]); delete liveMarkers[id]; } });
  document.getElementById('liveList').innerHTML=live.map(function(p){ var tag=p.phase==='return'?'<span class="tag" style="background:#d9770622;color:#fcd34d;border:1px solid #d9770644">إياب</span>':'<span class="tag" style="background:#6366f122;color:#c7d2fe;border:1px solid #6366f144">ذهاب</span>'; return '<div class="busitem"><div class="tit"><span>'+esc(p.name)+'</span>'+tag+'</div><div class="meta">'+(p.lat!=null?('<div>'+p.routeName+' · سرعة '+p.speed+' كم/س</div><div>التالي: '+esc(p.nextStop||'—')+'</div><div>'+esc(p.phaseReason||'')+(p.offRoute?' · ⚠️ خارج المسار':'')+'</div>'):'<div class="hint">غير متصل</div>')+'</div></div>'; }).join(''); }); }

function fmtT(time){ var p=String(time||'').split(':'); if(p.length<2)return time||''; var h=+p[0],m=p[1],suf=h>=12?'م':'ص'; h=h%12; if(h===0)h=12; return h+':'+m+' '+suf; }
function todayMin(){ var d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
function fillTtBus(){ var sel=document.getElementById('ttBus'); sel.innerHTML=buses.map(function(b){ var r=routes.find(function(x){return x.id===b.routeId;}); var st=b.schedule&&b.schedule.length?b.schedule.length:0; var dc=b.schedulesByDate?Object.keys(b.schedulesByDate).length:0; var wc=b.schedulesByWeekday?Object.keys(b.schedulesByWeekday).length:0; return '<option value="'+b.id+'">'+esc(b.name)+' — '+esc(r?r.name:'')+(st?' · '+st+' رحلة':'')+(dc?' · '+dc+' يوم':'')+(wc?' · '+wc+' أسبوع':'')+'</option>'; }).join(''); }
function renderTimetables(){ fillTtBus(); ttScopeChange(); }
var currentTtBusId=null;
function ttTarget(){ var scope=document.getElementById('ttScope').value; var key=null;
  if(scope==='date'){ key=document.getElementById('ttDate').value||todayMin(); }
  else if(scope==='weekday'){ key=document.getElementById('ttWeekday').value; }
  return {scope:scope, key:key};
}
function ttScheduleFor(b){ var t=ttTarget(); if(t.scope==='date'&&b.schedulesByDate&&b.schedulesByDate[t.key]) return b.schedulesByDate[t.key]; if(t.scope==='weekday'&&b.schedulesByWeekday&&b.schedulesByWeekday[t.key]) return b.schedulesByWeekday[t.key]; return b.schedule||[]; }
function currentTtBus(){ currentTtBusId=document.getElementById('ttBus').value; var b=buses.find(function(x){return x.id===currentTtBusId;}); if(b && window.schedInit){ schedInit('ttSched', ttScheduleFor(b)); } var hint=document.getElementById('ttHint'); if(hint)hint.textContent=b?('تعديل مواعيد الباص: '+b.name):'—'; }
function ttScopeChange(){ var sx=document.getElementById('ttScope').value; var row=document.getElementById('ttDateRow'); if(row)row.style.display=(sx==='base')?'none':'block'; if(sx==='date'){ var tv=document.getElementById('ttDate'); if(tv&&!tv.value) tv.value=todayMin(); } currentTtBus(); }
document.getElementById('ttBus').addEventListener('change',currentTtBus);
async function saveSchedule(){ var b=buses.find(function(x){return x.id===currentTtBusId;}); if(!b){ toast('اختر باصاً',true); return; } var t=ttTarget(); var sched=(window.schedGet? schedGet():null); try{ await api('api/admin/bus/'+b.id+'/schedule',{method:'PUT',body:JSON.stringify({scope:t.scope, key:t.key, schedule:sched})}); toast('حُفظت مواعيد '+b.name); renderTimetables(); }catch(e){ toast(e.message,true); } }
function adminTT(){ var el=document.getElementById('ttFull'); if(!el)return; api('api/timetable?date='+encodeURIComponent(todayMin())).then(function(j){ el.innerHTML='<h3 style="margin:10px 0">🗓 الجدول الكامل — '+esc(j.date)+' '+esc(j.weekday||'')+'</h3>'+j.routes.map(function(r){ var stopsA=r.stops.map(function(s,i){return '<li>'+(i+1)+' '+esc(s.name)+'</li>';}).join(''); var busRows=r.buses.map(function(b){ var sT=b.status==='on'?'شغّال الآن':(b.active?'جاهز':'متوقف'); var sC=b.status==='on'?'#22c55e':(b.active?'#f59e0b':'#94a3b8'); var trips=(b.schedule||[]).slice().sort(function(a,c){return a.dir!==c.dir? (a.dir==='out'?-1:1):(a.time<c.time?-1:1);}).map(function(t){return '<span class="tchip '+t.dir+'">'+(t.dir==='out'?'🌅':'↩️')+' '+fmtT(t.time)+'</span>';}).join(''); return '<div class="tt-bus"><div class="tt-bustitle"><b>'+esc(b.name)+'</b> <span class="btc" style="background:'+sC+'22;color:'+sC+'">'+sT+'</span></div>'+(trips?'<div class="tripchips">'+trips+'</div>':'<span class="hint">لا رحلات</span>')+'</div>'; }).join(''); return '<div class="tt-route" style="border-color:'+esc(r.color)+'"><div class="tt-rh" style="color:'+esc(r.color)+'">🚏 '+esc(r.name)+'</div><div class="tt-grid"><div class="tt-stops"><span class="hint">المواقف</span><ul>'+stopsA+'</ul></div><div class="tt-buses">'+busRows+'</div></div></div>'; }).join(''); }).catch(function(){ }); }
async function resetStuPass(id){ if(!confirm('إعادة تعيين كلمة المرور لهذا الطالب؟'))return; try{ var np='@'+Math.random().toString(36).slice(2,8); var j=await api('api/admin/student/'+id,{method:'PUT',body:JSON.stringify({password:np, passChanged:false})}); toast('كلمة المرور الجديدة: '+np); renderStudents(); }catch(e){ toast(e.message,true); } }
boot();
