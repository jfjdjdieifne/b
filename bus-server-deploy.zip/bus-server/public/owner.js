/* ==== لوحة المالك ==== */
var token=localStorage.getItem('sct_token');
var routes=[], buses=[], settings={};
var edit=null, editorMap=null, editorLayer=null, addStopMode=false, termMode=false;
var liveMap=null, liveMarkers={}, liveStarted=false;
var S_editBus=null;

function api(p, opts){ opts=opts||{}; opts.headers=Object.assign({'Authorization':'Bearer '+token,'Content-Type':'application/json'}, opts.headers||{}); return fetch(p, opts).then(function(r){ return r.json().then(function(j){ if(r.status===401){ window.location.href='index.html'; } return j; }); }); }
function toast(msg,err){ var t=document.createElement('div'); t.className='toast show'+(err?' err':''); t.textContent=msg; document.body.appendChild(t); setTimeout(function(){t.classList.remove('show');},2300); }

async function boot(){
  var me=await api('api/me'); if(me.role!=='owner'){ window.location.href='index.html'; return; }
  await load(); renderAll(); go('dashboard');
}
async function load(){ var m=await api('api/meta'); routes=m.routes; buses=m.buses; settings=m.settings; }
function renderAll(){ renderCards(); renderBuses(); renderRouteCards(); renderSettings(); renderStuRouteSelects(); }
function renderStuRouteSelects(){
  var sr=document.getElementById('stRoute');
  if(sr){ sr.innerHTML=routes.map(function(r){return '<option value="'+r.id+'">'+esc(r.name)+'</option>';}).join(''); if(routes.length){ fillOwnStops(sr.value); } }
  var fr=document.getElementById('filterRoute'); if(fr){ fr.innerHTML='<option value="">كل الخطوط</option>'+routes.map(function(r){return '<option value="'+r.id+'">'+esc(r.name)+'</option>';}).join(''); }
}
function renderCards(){
  var onR=buses.filter(function(b){return b.active;}).length;
  var nStops=routes.reduce(function(a,r){return a+r.stops.length;},0);
  var card=function(n,l,s,ic){return '<div class="card"><div class="ico" style="position:static;font-size:24px;opacity:.85">'+ic+'</div><div class="num">'+n+'</div><div class="lbl">'+l+'</div><div class="sub">'+s+'</div></div>';};
  document.getElementById('cards').innerHTML=
    card(onR,'باص فعّال',buses.length+' إجمالي','🚌')+
    card(routes.length,'خط',nStops+' موقف','🛣️')+
    card(settings.offRouteThreshold,'عتبة خارج المسار','م','📏')+
    card(settings.stopArriveRadius,'نصف قطر الوصول','م','🎯');
}
function go(t){ document.querySelectorAll('.nav-btn').forEach(function(b){b.classList.toggle('active',b.dataset.t===t);}); document.querySelectorAll('.panel').forEach(function(p){p.classList.remove('active');}); document.getElementById('p-'+t).classList.add('active'); var ti={dashboard:['لوحة القيادة','نظرة عامة'],buses:['الباصات','أضف وعدّل'],routes:['الخطوط','حرّر'],live:['الخريطة الحية','لحظة بلحظة'],students:['الطلاب','إضافة واستيراد'],admins:['إدارة الجامعة','حسابات'],settings:['الإعدادات','اضبط']}; document.getElementById('pageTitle').textContent=ti[t][0]; document.getElementById('pageSub').textContent=ti[t][1]; if(t==='live')startLive(); if(t==='students')renderStudents(); if(t==='admins')renderAdmins(); }

/* ---------------- الباصات ---------------- */
function fillRouteSel(sel){ if(!sel)return; sel.innerHTML='<option value="">— بدون —</option>'+routes.map(function(r){return'<option value="'+r.id+'">'+esc(r.name)+'</option>';}).join(''); }
function renderBuses(){
  fillRouteSel(document.getElementById('busRoute'));
  var tb=document.getElementById('busRows');
  tb.innerHTML=buses.map(function(b){ var r=routes.find(function(x){return x.id===b.routeId;}); return '<tr><td><span class="dot" style="background:'+(r?r.color:'#666')+'"></span><b>'+esc(b.name)+'</b></td><td>'+esc(b.plate)+'</td><td>'+b.capacity+'</td><td>'+(r?esc(r.name):'—')+'</td><td><span class="pill '+(b.active?'on':'off')+'">'+(b.active?'مفعّل':'متوقف')+'</span></td><td><span class="tag" style="background:#6366f122;color:#c7d2fe;border:1px solid #6366f144">🎒 '+(b.studentCount!=null?b.studentCount:'0')+'</span></td><td class="actions"><button class="btn sm ghost" onclick="editBus(\''+b.id+'\')">تعديل</button><button class="btn sm red" onclick="deleteBus(\''+b.id+'\')">حذف</button></td></tr>'; }).join('');
}
function resetBusForm(){ document.getElementById('busFormTitle').textContent='➕ إضافة باص'; document.getElementById('busName').value=''; document.getElementById('busPlate').value=''; document.getElementById('busCap').value=40; document.getElementById('drvUser').value=''; document.getElementById('drvPass').value=''; document.getElementById('busSaveBtn').textContent='الإضافة'; document.getElementById('busCancelBtn').style.display='none'; if(window.schedInit) schedInit('busSched',[]); S_editBus=null; }
function editBus(id){ var b=buses.find(function(x){return x.id===id;}); document.getElementById('busFormTitle').textContent='✏️ تعديل: '+b.name; document.getElementById('busName').value=b.name; document.getElementById('busPlate').value=b.plate; document.getElementById('busCap').value=b.capacity; document.getElementById('drvUser').value=b.driverUser; document.getElementById('drvPass').value=b.driverPass; document.getElementById('busRoute').value=b.routeId||''; if(window.schedInit) schedInit('busSched', b.schedule||[]); document.getElementById('busSaveBtn').textContent='💾 حفظ'; document.getElementById('busCancelBtn').style.display=''; S_editBus=id; }
async function saveBus(){
  var name=document.getElementById('busName').value.trim(); if(!name){ toast('أدخل اسم الباص',true); return; }
  var body={name:name, plate:document.getElementById('busPlate').value.trim(), capacity:+document.getElementById('busCap').value||40, routeId:document.getElementById('busRoute').value||null, driverUser:document.getElementById('drvUser').value.trim(), driverPass:document.getElementById('drvPass').value.trim(), schedule:(window.schedGet? schedGet():null)};
  if(S_editBus){ await api('api/admin/bus/'+S_editBus,{method:'PUT',body:JSON.stringify(body)}); } else { await api('api/admin/bus',{method:'POST',body:JSON.stringify(body)}); }
  await load(); renderAll(); resetBusForm(); toast('تم حفظ الباص');
}
async function deleteBus(id){ if(!confirm('حذف الباص؟'))return; await api('api/admin/bus/'+id,{method:'DELETE'}); await load(); renderAll(); toast('حُذف'); }

/* ---------------- الخطوط ---------------- */
function renderRouteCards(){
  var add='<button class="card" onclick="addRoute()" style="cursor:pointer;min-height:150px;text-align:center"><div style="font-size:38px;font-weight:800;color:var(--brand2)">＋</div><div class="lbl" style="font-weight:700">خط جديد</div></button>';
  document.getElementById('routeCards').innerHTML=routes.map(function(r){ var n=buses.filter(function(b){return b.routeId===r.id;}).length; return '<div class="card"><div style="display:flex;align-items:center;gap:9px;margin-bottom:8px"><span class="dot" style="background:'+r.color+';width:13px;height:13px"></span><b>'+esc(r.name)+'</b></div><div class="lbl" style="color:var(--muted);font-size:13px;margin-bottom:6px">'+r.stops.length+' موقف · النهاية: '+(r.terminal?esc(r.terminal.name):'—')+'</div><div class="hint" style="margin-bottom:12px">'+n+' باص</div><div class="actions"><button class="btn sm" onclick="openEditor(\''+r.id+'\')">فتح المحرر</button><button class="btn sm red" onclick="deleteRoute(\''+r.id+'\')">حذف</button></div></div>'; }).join('')+add;
}
function addRoute(){ go('routes'); setTimeout(function(){ openEditor(null); },40); }
function openEditor(id){ var r=id?routes.find(function(x){return x.id===id;}):null; edit=r?JSON.parse(JSON.stringify(r)):{id:null,name:'',color:'#6366f1',stops:[],terminal:null,origin:null}; edit.id=r?r.id:null; document.getElementById('routeEditor').style.display='block'; document.getElementById('erLineName').value=edit.name; document.getElementById('erColor').value=edit.color; document.getElementById('erName').textContent=edit.name||'خط جديد'; document.getElementById('erRadius').value=edit.terminal?edit.terminal.radius:120; radiusLblUpdate(); addStopMode=false; termMode=false; updateMode(); setTimeout(initEditorMap,60); }
function closeEditor(){ document.getElementById('routeEditor').style.display='none'; if(editorMap){editorMap.remove(); editorMap=null;} edit=null; }
function initEditorMap(){ if(editorMap)editorMap.remove(); var c=(edit&&(edit.stops[0]||edit.origin||edit.terminal))||{lat:33.508,lng:36.274}; editorMap=L.map('erMap',{zoomControl:true}).setView([c.lat,c.lng],14); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(editorMap); editorLayer=L.layerGroup().addTo(editorMap); editorMap.on('click',function(e){ onMapClick(e); }); redrawEditor(); setTimeout(function(){editorMap.invalidateSize();},120); }
function onMapClick(e){ var lat=e.latlng.lat,lng=e.latlng.lng; if(addStopMode){ edit.stops.push({name:'موقف '+(edit.stops.length+1),lat:+lat.toFixed(6),lng:+lng.toFixed(6)}); redrawEditor(); var ins=document.querySelectorAll('#stopsList input.stop-name'); if(ins.length){ins[ins.length-1].focus();ins[ins.length-1].select();} } else if(termMode){ edit.terminal={name:'نهاية الخط',lat:+lat.toFixed(6),lng:+lng.toFixed(6),radius:+document.getElementById('erRadius').value||120}; redrawEditor(); termMode=false; updateMode(); } }
function toggleAddStop(){ addStopMode=!addStopMode; termMode=false; updateMode(); }
function toggleTerm(){ termMode=!termMode; addStopMode=false; updateMode(); }
function updateMode(){ var b=document.getElementById('modeBanner'); if(addStopMode){b.style.display='flex';b.textContent='📍 وضع إضافة مواقف — انقر على الخريطة';} else if(termMode){b.style.display='flex';b.textContent='⌖ وضع نقطة النهاية — انقر على الخريطة';} else b.style.display='none'; }
function radiusLblUpdate(){ document.getElementById('radiusLbl').textContent=document.getElementById('erRadius').value; if(edit&&edit.terminal){edit.terminal.radius=+document.getElementById('erRadius').value; redrawEditor();} }
function redrawEditor(){ if(!editorLayer)return; editorLayer.clearLayers();
  if(edit.origin){ var oi=L.divIcon({className:'',html:'<div style="width:30px;height:30px;border-radius:50%;background:#d97706;color:#fff;font-weight:800;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:15px">🚩</div>',iconSize:[30,30]}); L.marker([edit.origin.lat,edit.origin.lng],{icon:oi}).addTo(editorLayer).bindPopup('انطلاق: '+edit.origin.name); }
  edit.stops.forEach(function(s,i){ var ic=L.divIcon({className:'',html:'<div style="width:30px;height:30px;border-radius:50%;background:'+(edit.color||'#6366f1')+';color:#fff;font-weight:800;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:14px">'+(i+1)+'</div>',iconSize:[30,30]}); L.marker([s.lat,s.lng],{icon:ic}).addTo(editorLayer).bindPopup('موقف '+(i+1)+': '+s.name); });
  if(edit.terminal){ L.circleMarker([edit.terminal.lat,edit.terminal.lng],{radius:9,color:'#fff',weight:2,fillColor:'#16a34a',fillOpacity:1}).addTo(editorLayer); L.circle([edit.terminal.lat,edit.terminal.lng],{radius:edit.terminal.radius,color:'#16a34a',weight:2,fillColor:'#16a34a',fillOpacity:.14}).addTo(editorLayer); }
  var poly=[]; if(edit.origin)poly.push([edit.origin.lat,edit.origin.lng]); edit.stops.forEach(function(s){poly.push([s.lat,s.lng]);}); if(edit.terminal)poly.push([edit.terminal.lat,edit.terminal.lng]); if(poly.length>1)L.polyline(poly,{color:edit.color,weight:3}).addTo(editorLayer);
  renderStopsList();
}
function renderStopsList(){ var el=document.getElementById('stopsList'); var html='';
  html+='<div class="stoprow"><span class="n">🚩</span><input class="stop-name" value="'+esc(edit.origin?edit.origin.name:'نقطة الانطلاق')+'" oninput="edit.origin=edit.origin||{lat:0,lng:0};edit.origin.name=this.value" style="background:rgba(217,119,6,.12);border-color:rgba(217,119,6,.4)"><span class="hint">انطلاق</span></div>';
  html+=edit.stops.map(function(s,i){ return '<div class="stoprow"><span class="n">'+(i+1)+'</span><input class="stop-name" value="'+esc(s.name)+'" oninput="edit.stops['+i+'].name=this.value"><button class="mini" onclick="moveStop('+i+',-1)">▲</button><button class="mini" onclick="moveStop('+i+',1)">▼</button><button class="mini red" onclick="edit.stops.splice('+i+',1);redrawEditor()">🗑</button></div>'; }).join('');
  if(edit.terminal)html+='<div class="stoprow" style="background:rgba(34,197,94,.12);border-radius:10px"><span class="n">⌖</span><input class="stop-name" value="'+esc(edit.terminal.name)+'" oninput="edit.terminal.name=this.value"><button class="mini red" onclick="edit.terminal=null;redrawEditor()">🗑</button></div>';
  el.innerHTML=html||'<div class="hint">لا نقاط بعد.</div>';
}
function moveStop(i,d){ var n=i+d; if(n<0||n>=edit.stops.length)return; var t=edit.stops[i]; edit.stops[i]=edit.stops[n]; edit.stops[n]=t; redrawEditor(); }
async function saveRoute(){ if(!edit.name){ toast('أدخل اسم الخط',true); return; } if(!edit.stops.length){ toast('أضف موقفاً واحداً',true); return; } var body={name:edit.name,color:edit.color,origin:edit.origin,stops:edit.stops.slice(),terminal:edit.terminal}; if(edit.id){await api('api/admin/route/'+edit.id,{method:'PUT',body:JSON.stringify(body)});} else {await api('api/admin/route',{method:'POST',body:JSON.stringify(body)});} await load(); renderAll(); closeEditor(); toast('تم حفظ الخط'); }
async function deleteRoute(id){ if(!confirm('حذف الخط؟'))return; var j=await api('api/admin/route/'+id,{method:'DELETE'}); if(j.error){ toast(j.error,true); return; } await load(); renderAll(); toast('حُذف'); }

/* ---------------- الخريطة الحية ---------------- */
function startLive(){ if(!liveMap){ liveMap=L.map('liveMap',{zoomControl:true}).setView([33.51,36.28],13); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(liveMap); var lg=document.getElementById('liveLegend'); lg.innerHTML=routes.map(function(r){return '<span class="item"><span class="sw" style="background:'+r.color+'"></span>'+esc(r.name)+'</span>';}).join(''); } if(!liveStarted){ liveStarted=true; pollLive(); setInterval(pollLive,2000); } setTimeout(function(){liveMap.invalidateSize();},120); }
async function pollLive(){ var live=await api('api/live'); var seen={}; live.forEach(function(p){ seen[p.busId]=true; var color=p.phase==='return'?'#d97706':(p.routeColor||'#6366f1'); var ic=L.divIcon({className:'',html:'<div style="width:32px;height:32px;border-radius:50%;background:'+color+';color:#fff;font-weight:800;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:16px">🚌</div>',iconSize:[32,32]}); if(!liveMarkers[p.busId]){ if(p.lat!=null)liveMarkers[p.busId]=L.marker([p.lat,p.lng],{icon:ic}).addTo(liveMap); } else { if(p.lat!=null){liveMarkers[p.busId].setLatLng([p.lat,p.lng]); liveMarkers[p.busId].setIcon(ic);} else liveMap.removeLayer(liveMarkers[p.busId]); } if(p.lat!=null)liveMarkers[p.busId].bindPopup('<b>'+esc(p.name)+'</b><br>المرحلة: '+(p.phase==='return'?'↩️ إياب':'🌅 ذهاب')+'<br>الموقف التالي: '+esc(p.nextStop||'—')+'<br>السرعة: '+p.speed+' كم/س<br>'+(p.offRoute?'⚠️ خارج المسار':'')); }); Object.keys(liveMarkers).forEach(function(id){ if(!seen[id]){ liveMap.removeLayer(liveMarkers[id]); delete liveMarkers[id]; } });
  var list=document.getElementById('liveList'); list.innerHTML=live.map(function(p){ var tag=p.phase==='return'?'<span class="tag" style="background:#d9770622;color:#fcd34d;border:1px solid #d9770644">إياب</span>':'<span class="tag" style="background:#6366f122;color:#c7d2fe;border:1px solid #6366f144">ذهاب</span>'; return '<div class="busitem"><div class="tit"><span>'+esc(p.name)+'</span>'+tag+'</div><div class="meta">'+(p.lat!=null?('<div>الموقع: '+p.lat.toFixed(5)+', '+p.lng.toFixed(5)+'</div><div>الموقف التالي: <b>'+esc(p.nextStop||'—')+'</b> · آخر تحديث: '+fmtClockShort(p.lastUpdate)+'</div><div>السرعة: '+p.speed+' كم/س</div><div>'+(p.offRoute?'<b style="color:#fcd34d">⚠️ خارج المسار ('+p.snapDist+'م)</b>':'<b>'+p.phaseReason+'</b>')+'</div>'):'<div class="hint">غير متصل — السوّاق لم يُرسل موقعاً بعد</div>')+'</div></div>'; }).join('');
}

/* ---------------- الإعدادات ---------------- */
function renderSettings(){ var s=document.getElementById('sStopR'), o=document.getElementById('sOffR'); if(s)s.value=settings.stopArriveRadius; if(o)o.value=settings.offRouteThreshold; var lk=document.getElementById('licKey'); if(lk)lk.value=settings.licenseKey||''; var lh=document.getElementById('licHolder'); if(lh)lh.value=settings.licenseHolder||''; var le=document.getElementById('licExpiry'); if(le)le.value=(settings.licenseExpiry||'').slice(0,10); var al=document.getElementById('sAllowLate'); if(al)al.checked=(settings.allowLate!==false); var lc=document.getElementById('sLateCool'); if(lc)lc.value=(settings.lateCooldownMin!=null?settings.lateCooldownMin:3); readLicense(); }
async function saveSettings(){ await api('api/admin/settings',{method:'PUT',body:JSON.stringify({stopArriveRadius:+document.getElementById('sStopR').value||45, offRouteThreshold:+document.getElementById('sOffR').value||300, allowLate:document.getElementById('sAllowLate').checked, lateCooldownMin:+document.getElementById('sLateCool').value||3})}); await load(); renderAll(); toast('حُفظت الإعدادات'); }
async function changePass(){ var p=document.getElementById('newPass').value; var j=await api('api/admin/password',{method:'PUT',body:JSON.stringify({password:p})}); if(j.error){toast(j.error,true);return;} document.getElementById('newPass').value=''; toast('تم تغيير كلمة المرور'); }
async function seedReset(){ if(!confirm('إعادة ضبط جميع البيانات؟'))return; await api('api/admin/seed',{method:'POST'}); await load(); renderAll(); toast('تمت إعادة الضبط'); }

var students=[], S_editStu=null, admins=[];
function fillOwnRouteSel(sel){ if(!sel)return; sel.innerHTML=db_routes_list().map(function(r){return '<option value="'+r.id+'">'+esc(r.name)+'</option>';}).join(''); }
function db_routes_list(){ return routes; }
function fillOwnStops(routeId){
  var r=routes.find(function(x){return x.id===routeId;}); var sel=document.getElementById('stStop');
  sel.innerHTML=r?r.stops.map(function(s,i){return '<option value="'+i+'">موقف '+(i+1)+' — '+esc(s.name)+'</option>';}).join(''):'<option>لا مواقف</option>';
  if(S_editStu)sel.value=S_editStu.stopIdx;
  fillOwnBus(routeId);
}
function fillOwnBus(routeId){
  var bs=db._buses||busList(); var sel=document.getElementById('stBus'); if(!sel)return;
  var busesForRoute=buses.filter(function(b){return b.routeId===routeId;});
  if(!busesForRoute.length){ sel.innerHTML='<option value="">— لا باصات على الخط (أضف باصاً) —</option>'; return; }
  sel.innerHTML=busesForRoute.map(function(b){return '<option value="'+b.id+'">'+esc(b.name)+' (السعة '+b.capacity+')</option>';}).join('');
  sel.options[0].selected=true; // pick first
  // if there is only one bus, preselect it
  if(busesForRoute.length===1) sel.value=busesForRoute[0].id;
  if(S_editStu && S_editStu.busId) sel.value=S_editStu.busId;
}
function busList(){ return buses; }
document.getElementById('stRoute').addEventListener('change',function(){ fillOwnStops(this.value); });
async function renderStudents(){
  var q=document.getElementById('stSearch').value.trim(); var rid=document.getElementById('filterRoute').value;
  var rows=await api('api/admin/students?q='+encodeURIComponent(q)+(rid?'&routeId='+rid:'')); students=rows;
  document.getElementById('stuRows').innerHTML=rows.map(function(s){ var r=routes.find(function(x){return x.id===s.routeId;}); var stopName=r&&r.stops[s.stopIdx]?r.stops[s.stopIdx].name:'—'; return '<tr><td><b>'+esc(s.universityId)+'</b></td><td>'+esc(s.name)+'</td><td>'+esc(r?r.name:'—')+'</td><td>'+esc(stopName)+'</td><td class="actions"><button class="btn sm ghost" onclick="editStudent(\''+s.id+'\')">تعديل</button><button class="btn sm red" onclick="deleteStudent(\''+s.id+'\')">حذف</button></td></tr>'; }).join('')||'<tr><td colspan="5" style="text-align:center" class="muted">لا طلاب.</td></tr>';
  document.getElementById('countLbl').textContent='إجمالي '+rows.length+' طالب';
}
document.getElementById('stSearch').addEventListener('input',renderStudents);
document.getElementById('filterRoute').addEventListener('change',renderStudents);
function resetStForm(){ document.getElementById('stSaveBtn').textContent='إضافة'; document.getElementById('stCancelBtn').style.display='none'; S_editStu=null; document.getElementById('stId').value=''; document.getElementById('stName').value=''; document.getElementById('stPass').value=''; }
function editStudent(id){ var s=students.find(function(x){return x.id===id;}); if(!s)return; S_editStu=s; document.getElementById('stId').value=s.universityId; document.getElementById('stName').value=s.name; document.getElementById('stPass').value=s.password; document.getElementById('stRoute').value=s.routeId||(routes[0]&&routes[0].id); fillOwnStops(s.routeId||(routes[0]&&routes[0].id)); document.getElementById('stStop').value=s.stopIdx; document.getElementById('stSaveBtn').textContent='💾 حفظ'; document.getElementById('stCancelBtn').style.display=''; }
async function saveStudent(){
  var busSel=document.getElementById('stBus'); var body={universityId:document.getElementById('stId').value.trim(), name:document.getElementById('stName').value.trim(), password:document.getElementById('stPass').value.trim()||settings.studentDefaultPass, routeId:document.getElementById('stRoute').value, stopIdx:+document.getElementById('stStop').value, busId:(busSel&&busSel.value)||null};
  try{ if(S_editStu){ await api('api/admin/student/'+S_editStu.id,{method:'PUT',body:JSON.stringify(body)}); } else { await api('api/admin/student',{method:'POST',body:JSON.stringify(body)}); } toast('تم حفظ الطالب'); resetStForm(); renderStudents(); }catch(e){ toast(e.message,true); }
}
async function deleteStudent(id){ if(!confirm('حذف الطالب؟'))return; await api('api/admin/student/'+id,{method:'DELETE'}); renderStudents(); toast('حُذف'); }
function importCsv(){ document.getElementById('csvFile').click(); }
document.getElementById('csvFile').addEventListener('change',function(ev){ var f=ev.target.files[0]; if(!f)return; var rd=new FileReader(); rd.onload=async function(){ var lines=String(rd.result).split(/\r?\n/).map(function(l){return l.trim();}).filter(Boolean); var parsed=[]; lines.forEach(function(l){ var p=l.split(',').map(function(x){return x.trim();}); if(p.length<2)return; var row={universityId:p[0], name:p[1], routeId:p[2]||null, stopIdx:(p[3]?+p[3]-1:0)||0}; if(row.routeId && !routes.some(function(r){return r.id===row.routeId;})){ var rr=routes.find(function(r){return r.name===row.routeId;}); row.routeId=rr?rr.id:null; } parsed.push(row); }); if(!parsed.length){ toast('لا صفوف صالحة',true); return; } try{ var j=await api('api/admin/students/import',{method:'POST',body:JSON.stringify({students:parsed})}); toast('أُضيف '+j.added+' · مكرر '+j.duplicate+' · الإجمالي '+j.total); renderStudents(); }catch(e){ toast(e.message,true); } }; rd.readAsText(f); });
async function readLicense(){
  var j=await api('api/license'); var el=document.getElementById('licStatus');
  if(el){ el.value = j.expired? '⛔ منتهي' : '✔ فعّال' + (j.expiry?(' حتى '+j.expiry):''); el.style.color=j.expired?'#f87171':'#4ade80'; }
}
async function saveLicense(){
  var body={key:document.getElementById('licKey').value.trim(), holder:document.getElementById('licHolder').value.trim(), expiry:document.getElementById('licExpiry').value||null};
  try{ await api('api/admin/license',{method:'PUT',body:JSON.stringify(body)}); toast('تم حفظ الترخيص'); readLicense(); }catch(e){ toast(e.message,true); }
}
async function renderAdmins(){
  var j=await api('api/admin/admins'); admins=j.admins;
  document.getElementById('admRows').innerHTML=admins.map(function(a){ return '<tr><td>'+esc(a.name)+'</td><td><b>'+esc(a.username)+'</b></td><td>'+esc(a.password)+'</td><td class="actions"><button class="btn sm red" onclick="deleteAdmin(\''+a.id+'\')">حذف</button></td></tr>'; }).join('')||'<tr><td colspan="4" style="text-align:center" class="muted">لا حسابات.</td></tr>';
}
async function saveAdmin(){ var body={username:document.getElementById('adUser').value.trim(), password:document.getElementById('adPass').value.trim(), name:document.getElementById('adName').value.trim()}; try{ await api('api/admin/admin',{method:'POST',body:JSON.stringify(body)}); toast('تمت إضافة حساب إدارة'); renderAdmins(); document.getElementById('adUser').value='';document.getElementById('adPass').value='';document.getElementById('adName').value=''; }catch(e){ toast(e.message,true); } }
async function deleteAdmin(id){ if(!confirm('حذف حساب الإدارة؟'))return; await api('api/admin/admin/'+id,{method:'DELETE'}); renderAdmins(); toast('حُذف'); }

boot();
