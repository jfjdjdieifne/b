/* ==== مونيتور الطالب — مرتبط بحسابه تلقائياً (خطه + موقفه + باصه) ==== */
var token=localStorage.getItem('sct_token');
var me=null, route=null, busId=null, live=[], routeBuses=[], allBuses=[], ROUTES=[], map=null, busMarker=null, meMarker=null, mePos=null, stuMoved=false, MYLATE=null, LATE_COUNT=0;
var ACTIVE_STOP=null, ACTIVE_ROUTE=null, ROUTE_GEOM=null, tripStart=null;

function api(p,o){ o=o||{}; o.headers=Object.assign({'Authorization':'Bearer '+token,'Content-Type':'application/json'},o.headers||{}); return fetch(p,o).then(function(r){ if(r.status===401){ window.location.href='index.html'; } return r.json(); }); }
function fd(){ return api('api/live'); }

async function boot(){
  if(!token){ window.location.href='index.html'; return; }
  var m=await api('api/student/me');
  if(m.error||!m.student){ window.location.href='index.html'; return; }
  me=m.student; route=m.route; if(m.student&&m.student.passChanged===false){ document.getElementById('passModal').style.display='flex'; return; }
  document.getElementById('who').textContent='👤 '+esc(me.name);
  document.getElementById('lineBadge').textContent='🚌 شبكة الباصات · خطك: '+esc(route?route.name:'—');
  document.getElementById('stopBadge').textContent='📍 موقفك: '+esc(route&&route.stops[me.stopIdx]?route.stops[me.stopIdx].name:'—');
  ACTIVE_STOP=me.stopIdx; ACTIVE_ROUTE=route;
  routeBuses=m.busesOnRoute||[];
  allBuses=m.allBuses||[];
  if(m.bus) busId=m.bus.busId; if(!busId&&allBuses.length) busId=allBuses[0].busId; else if(!busId&&routeBuses.length) busId=routeBuses[0].busId;
  MYLATE=(m.late&&m.late.mine)?m.late:null; LATE_COUNT=(m.late&&m.late.count)||0;
  autoLocate();
  var mt=await api('api/meta'); ROUTES=mt.routes||[];
  var td=document.getElementById('ttDate'); if(td&&!td.value){ var d=new Date(); td.value=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
  var bp=document.getElementById('busPick'); if(bp&&!bp._wired){ bp.addEventListener('change',function(){ busId=this.value; recomputeStop(); tripStart=Date.now(); ui(); }); bp._wired=true; }
  recomputeStop();
  tripStart=Date.now();
  await ui();
  setInterval(ui,1500);
}
function routeOf(){ return ACTIVE_ROUTE; }
function studentStopState(rt, stopCum, returning){
  if(!rt||rt.progress==null) return 'upcoming'; var tol=12;
  if(rt.speed<5 && Math.abs(rt.progress-stopCum)<25) return 'arrived';
  if(returning){ if(rt.progress>stopCum+tol)return'upcoming'; if(rt.progress<stopCum-tol)return'passed'; return'upcoming'; }
  if(rt.progress<stopCum-tol)return'upcoming'; if(rt.progress>stopCum+tol)return'passed'; return'upcoming';
}
function markForStop(rt,cum,si,sidx,returning){
  if(!rt||rt.progress==null)return 'up';
  if(rt.speed<5 && Math.abs(rt.progress-cum)<25) return (si===sidx?'arrived':'now');
  var tol=12; var passing=returning?(rt.progress<cum-tol):(rt.progress>cum+tol);
  if(passing)return'done'; return (si===sidx?'you':'up');
}
function fmtSimClock(){ if(!tripStart)return '—'; var mins=Math.floor((Date.now()-tripStart)/60000); var h=6+Math.floor(mins/60),m=mins%60; return '🕕 '+String(h).padStart(2,'0')+':'+String(m).padStart(2,'0'); }

async function ui(){
  live=await fd();
  var hero=document.getElementById('hero');
  var r=routeOf(); if(!r||!me){ hero.innerHTML='<div class="stage">📡</div><h2>تعذّر التحميل</h2>'; return; }
  var lv=live.find(x=>x.busId===busId)||{};
  var g=buildGeometry(r); ROUTE_GEOM=g; var sc=stopCumPositions(g);
  var sidx=(ACTIVE_STOP!=null&&ACTIVE_STOP>=0&&ACTIVE_STOP<sc.length)?ACTIVE_STOP:-1; var noStar=(sidx<0); var st=sidx>=0?sc[sidx]:null;
  var rt={progress:lv.progress, speed:lv.speed, status:lv.status, dir:lv.dir, phase:lv.phase};
  var returning=(lv.phase==='return'||lv.dir===-1);
  var yourState = st?studentStopState(rt, st.cum, returning):'none';
  document.getElementById('dirBadge').textContent= returning?'↩️ رحلة الإياب':'🌅 رحلة الذهاب';
  document.getElementById('clock').textContent=fmtSimClock();
  var busName = lv.name?lv.name: (busId?'الباص':'—');
  document.getElementById('busBadge').textContent='🚍 '+esc(busName)+' · '+esc(r.name||'');
  var zone=zoneText(r,g,lv);
  var etaSec=null;
  if(st && yourState==='upcoming'){ var dist=Math.abs((rt.progress||0)-st.cum); var eff=(lv.speed||30)/3.6; etaSec=eff>0?dist/eff:null; }
  var cls = st&&yourState==='arrived'?'arrived':(etaSec!=null&&etaSec<80?'soon':'travel');
  var etaTxt='—'; if(st&&yourState==='upcoming'&&etaSec!=null){ etaTxt=etaSec>=60?Math.round(etaSec/60):Math.round(etaSec); }
  var subtitle;
  if(st && yourState==='arrived') subtitle='الباص وصل إلى موقفك — اركب الآن';
  else if(st && yourState==='passed') subtitle='الباص تجاوز موقفك';
  else if(noStar) subtitle='الباص على خط '+r.name+' — اضغط 📍 موقعي لتحديد موقفك أو "أنا متأخر"';
  else subtitle= returning?'الباص في طريق العودة إلى موقفك':'الباص في الطريق إلى موقفك';
  var stopLine = st?('موقفك: '+esc(st.name)) : ('الموقف التالي: '+esc(nextStopNameForBus(sc,lv)));
  var pillTxt = (st&&yourState==='arrived')?'اركب الآن':(etaSec!=null?('الوصول خلال '+etaTxt+' دقيقة'):'في الطريق');
  var offwarn = lv.offRoute?' <div style="margin-top:10px"><span class="offwarn" style="display:inline-block">⚠️ الباص خارج المسار المحدد</span></div>':'';
  hero.innerHTML='<div class="stage">'+esc(lv.phase==='return'?'رحلة الإياب':'رحلة الذهاب')+' · '+esc(zone)+'</div>'+
    '<h2>'+esc(subtitle)+'</h2>'+
    '<div class="hint" style="font-size:15px;color:#c7d2fe;margin-top:8px">'+stopLine+' · السرعة '+(lv.speed||0)+' كم/س</div>'+
    '<div style="margin-top:14px"><span class="pill '+(cls==='arrived'?'on':'tri')+'" style="font-size:14px">'+pillTxt+'</span></div>'+offwarn;
  renderBusPick();
  renderBusDetail();
  renderLateBar();
  renderMap(r,g,lv,rt,sidx,sc);
  renderTimeline(r,g,lv,rt,sidx,sc,returning);
  renderSchedule(r,g,sidx,sc);
  setTimeout(function(){ if(map) map.invalidateSize(); },60);
}
function zoneText(r,g,lv){
  if(!lv||lv.progress==null)return '—'; var sc=stopCumPositions(g);
  if(lv.dir===-1){ var down=sc.filter(s=>s.cum<lv.progress); var passed=sc.filter(s=>s.cum>lv.progress); return (passed.length?'بين '+passed[0].name+' و '+(down.length?down[down.length-1].name:r.origin.name):'متّجه إلى '+(r.origin?r.origin.name:'البداية')); }
  var p=sc.filter(s=>s.cum<=lv.progress), u=sc.filter(s=>s.cum>lv.progress); var pp=p.length?p[p.length-1].name:(r.origin?r.origin.name:'الانطلاق'); var nn=u.length?u[0].name:null; return nn?'بين '+pp+' و '+nn:'بين '+pp+' و '+(r.terminal?r.terminal.name:'النهاية');
}
function nextStopNameForBus(sc, lv){ if(!sc||!sc.length||lv.progress==null) return '—'; if(lv.dir===-1){ for(var i=sc.length-1;i>=0;i--){ if(sc[i].cum<lv.progress) return sc[i].name; } return sc[0].name; } for(var j=0;j<sc.length;j++){ if(sc[j].cum>lv.progress) return sc[j].name; } return sc[sc.length-1].name; }
function renderMap(r,g,lv,rt,sidx,sc){
  if(!map){ map=L.map('map',{zoomControl:true}); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map); }
  var c=(rt.progress!=null?getPointAtProgress(g,rt.progress):g.pts[0]);
  map.eachLayer(function(x){ if(x._custom) map.removeLayer(x); });
  var poly=g.pts.map(function(p){return[p.lat,p.lng];}); if(poly.length>1){ var pl=L.polyline(poly,{color:r.color,weight:5,opacity:.9}).addTo(map); pl._custom=true; }
  sc.forEach(function(s,i){ var isMe=(i===sidx); var icon=L.divIcon({className:'',html:'<div style="width:'+(isMe?34:26)+'px;height:'+(isMe?34:26)+'px;border-radius:50%;background:'+(isMe?'#6366f1':'rgba(255,255,255,.85)')+';border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:'+(isMe?15:12)+'px;color:'+(isMe?'#fff':'#333')+'">'+(isMe?'★':'')+(i+1)+'</div>',iconSize:[isMe?34:26,isMe?34:26]}); var mk=L.marker([g.pts[s.index].lat,g.pts[s.index].lng],{icon:icon}).addTo(map); mk._custom=true; });
  if(r.origin){ var oi=L.divIcon({className:'',html:'<div style="width:30px;height:30px;border-radius:50%;background:#d97706;color:#fff;font-weight:800;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:15px">🚩</div>',iconSize:[30,30]}); var om=L.marker([r.origin.lat,r.origin.lng],{icon:oi}).addTo(map); om._custom=true; }
  if(r.terminal){ var ti=L.divIcon({className:'',html:'<div style="width:32px;height:32px;border-radius:50%;background:#16a34a;color:#fff;font-weight:800;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:15px">🏫</div>',iconSize:[32,32]}); var tm=L.marker([r.terminal.lat,r.terminal.lng],{icon:ti}).addTo(map); tm._custom=true; }
  var bicon=L.divIcon({className:'',html:'<div style="width:32px;height:32px;border-radius:50%;background:'+(lv.phase==='return'?'#d97706':'#6366f1')+';color:#fff;font-weight:800;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:16px;box-shadow:0 0 0 4px rgba(0,0,0,.3)">🚌</div>',iconSize:[32,32]});
  busMarker=L.marker([c.lat,c.lng],{icon:bicon}).addTo(map); busMarker._custom=true;
  if(mePos){ if(meMarker)meMarker.setLatLng([mePos.lat,mePos.lng]); }
  if(!stuMoved) map.setView([c.lat,c.lng],14);
  var d=Math.max(0, Math.abs((rt.progress||0)-st.cum));
  document.getElementById('dist').textContent='📏 '+meterText(d)+' عن موقفك';
}
function renderTimeline(r,g,lv,rt,sidx,sc,returning){
  var steps=g.pts.map(function(p,i){return{kind:p.type,name:p.name,cum:g.cum[i],i:i};});
  var html='<div class="timeline"><div class="tl-node-line"></div>'+(lv.progress!=null?'<div class="tl-node-fill" style="height:'+Math.min(100,(lv.progress/g.total*100))+'%"></div>':'');
  steps.forEach(function(s){ var si=(s.i-(r.origin?1:0)); var isYou2=(s.kind==='stop'&&si===sidx); var state='up';
    if(lv.progress!=null){ if(s.kind==='origin')state=(lv.progress>5?'done':'now'); else if(s.kind==='terminal')state=(lv.progress>=g.total-12?'done':(lv.progress>g.total-200?'now':'up')); else state=markForStop({progress:lv.progress,speed:lv.speed},s.cum,si,sidx,returning); }
    if(isYou2)state=(state==='done'?'done':'you');
    var icon=s.kind==='origin'?'🚩':s.kind==='terminal'?'🏫':(''+(si));
    var sub=state==='done'?'مرّ من هنا':state==='arrived'?'★ موقفك — الباص هنا':state==='now'?(isYou2?'★ موقفك':'الباص هنا الآن'):state==='you'?'★ موقفك':'قادم';
    html+='<div class="tl-step '+state+'"><div class="tl-node">'+icon+'</div><div class="tl-body"><div class="tl-name">'+esc(s.name)+'</div><div class="tl-sub">'+sub+'</div></div></div>'; });
  html+='</div>'; document.getElementById('timeline').innerHTML=html;
}
async function renderSchedule(r,g,sidx,sc){
  var j=await api('api/schedule?busId='+busId);
  var el=document.getElementById('sched'); var items=j.items||[];
  if(!items.length){ el.innerHTML='<div class="sched-head"><span>⏱ توقيت اليوم</span></div><div class="hint">لا أوقات بعد — سيُسجّل تلقائياً عند مرور الباص.</div>'; return; }
  var rows='', myStop=null, out=0, ret=0;
  items.forEach(function(it){ if(it.dir===1)out++; else ret++; });
  sc.forEach(function(s,i){ var tO=items.find(it=>it.stopIdx===i&&it.dir===1), tR=items.find(it=>it.stopIdx===i&&it.dir===-1); if(!tO&&!tR)return; var isYou=(i===sidx); var t=''; if(tO)t+='<span class="sched-chip out">🌅 '+fmtClockShort(tO.arriveTs)+'</span>'; if(tR)t+='<span class="sched-chip ret">↩️ '+fmtClockShort(tR.arriveTs)+'</span>'; rows+='<div class="sched-row'+(isYou?' you':'')+'"><span class="name">'+(isYou?'★ موقفك':esc(s.name))+'</span><span>'+t+'</span></div>'; if(isYou&&tO)myStop=tO; });
  el.innerHTML='<div class="sched-head"><span>⏱ توقيت اليوم</span><span class="hint">🌅 '+out+' · ↩️ '+ret+'</span></div>'+(myStop?'<div class="sched-now">كان باصك عند موقفك الساعة <b>'+fmtClockShort(myStop.arriveTs)+'</b></div>':'')+'<div class="sched-list">'+rows+'</div>';
}
function fmtT(time){ var p=String(time||'').split(':'); if(p.length<2)return time||''; var h=+p[0],m=p[1]; var suf=h>=12?'م':'ص'; h=h%12; if(h===0)h=12; return h+':'+m+' '+suf; }
function nowMinOTD(){ var d=new Date(); return d.getHours()*60+d.getMinutes(); }
function tripActive(t, lv){ // هل هذه الرحلة نشطة الآن؟ (حسب المرحلة + الوقت)
  if(!lv||lv.progress==null) return false;
  var min=nowMinOTD(); var tp=+String(t.time).split(':')[0]*60 + (+String(t.time).split(':')[1]||0);
  if(lv.phase==='return' && t.dir==='ret') return true; // مركّز: نفترض الشرط الفعلي من GPS أصدق
  return false;
}
function selectBus(id){ busId=id; recomputeStop(); tripStart=Date.now(); ui(); }
function routeOfBus(){ var b=allBuses.find(function(x){return x.busId===busId;})||routeBuses.find(function(x){return x.busId===busId;}); if(!b) return route||null; return ROUTES.find(function(x){return x.id===b.routeId;})||route||null; }
function recomputeStop(){ ACTIVE_ROUTE=routeOfBus(); var r=ACTIVE_ROUTE; if(!r){ ACTIVE_STOP=(me&&me.stopIdx!=null)?me.stopIdx:0; return; } if(r.id===me.routeId){ ACTIVE_STOP=(me&&me.stopIdx!=null)?me.stopIdx:0; return; } if(mePos&&r.stops){ var best=0,bd=1e18,cl=Math.cos(mePos.lat*Math.PI/180); r.stops.forEach(function(s,i){ var m=Math.pow((+s.lat-mePos.lat)*111320,2)+Math.pow((+s.lng-mePos.lng)*111320*cl,2); if(m<bd){bd=m;best=i;} }); ACTIVE_STOP=best; } else { ACTIVE_STOP=-1; } }
function renderBusPick(){
  var el=document.getElementById('busPick'); if(!el)return;
  var buses=allBuses.length?allBuses:routeBuses;
  if(!buses.length){ el.innerHTML='<option>لا باصات</option>'; return; }
  // الشغّال أولاً ثم المتوقف
  var sorted=buses.slice().sort(function(a,b){ var sa=(a.active?0:1), sb=(b.active?0:1); return sa-sb; });
  var had=el.value||busId;
  el.innerHTML=sorted.map(function(b){ var st=b.active?(b.online?'شغّال الآن':'جاهز'):'متوقف'; return '<option value="'+b.busId+'">'+esc(b.name)+' · '+esc(b.lineName||'')+' — '+st+'</option>'; }).join('');
  if(had && sorted.some(function(b){return b.busId===had;})) el.value=had; else if(sorted.length){ el.value=sorted[0].busId; busId=sorted[0].busId; }
}
function renderBusDetail(){
  var el=document.getElementById('lineBuses'); if(!el)return;
  var b=allBuses.find(function(x){return x.busId===busId;})||routeBuses.find(function(x){return x.busId===busId;});
  if(!b){ el.innerHTML='<div class="hint">اختر باصاً من القائمة أعلاه.</div>'; return; }
  var lvv=live.find(function(x){return x.busId===busId;})||{};
  var online=(lvv.lat!=null);
  var statusTxt=b.active?(online?'شغّال الآن':'جاهز (لم يبدأ)'):'متوقف';
  var statusC = b.active?(online?'#22c55e':'#f59e0b'):'#94a3b8';
  var chips=(b.schedule||[]).slice().sort(function(a,c){return a.dir!==c.dir? (a.dir==='out'?-1:1):(a.time<c.time?-1:1);}).map(function(t){
    return '<span class="tchip '+t.dir+'">'+(t.dir==='out'?'🌅':'↩️')+' '+fmtT(t.time)+'</span>';
  }).join('');
  var stops=(b.stops||[]).map(function(s,i){ return '<span class="pill tri" style="margin:3px">'+(i+1)+' '+esc(s.name)+'</span>'; }).join('');
  var isLateHere=(MYLATE&&MYLATE.busId===b.busId);
  var lateBtn;
  if(isLateHere){ lateBtn='<button class="btn sm" onclick="clearLate();event.stopPropagation()">⏳ أنت متأخر هنا ✓</button>'; }
  else if(b.lateOpen===false){ lateBtn='<div class="hint">⛔ '+esc(b.lateReason||'التأخير مغلق')+'</div>'; }
  else { lateBtn='<button class="btn sm accent" onclick="pressLate(\''+b.busId+'\');event.stopPropagation()">⏳ أنا متأخر</button>'; }
  el.innerHTML='<div class="buscard2 sel">'
    +'<div class="bt"><span>'+esc(b.name)+'</span><span class="btc" style="background:'+statusC+'22;color:'+statusC+'">'+statusTxt+'</span></div>'
    +'<div class="bd" style="color:'+esc(b.lineColor||'#666')+'">🚏 '+esc(b.lineName||'')+(b.plate?' · '+esc(b.plate):'')+'</div>'
    +'<div class="stops"><span class="hint">المواقف:</span><div style="margin-top:6px">'+stops+'</div></div>'
    +'<div class="tripchips" style="margin-top:10px">'+(chips||'<span class="hint">لا رحلات بعد</span>')+'</div>'
    +'<div class="lateact">'+lateBtn+'</div></div>';
}
function toggleTT(){ var p=document.getElementById('ttPanel'); if(!p)return; var show=(p.style.display!=='none'); p.style.display=show?'none':'block'; if(!show) loadTT(); }
function todayStrF(){ var d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
function loadTT(){
  var d=document.getElementById('ttDate').value||todayStrF();
  api('api/timetable?date='+encodeURIComponent(d)).then(function(j){
    var wd=document.getElementById('ttWeekday'); if(wd)wd.textContent='· '+(j.weekday||'');
    var body=document.getElementById('ttBody');
    body.innerHTML=j.routes.length?j.routes.map(function(r){
      var stopsA=r.stops.map(function(s,i){ return '<li>'+(i+1)+' '+esc(s.name)+'</li>'; }).join('');
      var busRows=r.buses.map(function(b){
        var sT=b.status==='on'?'شغّال الآن':(b.active?'جاهز':'متوقف');
        var sC=b.status==='on'?'#22c55e':(b.active?'#f59e0b':'#94a3b8');
        var trips=(b.schedule||[]).slice().sort(function(a,c){return a.dir!==c.dir? (a.dir==='out'?-1:1):(a.time<c.time?-1:1);}).map(function(t){ return '<span class="tchip '+t.dir+'">'+(t.dir==='out'?'🌅':'↩️')+' '+fmtT(t.time)+'</span>'; }).join('');
        return '<div class="tt-bus"><div class="tt-bustitle"><b>'+esc(b.name)+'</b> <span class="btc" style="background:'+sC+'22;color:'+sC+'">'+sT+'</span></div>'+(trips?'<div class="tripchips">'+trips+'</div>':'<span class="hint">لا رحلات لهذا اليوم</span>')+'</div>';
      }).join('');
      return '<div class="tt-route" style="border-color:'+esc(r.color)+'">'
        +'<div class="tt-rh"><span style="color:'+esc(r.color)+'">🚏 '+esc(r.name)+'</span></div>'
        +'<div class="tt-grid"><div class="tt-stops"><span class="hint">المواقف</span><ul>'+stopsA+'</ul></div>'
        +'<div class="tt-buses">'+busRows+'</div></div></div>';
    }).join(''):'<div class="hint">لا خطوط بعد.</div>';
  }).catch(function(){ });
}
function renderLateBar(){
  var el=document.getElementById('lateBar'); if(!el)return;
  if(MYLATE){
    var others=Math.max(0,(MYLATE.count||1)-1); var bName='باصك';
    var bb=allBuses.find(function(x){return x.busId===MYLATE.busId;}); if(bb)bName=bb.name;
    el.style.display='block';
    el.innerHTML='<div class="latecard on"><span>⏳ أنت متأخر على '+esc(bName)+' 📍 '+esc(MYLATE.stopName||'—')+'</span><span class="hint">رأى السوّاق إشارتك'+(others?(' (+'+others+' آخرون)'):'')+' — انتظر عند الموقف</span><button class="btn sm" onclick="clearLate()">إلغاء</button></div>';
    return;
  }
  el.style.display='block';
  el.innerHTML='<div class="latecard"><span>⏰ تأخّرت على باصك؟</span><span class="hint">اضغط "أنا متأخر" على الباص الذي تنتظره — يصل الإشعار للسوّاق وحده (لا لكل الباصات) ويُلغى تلقائياً عند مروره.</span></div>';
}
function pressLate(busId){
  var body={busId:busId, stopIdx:(me&&me.stopIdx!=null)?me.stopIdx:0};
  if(mePos){ body.lat=mePos.lat; body.lng=mePos.lng; }
  api('api/student/late',{method:'POST',body:JSON.stringify(body)}).then(function(j){
    if(j.ok){ MYLATE={busId:j.busId, stopIdx:j.stopIdx, stopName:j.stopName, count:j.count}; toast('⏳ أُخطر السوّاق أنك متأخر'); ui(); }
    else toast(j.error||'تعذّر الإرسال',true);
  });
}
function clearLate(){
  var body={}; if(MYLATE) body={busId:MYLATE.busId, stopIdx:MYLATE.stopIdx};
  api('api/student/late/clear',{method:'POST',body:JSON.stringify(body)}).then(function(){ MYLATE=null; LATE_COUNT=0; toast('أُلغي إشعار متأخر'); ui(); });
}
function autoLocate(){ if(!('geolocation' in navigator)) return; navigator.geolocation.getCurrentPosition(function(pos){ mePos={lat:pos.coords.latitude,lng:pos.coords.longitude}; if(!stuMoved&&map){ stuMoved=true; map.setView([mePos.lat,mePos.lng],14); } }, function(){}, {enableHighAccuracy:true,timeout:8000}); }
function saveNewPass(){
  var p=document.getElementById('npPass').value, p2=document.getElementById('npPass2').value;
  var er=document.getElementById('npErr');
  if(p!==p2){ er.textContent='كلمتا المرور غير متطابقتين'; return; }
  if(p===String(me.universityId)){ er.textContent='لا تستخدم رقمك الجامعي'; return; }
  api('api/student/password',{method:'POST',body:JSON.stringify({password:p})}).then(function(j){
    if(j.ok){ document.getElementById('passModal').style.display='none'; toast('تم تفعيل حسابك ✔'); boot(); }
    else er.textContent=j.error||'خطأ';
  });
}
function locateMe(){ if(!('geolocation' in navigator)){ toast('متصفحك لا يدعم الموقع'); return; } navigator.geolocation.getCurrentPosition(function(pos){ mePos={lat:pos.coords.latitude,lng:pos.coords.longitude}; if(meMarker){meMarker.remove();} meMarker=L.marker([mePos.lat,mePos.lng],{icon:L.divIcon({className:'',html:'<div style="width:20px;height:20px;border-radius:50%;background:#f43f5e;border:3px solid #fff;box-shadow:0 0 0 5px rgba(244,63,94,.25)"></div>',iconSize:[0,0]})}).addTo(map); map.setView([mePos.lat,mePos.lng],14); stuMoved=true; },function(){ toast('تعذّر تحديد الموقع',true); },{enableHighAccuracy:true,timeout:10000}); }
function focusBus(){ stuMoved=false; ui(); }
function toast(msg,err){ var t=document.createElement('div'); t.className='toast show'+(err?' err':''); t.textContent=msg; document.body.appendChild(t); setTimeout(function(){t.classList.remove('show');},2200); }
boot();
