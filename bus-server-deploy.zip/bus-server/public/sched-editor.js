/* ============================================================
   محرّر جدول الرحلات (ذهاب/إياب + الوقت) — مشترك بين المالك والإدارة
   ============================================================ */
var SchedEdit = { items: [], container: null };

/* تهيئة المحرّر بقائمة رحلات موجودة */
function schedInit(containerId, schedule){
  SchedEdit.container = document.getElementById(containerId);
  SchedEdit.items = (schedule||[]).map(function(t){ return {id:t.id||('t'+Date.now()+Math.random()), dir:t.dir, time:t.time||'08:00', label:t.label||''}; });
  schedRender();
}
function schedRender(){
  var c = SchedEdit.container; if(!c) return;
  if(!SchedEdit.items.length){
    c.innerHTML = '<div class="hint" style="padding:6px 0">لا رحلات بعد — أضف رحلات الذهاب والإياب.</div>';
    return;
  }
  // نعرض الذهاب ثم الإياب
  function row(t){
    return '<div class="schedrow" data-id="'+t.id+'">'+
      '<select onchange="schedSetDir(\''+t.id+'\', this.value)" class="sd">'+
        '<option value="out"'+(t.dir==='out'?' selected':'')+'>🌅 ذهاب</option>'+
        '<option value="ret"'+(t.dir==='ret'?' selected':'')+'>↩️ إياب</option>'+
      '</select>'+
      '<input type="time" value="'+t.time+'" onchange="schedSetTime(\''+t.id+'\', this.value)" class="st">'+
      '<span class="lbl" style="flex:1">'+esc(t.label||'')+'</span>'+
      '<button class="mini red" onclick="schedDel(\''+t.id+'\')">🗑</button>'+
    '</div>';
  }
  var outs = SchedEdit.items.filter(function(t){return t.dir==='out';}).sort(function(a,b){return a.time<b.time?-1:1;});
  var rets = SchedEdit.items.filter(function(t){return t.dir==='ret';}).sort(function(a,b){return a.time<b.time?-1:1;});
  var html = '';
  if(outs.length) html += '<div class="hint" style="margin:4px 0 2px;font-weight:800">🌅 رحلات الذهاب</div>' + outs.map(row).join('');
  if(rets.length) html += '<div class="hint" style="margin:8px 0 2px;font-weight:800">↩️ رحلات الإياب</div>' + rets.map(row).join('');
  c.innerHTML = html;
}
function schedSetDir(id, dir){ var t=SchedEdit.items.find(function(x){return x.id===id;}); if(t) t.dir=dir; schedRender(); }
function schedSetTime(id, time){ var t=SchedEdit.items.find(function(x){return x.id===id;}); if(t) t.time=time; schedSyncLabels(); }
function schedSyncLabels(){
  SchedEdit.items.forEach(function(t){ t.label=(t.dir==='out'?'ذهاب ':'إياب ')+fmtT(t.time); });
}
function schedAdd(dir){
  var time = (dir==='out'?'08:00':'12:00');
  SchedEdit.items.push({id:'t'+Date.now()+Math.random().toString(16).slice(2), dir:dir, time:time, label:(dir==='out'?'ذهاب ':'إياب ')+time});
  schedRender();
}
function schedDel(id){ SchedEdit.items = SchedEdit.items.filter(function(t){return t.id!==id;}); schedRender(); }
function schedGet(){ schedSyncLabels(); return SchedEdit.items.map(function(t){ return {id:t.id, dir:t.dir, time:t.time, label:t.label}; }); }
function fmtT(time){ var p=String(time||'').split(':'); if(p.length<2)return time||''; var h=+p[0],m=p[1],suf=h>=12?'م':'ص'; h=h%12; if(h===0)h=12; return h+':'+m+' '+suf; }
