/* ==== تطبيق السوّاق: يرسل موقع GPS حقيقي، ويتحكم في بدء/إيقاف التتبع ==== */
var token=localStorage.getItem('sct_token');
var buses=[], routes=[], bus=null, r=null, map=null, busMarker=null, watchId=null, tracking=false, lastSend=0;
var audioCtx=null, alertTimer=null, prevLateTotal=0, prevInitialised=false;

function fd(){ return fetch('api/live').then(r=>r.json()); }
async function boot(){
  if(!token){ window.location.href='index.html'; return; }
  var me=await fetch('api/me').then(r=>r.json());
  if(me.role!=='driver'){ window.location.href='index.html'; return; }
  var m=await fetch('api/meta').then(r=>r.json());
  buses=m.buses; routes=m.routes;
  bus=buses.find(b=>b.id===me.busId)||buses.find(b=>b.active)||buses[0];
  if(!bus){ document.getElementById('err').textContent='لا باصات متاحة'; return; }
  r=routes.find(x=>x.id===bus.routeId);
  if('Notification' in window && Notification.permission==='default'){ try{ Notification.requestPermission(); }catch(e){} }
  if(!audioCtx && (window.AudioContext||window.webkitAudioContext)){ try{ audioCtx=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} }
  document.getElementById('busLabel').textContent=bus.name+' ('+bus.plate+') — '+r.name;
  tracking=!!bus.active;
  if(bus.active && tracking) startTracking(true);
  setupMap();
  setInterval(loadLate,2000);
  // أعد تعيين منظور الخريطة إلى موقع الباص (آخر معرف)
  if(busMarker){ var pos=busMarker.getLatLng(); if(pos) map.setView(pos,14); }
}
async function setupMap(){
  map=L.map('map',{zoomControl:true}); L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
  if(r){ var g=buildGeometry(r); var poly=g.pts.map(function(p){return[p.lat,p.lng];}); if(poly.length>1)L.polyline(poly,{color:r.color,weight:4,opacity:.9}).addTo(map); var sc=stopCumPositions(g); sc.forEach(function(s,i){ L.marker([g.pts[s.index].lat,g.pts[s.index].lng],{icon:L.divIcon({className:'',html:'<div style="width:24px;height:24px;border-radius:50%;background:rgba(255,255,255,.85);color:#333;font-weight:800;font-size:12px;border:2px solid #fff;display:flex;align-items:center;justify-content:center">'+(i+1)+'</div>',iconSize:[24,24]})}).addTo(map); }); }
  if(r.terminal)L.circleMarker([r.terminal.lat,r.terminal.lng],{radius:9,color:'#fff',weight:2,fillColor:'#16a34a',fillOpacity:1}).addTo(map).bindPopup('الجامعة');
  document.getElementById('legend').innerHTML='<span class="item"><span class="sw" style="background:'+(r?r.color:'#6366f1')+'"></span>'+(r?r.name:'')+'</span>';
}
function startTracking(isResume){
  tracking=true;
  document.getElementById('trackBtn').textContent='⏹ إيقاف التتبع';
  fetch('api/driver/tracking',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({busId:bus.id,on:true})});
  document.getElementById('status').textContent='🟢 التتبع شغّال — جارٍ إرسال الموقع…';
  if(watchId==null && ('geolocation' in navigator)){
    watchId=navigator.geolocation.watchPosition(onPos, onErr, {enableHighAccuracy:true,timeout:15000,maximumAge:2000});
  }
}
function stopTracking(){
  tracking=false; document.getElementById('trackBtn').textContent='▶ بدء التتبع';
  fetch('api/driver/tracking',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({busId:bus.id,on:false})});
  if(watchId!=null){ navigator.geolocation.clearWatch(watchId); watchId=null; }
  document.getElementById('status').textContent='⏹ التتبع متوقف';
}
document.getElementById('trackBtn').addEventListener('click',function(){ tracking?stopTracking():startTracking(); });
function onErr(e){ document.getElementById('gpsHint').textContent='⚠️ تعذّر تحديد الموقع: '+(e&&e.message||'خطأ'); }
function onPos(pos){
  var lat=pos.coords.latitude, lng=pos.coords.longitude, acc=Math.round(pos.coords.accuracy||0);
  document.getElementById('gpsHint').textContent='📍 '+lat.toFixed(6)+', '+lng.toFixed(6)+' (±'+acc+'م)';
  if(busMarker){ busMarker.setLatLng([lat,lng]); } else { busMarker=L.marker([lat,lng],{icon:L.divIcon({className:'',html:'<div style="width:34px;height:34px;border-radius:50%;background:#22c55e;color:#fff;font-weight:800;border:3px solid #fff;display:flex;align-items:center;justify-content:center;font-size:17px;box-shadow:0 0 0 5px rgba(34,197,94,.3)">🚌</div>',iconSize:[34,34]})}).addTo(map); }
  map.panTo([lat,lng]);
  var now=Date.now();
  if(now-lastSend>2000){ lastSend=now;
    fetch('api/driver/gps',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({busId:bus.id,lat:lat,lng:lng,speed:pos.coords.speed?Math.round(pos.coords.speed*3.6):0})})
      .then(r=>r.json()).then(function(j){ if(j.phase){ document.getElementById('status').textContent='✔ المرحلة: '+(j.phase==='return'?'↩️ إياب':'🌅 ذهاب')+' · '+j.reason; document.getElementById('busLabel').textContent=bus.name+' ('+bus.plate+') — '+r.name; } });
  }
}
function lateWord(n){
  if(n===1) return 'طالب واحد';
  if(n===2) return 'طالبان';
  if(n>=3 && n<=10) return n+' طلاب';
  return n+' طالب';
}
async function loadLate(){
  if(!bus) return;
  var el=document.getElementById('latePanel'); if(!el) return;
  apiFD('api/late?busId='+bus.id).then(function(j){
    var total=j.total||0;
    if(!total){ el.innerHTML='<div class="hint">لا طلبات تأخير الآن.</div>'; }
    else {
      el.innerHTML='<div class="latecard on" style="background:rgba(245,158,11,.14);border-color:rgba(245,158,11,.4);border:1px solid;border-radius:14px;padding:14px 16px"><span style="font-size:30px">⏳</span><div><b style="color:#fcd34d;font-size:22px">'+lateWord(total)+' متأخر</b><br><span class="hint">على باصك — انتظر أو كلّمهم إذا توفر وقت</span></div></div>'
        +(j.lateOpen?'':' <div class="hint" style="margin-top:6px">· '+esc(j.lateReason||'التأخير مغلق')+'</div>');
    }
    // تتبّع عدد إجمالي الطلبات لاكتشاف طلب جديد -> جرس/اهتزاز/وميض (بدون أي هوية)
    if(total>prevLateTotal){ fireAlert(total); }
    prevLateTotal=total; prevInitialised=true;
  }).catch(function(){ });
}
function fireAlert(total){
  if(audioCtx){ try{ beep(); }catch(e){} }
  if(navigator.vibrate) try{ navigator.vibrate([320,140,320]); }catch(e){}
  if('Notification' in window && Notification.permission==='granted'){ try{ new Notification('🚌 طلب تأخير على باصك', {body:'لاحظ: '+lateWord(total)+' أشار أنه متأخر'}); }catch(e){} }
  var ov=document.getElementById('bellOverlay'), tx=document.getElementById('bellText');
  if(ov){ tx.innerHTML='🚌 <b>'+lateWord(total)+' متأخر</b><br><span style="font-weight:600;font-size:15px">أشارو أنهم متأخرون على باصك</span>'; ov.style.display='flex';
    clearTimeout(alertTimer); alertTimer=setTimeout(function(){ ov.style.display='none'; },6000); }
}
function apiFD(p){ return fetch(p,{headers:{'Authorization':'Bearer '+token}}).then(function(r){return r.json();}); }
boot();
