#!/usr/bin/env bash
# تشغيل منظومة النقل الذكي (المحلي)
cd "$(dirname "$0")"
[ -d node_modules/express ] || npm install
echo "▶ تشغيل المنظومة على http://localhost:3000"
node server.js
