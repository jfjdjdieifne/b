# 📱 بناء تطبيق أندرويد (APK) للمنظومة

التطبيق عبارة عن **غلاف أصلي** (Capacitor/WebView) يعرض واجهات الطالب والسوّاق من خادمك. هذا يطابق استراتيجية الحماية: **الدماغ على الخادم، والعميل (APK) يعرض النتائج فقط**.

## الطريقة ١ — الأسهل: بناء APK مجاناً عبر GitHub (بدون سديف) ✨

1. ارفع مجلد `mobile/` إلى مستودع GitHub.
2. (بلّغ) عدّل `capacitor.config.json` → ضع رابط خادمك في `server.url`.
3. من صفحة المستودع: **Actions** → **Build Android APK** → **Run workflow**.
4. بعد دقيقتين نزّل `transit-apk` (ملف `.apk`) واضغطه على هاتفك. **مجاني، بلا توقيع/متجر.**

## الطريقة ٢ — بناء محلي عبر Android Studio

تتطلب: Node.js 20 + Java 17 + Android Studio.

```bash
cd mobile
npm install
# عدّل رابط الخادم في capacitor.config.json
npx cap add android        (مرة واحدة)
npx cap sync android
# افتح مجلد android في Android Studio ثم Build > Build APK(s)
```

أو من سطر الأوامر:
```bash
cd android && ./gradlew assembleRelease
# الناتج: android/app/build/outputs/apk/release/
```

## ⚠️ قبل تسليم APK لطلاب/جهة

- **هاشت الخادم على رابط ثابت** (استضافة) — بدون خادم لن تعمل التتبّع الحي.
- **وقّع (Sign) النسخة** بمفتاح خاص لك (Android Studio: Build > Generate Signed APK) — لا توزّع نسخة unsigned.
- ضع رابط HTTPS أو فعّل `cleartext:true` للاختبار المحلي فقط.
- لا تبني حزمة فيها بياناتك/سورس الخادم — العميل لا يحتاجها.

## 📁 بنية مجلد mobile
```
mobile/
  capacitor.config.json   ← رابط الخادم (عدّله)
  www/index.html          ← شاشة ترحيب/تحميل
  android/                ← مشروع أندرويد (يُبنى منه الـ APK)
  .github/workflows/build-apk.yml  ← بناء APK مجاني
  README-APK.md
```
