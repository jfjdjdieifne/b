package sy.smarttransit.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
