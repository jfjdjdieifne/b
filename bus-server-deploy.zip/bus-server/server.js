// ============================================================
// منظومة النقل الذكي — الخادم (Node + Express) — نسخة الإنتاج
// أدوار: مالك / إدارة الجامعة / سوّاق / طالب
// كل شيء محلي ومجاني: قاعدة البيانات = ملف JSON على جهازك.
// ============================================================
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PH = require('./lib/phase');

const app = express();
app.use(express.json());
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const LOG_FILE = path.join(DATA_DIR, 'passlog.json');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, {recursive:true});

/* ------------------------- البيانات الافتراضية ------------------------- */
const DEFAULTS = {
  seed: 5,
  owner: { username: 'owner', password: 'owner123' },
  settings: { baseSpeedKph: 34, dwellAtTerminalSec: 15, offRouteThreshold: 300, stopArriveRadius: 45, studentDefaultPass: 'student123', licenseKey:'DEMO-2026-OWNER', licenseHolder:'مالك النظام', licenseExpiry:null, allowSelfReg:false, lateWindowMin:30, allowLate:true, lateCooldownMin:3 },
  // ترخيص الاستخدام — عند الاستضافة يُحفظ في خادم المُشغّل ولا يستطيع العميل تعديله بسهولة
  routes: [
    { id:'route-1', name:'خط الجامعة (الميدان)', color:'#6366f1',
      origin:{name:'محطة الميدان', lat:33.5082, lng:36.2742},
      stops:[
        {name:'ركن الدين', lat:33.5110, lng:36.2772},
        {name:'ساحة شمدين', lat:33.5136, lng:36.2802},
        {name:'موقف النور', lat:33.5162, lng:36.2832},
        {name:'باب المصلى', lat:33.5188, lng:36.2862},
        {name:'سوق الهال', lat:33.5214, lng:36.2892}
      ],
      terminal:{name:'الجامعة', lat:33.5240, lng:36.2922, radius:120} },
    { id:'route-2', name:'خط المدينة – الجامعة', color:'#22c55e',
      origin:{name:'ساحة الأمويين', lat:33.5080, lng:36.2860},
      stops:[
        {name:'المركز القديم', lat:33.5100, lng:36.2880},
        {name:'جسر الثورة', lat:33.5130, lng:36.2900},
        {name:'ساحة العباسيين', lat:33.5160, lng:36.2920}
      ],
      terminal:{name:'الجامعة', lat:33.5240, lng:36.2922, radius:150} }
  ],
  buses: [
    { id:'bus-1', name:'باص 1', plate:'س 7277', capacity:40, routeId:'route-1', driverUser:'drv1', driverPass:'driver123', active:true,
      schedule:[
        {id:'t1', dir:'out', time:'08:00', label:'ذهاب 8:00 ص'},
        {id:'t2', dir:'out', time:'09:00', label:'ذهاب 9:00 ص'},
        {id:'t3', dir:'out', time:'11:00', label:'ذهاب 11:00 ص'},
        {id:'t4', dir:'ret', time:'12:00', label:'إياب 12:00 م'},
        {id:'t5', dir:'ret', time:'13:00', label:'إياب 1:00 م'},
        {id:'t6', dir:'ret', time:'14:00', label:'إياب 2:00 م'}
      ] },
    { id:'bus-2', name:'باص 2', plate:'س 5678', capacity:35, routeId:'route-1', driverUser:'drv2', driverPass:'driver123', active:false,
      schedule:[
        {id:'t1', dir:'out', time:'08:30', label:'ذهاب 8:30 ص'},
        {id:'t2', dir:'out', time:'10:00', label:'ذهاب 10:00 ص'},
        {id:'t3', dir:'ret', time:'12:30', label:'إياب 12:30 م'},
        {id:'t4', dir:'ret', time:'14:30', label:'إياب 2:30 م'}
      ] },
    { id:'bus-3', name:'باص 3', plate:'س 9012', capacity:30, routeId:'route-2', driverUser:'drv3', driverPass:'driver123', active:true,
      schedule:[
        {id:'t1', dir:'out', time:'08:00', label:'ذهاب 8:00 ص'},
        {id:'t2', dir:'ret', time:'12:00', label:'إياب 12:00 م'}
      ] }
  ],
  admins: [
    { id:'adm-1', username:'admin1', password:'admin123', name:'إدارة الجامعة' }
  ],
  students: [
    { id:'stu-1', universityId:'2023001', name:'أحمد الحمصي', routeId:'route-1', stopIdx:1, busId:'bus-1', password:'student123', passChanged:true, phone:null },
    { id:'stu-2', universityId:'2023002', name:'سارة النجار', routeId:'route-1', stopIdx:2, busId:'bus-1', password:'student123', passChanged:true, phone:null },
    { id:'stu-3', universityId:'2023003', name:'خالد الخطيب', routeId:'route-1', stopIdx:0, busId:'bus-1', password:'student123', passChanged:true, phone:null },
    { id:'stu-4', universityId:'2023004', name:'هبة مصطفى', routeId:'route-2', stopIdx:1, busId:'bus-3', password:'student123', passChanged:true, phone:null },
    { id:'stu-5', universityId:'2023005', name:'عمر الزعبي', routeId:'route-2', stopIdx:2, busId:'bus-3', password:'student123', passChanged:true, phone:null }
  ]
};

function loadJson(file, fallback) {
  try { if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8')); } catch(e){ console.warn('تعذّر قراءة', file, e.message); }
  return fallback;
}
function saveJson(file, obj) { try { fs.writeFileSync(file, JSON.stringify(obj, null, 2)); } catch(e){ console.warn('تعذّر حفظ', file, e.message); } }

let db = loadJson(DB_FILE, null);
if (!db || !db.owner || db.seed !== DEFAULTS.seed) { db = JSON.parse(JSON.stringify(DEFAULTS)); saveJson(DB_FILE, db); }
let passLog = loadJson(LOG_FILE, {});   // { "2026-08-31": { busId: [ {stopIdx,stopName,dir,arriveTs} ] } }
let RT = {};                            // حالة حية لكل باص
let sessions = {};                      // token -> session

function saveDb(){ saveJson(DB_FILE, db); }
function saveLog(){ saveJson(LOG_FILE, passLog); }

function todayStr(){ const d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); }
function fmtSimMin(min){ if(min==null)return '—'; let h=Math.floor(min/60)%24, m=min%60, suf=h>=12?'م':'ص'; h=h%12; if(h===0)h=12; return h+':'+String(m).padStart(2,'0')+' '+suf; }
function fmtClockShort(ts){ if(!ts)return '—'; const d=new Date(ts); let h=d.getHours(),m=d.getMinutes(),suf=h>=12?'م':'ص'; h=h%12; if(h===0)h=12; return h+':'+String(m).padStart(2,'0')+' '+suf; }

/* ------------------------- الجلسات والدخول (4 أدوار) ------------------------- */
function weekdayName(i){ return ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'][i]||''; }
function weekdayKey(i){ return ['sun','mon','tue','wed','thu','fri','sat'][i]||''; }
// جدول باص لتاريخ معيّن: يخصّص بالتاريخ، أو بيوم الأسبوع، وإلا الجدول الأساسي
function busDateSched(bus, dateStr){
  if(bus.schedulesByDate && bus.schedulesByDate[dateStr]) return bus.schedulesByDate[dateStr];
  var d=new Date(dateStr); if(isNaN(d.getTime())) return bus.schedule||[];
  var wk=weekdayKey(d.getDay());
  if(bus.schedulesByWeekday && bus.schedulesByWeekday[wk]) return bus.schedulesByWeekday[wk];
  return bus.schedule||[];
}
function randomPassword(len){ var c='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789'; len=len||8; var out=''; for(var i=0;i<len;i++) out+=c.charAt(Math.floor(Math.random()*c.length)); return out; }
// أي جلسة (مالك/إدارة/سوّاق/طالب)
function anyAuth(req,res,next){ const s=auth(req); if(!s) return res.status(401).json({error:'لم تسجّل الدخول'}); next(); }
// بيانات "متأخر": لكل يوم، لكل باص، لكل موقف، قائمة الطلاب المنتظرين
var lateData = {};   // { "2026-08-31": { busId: { stopIdx: { students:{id:{universityId,name}}, updatedAt } } } }
function lateKey(){ return todayStr(); }
function lateCountFor(busId){ var bd=lateData[lateKey()]&&lateData[lateKey()][busId]; if(!bd)return 0; var n=0; Object.keys(bd).forEach(function(k){ n+=Object.keys(bd[k].students).length; }); return n; }
function lateForStop(busId, stopIdx){ var bd=lateData[lateKey()]&&lateData[lateKey()][busId]; if(!bd||!bd[stopIdx])return {count:0, students:[]}; return {count:Object.keys(bd[stopIdx].students).length, students:Object.values(bd[stopIdx].students)}; }
var lateCooldowns = {};   // studentId -> { busId+':'+stopIdx: ts }  (منع التكرار)
function stopNameOf(busId, stopIdx){ var bus=db.buses.find(function(b){return b.id===busId;}); var r=bus&&db.routes.find(function(x){return x.id===bus.routeId;}); return (r&&r.stops[stopIdx])?r.stops[stopIdx].name:('الموقف '+(stopIdx+1)); }
function findActiveLate(stuId){ // أين لديه الطالب طلب "متأخر" فعّال الآن؟
  var bd=lateData[lateKey()]; if(!bd) return null;
  for(var busId in bd){ for(var k in bd[busId]){ var st=bd[busId][k].students; if(st&&st[stuId]){ return {busId:busId, stopIdx:+k, count:Object.keys(st).length, stopName:stopNameOf(busId,+k)}; } } }
  return null;
}
function removeLateEntry(stuId,busId,stopIdx){ var day=lateKey(); var bd=lateData[day]&&lateData[day][busId]; if(!bd||!bd[stopIdx]||!bd[stopIdx].students) return; delete bd[stopIdx].students[stuId]; if(!Object.keys(bd[stopIdx].students).length) delete bd[stopIdx]; if(!Object.keys(bd).length) delete lateData[day][busId]; }
function nearestStopIdx(r, lat, lng, fallback){ if(!r||!r.stops) return fallback!=null?fallback:0; var best=fallback!=null?fallback:0, bd=1e18, cl=Math.cos(lat*Math.PI/180); r.stops.forEach(function(s,i){ var m=Math.pow((+s.lat-lat)*111320,2)+Math.pow((+s.lng-lng)*111320*cl,2); if(m<bd){bd=m;best=i;} }); return best; }
function clearLateAtPassedStops(bus, r, g, rt){
  var day=lateKey(); var bd=lateData[day]; if(!bd||!bd[bus.id])return;
  var sc=PH.stopCumPositions(g);
  sc.forEach(function(s){
    var passed = rt.dir===-1 ? (rt.progress < s.cum - 5) : (rt.progress > s.cum + 5);
    if(passed && bd[bus.id] && bd[bus.id][s.index]){ delete bd[bus.id][s.index]; }
  });
  if(bd[bus.id] && !Object.keys(bd[bus.id]).length) delete bd[bus.id];
}
function lateOpenFor(bus){
  if(db.settings.allowLate===false) return {open:false, reason:'الخاصية معطّلة من الإدارة'};
  var rt=RT[bus.id]; var r=db.routes.find(function(x){return x.id===bus.routeId;});
  if(!r||!r.stops) return {open:false, reason:'لا خط'};
  // السوّاق يجب أن يكون متصلاً وعلى رحلة فعلية
  if(!rt||!rt.online||rt.lat==null) return {open:false, reason:'الباص غير متصل الآن'};
  // خيار التأخير فقط برحلة الذهاب (⛅) وليس بالعودة
  if(rt.dir===-1||rt.phase==='return') return {open:false, reason:'خيار التأخير متاح فقط برحلة الذهاب (⛅)'};
  var g=PH.buildGeometry(r); var sc=PH.stopCumPositions(g); if(!sc.length) return {open:false, reason:'لا مواقف'};
  var lastCum=sc[sc.length-1].cum;
  // بعد آخر موقف والانطلاق نحو الجامعة: يُغلق التأخير
  if(rt.progress!=null && rt.progress > lastCum - 5) return {open:false, reason:'وصل الباص لآخر مواقفه وانطلق نحو الجامعة — التأخير مغلق'};
  return {open:true, reason:''};
}
function newSession(role, identity){ const t=crypto.randomBytes(24).toString('hex'); sessions[t]=Object.assign({role:role}, identity||{}); return t; }
function auth(req){ const t=(req.headers.authorization||'').replace(/^Bearer /,'')||req.query.token||req.body.token; return sessions[t]||null; }
// requireRole(role) يسمح أيضاً للمالك (superuser)
function requireRole(role){ return (req,res,next)=>{ const s=auth(req); if(!s) return res.status(401).json({error:'لم تسجّل الدخول'}); if(s.role!==role && s.role!=='owner') return res.status(403).json({error:'صلاحية غير كافية'}); next(); }; }

app.post('/api/login', (req,res)=>{
  const {username, password} = req.body||{};
  if (username===db.owner.username && password===db.owner.password) return res.json({token:newSession('owner',{}), role:'owner', name:'المالك'});
  const adm = db.admins.find(a=>a.username===username && a.password===password);
  if (adm) return res.json({token:newSession('admin',{adminId:adm.id}), role:'admin', name:adm.name});
  const bus = db.buses.find(b=>b.driverUser===username && b.driverPass===password);
  if (bus) return res.json({token:newSession('driver',{busId:bus.id}), role:'driver', name:bus.name, busId:bus.id});
  const stu = db.students.find(s=>s.universityId===username && s.password===password);
  if (stu) return res.json({token:newSession('student',{studentId:stu.id}), role:'student', name:stu.name, mustChange:!stu.passChanged});
  res.status(401).json({error:'بيانات الدخول غير صحيحة'});
});
app.post('/api/logout', (req,res)=>{ const s=auth(req); if(s) delete sessions[s]; res.json({ok:true}); });
app.get('/api/me', (req,res)=>{ const s=auth(req); if(!s) return res.json({role:null}); res.json({role:s.role, name:s.name, busId:s.busId||null, adminId:s.adminId||null, studentId:s.studentId||null}); });

/* ------------------------- بيانات عامة (آمنة — بدون أسرار) ------------------------- */
function publicBuses(){ return db.buses.map(b=>({id:b.id, name:b.name, plate:b.plate, capacity:b.capacity, routeId:b.routeId, active:b.active})); }
app.get('/api/meta', (req,res)=> res.json({settings:db.settings, routes:db.routes, buses:publicBuses()}));
/* ---- الترخيص ---- */
app.get('/api/license', (req,res)=>{
  const s=db.settings; const expired = s.licenseExpiry ? (Date.now() > new Date(s.licenseExpiry).getTime()) : false;
  res.json({key:s.licenseKey, holder:s.licenseHolder, expiry:s.licenseExpiry, expired:expired, active:!expired});
});
app.put('/api/admin/license', requireRole('owner'), (req,res)=>{
  const b=req.body||{}; if(!b.key && b.key!==''){ return res.status(400).json({error:'أدخل مفتاح الترخيص'}); }
  if(b.key && !/^[A-Z0-9-]{12,}$/i.test(b.key)) return res.status(400).json({error:'مفتاح غير صالح (حروف/أرقام/شرطات، 12+ حرف)'});
  db.settings.licenseKey=b.key||'';
  if(b.holder!=null) db.settings.licenseHolder=b.holder;
  if(b.expiry!==undefined) db.settings.licenseExpiry=b.expiry||null;
  saveDb(); res.json({ok:true, license:db.settings.licenseKey});
});

app.get('/api/buses', (req,res)=> res.json(publicBuses()));

/* المواقع الحية لكل باص (يستخدمها الطالب/الإدارة/السوّاق) */
function studentCountForBus(busId){ return db.students.filter(function(s){return s.busId===busId;}).length; }
function rosterForBus(busId, onlyNames){ var list=db.students.filter(function(s){return s.busId===busId;}); return onlyNames?list.map(function(s){return{universityId:s.universityId, name:s.name, stopIdx:s.stopIdx, routeId:s.routeId};}):list; }

function busLive(id){
  const bus = db.buses.find(b=>b.id===id); if(!bus) return null;
  const r = db.routes.find(x=>x.id===bus.routeId);
  const rt = RT[id];
  if(!rt || !rt.online) return {busId:id, name:bus.name, plate:bus.plate, routeId:bus.routeId, routeName:r?r.name:'', routeColor:r?r.color:'#666', status:'offline', lat:null, lng:null, speed:0, phase:null, dir:1, phaseReason:'', offRoute:false, progress:0, lastUpdate:null, studentCount:studentCountForBus(id), schedule:(bus.schedule||[])};
  return {busId:id, name:bus.name, plate:bus.plate, routeId:bus.routeId, routeName:r?r.name:'', routeColor:r?r.color:'#666', status:'on', lat:rt.lat, lng:rt.lng, speed:Math.round(rt.speed||0), phase:rt.phase, dir:rt.dir, phaseReason:rt.phaseReason, offRoute:rt.offRoute, snapDist:rt.snapDist, progress:rt.progress, nextStop:nextStopName(bus,r,rt), lastUpdate:rt.lastUpdate, studentCount:studentCountForBus(id), schedule:(bus.schedule||[])};
}
function nextStopName(bus, r, rt){
  if(!r||!rt||rt.progress==null) return null;
  const g=PH.buildGeometry(r); const sc=PH.stopCumPositions(g); if(!sc.length) return null;
  if(rt.dir===-1){ const down=sc.filter(s=>s.cum<rt.progress); return down.length?down[down.length-1].name:null; }
  const up=sc.filter(s=>s.cum>rt.progress); return up.length?up[0].name:null;
}
app.get('/api/live', (req,res)=> res.json(db.buses.map(b=>busLive(b.id))));

/* سجل أوقات المرور لليوم مباشرة */
app.get('/api/schedule', (req,res)=>{
  const busId=req.query.busId; const day=todayStr();
  res.json({day:day, items:(passLog[day]||{})[busId]||[]});
});

/* ---- الجدول الكامل (تخطيط) لكل الخطوط والباصات لتاريخ معيّن — يصلح للطالب والإدارة ---- */
app.get('/api/timetable', anyAuth, (req,res)=>{
  const date=req.query.date||todayStr();
  const d=new Date(date);
  const routes=db.routes.map(function(r){
    return { id:r.id, name:r.name, color:r.color, origin:r.origin||null, terminal:r.terminal||null,
      stops:r.stops.map(function(s,i){return {index:i, name:s.name, lat:s.lat, lng:s.lng};}),
      buses: db.buses.filter(function(b){return b.routeId===r.id;}).map(function(b){
        var rt=RT[b.id]||{}; var online=!!(rt.online&&rt.lat!=null);
        return { id:b.id, name:b.name, plate:b.plate, capacity:b.capacity, active:!!b.active, online:online,
                 status: online?'on':(b.active?'ready':'off'), schedule: busDateSched(b, date) };
      })
    };
  });
  res.json({ date:date, weekday: isNaN(d.getTime())?'':weekdayName(d.getDay()), routes:routes });
});

/* ------------------------- سجلات الطالب لنفسه (طالب) ------------------------- */
app.get('/api/student/me', requireRole('student'), (req,res)=>{
  const s=auth(req); const stu=db.students.find(x=>x.id===s.studentId); if(!stu) return res.status(404).json({error:'لا يوجد طالب'});
  const route=db.routes.find(r=>r.id===stu.routeId);
  const bus = stu.busId ? db.buses.find(b=>b.id===stu.busId) : db.buses.find(b=>b.routeId===stu.routeId && b.active);
  var act = findActiveLate(stu.id);
  res.json({student:{universityId:stu.universityId, name:stu.name, stopIdx:stu.stopIdx, busId:stu.busId, routeId:stu.routeId, busName:bus?bus.name:null, passChanged:!!stu.passChanged},
           route:route||null, bus: bus?busLive(bus.id):null, busName:bus?bus.name:null,
           late: act ? {active:true, mine:true, busId:act.busId, stopIdx:act.stopIdx, stopName:act.stopName, count:act.count} : {active:false, mine:false, count:0},
           settings:{allowSelfReg:db.settings.allowSelfReg, allowLate:db.settings.allowLate!==false, lateCooldownMin:db.settings.lateCooldownMin||3},
           busesOnRoute: db.buses.filter(b=>b.routeId===stu.routeId).map(b=>busLive(b.id)),
           allBuses: db.buses.map(function(b){ var br=db.routes.find(function(x){return x.id===b.routeId;}); var lv=busLive(b.id); var rt=RT[b.id]||{}; var online=!!(rt.online&&rt.lat!=null); lv.lineName=br?br.name:''; lv.lineColor=br?br.color:'#666'; lv.active=!!b.active; lv.online=online; lv.status=online?'on':(b.active?'ready':'off'); lv.stops=(br?br.stops:[]).map(function(s,i){return {index:i, name:s.name};}); lv.dir=rt.dir||1; lv.phase=rt.phase||null; var lg=lateOpenFor(b); lv.lateOpen=lg.open; lv.lateReason=lg.reason; return lv; })});
});

/* ---- الطالب: تغيير كلمة المرور / تسجيل "متأخر" / التسجيل الذاتي ---- */
app.post('/api/student/password', requireRole('student'), (req,res)=>{
  const s=auth(req); const stu=db.students.find(x=>x.id===s.studentId); if(!stu) return res.status(404).json({error:'لا يوجد طالب'});
  const np=req.body&&req.body.password;
  if(!np || String(np).length<4) return res.status(400).json({error:'كلمة المرور قصيرة (4+ أحرف)'});
  // لا تسمح بكلمة مرور سهلة (مثل رقم جامعي أو student123)
  if(String(np).toLowerCase()==='student123') return res.status(400).json({error:'اختر كلمة مرور أقوى من الافتراضية'});
  stu.password=String(np); stu.passChanged=true; saveDb();
  res.json({ok:true});
});
// الطالب يسجّل "متأخر" عند موقفه على باص معيّن
app.post('/api/student/late', requireRole('student'), (req,res)=>{
  const s=auth(req); const stu=db.students.find(x=>x.id===s.studentId); if(!stu) return res.status(404).json({error:'لا يوجد طالب'});
  const {busId, stopIdx, lat, lng} = req.body||{};
  const bus=db.buses.find(b=>b.id===busId); if(!bus) return res.status(400).json({error:'باص غير موجود'});
  const r=db.routes.find(x=>x.id===bus.routeId); if(!r||!r.stops) return res.status(400).json({error:'خط الباص غير محدد'});
  // 1) هل التأخير مفتوح لهذا الباص (ذهاب فقط + قبل آخر مواقفه)؟
  var g=lateOpenFor(bus); if(!g.open) return res.status(400).json({error:g.reason});
  // 2) الموقف: أقرب موقف لموقع الطالب الحقيقي (إن أرسل موقعه) وإلا موقفه المسجّل
  var si = (lat!=null && lng!=null) ? nearestStopIdx(r, +lat, +lng, +stopIdx) : +stopIdx;
  if(si==null || r.stops[si]==null) return res.status(400).json({error:'حدّد الموقف الذي تنتظر فيه'});
  var stopName = r.stops[si].name;
  var rt=RT[bus.id];
  // لا يُسمح بالتأخير عند موقفٍ تجاوزه الباص
  if(rt.progress!=null){ var sc=PH.stopCumPositions(PH.buildGeometry(r)); if(sc[si]&&rt.progress>sc[si].cum+5) return res.status(400).json({error:'الباص تجاوز موقفك — لا يمكن إشعاره لهذا الموقف'}); }
  // 3) منع التكرار: إن كان فعّالاً على نفس الباص/الموقف -> تأكيد من دون مضاعفة (لا يتراكم لطالب واحد)
  var active = findActiveLate(stu.id);
  if(active && active.busId===busId && active.stopIdx===si){
    // لا يتراكم: يعيد التأكيد فقط بنفس العدد
    return res.json({ok:true, count:active.count, stopIdx:si, stopName:active.stopName, busId:busId, already:true});
  }
  var now=Date.now();
  // 4) الانتقال لباص/موقف آخر: يُلغى طلب الطالب السابق تلقائياً (لا يتراكم من موقف لموقف)
  if(active) removeLateEntry(stu.id, active.busId, active.stopIdx);
  // 5) تسجيل
  const day=lateKey(); lateData[day]=lateData[day]||{}; lateData[day][busId]=lateData[day][busId]||{};
  const slot=lateData[day][busId][si]=lateData[day][busId][si]||{students:{}, updatedAt:now};
  slot.students[stu.id]={universityId:stu.universityId, name:stu.name, pressTs:now};
  slot.updatedAt=now;
  const count=Object.keys(slot.students).length;
  res.json({ok:true, count:count, stopIdx:si, stopName:stopName, busId:busId, canRepress:true});
});
app.post('/api/student/late/clear', requireRole('student'), (req,res)=>{
  const s=auth(req); const stu=db.students.find(x=>x.id===s.studentId); if(!stu) return res.status(404).json({error:'لا يوجد طالب'});
  const {busId, stopIdx} = req.body||{};
  if(busId!=null && stopIdx!=null) removeLateEntry(stu.id, busId, +stopIdx);
  else { var active=findActiveLate(stu.id); if(active) removeLateEntry(stu.id, active.busId, active.stopIdx); }
  res.json({ok:true});
});
// استعلام طلبات "متأخر" لباص (السوّاق/الإدارة/المالك/الطالب)
app.get('/api/late', anyAuth, (req,res)=>{
  const busId=req.query.busId; if(!busId) return res.status(400).json({error:'حدد الباص'});
  const bus=db.buses.find(b=>b.id===busId); if(!bus) return res.status(404).json({error:'باص غير موجود'});
  const r=db.routes.find(x=>x.id===bus.routeId); const bd=lateData[lateKey()]&&lateData[lateKey()][busId]||{};
  const rt=RT[busId]||{}; const lg=lateOpenFor(bus);
  // الخصوصية: لا نُعيد أي معرف/اسم/موقف — نعيد العدد الإجمالي فقط
  const items=Object.keys(bd).map(function(k){ return {count:Object.keys(bd[k].students).length}; });
  res.json({day:lateKey(), busId:busId, dir:rt.dir||1, phase:rt.phase||null, online:!!(rt.online&&rt.lat!=null), lateOpen:lg.open, lateReason:lg.reason, total:lateCountFor(busId), items:items});
});

/* ---- "تفعيل" حساب الطالب: خاصة للطلاب الذين أنشأهم الإدارة ---- */
/* يُستخدم لتأكيد الهوية: الطالب يُدخل رقمه الجامعي + اسمه كما سجّله الإدارة،
   ثم يضع كلمة مرور شخصية. لكن لحماية من يعرف رقم زميله، يجب أن يطابق اسمه
   الاسمَ الذي أنشأته الإدارة (ويبقى الأفضل توزيع كلمة مرور أولية خاصة). */
app.post('/api/student/regist', (req,res)=>{
  const b=req.body||{}; if(!b.universityId) return res.status(400).json({error:'أدخل الرقم الجامعي'});
  const stu=db.students.find(x=>x.universityId===b.universityId);
  if(!stu) return res.status(404).json({error:'رقمك ليس في سجل الإدارة — تواصل مع الإدارة'});
  return res.json({ok:true, exists:true, name:stu.name, note:'حسابك موجود — سجّل الدخول. إن أردت تغيير كلمة المرور استخدم الإعدادات.'});
});

/* ------------------------- أدوار السوّاق ------------------------- */
/* قائمة طلاب الباص (المالك/الإدارة/السوّاق يستطيعون رؤية قائمتهم) */
app.get('/api/bus/roster', (req,res)=>{
  const busId=req.query.busId; const bus=db.buses.find(b=>b.id===busId); if(!bus) return res.status(404).json({error:'باص غير موجود'});
  res.json({busId:busId, busName:bus.name, routeId:bus.routeId, count:studentCountForBus(busId), students:rosterForBus(busId, true)});
});

app.post('/api/driver/gps', requireRole('driver'), (req,res)=>{
  const {lat,lng,speed,busId} = req.body||{};
  const bus = db.buses.find(b=>b.id===busId); if(!bus) return res.status(400).json({error:'باص غير موجود'});
  if(lat==null||lng==null) return res.status(400).json({error:'لا موقع'});
  const r = db.routes.find(x=>x.id===bus.routeId);
  let rt = RT[bus.id] || (RT[bus.id]={});
  rt.lat=lat; rt.lng=lng; rt.speed=speed||0; rt.online=true; rt.lastUpdate=Date.now();
  if(r){
    const g=PH.buildGeometry(r);
    const ph=PH.inferTripPhase(r,g,rt,lat,lng);
    rt.phase=ph.phase; rt.dir=ph.dir; rt.progress=ph.progress; rt.offRoute=ph.offRoute;
    rt.phaseReason=ph.reason; rt.snapDist=ph.snapDist;
    recordStopCrossings(bus, r, g, rt);
    clearLateAtPassedStops(bus, r, g, rt);   // حين يمرّ الباص عن الموقف تُلغى إشارة "متأخر" تلقائياً
  }
  res.json({ok:true, success:true, phase:rt.phase, reason:rt.phaseReason});
});
app.post('/api/driver/tracking', requireRole('driver'), (req,res)=>{
  const {busId, on} = req.body||{};
  const bus = db.buses.find(b=>b.id===busId); if(!bus) return res.status(400).json({error:'باص غير موجود'});
  bus.active = on;
  if(!on && RT[busId]) { RT[busId].online=false; RT[busId].lat=null; RT[busId].lng=null; }
  saveDb();
  res.json({ok:true, active:bus.active});
});

function recordStopCrossings(bus, r, g, rt){
  const sc=PH.stopCumPositions(g); const now=Date.now();
  rt.logged = rt.logged||[];
  const p = rt.progress; const prev = rt._prevProg==null?p:rt._prevProg;
  if(rt.dir===1){ sc.forEach(function(s){ if(s.cum>prev && s.cum<=p && !rt.logged.includes(s.index)){ rt.logged.push(s.index); addPass(bus, s, 1, now); } }); }
  else if(rt.dir===-1){ for(let i=sc.length-1;i>=0;i--){ const s=sc[i]; if(s.cum<prev && s.cum>=p && !rt.logged.includes(s.index)){ rt.logged.push(s.index); addPass(bus, s, -1, now); } } }
  rt._prevProg = p;
  if(rt.dir===1 && rt.progress>=g.total-2){ rt.logged=[]; }
  if(rt.dir===-1 && rt.progress<=2){ rt.logged=[]; }
}
function addPass(bus, s, dir, ts){
  const day=todayStr(); passLog[day]=passLog[day]||{}; passLog[day][bus.id]=passLog[day][bus.id]||[];
  const items=passLog[day][bus.id];
  const last=items[items.length-1];
  if(last && last.stopIdx===s.index && last.dir===dir && ts-last.arriveTs<30000) return;
  const d=new Date(ts); const min=d.getHours()*60+d.getMinutes();
  items.push({stopIdx:s.index, stopName:s.name, dir:dir, arriveTs:ts, arriveMin:min});
  if(items.length>300) items=items.slice(-300);
  saveLog();
}

/* ------------------------- الإدارة (مالك + إدارة الجامعة) ------------------------- */
app.use('/api/admin', requireRole('admin'));   // يسمح للمالك والإدارة
app.get('/api/admin/meta', (req,res)=> res.json({routes:db.routes, buses:db.buses.map(function(b){ return Object.assign({}, b, {studentCount:studentCountForBus(b.id)}); }), settings:db.settings}));

/* ---- التعميم: باصات / خطوط (الإدارة تستطيع التعديل، المالك يتجاوز كل شيء) ---- */
app.post('/api/admin/bus', (req,res)=>{
  const b=req.body||{}; if(!b.name) return res.status(400).json({error:'أدخل اسم الباص'});
  const id='bus-'+crypto.randomBytes(3).toString('hex');
  db.buses.push({id:id, name:b.name, plate:b.plate||'—', capacity:+b.capacity||40, routeId:b.routeId||null,
                 driverUser:b.driverUser||('drv'+Math.random().toString(16).slice(2,5)), driverPass:b.driverPass||'driver123', active:b.active!==false});
  saveDb(); res.json({ok:true, id:id});
});
app.put('/api/admin/bus/:id', (req,res)=>{ const b=db.buses.find(x=>x.id===req.params.id); if(!b) return res.status(404).json({error:'غير موجود'}); Object.assign(b, req.body||{}); saveDb(); res.json({ok:true}); });
app.put('/api/admin/bus/:id/schedule', (req,res)=>{
  const b=db.buses.find(x=>x.id===req.params.id); if(!b) return res.status(404).json({error:'غير موجود'});
  const {scope, key, schedule} = req.body||{};
  const sched=(schedule&&schedule.length)?schedule:[];
  if(scope==='date'){
    if(!key||!/^\d{4}-\d{2}-\d{2}$/.test(key)) return res.status(400).json({error:'تاريخ غير صالح'});
    b.schedulesByDate=b.schedulesByDate||{}; if(sched.length) b.schedulesByDate[key]=sched; else delete b.schedulesByDate[key];
  } else if(scope==='weekday'){
    if(!key||['sun','mon','tue','wed','thu','fri','sat'].indexOf(key)<0) return res.status(400).json({error:'يوم غير صالح'});
    b.schedulesByWeekday=b.schedulesByWeekday||{}; if(sched.length) b.schedulesByWeekday[key]=sched; else delete b.schedulesByWeekday[key];
  } else {
    b.schedule=sched;
  }
  saveDb(); res.json({ok:true});
});
app.delete('/api/admin/bus/:id', (req,res)=>{ db.buses=db.buses.filter(x=>x.id!==req.params.id); delete RT[req.params.id]; saveDb(); res.json({ok:true}); });
app.post('/api/admin/route', (req,res)=>{
  const r=req.body||{}; if(!r.name||!r.stops||!r.stops.length) return res.status(400).json({error:'اسم الخط ومواقف مطلوبة'});
  const id='route-'+crypto.randomBytes(3).toString('hex');
  db.routes.push({id:id, name:r.name, color:r.color||'#6366f1', origin:r.origin||null, stops:r.stops, terminal:r.terminal||null});
  saveDb(); res.json({ok:true, id:id});
});
app.put('/api/admin/route/:id', (req,res)=>{ const r=db.routes.find(x=>x.id===req.params.id); if(!r) return res.status(404).json({error:'غير موجود'}); Object.assign(r, req.body||{}); saveDb(); res.json({ok:true}); });
app.delete('/api/admin/route/:id', (req,res)=>{ const used=db.buses.some(b=>b.routeId===req.params.id)||db.students.some(s=>s.routeId===req.params.id); if(used) return res.status(400).json({error:'الخط مستخدم'}) ; db.routes=db.routes.filter(x=>x.id!==req.params.id); saveDb(); res.json({ok:true}); });

/* ---- الطلاب (تضيف الإدارة وتعدّل، والمالك أيضاً) ---- */
function studentOut(s){ const route=db.routes.find(r=>r.id===s.routeId); return Object.assign({}, s, {routeName:route?route.name:null}); }
app.get('/api/admin/students', (req,res)=>{ const q=req.query; let list=db.students.slice(); if(q.routeId) list=list.filter(s=>s.routeId===q.routeId); if(q.q) list=list.filter(s=>String(s.universityId).includes(q.q)||String(s.name).includes(q.q)); res.json(list.map(studentOut)); });
app.post('/api/admin/student', (req,res)=>{
  const s=req.body||{}; if(!s.universityId&&!s.name) return res.status(400).json({error:'بيانات الطالب ناقصة'});
  if(db.students.some(x=>x.universityId===s.universityId)) return res.status(400).json({error:'الرقم الجامعي مكرر'});
  var autoBus = s.busId || (db.buses.find(function(b){return b.routeId===s.routeId&&b.active;})||{}).id || null;
  const sp=s.password&&String(s.password).trim() ? String(s.password).trim() : randomPassword(8);
  const st={id:'stu-'+crypto.randomBytes(3).toString('hex'), universityId:s.universityId, name:s.name||('طالب '+s.universityId),
            routeId:s.routeId||null, stopIdx:(+s.stopIdx!=null&&s.stopIdx!==''?+s.stopIdx:0)||0, busId:autoBus,
            password:sp, passChanged:false};
  db.students.push(st); saveDb(); res.json({ok:true, id:st.id, password:st.password});
});
app.put('/api/admin/student/:id', (req,res)=>{ const s=db.students.find(x=>x.id===req.params.id); if(!s) return res.status(404).json({error:'غير موجود'}); Object.assign(s, req.body||{}); saveDb(); res.json({ok:true}); });
app.delete('/api/admin/student/:id', (req,res)=>{ db.students=db.students.filter(x=>x.id!==req.params.id); saveDb(); res.json({ok:true}); });
// استيراد جماعي (بالتكرار)
app.post('/api/admin/students/import', (req,res)=>{
  const rows=req.body.students||[]; if(!rows.length) return res.status(400).json({error:'لا صفوف'});
  let added=0, dup=0, bad=0, pw={};
  rows.forEach(function(s){
    if(!s.universityId){ bad++; return; }
    if(db.students.some(x=>x.universityId===s.universityId)){ dup++; return; }
    var p=s.password&&String(s.password).trim()?String(s.password).trim():randomPassword(8);
    pw[String(s.universityId)]=p;
    db.students.push({id:'stu-'+crypto.randomBytes(3).toString('hex'), universityId:String(s.universityId).trim(), name:String(s.name||'').trim()||('طالب '+s.universityId),
                      routeId:s.routeId||null, stopIdx:(s.stopIdx!=null?+s.stopIdx:0)||0, busId:s.busId||(db.buses.find(function(b){return b.routeId===s.routeId&&b.active;})||{}).id||null, password:p, passChanged:false});
    added++;
  });
  saveDb(); res.json({ok:true, added:added, duplicate:dup, bad:bad, total:db.students.length, passwords:pw});
});

/* ---- حسابات إدارة الجامعة (المالك فقط) ---- */
const requireOwner = requireRole('admin');  // للتجاوز نتحقق فعلياً
function isOwner(req){ const s=auth(req); return s && s.role==='owner'; }
app.get('/api/admin/admins', (req,res)=>{ if(!isOwner(req)) return res.status(403).json({error:'للمالك فقط'}); res.json({admins:db.admins, ownerUser:db.owner.username}); });
app.post('/api/admin/admin', (req,res)=>{ if(!isOwner(req)) return res.status(403).json({error:'للمالك فقط'}); const a=req.body||{}; if(!a.username||!a.password) return res.status(400).json({error:'بيانات ناقصة'}); const id='adm-'+crypto.randomBytes(3).toString('hex'); db.admins.push({id:id, username:a.username, password:a.password, name:a.name||'إدارة'}); saveDb(); res.json({ok:true, id:id}); });
app.put('/api/admin/admin/:id', (req,res)=>{ if(!isOwner(req)) return res.status(403).json({error:'للمالك فقط'}); const a=db.admins.find(x=>x.id===req.params.id); if(!a) return res.status(404).json({error:'غير موجود'}); Object.assign(a, req.body||{}); saveDb(); res.json({ok:true}); });
app.delete('/api/admin/admin/:id', (req,res)=>{ if(!isOwner(req)) return res.status(403).json({error:'للمالك فقط'}); db.admins=db.admins.filter(x=>x.id!==req.params.id); saveDb(); res.json({ok:true}); });

/* ---- الإعدادات + إعادة الضبط (المالك فقط) ---- */
app.put('/api/admin/settings', (req,res)=>{ if(!isOwner(req)) return res.status(403).json({error:'للمالك فقط'}); Object.assign(db.settings, req.body||{}); saveDb(); res.json({ok:true}); });
app.put('/api/admin/password', (req,res)=>{ if(!isOwner(req)) return res.status(403).json({error:'للمالك فقط'}); if(!req.body.password||String(req.body.password).length<4) return res.status(400).json({error:'قصيرة'}); db.owner.password=req.body.password; saveDb(); res.json({ok:true}); });
app.post('/api/admin/seed', (req,res)=>{ if(!isOwner(req)) return res.status(403).json({error:'للمالك فقط'}); db=JSON.parse(JSON.stringify(DEFAULTS)); RT={}; saveDb(); res.json({ok:true}); });

/* ------------------------- الثابت + التشغيل ------------------------- */
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req,res)=> res.sendFile(path.join(__dirname, 'public', 'index.html')));

(function prune(){ Object.keys(passLog).forEach(k=>{ if(k<todayStr()) delete passLog[k]; }); saveLog(); })();

app.listen(PORT, '0.0.0.0', ()=> console.log('منظومة النقل الذكي (الإنتاج) تعمل على http://localhost:'+PORT));
