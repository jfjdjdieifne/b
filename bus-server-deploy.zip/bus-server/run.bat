@echo off
REM تشغيل المنظومة على ويندوز
cd /d "%~dp0"
if not exist node_modules\express ( echo تثبيت المتطلبات... & call npm install )
echo تشغيل المنظومة على http://localhost:3000
node server.js
pause
