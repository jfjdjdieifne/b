"""Module 6.2A-4 V1 Stage 4A: Shared Per-Bar Market-State Trajectory.

Factual shared market-state layer on top of CLOSED Stage 1/2/3.

Supported domains (V1):
- Dynamic Volatility (CLOSED 1.1)
- Session Context (CLOSED 1.2)
- Volume Delta / Order Flow in OHLCV_PROXY mode (CLOSED 3.1)
- Absorption / Response in OHLCV_PROXY mode (CLOSED 3.2)

NOT supported in Stage 4A V1:
- ACTUAL_AGGRESSOR order flow
- ACTUAL absorption

Reason: the CLOSED MarketObservationTimeline does not seal buy_volume/sell_volume, and no
authoritative external source-availability contract exists for aggressor data. Stage 4A must not
invent factual-available-at semantics for external aggressor data. Requesting ACTUAL mode is
rejected explicitly (NOT_SUPPORTED_BY_STAGE4A_V1_SOURCE_CONTRACT); no fallback to PROXY is performed.

Architecture:
- Domain surfaces are SHARED per exact DOMAIN SURFACE IDENTITY (timeline identity + CLOSED contract
  version + exact configuration binding + exact reconstruction-input binding + upstream surface
  identity where applicable + complete public-result hash), NOT merely per timeline.
- Surfaces are computed once, independently of hypothesis identity. A hypothesis projection is a
  compact prefix binding (surface reference + immutable prefix identity through a boundary), never a
  physical duplicate of the surface rows.
- All identities are DETERMINISTIC RECONSTRUCTION / DERIVATION WITNESSES, NOT historical
  generating-input provenance.

Information time: all supported domains are completed-bar / timestamp-only causal; no future rows,
no centered rolling, no shift(-1), no full-future fitting.

RESEARCH-DEBT-020/021/022/023/024/025 remain OPEN.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final, Optional, Tuple

import pandas as pd

from trading_system.research.hashing import canonical_sha256
from trading_system.research.information_time import (
    InformationKey,
    InformationPhase,
    PositionalTimelineAdapter,
    TimeIndexedTimelineAdapter,
)
from trading_system.research.trajectory.trajectory_contract import (
    MarketObservationTimeline,
    TIMELINE_ADAPTER_KIND,
    TrajectoryContractError,
    TrajectoryDataError,
)

# CLOSED engines consumed (LIVE Layer 1 / Layer 3 public APIs)
from trading_system.environment.dynamic_volatility import DynamicVolatilityEngine
from trading_system.environment.session_context import (
    CausalSessionContextEngine,
    SessionDefinition,
)
from trading_system.orderflow.volume_delta import (
    CausalVolumeDeltaEngine,
    OrderFlowMode,
    VolumeDeltaError,
)
from trading_system.orderflow.absorption import (
    AbsorptionError,
    CausalAbsorptionEvidenceEngine,
)
from trading_system.environment.session_context import SessionContextError
from trading_system.environment.dynamic_volatility import DynamicVolatilityError

TimelineAdapter = PositionalTimelineAdapter | TimeIndexedTimelineAdapter

TRAJECTORY_STAGE4A_CONTRACT_VERSION: Final = "CAUSAL_SHARED_PER_BAR_MARKET_STATE_TRAJECTORY_V1"

VOLATILITY_CONTRACT_VERSION: Final = "MODULE_1_1_V1_1"
SESSION_CONTRACT_VERSION: Final = "MODULE_1_2_V1"
ORDER_FLOW_CONTRACT_VERSION: Final = "MODULE_3_1_V1_1"
ABSORPTION_CONTRACT_VERSION: Final = "MODULE_3_2_V1_1"

_ORDER_FLOW_PROXY_DOMAIN: Final = "ORDER_FLOW_PROXY"
_ABSORPTION_PROXY_DOMAIN: Final = "ABSORPTION_PROXY"
_VOLATILITY_DOMAIN: Final = "VOLATILITY"
_SESSION_DOMAIN: Final = "SESSION"

_ACTUAL_NOT_SUPPORTED: Final = (
    "ACTUAL_AGGRESSOR is NOT_SUPPORTED_BY_STAGE4A_V1_SOURCE_CONTRACT: the CLOSED "
    "MarketObservationTimeline does not seal buy_volume/sell_volume and no authoritative "
    "external source-availability contract has been established; no fallback to OHLCV_PROXY "
    "is performed."
)


# ---------------------------------------------------------------------------
# Shared surface identity types
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Stage4ADomainSurface:
    """A shared per-bar market-state domain surface, computed once per surface identity.

    The `surface` frame holds the CLOSED engine's full output (input columns + derived columns);
    `output_columns` lists the derived factual columns whose complete content is bound by
    `public_result_hash`. This is deterministic reconstruction identity only.
    """

    domain: str
    contract_version: str
    timeline_id: str
    timeline_hash: str
    configuration_binding_hash: str
    reconstruction_input_hash: str
    upstream_surface_hash: Optional[str]  # ABSORPTION_PROXY only
    public_result_hash: str
    surface_id: str
    output_columns: Tuple[str, ...]
    surface: pd.DataFrame  # full shared surface, computed once


@dataclass(frozen=True)
class Stage4APrefixBinding:
    """Compact hypothesis projection: a reference to a shared surface + an immutable prefix
    identity through an information boundary. Contains NO physical surface rows.
    """

    domain: str
    surface_id: str
    boundary_position: int
    boundary_key: InformationKey
    prefix_hash: str
    prefix_row_count: int


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _new_columns(result: pd.DataFrame, input_frame: pd.DataFrame) -> Tuple[str, ...]:
    existing = set(input_frame.columns)
    return tuple(c for c in result.columns if c not in existing)


def _surface_public_result_hash(output_frame: pd.DataFrame) -> str:
    try:
        return canonical_sha256(
            domain="STAGE4A_PUBLIC_RESULT_EQUIVALENCE_V1", payload=output_frame
        )
    except Exception as exc:
        raise TrajectoryDataError(f"Stage 4A public result hash failed: {exc}") from exc


def _surface_identity_hash(payload: dict) -> str:
    try:
        return canonical_sha256(domain="STAGE4A_DOMAIN_SURFACE_IDENTITY_V1", payload=payload)
    except Exception as exc:
        raise TrajectoryDataError(f"Stage 4A surface identity hash failed: {exc}") from exc


def _prefix_hash(output_frame_prefix: pd.DataFrame) -> str:
    try:
        return canonical_sha256(domain="STAGE4A_PREFIX_IDENTITY_V1", payload=output_frame_prefix)
    except Exception as exc:
        raise TrajectoryDataError(f"Stage 4A prefix hash failed: {exc}") from exc


def _session_config_payload(sessions: Tuple[SessionDefinition, ...]) -> list:
    return [
        {
            "name": s.name,
            "timezone": s.timezone,
            "start_local": s.start_local.isoformat(),
            "end_local": s.end_local.isoformat(),
        }
        for s in sessions
    ]


def _config_binding_hash(domain: str, payload: dict) -> str:
    try:
        return canonical_sha256(
            domain=f"STAGE4A_{domain}_CONFIG_BINDING_V1", payload=payload
        )
    except Exception as exc:
        raise TrajectoryDataError(f"{domain} config binding hash failed: {exc}") from exc


def _reconstruction_input_hash(payload: dict) -> str:
    try:
        return canonical_sha256(
            domain="STAGE4A_RECONSTRUCTION_INPUT_BINDING_V1", payload=payload
        )
    except Exception as exc:
        raise TrajectoryDataError(f"Stage 4A reconstruction input hash failed: {exc}") from exc


def _require_proxy_mode(mode: OrderFlowMode) -> None:
    if not isinstance(mode, OrderFlowMode):
        raise TrajectoryContractError("mode must be an OrderFlowMode")
    if mode is OrderFlowMode.ACTUAL_AGGRESSOR:
        raise TrajectoryDataError(_ACTUAL_NOT_SUPPORTED)


# ---------------------------------------------------------------------------
# Builders — shared surfaces
# ---------------------------------------------------------------------------

def build_volatility_surface(
    *,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    high_col: str = "high",
    low_col: str = "low",
    close_col: str = "close",
) -> Stage4ADomainSurface:
    """Build the shared volatility domain surface from CLOSED DynamicVolatilityEngine."""
    timeline.verify(adapter=adapter, market_history=market_history)

    config_payload = {"high_col": high_col, "low_col": low_col, "close_col": close_col}
    configuration_binding_hash = _config_binding_hash(_VOLATILITY_DOMAIN, config_payload)
    reconstruction_input_hash = _reconstruction_input_hash(
        {
            "domain": _VOLATILITY_DOMAIN,
            "contract_version": VOLATILITY_CONTRACT_VERSION,
            "timeline_id": timeline.timeline_id,
            "timeline_hash": timeline.timeline_hash,
            **config_payload,
        }
    )

    try:
        result = DynamicVolatilityEngine().analyze(
            market_history, high_col=high_col, low_col=low_col, close_col=close_col
        )
    except DynamicVolatilityError as exc:
        raise TrajectoryDataError(f"volatility engine rejected input: {exc}") from exc

    output_columns = _new_columns(result, market_history)
    output_frame = result.loc[:, list(output_columns)]
    public_result_hash = _surface_public_result_hash(output_frame)

    surface_id = _surface_identity_hash(
        {
            "domain": _VOLATILITY_DOMAIN,
            "contract_version": VOLATILITY_CONTRACT_VERSION,
            "timeline_id": timeline.timeline_id,
            "timeline_hash": timeline.timeline_hash,
            "configuration_binding_hash": configuration_binding_hash,
            "reconstruction_input_hash": reconstruction_input_hash,
            "upstream_surface_hash": None,
            "public_result_hash": public_result_hash,
        }
    )
    return Stage4ADomainSurface(
        domain=_VOLATILITY_DOMAIN,
        contract_version=VOLATILITY_CONTRACT_VERSION,
        timeline_id=timeline.timeline_id,
        timeline_hash=timeline.timeline_hash,
        configuration_binding_hash=configuration_binding_hash,
        reconstruction_input_hash=reconstruction_input_hash,
        upstream_surface_hash=None,
        public_result_hash=public_result_hash,
        surface_id=surface_id,
        output_columns=output_columns,
        surface=result,
    )


def build_session_surface(
    *,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    sessions: Tuple[SessionDefinition, ...] = (),
) -> Stage4ADomainSurface:
    """Build the shared session domain surface from CLOSED CausalSessionContextEngine.

    Requires a time-indexed (timezone-aware) timeline. An empty session configuration is valid
    only because the CLOSED contract treats it as such (calendar features + zero active count).
    """
    timeline.verify(adapter=adapter, market_history=market_history)
    if timeline.adapter_kind is not TIMELINE_ADAPTER_KIND.TIME_INDEXED:
        raise TrajectoryDataError(
            "session surface requires a time-indexed (timezone-aware) timeline"
        )

    sessions = tuple(sessions)
    config_payload = {"sessions": _session_config_payload(sessions)}
    configuration_binding_hash = _config_binding_hash(_SESSION_DOMAIN, config_payload)
    reconstruction_input_hash = _reconstruction_input_hash(
        {
            "domain": _SESSION_DOMAIN,
            "contract_version": SESSION_CONTRACT_VERSION,
            "timeline_id": timeline.timeline_id,
            "timeline_hash": timeline.timeline_hash,
            **config_payload,
        }
    )

    try:
        engine = CausalSessionContextEngine(sessions)
        result = engine.analyze(market_history)
    except SessionContextError as exc:
        raise TrajectoryDataError(f"session engine rejected input: {exc}") from exc

    output_columns = _new_columns(result, market_history)
    output_frame = result.loc[:, list(output_columns)]
    public_result_hash = _surface_public_result_hash(output_frame)

    surface_id = _surface_identity_hash(
        {
            "domain": _SESSION_DOMAIN,
            "contract_version": SESSION_CONTRACT_VERSION,
            "timeline_id": timeline.timeline_id,
            "timeline_hash": timeline.timeline_hash,
            "configuration_binding_hash": configuration_binding_hash,
            "reconstruction_input_hash": reconstruction_input_hash,
            "upstream_surface_hash": None,
            "public_result_hash": public_result_hash,
        }
    )
    return Stage4ADomainSurface(
        domain=_SESSION_DOMAIN,
        contract_version=SESSION_CONTRACT_VERSION,
        timeline_id=timeline.timeline_id,
        timeline_hash=timeline.timeline_hash,
        configuration_binding_hash=configuration_binding_hash,
        reconstruction_input_hash=reconstruction_input_hash,
        upstream_surface_hash=None,
        public_result_hash=public_result_hash,
        surface_id=surface_id,
        output_columns=output_columns,
        surface=result,
    )


def build_order_flow_proxy_surface(
    *,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    mode: OrderFlowMode = OrderFlowMode.OHLCV_PROXY,
) -> Stage4ADomainSurface:
    """Build the shared order-flow domain surface (OHLCV_PROXY mode only)."""
    _require_proxy_mode(mode)
    timeline.verify(adapter=adapter, market_history=market_history)

    config_payload = {"mode": mode.value}
    configuration_binding_hash = _config_binding_hash(_ORDER_FLOW_PROXY_DOMAIN, config_payload)
    reconstruction_input_hash = _reconstruction_input_hash(
        {
            "domain": _ORDER_FLOW_PROXY_DOMAIN,
            "contract_version": ORDER_FLOW_CONTRACT_VERSION,
            "timeline_id": timeline.timeline_id,
            "timeline_hash": timeline.timeline_hash,
            **config_payload,
        }
    )

    try:
        result = CausalVolumeDeltaEngine(mode=mode).analyze(market_history)
    except VolumeDeltaError as exc:
        raise TrajectoryDataError(f"volume-delta engine rejected input: {exc}") from exc

    output_columns = _new_columns(result, market_history)
    output_frame = result.loc[:, list(output_columns)]
    public_result_hash = _surface_public_result_hash(output_frame)

    surface_id = _surface_identity_hash(
        {
            "domain": _ORDER_FLOW_PROXY_DOMAIN,
            "contract_version": ORDER_FLOW_CONTRACT_VERSION,
            "timeline_id": timeline.timeline_id,
            "timeline_hash": timeline.timeline_hash,
            "configuration_binding_hash": configuration_binding_hash,
            "reconstruction_input_hash": reconstruction_input_hash,
            "upstream_surface_hash": None,
            "public_result_hash": public_result_hash,
        }
    )
    return Stage4ADomainSurface(
        domain=_ORDER_FLOW_PROXY_DOMAIN,
        contract_version=ORDER_FLOW_CONTRACT_VERSION,
        timeline_id=timeline.timeline_id,
        timeline_hash=timeline.timeline_hash,
        configuration_binding_hash=configuration_binding_hash,
        reconstruction_input_hash=reconstruction_input_hash,
        upstream_surface_hash=None,
        public_result_hash=public_result_hash,
        surface_id=surface_id,
        output_columns=output_columns,
        surface=result,
    )


def build_absorption_proxy_surface(
    *,
    timeline: MarketObservationTimeline,
    adapter: TimelineAdapter,
    market_history: pd.DataFrame,
    order_flow_surface: Stage4ADomainSurface,
    mode: OrderFlowMode = OrderFlowMode.OHLCV_PROXY,
) -> Stage4ADomainSurface:
    """Build the shared absorption domain surface (PROXY mode only), bound to the exact
    upstream Stage 4A ORDER_FLOW_PROXY surface identity."""
    _require_proxy_mode(mode)
    if not isinstance(order_flow_surface, Stage4ADomainSurface):
        raise TrajectoryContractError("order_flow_surface must be a Stage4ADomainSurface")
    if order_flow_surface.domain != _ORDER_FLOW_PROXY_DOMAIN:
        raise TrajectoryDataError(
            "absorption requires an upstream ORDER_FLOW_PROXY domain surface"
        )
    if (
        order_flow_surface.timeline_id != timeline.timeline_id
        or order_flow_surface.timeline_hash != timeline.timeline_hash
    ):
        raise TrajectoryDataError("upstream order-flow surface timeline mismatch")
    timeline.verify(adapter=adapter, market_history=market_history)

    config_payload = {"mode": mode.value}
    configuration_binding_hash = _config_binding_hash(_ABSORPTION_PROXY_DOMAIN, config_payload)
    reconstruction_input_hash = _reconstruction_input_hash(
        {
            "domain": _ABSORPTION_PROXY_DOMAIN,
            "contract_version": ABSORPTION_CONTRACT_VERSION,
            "timeline_id": timeline.timeline_id,
            "timeline_hash": timeline.timeline_hash,
            **config_payload,
            "upstream_surface_id": order_flow_surface.surface_id,
        }
    )

    try:
        result = CausalAbsorptionEvidenceEngine(mode=mode).analyze(order_flow_surface.surface)
    except AbsorptionError as exc:
        raise TrajectoryDataError(f"absorption engine rejected input: {exc}") from exc

    output_columns = _new_columns(result, order_flow_surface.surface)
    output_frame = result.loc[:, list(output_columns)]
    public_result_hash = _surface_public_result_hash(output_frame)

    surface_id = _surface_identity_hash(
        {
            "domain": _ABSORPTION_PROXY_DOMAIN,
            "contract_version": ABSORPTION_CONTRACT_VERSION,
            "timeline_id": timeline.timeline_id,
            "timeline_hash": timeline.timeline_hash,
            "configuration_binding_hash": configuration_binding_hash,
            "reconstruction_input_hash": reconstruction_input_hash,
            "upstream_surface_hash": order_flow_surface.surface_id,
            "public_result_hash": public_result_hash,
        }
    )
    return Stage4ADomainSurface(
        domain=_ABSORPTION_PROXY_DOMAIN,
        contract_version=ABSORPTION_CONTRACT_VERSION,
        timeline_id=timeline.timeline_id,
        timeline_hash=timeline.timeline_hash,
        configuration_binding_hash=configuration_binding_hash,
        reconstruction_input_hash=reconstruction_input_hash,
        upstream_surface_hash=order_flow_surface.surface_id,
        public_result_hash=public_result_hash,
        surface_id=surface_id,
        output_columns=output_columns,
        surface=result,
    )


# ---------------------------------------------------------------------------
# Hypothesis projection (compact prefix binding)
# ---------------------------------------------------------------------------

def project_surface_prefix(
    *,
    surface: Stage4ADomainSurface,
    boundary_key: InformationKey,
) -> Stage4APrefixBinding:
    """Project a shared surface through an information boundary.

    Returns a compact prefix binding (reference + immutable prefix identity). No physical surface
    rows are copied. The boundary key must belong to the surface's timeline and be within range.
    """
    if not isinstance(surface, Stage4ADomainSurface):
        raise TrajectoryContractError("surface must be a Stage4ADomainSurface")
    if not isinstance(boundary_key, InformationKey):
        raise TrajectoryContractError("boundary_key must be an InformationKey")
    if boundary_key.timeline_id != surface.timeline_id:
        raise TrajectoryDataError("boundary_key timeline mismatch with surface")
    position = boundary_key.bar_position
    n = len(surface.surface)
    if position < 0 or position >= n:
        raise TrajectoryDataError(
            f"boundary position {position} outside surface range [0, {n - 1}]"
        )

    output_frame = surface.surface.loc[:, list(surface.output_columns)]
    prefix_frame = output_frame.iloc[: position + 1]
    prefix_hash = _prefix_hash(prefix_frame)

    return Stage4APrefixBinding(
        domain=surface.domain,
        surface_id=surface.surface_id,
        boundary_position=position,
        boundary_key=boundary_key,
        prefix_hash=prefix_hash,
        prefix_row_count=position + 1,
    )


def verify_surface_matches_reconstruction(
    supplied: Stage4ADomainSurface,
    authoritative: Stage4ADomainSurface,
) -> None:
    """Reject when the supplied surface is not deterministically equivalent to the authoritative
    reconstruction (complete public-result hashes must match)."""
    if supplied.surface_id != authoritative.surface_id:
        raise TrajectoryDataError(
            "Stage 4A surface mismatch: supplied surface identity differs from reconstruction"
        )
    if supplied.public_result_hash != authoritative.public_result_hash:
        raise TrajectoryDataError(
            "Stage 4A public result mismatch: supplied vs reconstructed complete public result"
        )


# ---------------------------------------------------------------------------
# Manifest
# ---------------------------------------------------------------------------

def trajectory_stage4a_manifest() -> pd.DataFrame:
    rows = [
        ("CONTRACT", "VERSION", TRAJECTORY_STAGE4A_CONTRACT_VERSION),
        ("SURFACE", "ARCHITECTURE", "SHARED_PER_EXACT_DOMAIN_SURFACE_IDENTITY_NOT_PER_TIMELINE"),
        ("SURFACE", "IDENTITY", "DETERMINISTIC_RECONSTRUCTION_DERIVATION_WITNESS_NOT_HISTORICAL_PROVENANCE"),
        ("DOMAIN", "VOLATILITY", "SUPPORTED_CLOSED_1_1"),
        ("DOMAIN", "SESSION", "SUPPORTED_CLOSED_1_2"),
        ("DOMAIN", "ORDER_FLOW_PROXY", "SUPPORTED_CLOSED_3_1_PROXY_ONLY"),
        ("DOMAIN", "ABSORPTION_PROXY", "SUPPORTED_CLOSED_3_2_PROXY_ONLY"),
        ("DOMAIN", "ACTUAL_AGGRESSOR", "NOT_SUPPORTED_BY_STAGE4A_V1_SOURCE_CONTRACT_NO_FALLBACK"),
        ("DOMAIN", "ACTUAL_ABSORPTION", "NOT_SUPPORTED_BY_STAGE4A_V1_SOURCE_CONTRACT_NO_FALLBACK"),
        ("EQUIVALENCE", "PUBLIC_RESULT", "COMPLETE_CLOSED_FACTUAL_OUTPUT_HASHED_PER_DOMAIN"),
        ("PROJECTION", "HYPOTHESIS", "COMPACT_PREFIX_BINDING_NO_ROW_DUPLICATION"),
        ("IDENTITY", "PREFIX", "IMMUTABLE_PREFIX_IDENTITY_THROUGH_BOUNDARY_T"),
        ("INFORMATION_TIME", "DOMAINS", "COMPLETED_BAR_OR_TIMESTAMP_ONLY_NO_FUTURE_NO_CENTERED_ROLLING"),
        ("SOURCE_FIDELITY", "PROXY", "OHLCV_PROXY_IS_PROXY_NEVER_ACTUAL"),
        ("OUT_OF_SCOPE", "STAGE4B", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "STAGE4C", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "DESCRIPTORS", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "ESTIMANDS", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "MODEL", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "GEOMETRY", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "EXECUTION", "NOT_IMPLEMENTED"),
        ("OUT_OF_SCOPE", "WIN_LOSS", "FORBIDDEN"),
        ("DEBT", "RESEARCH-DEBT-020", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-021", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-022", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-023", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-024", "OPEN"),
        ("DEBT", "RESEARCH-DEBT-025", "OPEN"),
    ]
    return pd.DataFrame(
        [{"record_type": a, "name": b, "value": c, "serialization_order": i} for i, (a, b, c) in enumerate(rows)]
    )
